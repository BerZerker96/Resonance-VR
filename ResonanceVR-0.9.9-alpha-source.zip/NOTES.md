# Resonance VR - technical notes

Resonance: A Plague Tale Legacy, `Resonance.exe` (PE32+ x64, D3D12, Asobo's Zouna engine), analysed statically:
link date `0x6A7F2BB0`, 63 MB, `.text` 42 MB (not encrypted; a SteamStub `.bind` section wraps the entry point),
game version 1.2.0.0 (Steam). Imports `dxgi.dll` statically - the mod loads as `dxgi.dll` (also `winmm.dll`, or an
`.asi`). Every address below is an RVA of that exe; **the mod hard-codes none of them**: every function is found by a
wildcarded byte pattern and every struct offset is read from the instruction that uses it
(`tools/verify_signatures.py <exe>` prints all of them for any build; `build/game_scan_test.exe <exe>` runs the mod's
own C++ analysis on a mapped image).

## 1. What was verified, and how

| Verified | How |
|---|---|
| Every signature matches exactly once and every offset is read correctly (camera, clock, culling, GUI, render settings, post effects, aspect clamp, focus limiter) | `tools/verify_signatures.py` on the 1.2.0.0 exe: all OK |
| The camera / projection / GUI placement maths (engine conventions, eye pose, frustum, reversed Z, jitter, the right-handed copy for reconstruction, the NanoVG transform) | `tools/zouna_math_test.cpp`: 20 checks, all OK |
| The mod builds (dxgi.dll, winmm.dll, ResonanceVR.asi) | MinGW-w64 13, static OpenXR loader 1.1.43 |
| **Not verified** | Anything in the running game or in a headset. This build has not been run in the game. The first log from a real run is needed: see section 9. |

## 2. Engine conventions

- World: right-handed, **+Y up**, metres (`units_per_metre = 1`). Handles are `{T** ptr, u32 id}`, valid when
  `ptr && (*ptr)+0x1C == id`.
- `Camera_Z` (RTTI `.?AVCamera_Z@@`, a component at camera object +0x120):
  `+0x3A0` near, `+0x3A4/+0x3A8` far, `+0x3D0` vertical FOV (radians), `+0x3D4` roll,
  `+0x3F0` camera->world 4x4, row-vector, rows **right, up, forward, position**, `+0x430` its inverse (the view),
  `+0x470` position, `+0x47C` look direction, `+0x488` look-at target point, `+0x494` up hint.
  The constructor (exe+18EDDB0) sets FOV 0.8727 rad (50 deg), far 10000.
  Setters: SetFov exe+18F0910 (+0x3D0), SetNear exe+18F0920, SetFar exe+18F08F0. The gameplay camera calls them
  every frame from its behaviour (+0x354 / +0x35C) at exe+F7167E.
- The look-at builder exe+185A4B0 (`right = (-fz, 0, fx)/|.|`, `up = forward x right`): checked in the unit test -
  (right, up, -forward) is a right-handed frame, exactly OpenXR's (right, up, back), so a head pose composes onto it
  directly.
- `Viewport_Z` (RTTI `.?AVViewport_Z@@`): `+0x20/+0x24` size, `+0x68/+0x70` camera handle, `+0xA4` tan(vFOV/2),
  `+0xC4/+0xC8/+0xD4/+0xD8` pixel scales, `+0xCC/+0xD0` tan(half FOV) x / y (what culling and LOD read),
  `+0xE0` the projection the getter writes, `+0x120/+0x124` TAA jitter (NDC), `+0x128/+0x12C` zoom,
  `+0x59E0` the frame's view block (view `+0x00`, camera->world `+0x80`, previous frame `+0x40/+0xC0`, camera position
  `+0x450` copied from the camera OBJECT's world matrix, `+0x6D8` camera).
- Projection (exe+18FC5A0), row-vector, left-handed view space (+z forward, w = z), **reversed Z**:
  `[0] = zoom/tanX`, `[5] = zoom/tanY`, `[8]/[9] = jitter`, `[10] = n/(n-f)`, `[11] = 1`, `[14] = n f/(f-n)`.
  An orthographic branch and an external-provider branch (viewport flag bit 0x12) exist; both end in vp+0xE0.

## 3. Hooks

| Hook | Where (1.2.0.0) | Found by | What the mod does |
|---|---|---|---|
| `Viewport_Z::SetupView(vp, bool, bool)` | exe+18F70C0, called once per viewport per frame by the renderer exe+18BCC60 | prologue pattern; view block / camera component / matrices / object world read from its body; the inverse thunk exe+18F09E0 checked byte for byte | main viewport (the renderer's viewport table slot 0, see below): reads the game camera (+0x3F0 - anything other than what the mod wrote = the game's new camera), builds the eye (decoupled pitch, first person, offsets, shake filter, idle-sway lock, head pose), writes +0x3F0; the original inverts it into the view and fills the view block; afterwards the block's camera position is set to the eye's. Frame record into the FIFO for Present. |
| `Viewport_Z::GetProjection(vp, int)` | exe+18FC5A0, 23 callers (culling, shadows, lights, screen-space passes, the view block) | prologue pattern; handle / output / jitter offsets from its body | main viewport, perspective only: x / y terms = the drawn frustum (asymmetric eye or symmetric view), jitter and depth rows kept. Reconstruction keeps a right-handed copy. |
| `Viewport_Z::UpdateFovTangents(vp)` | exe+1901000, 19 callers | prologue pattern; tangent / size offsets from its body | wide culling: +0xCC / +0xD0 = one symmetric frustum covering both eyes of every method |
| `Engine::UpdateFrameTime(engine)` | exe+18E8340 (main loop, once a frame) | prologue pattern; frame-time offsets from its first instructions, pause flag and time scale from its body | synchronized stereo: the second eye's tick keeps 1/32 of its step, the rest is given back on the next tick (game time exact over a pair); pause detection; clock check (game time / real time every 10 s) |
| `Camera_Z` vtable slot 27 (the camera update) | exe+18F0A00 | RTTI vtable, slot recognised by its first instructions (not by its index) | head aim (pattern A: the aiming camera turned to the head, taken back out for the picture); "did the GAME move its camera" for the flat-screen rules |

The main viewport (0.3). The renderer ([exe+39ADEC0], the `this` of exe+18BCC60 - both callers load it from there)
walks its viewport list (`renderer+0xB08`, next `+0xCF18`) and calls SetupView for each. `Viewport+0x40` is the
viewport's slot: only slot 0 gets the camera update (exe+18EE000) and the FOV tangents in that loop; slots 1..8 copy
blocks (`+0x5320`, `+0x5E70`) from `renderer+0xB20[0]` before their own setup; slot 9 and above are skipped there
(render-to-texture / UI). `renderer+0xB20` is the table of viewports by slot, so `**(renderer+0xB20)` is the player's
view. Found by the loop's SetupView call (`mov rcx,rbx / call / xor r8d,r8d / mov dl,1 / call SetupView / lea r13,
[rbx+59E0] / mov rax,[r12+0B20] / mov rdi,[rax]`, the call target checked) and `mov r14d,[rbx+40] ... cmp r14d,9`.
0.2 picked the main viewport by size (a viewport the back buffer's size scored 1,000,000) - the first in-game log shows
a viewport drawn ~3 times a second chosen on the first frame, the player's view never posed.

Frame latency (0.4). The renderer draws on its own thread ("RenderThreadDraw %d", "Enable Render Thread Jobs"):
SetupView for frame N runs while the render thread still draws N-1, and the Present that follows shows N-1. The frame
FIFO must keep one record back (`aer_frame_delay = 1`); with 0 every picture carried the next frame's camera - the
second in-game log: eyes swapped in alternate eye / synchronized, a hitch in every head turn.

Render size (0.3, 0.4). A viewport's size comes from exe+19005A0: `vp+0x5700` or the display object `[exe+39B07D8]`,
`+0x1D4/+0x1D8` (its render surface; `+0x178/+0x17C` is the saved resolution setting, `+0x190/+0x191` the fullscreen
flags, written by exe+135EF90). The surface follows the game's resolution setting, not the swap chain: with the swap
chain forced to 4440x2722 the game still drew 16:9 (its own projection x 2.343 y 4.165). 0.4: the mod sets the
surface (+0x1D4/+0x1D8) inside the ResizeBuffers / CreateSwapChain call where it forces the swap chain size - the game
releases its targets before that call and makes them again from the surface after it, so the 3D and every target come
out at the headset's size and shape. Only a surface equal to the size the game asked for (or 0) is changed.
`render_resolution = auto` is the default; the player's view is still checked against the back buffer and the forced
size is dropped for the session if a build does not follow. The engine's aspect-ratio factor ([exe+3BE575C], read by
exe+18CF200 in the FOV tangents) is a constant 1.0 - the projection's shape is the viewport's width / height.

Scene depth (0.4): the scene is drawn GPU-driven (ExecuteIndirect) with depth-only passes; they count as depth
candidates (0.3 only took a depth bound together with colour targets and never found one).

HUD in the engine (0.5). The game's HUD is not drawn through NanoVG and not into a layer the D3D12 hooks can split.
Every widget's screen quad comes from exe+2283F30 (widget, float out[8] = 4 corners in canvas pixels, bool storeCache,
bool); parents are nested calls of the same function, the result is copied to the widget's cache (+0x40) before it
returns. The canvas is widget+0x1B8 (read from `mov r12,[rbx+1B8]`); its size comes from exe+2275DC0 / exe+2275D30 =
renderer+0xB20[canvas+0xD4]+0x20/+0x24 (the viewport table: screen pixels). The mod scales the OUTERMOST result about the
eye's UI centre (each widget once, the cache stays the game's) and multiplies the text scale (exe+22CB670, from the
canvas height) by the same factor. Only canvases the size of the main viewport.

Head aim (0.5). The camera update builds +0x3F0 as a look-at from its position (+0x470) to its target (+0x488) - 22
functions read that pair. Head aim turns the target to position + head direction x the same distance; the game's
own target goes back before the next camera update.

Data written (not hooked):

| What | Where | Found by | Why |
|---|---|---|---|
| Picture-shape clamp min / max | exe+386BDF8 / exe+386BDFC, set to 1.6 .. 2.33 by the script command `CapAspectRatio` (exe+1350F60; `UncapAspectRatio` exe+1350FE0 sets 1.6 .. 3.56) and applied by exe+18CF3A0 | the handler's bytes (the same pattern the community 32:9 patcher uses) | a VR eye is ~0.9 wide per 1 high: with the clamp the eye is letterboxed. `no_black_bars` keeps it at 0.2 .. 8 in VR and sets the renderer's re-layout byte ([exe+39ADEC0]+0x10D0, from the handler's own call) |
| Out-of-focus frame limiter | [exe+39ADEC0]+0x116A8 bit 63 ("Enable out of focus frame limiter"), read in the frame clock at exe+18E85A5 | the frame clock's body | in VR the headset software has the focus: the game would cap itself. `run_in_background` clears the bit, puts the game's back when off |
| Depth of field | exe+1CA7570 (this, view, params = view data +0x940): `xorps xmm0 / comiss xmm0,[r8+0xC] / setb` - blur on when params+0xC > 0, else the function frees its targets and returns | `4C 8B F9 0F 57 C0 41 0F 2F 40 0C 0F 92 85 ...`, function start found backwards (`48 89 54 24 ?? 55 53 56 57`) | `depth_of_field`: params+0xC = 0 for that call (cutscenes / off), the game's value back after |
| Camera node | Camera_Z update exe+18F0A00 (cam, node): position = [node+0x148]+0x30, without a look-at object the target = pos + rotate(node+0x50 quaternion x y z w, +X) | `48 8B 82 48 01 00 00 4C 8D 81 ...` | head aim turns the node's quaternion and its world rotation rows (checked: the node's +X is the camera's forward) |
| Culling frustum | exe+18F9B40 (vp, cam+0x140, -, near, far, [cam+0x3A4]), called inside UpdateFovTangents exe+1901000 after the near / far loads; reads vp+0xCC / +0xD0 | the call after `F3 0F 11 44 24 ?? E8` in the tangent update, target checked `48 8B C4 48 89 70 ?? 48 89 78 ?? 55` | wide culling: the tangents covering every eye written before it runs |
| Intro logos | exe+136A2F2: `test al,al / jz` after `HasCommandLineArg("-FastLaunch")` (exe+18E8C40), the branch that sets the script variable `SKIP_LOGOS` | the code shape `xor r8d,r8d / lea rdx,"-FastLaunch" / lea rcx / call / test al,al / jz / lea rdx,"SKIP_LOGOS"`, both strings compared | `skip_intro`: `B0 01 90 90` (mov al,1) - the game's own skip; the original bytes back when off |
| Post-effect switches | [exe+39B0838] + 0x4A4 + preset (+0x4A0) x 0x14C: +0xC4 fringe, +0xC5 lens distortion, +0xC6 dirt, +0xC7 lens flare, +0xC8 film grain, +0xC9 vignette | the renderer's config read (exe+18BCCC8), the byte offsets from the game's own settings dump (`movzx r8d, byte [r14+off]` before each `"\t\t<Name> %d\n"`) | lens effects that do not fit a stereo picture; off / the game's own value back |

Engine UI (ui.cpp):

| What | Where (1.2.0.0) | Found by | What the mod does |
|---|---|---|---|
| `GUI::GuiRendererNanoVG` BeginFrame (**never used by the game** - its factory exe+251A330 has no caller and no pointer to it exists; the hook stays for other builds, the D3D12 hooks place the UI) | vtable slot 4 = exe+251A120: sets the target, then `nvgBeginFrame(ctx = renderer+8, w = target+0x20, h = target+0x24, dpr)` | RTTI vtable, the slot that calls nvgBeginFrame (pattern); context / size offsets from its body | after it: `nvgTranslate(ctx, cx - W/2 s, cy - H/2 s)`, `nvgScale(ctx, s, s)` - the whole GUI frame (widgets, text, scissors) on the eye's line of sight at ui_scale, converged at ui_depth; the same placement as the D3D12 path (UiPlacement), which then stands aside. Full-screen GUI only (target = back buffer); render-to-texture GUI untouched. `hide_hud`: the frame is translated off the picture (VR frames only). |
| nvgBeginFrame / nvgTranslate / nvgScale | exe+20561F0 / exe+205CC10 / exe+2059D40; NanoVG context: `+0x2500` nstates, state stride 0x124, xform at state+0x1C | patterns; nstates checked equal in all three | called, never patched. No transform reset exists in the GUI path after BeginFrame (only relative transforms and save / restore pairs) - checked statically. |

Render settings (read only) - the same object as the post effects (`[exe+39B0838]`), offsets from the game's settings
dump: `+0x3F8` anti-aliasing (5 FXAA, 6 DLAA, 7 TAA, 8 DLSS, 9 DLSS RR, 10 FSR, 11 PSSR, else off), `+0x460` DLSS mode,
`+0x464` FSR mode, `+0x468` frame generation (1 DLSS-G, 2 FSR-FG), `+0x488` primary scaling. The renderer reads them
through accessors, so the mod does not write them: the setup check reports frame generation (a problem) and a temporal
AA in synchronized / alternate eye; the panel's status line shows DLSS / FSR.

Camera ownership: the Camera_Z is shared by the game's logic and its renderer. After `SetupView` has copied the eye
into the view block, the Camera_Z gets back what it held before (`keep_game_camera`, default on) - the game's camera
behaviours, movement and audio never see the head pose, so nothing can accumulate. Head aim's turn (made in the camera
update) is what is given back, so the aim still follows the head. Other viewports drawing from the main camera are
counted in the log (reflections would show the game camera).

Read only: the gameplay FOV load (exe+F7167E) - patched there by an external FOV patcher -> setup check.

## 4. Coordinate conversion

`zouna_math.h`: engine 16 floats (right, up, forward, position) <-> the mod's 12 (right, up, back, position);
the rigid inverse; the projection's x / y terms (`P8 = -(r+l)/(r-l) + jitter`, the sign of a left-handed view);
the right-handed copy for reconstruction (third row negated, `[11] = -1`). All covered by the unit test.

## 5. The 3D methods on this engine

- **Stereo reconstruction (default)**: the head-centre view is drawn every frame (symmetric covering frustum); both
  eyes are rebuilt from colour + depth (the framework's recon.cpp: forward splat, resolve, UI split). 0.8: the 0.6.84 infill
  pipeline (`src/recon_shaders2.h`): remembered real pixels, matched tiles, PatchMatch on a half map, a membrane, ring, steady
  infill, finish; plus the shared forward pass for both eyes, boundary cleaning, the tile gradient seam, the YCoCg clip of remembered pixels, the headset-size view and the shading rate around both eyes (0.8.1). 0.9: the performance path - eye-size drawn view (`CameraUpdate` shrinks the centre view's monoTan by `recon_eye_cover`; `ResolutionFollowView` takes the render growth from it), edge fill in `res2` (`EdgeFill`), 35-offset tiles with a held candidate per eye (`g_heldTile`), `Membrane`, the history's `pc.w x dist` test with `SharpFill`, the finish blend band with a 20-cell apron, `Edge` / `Edge2` constants (the constant buffer is 784 bytes: keep `ByteWidth` equal to `sizeof(Cb2)`), counters at byte offsets 0 .. 12 (picture, gap, remembered, UI), 16 / 20 (depth halves) and 24 (fill that kept last frame's fill); `fov_effects` is a second pair of rate images (sets 2 and 3 of `g_img`). 0.9.1: `res2` writes the eye image through u6 (`MemOffOut`, bound to `g_result`) and the blend input (u1) only when `gsNear` (`Edge2.x` = band-only on); `finish` then writes band pixels only. Sharpening is `recon::BlitSharpen` in the compositor's blit (`q.z` = step cap). Fill history: `g_fillCurE[eye]` / `g_fillPrev[eye]`. A second HLSL source, so a compile failure there only falls back to the older two-pass infill (`kHlsl`).
  The game's TAA / DLSS / FSR see the same view every frame - no eye mixing.
- **Synchronized**: the clock hold above; pairs submitted together; alternates when the clock is paused (menus with
  3D, photo mode) or no twin comes for 4 frames; the pair check measures motion amounts (never an exact compare).
- **Alternate eye**, **head-tracked mono**, **flat screen**: as in the framework.

`symmetric_view` defaults to **on** for this engine: the engine builds projections from the FOV tangents in more
places than the getter (any of them would disagree with an off-centre eye). Off = each eye's own frustum (fewer
pixels), culling still covered (`wide_cull`).

## 6. Flat screen

Paused = the game's own "game halted" flag ([exe+39ADEF8]+0x10, read by the frame clock) or a frame time of 0, with
the game camera still for 0.3 s (photo mode moves its camera and stays 3D). Judged on the GAME's camera (the camera
update hook), never on the mod's posed one. Videos: the game's Movie_Z / WinMovie_Z player (Media Foundation, no
Bink) draws no 3D view, so no VR frame is made and the compositor shows the flat screen by itself.

## 7. First person

No skeleton lookup: the eye goes to the game camera's look-at target (Camera_Z+0x488, written by the camera update
from the followed object or the behaviour's target) plus offsets (right, up along world +Y, forward along the
camera's heading). Suspended when the target is farther than `fp_max_distance`, closer than 5 cm, or behind the
camera. Vertical bob filtered (critically damped), horizontal motion never delayed. The body is not hidden (no
SetVisible found yet) - the forward offset puts the eye in front of the head.

## 8. Left out (and why) - nothing is offered that does nothing

| Framework feature | Here |
|---|---|
| Game AA / upscaling switches | read only (section 3): the renderer reads them through accessors - changing them belongs to the game's menu. Reported by the setup check and the status line. |
| Near clip | the engine keeps its near plane in the camera and in the projection's depth rows; changing one made the lighting disagree in the reference mod. The game's own is used. |
| Launcher skip, registry windowed mode | not present in this game (the swap chain / window side forces the windowed eye size) |
| Temporal SSAO / SSR / DOF switches | they exist as renderer config variables ("Renderer Config/Rendering Features/SSAO/Temporal" ...) built by static initialisers; their value layout was not decoded. Stereo reconstruction is not affected (the same view every frame). |
| Video hooks | not needed (section 6) |
| UI pass probe | the UI layer is classified by the D3D12 hooks (pipeline state, bind order, a confirmed layer kept at any draw count) |
| Hide the body in first person | the game hides meshes through queued script commands (HIDE_MESH) only - not reachable safely; Eye Z puts the eye in front of the head |

## 9. What the first log has to show

1. `game: renderer viewport table +b20` and `camera: main viewport ... (slot 0, ..., the renderer's own main viewport)`;
   `camera: viewports last frame:` - exactly one `MAIN`, slot 0, its size equal to the back buffer's.
   No `resolution: the game draws its 3D at ...` error. `ui: UI layer` found; `recon: scene depth` found.
2. `render settings:` - the game's AA / DLSS / FSR / frame generation as it runs; `camera: game camera given back` > 0.
3. `game:` lines - every hook found, the offsets read (they must equal the table above on 1.2.0.0).
4. `camera: view setups ..., main ..., poses applied ...` - main > 0 and poses applied > 0 once in VR.
5. `camera: the game's own projection x .. y .. -> FOV ..` - the game's FOV (~50 deg vertical); `projections patched` > 0.
6. `blackbars:` - the clamp found and kept open; `focus:` - the limiter found.
7. Reconstruction: `recon:` lines - the depth buffer found and its direction.
8. If head movement goes the wrong way: `camera_axes` (default `+0+1+2`); if the world size is off: `units_per_metre`.

## 10. Community research used

The community "Resonance 32:9 & FOV patcher" (sKuhLight, source on GitHub) patches the same picture-shape clamp
(its `StockCapSignature` is the `CapAspectRatio` handler above) and the gameplay FOV load at exe+F7167E (a
`movss xmm1, [rbx+35Ch]` before `Camera_Z::SetFov`); its renderer refresh is the same +0x10D0 byte. Both confirmed
the static analysis. An external photo-mode tool for this game exists (closed source) - not used.

0.9.3: the depth reaches its shared texture in `recon::PresentDepthCopy` (called from the compositor's `CopyOut`, on the mod's own list) unless the self-check switched back to barrier copies (`g_depthAtPresent`). Counters: byte offsets 28 / 32 count depth samples at exactly 0 / 1. The atlas layout is in `g_r1x / g_r1y / g_hx / g_hy` (compositor). The host publishes `displayRefreshHz` and `hostWake100ns` in `IpcShared` (taken from the reserved words; the layout's size is unchanged). `ResolutionApplyLive` / `ResolutionPreview` (window.cpp) are the one size path for start-up, APPLY and the preview.

