# Resonance VR performance and version / store audit (0.5.0, updated for 0.6.0)

What was checked, against what evidence, and what changed. The evidence is the 0.4.0 in-game log (Pimax Dream Air,
RTX 4080, i9-14900KF, Steam build 1.2.0.0) and the exe itself.

## 1. Performance

### Measured in the 0.4 log (per 10 s, alternate eye, 3420x2668 per eye, ~51 game fps)

| Where | 0.4 | Verdict |
|---|---|---|
| Mod CPU time at Present (average) | 0.5 - 1.2 ms (menu closed: ~0.5 ms) | fine |
| Camera at Present: flat-screen decision / camera read | 0.000 / 0.001 - 0.010 ms | fine |
| Viewport tally at Present | 0.15 - 0.34 ms | **fixed:** each viewport's slot was read with a memory check on every Present; now read once when the viewport is first set up in a frame |
| Memory checks (all threads) | 140 - 160 VirtualQuery, **200 - 390 ms**, ~2.5 ms each | **fixed:** see below |
| Eye copy / reconstruction / blits | 0.10 - 0.18 ms | fine |
| Send to the headset | 0.18 - 0.32 ms | fine |
| Projection getter (main viewport) | ~8 800 calls/s patched | cheap (a few multiplies, no allocation) |
| View setups | ~950/s (19 viewports a frame) | cheap after the slot fix |
| Frame cap | 72 fps (headset), waited in < 15 frames per 10 s | not limiting: the GPU is (game frame 19 - 20 ms) |
| xrhost: late frames | 0 - 9 per 10 s at ~50 game fps | fine; the headset gets a fresh image of the newest frame every refresh |

**Memory checks.** Every pointer the mod follows into the game is checked first (the mod never crashes the game on a
stale pointer). Since 0.6.14 those checks were cached per thread, and only cache misses called `VirtualQuery`. In
this game, with its huge and fragmented address space, a single `VirtualQuery` took ~2.5 ms, and some misses happened
on the game's render-setup thread inside the camera hooks, a stall of a few ms inside a frame. 0.5 replaces it with
a one-byte probe per page through `ReadProcessMemory` on the mod's own process. The kernel copy fails safely on an
unreadable page, costs about a microsecond whatever the address space looks like, and never touches a guard page from
user mode. The cache is now 64 regions per thread, kept 2 s. The log line `memory checks N (X ms in 10 s)` should now
show X well under 1 ms.

### Hooks on hot paths (cost per call)

| Hook | Calls | Work |
|---|---|---|
| Viewport::SetupView | ~950/s | tally (lock, 16-entry scan); main viewport only: pose composition (~100 flops), 2 matrix copies |
| Viewport::GetProjection | ~9 000/s | other viewports: one compare and return; main: 6 stores |
| Viewport::UpdateFovTangents | ~50/s (main) | 2 stores |
| Camera_Z update | ~50/s per camera | head aim on the main camera: one quaternion → matrix, one look-at target write; 0.6: the cutscene test (one distance, one dot product), the node turn (two quaternion products, three row rotations) |
| Culling frustum builder (0.6) | ~50/s (main) + other viewports | main: two compares and two stores before the game's own; others: one compare |
| Depth of field passes (0.6) | once per frame | one compare; when off: one float written and put back |
| GUI widget layout (0.6) | 15 000 - 90 000 / 10 s | adds a stack-range test (two loads from the thread block) before the existing work |
| Engine frame clock | ~50/s | a few floats |
| GUI widget layout (new) | per widget per frame | outermost call only: 8 multiply-adds; canvas size from two engine getters |
| GUI text scale (new) | per text per frame | one multiply |
| D3D12 command-list hooks | per draw / bind | map lookup, counters; the reconstruction depth tally per bind |

No allocation, file or log I/O happens on any game thread per frame; the log is written by its own thread every
10 s.

### What costs frame time that the mod cannot remove

- Alternate eye and synchronized draw one eye per game frame: at ~50 game fps each eye gets ~25 new images a second
  (the log says so: "LOW FPS FOR THIS MODE"). Stereo reconstruction gives both eyes every frame (now that the scene depth
  is found).
- The headset's resolution (3420x2668 per eye on the Dream Air) is the GPU cost. **View > Render scale** below 1, or
  DLSS / DLAA in the game's options, trades sharpness for frame rate. Temporal AA / DLSS mixes the two eyes in alternate
  eye and synchronized (they alternate frame to frame); in stereo reconstruction it is fine.

## 2. Version and store agnostic

### How the mod finds things

- **Every function** by a wildcarded byte pattern that must be unique in the code section; nothing is addressed by a
  fixed RVA (checked: no `exe+` constants in the source).
- **Every struct offset** the camera, projection, viewport, display, GUI, clock, post-effect and render-settings code
  use is **read from the instruction that uses it** in the game's own code. 0.5 closed the last gap in the camera path:
  the camera's FOV / near / far offsets (+0x3D0 / +0x3A0 / +0x3A8) are now read from the FOV-tangent function too.
- **Two strings check one patch** (intro logos: `-FastLaunch` and `SKIP_LOGOS` must be what the code points at).
- **Class tables** by RTTI name (Camera_Z, GuiRendererNanoVG), and their slots by what the code in them does, never by
  index.
- A pattern that is missing or not unique turns **that feature** off, says so in the log, and leaves the game alone.
  The log's first 60 lines list every lookup and the offsets it read.

### Stores

| Store | What differs | Handled |
|---|---|---|
| Steam | SteamStub DRM (`.bind` section): the code is decrypted after the loader runs the mod | the mod retries for up to 2 minutes until the code is readable (`game: code readable after N ms`) |
| Epic | no DRM wrapper; same engine build | found at start |
| Xbox app / Game Pass | the game folder is protected unless installed with *Advanced management features*; a GDK build may differ in code layout | the README says how to make the folder writable; config and logs fall back to `%LOCALAPPDATA%\ResonanceVR` when the folder is read-only; patterns are wildcarded over registers and offsets |
| Any | another mod named `dxgi.dll` | the mod chains `dxgi_chain.dll`; `winmm.dll` / `.asi` builds as alternatives |

The mod checks the process name (`Resonance*.exe`) and does nothing inside any other program (the launcher, crash
reporters).

### Checked on the Steam exe 1.2.0.0 (link date 0x6A7F32B0)

`tools/verify_signatures.py <Resonance.exe>` prints OK / MISSING / AMBIGUOUS for all 35 patterns and in-function lookups, and every offset read.
All OK. Run it on any other build (Epic, Xbox, a future patch) to see what the mod will find there before playing.

### Known limits

- No other build was available here (Epic / Xbox / later patches): their patterns are expected to hold (they cover
  instruction shapes, not addresses) but are unverified. The log shows any miss at once.
- The GUI renderer the game ships with NanoVG is unused (no factory call); the engine HUD path is the widget layout
  hook. The NanoVG hook stays installed for a build that uses it and costs nothing otherwise.


## 0.7.1 audit

- Source scan: no `exe+0x...` constant is used as an address (only in comments); `GetFileVersion` / link date are logged, never
  compared. Steam, Epic, GOG and Game Pass differ only in the PC settings block address, found by signature.
- `tools/verify_signatures.py`: all 38 signatures unique on the 1.2.0.0 exe, struct offsets read from code.
- Widget layout (UI): quad units are canvas-height units; the quad is scaled about the eye's UI centre, which is placed from the
  real eye distance and the eye's frustum so both eyes meet at `ui_depth` (checked by `zouna_math_test`). A quad the game
  hands back from its layout cache is restored before it is scaled again, so nothing compounds.
- Rendering: the engine draws through GPU-driven paths (ExecuteIndirect, mesh shaders); counters for all of them are logged.

## 0.7.2 performance audit

Mod cost at Present in the 0.7.0 log: 0.65 ms average (menu + input 0.28, eyes 0.12, send 0.24, camera < 0.01) against a 13.9 ms
frame at 72 Hz. The rest of the frame time is the game rendering a 3420 x 2668 eye image in alternate eye (35 frames per eye):
the render resolution, foveation (`foveated`) and the upscaler are the settings that move it; the mod's own work does not.

## 0.7.3 audit

The HUD / UI eye mismatch in alternate-eye and synchronized modes came from the layout running on the update thread, ahead of the
render thread that sets the current eye. The layout eye is now predicted from the number of frames the update thread is ahead.
The host now names OpenXR results, reports refused frames, and reconnects after a runtime loss. Reconstruction now runs the framework's
0.6.84 PatchMatch / real-pixel infill (0.8.0); the older two-pass infill stays as the fallback if the new shaders do not compile.
Its HLSL could not be compile-checked in the build environment, so the first in-game log must be read for "recon: shader" errors.

## 0.9.0-alpha audit notes

- Constant buffer size: the second-eye constants of 0.8.1 lay beyond the 672 bytes the buffer was created with. Fixed; the buffer's size is now the structure's, and a static assertion pins the structure at 784 bytes.
- Config migration (version 12) touches only exact old defaults (`recon_view = wide`, `recon_preset = balanced`, `recon_infill_blend = 1.0`); every other value of a player stays.
- Every new option (`recon_eye_cover`, `recon_hud_split`, `fov_effects`) has a tab-table entry and a default in the written config; the log states whether any option lacks one.
- New compute shaders are not compile-checked in the build environment; a compile failure falls back to the older infill and logs the compiler's message.
- No existing function or option was removed; `recon_view` keeps `wide` and `headset`.

## 0.9.1-alpha audit notes

- Second pass over Framework Boost 41 - 50 and Stereo Reconstruction 0 / 32 / 46 item by item; the gaps found are listed in the changelog and implemented.
- Legacy constant structs (`cf`, `cr`) were not zero-initialised; now `= {}`.
- Band-only writes: the eye image is complete after the resolve (u6); the blend pass only rewrites band pixels, so a skipped group can never leave a stale pixel in the eye.
- Forward pass shared memory loads use the same clamped addressing as before: results are bit-identical.

## 0.9.2-alpha audit notes (hitches)

- Hot-path waits checked: shader compile and shader object creation are off the frame (cache + worker threads), the counter / timestamp reads never wait (DO_NOT_WAIT / DONOTFLUSH), the only fence wait is in the swap-chain release. The log was the one blocking call on the render thread; it is now written by its own thread.
- Render resizes: only when the selected method's view size changes, applied after it has held for 1 s; never from a flat pause menu or loading screen.
- `recon_resolve_split` is not added: the framework keeps it only to compare against the slower two-dispatch resolve (measured 0.198 against 0.143 ms per megapixel).

## 0.9.3-alpha audit notes (all chapters)

- Checked item by item: Framework Boost 1 - 16 (resolution chain, atlas, host, logging, performance items, testing, lessons, VR resolution, steady infill, depth direction, upscalers, pacing), 21 - 50 and the port checklist / appendix log lines; Stereo Reconstruction 0, 32, 46, 47.
- Implemented in this version: see the changelog. Remaining, and why: the per-pass log is already split; "in-game assertions logged once" is followed where branches exist (warn-once lines); OpenXR simulator tests and multi-runtime runs need hardware.
- Source-wide scan for code swallowed by comments (the 0.6.96 lesson): one found and fixed in the host.

## 0.9.9-alpha audit notes (issue by issue)

- HUD fusing: both placement paths (`UiPlacementForSetup`, `UiCentreForEye`) keep the HUD at infinity with a symmetric view and
  `ui_converge` off; the frustum is rebuilt when `symmetric_view` changes.
- Edge fill: border in alternate eye, synchronized, reconstruction (rebuilt eye and centre eye), and now head mode; HDR-correct.
  Screen mode and the flat menu slot have no headset view to fill.
- Reconstruction: eye-size view grown to the headset's density, band-only writes, depth copied once at Present, 10-bit eye image.
- Hitches: rate-image rebuilds on head turns removed (head-relative eye axis); first panel open prewarmed; config save and log writes off
  the Present thread.
- Version agnostic: signatures by byte pattern, every executable section scanned as fallback, COMPAT line, `safe_mode`.

