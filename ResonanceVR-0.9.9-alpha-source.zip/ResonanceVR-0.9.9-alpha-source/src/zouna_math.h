#pragma once
// Matrix conventions of the Zouna engine and the conversions the camera code uses (header only, portable: the unit test
// tools/zouna_math_test.cpp builds it natively).
//   Engine camera->world (Camera_Z+0x3F0): 4x4 row-vector, rows right, up, FORWARD, position (w 0, 0, 0, 1).
//   Engine view (Camera_Z+0x430): its inverse; view space x right, y up, z forward (left-handed), metres.
//   Engine projection: [0] = 2/(r-l), [5] = 2/(u-d), [8] = -(r+l)/(r-l) + jitter x, [9] = -(u+d)/(u-d) + jitter y,
//                      [10] = n/(n-f), [11] = 1 (w = z), [14] = n f/(f-n): reversed Z (near 1, far 0).
//   The mod's frames (vrmath.h Frame, RenderedEye.node*): 12 floats right, up, BACK, position - OpenXR's convention.
#include <cstring>

namespace zm {

inline void EngToT(const float* M, float* T) {
    for (int i = 0; i < 3; i++) { T[i] = M[i]; T[3 + i] = M[4 + i]; T[6 + i] = -M[8 + i]; T[9 + i] = M[12 + i]; }
}
inline void TToEng(const float* T, float* M) {
    for (int i = 0; i < 3; i++) { M[i] = T[i]; M[4 + i] = T[3 + i]; M[8 + i] = -T[6 + i]; M[12 + i] = T[9 + i]; }
    M[3] = M[7] = M[11] = 0.f; M[15] = 1.f;
}
// row-vector inverse of a rigid camera->world
inline void RigidInverse(const float* M, float* V) {
    for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) V[r * 4 + c] = M[c * 4 + r];
    V[3] = V[7] = V[11] = 0.f;
    for (int c = 0; c < 3; c++) V[12 + c] = -(M[12] * M[c * 4] + M[13] * M[c * 4 + 1] + M[14] * M[c * 4 + 2]);
    V[15] = 1.f;
}
// x / y terms of an engine projection for the frustum t = (l, r, u, d tangents), jitter kept
inline bool ProjXY(float* P, const float* t, float jx, float jy) {
    float w = t[1] - t[0], h = t[2] - t[3];
    if (!(w > 0.05f && h > 0.05f)) return false;
    P[0] = 2.f / w; P[5] = 2.f / h;
    P[8] = jx - (t[1] + t[0]) / w;
    P[9] = jy - (t[2] + t[3]) / h;
    P[1] = P[4] = 0.f;
    return true;
}
// the same projection for a right-handed view (z = -forward), as the reconstruction code expects ([11] = -1)
inline void ProjToRH(const float* P, float* Q) { memcpy(Q, P, 64); for (int i = 8; i < 12; i++) Q[i] = -Q[i]; }

// the NanoVG placement of a W x H GUI frame: translate (tx, ty) then scale s puts the frame's centre at (cx, cy)
// (x' = s x + tx, NanoVG premultiplies: the later scale applies first)
inline void NvgPlace(float W, float H, float cx, float cy, float s, float& tx, float& ty) { tx = cx - 0.5f * W * s; ty = cy - 0.5f * H * s; }

} // namespace zm
