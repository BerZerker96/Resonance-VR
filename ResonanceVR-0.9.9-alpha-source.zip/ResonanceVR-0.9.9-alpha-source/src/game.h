#pragma once
// Resonance: A Plague Tale Legacy (Resonance.exe, Asobo's Zouna engine, D3D12, x64).
// Everything is located by byte pattern at run time and every struct offset the mod uses is READ FROM THE CODE that
// uses it (tools/verify_signatures.py prints them for any exe). A build where a pattern does not match turns that
// feature off instead of crashing. RVAs in comments are of the exe this was written against (link date 0x6A7F2BB0,
// game version 1.2.0.0, Steam).
//
// Engine facts (NOTES.md has the full reverse-engineering report):
//   World: right-handed, +Y up, metres. Handles {T** ptr, u32 id}: valid when ptr && (*ptr)+0x1C id == the handle's id.
//   Viewport_Z (RTTI .?AVViewport_Z@@): +0x20/+0x24 render width / height (ints), +0x68/+0x70 handle of the camera
//     OBJECT, whose Camera_Z component is object+0x120. +0xCC / +0xD0 tan(half FOV) x / y, +0xE0 the 4x4 projection
//     the getter writes, +0x120 / +0x124 TAA jitter (NDC), +0x59E0 the frame's view block (view, camera world,
//     previous frame, camera position at +0x450 ...).
//   Camera_Z (RTTI .?AVCamera_Z@@): +0x3A0 near, +0x3A8 far, +0x3D0 vertical FOV (rad), +0x3F0 camera->world 4x4
//     (rows right, up, FORWARD, position; row-vector), +0x430 its inverse (the view matrix), +0x470 position,
//     +0x47C look direction, +0x488 look-at target point (the followed character for gameplay cameras).
//   Projection (row-vector, left-handed view space +z forward, w = z, reversed Z):
//     [0] = 1/tanX, [5] = 1/tanY, [8] / [9] = off-centre + jitter, [10] = n/(n-f), [11] = 1, [14] = n f/(f-n).

#include <windows.h>
#include <cstdint>
#include "upscale.h"

namespace game {

extern uintptr_t g_base;
extern size_t g_size;

bool Init(bool quiet = false);      // false: code not readable yet - call again later
bool InitAt(uintptr_t base, bool quiet);   // the same on an image mapped elsewhere (offline test)
bool InCode(uintptr_t a);
bool Readable(const void* p, size_t n);
double ReadableStatsMs();   // ms spent in VirtualQuery since the last call
void ReadableStats(long long& calls, long long& hits);
uintptr_t VtableByRtti(const char* typeName);
uintptr_t Scan(const char* name, const char* pattern);   // unique byte pattern in the main code section, 0 = none / ambiguous

// --- the render camera (camera.cpp) -----------------------------------------------------------------------------
// exe+18F70C0 Viewport_Z::SetupView(vp, bool, bool): once per viewport per frame on the render-setup thread. Inverts
// camera+0x3F0 into +0x430 and copies both, the camera position and the projection into the view block.
// exe+18FC5A0 Viewport_Z::GetProjection(vp, int) -> float* (vp+0xE0): every consumer (culling, lights, shadows,
// screen-space passes, the view block) gets the projection here - 23 call sites.
// exe+1901000 Viewport_Z::UpdateFovTangents(vp): tan(half FOV) from the camera's vertical FOV and the viewport shape.
// The culling and LOD work with those symmetric tangents.
// exe+18F0A00 Camera_Z vtable slot 27: the game camera's update (position, look direction, target -> +0x3F0).
extern void* g_viewSetup;
extern void* g_getProj;
extern void* g_fovTangents;
extern void* g_dofPass;            // exe+1CA7570 the depth of field passes (this, view, params): run only when params+0xC > 0
extern void* g_cullBuild;          // exe+18F9B40 BuildCullFrustum(vp, frustum, -, near, far, far2): from vp tangents +0xCC/+0xD0
extern void* g_camUpdate;          // Camera_Z::Update (head aim / first person target)
extern uintptr_t kVpCam, kVpCamId, kVpW, kVpH, kVpTanX, kVpTanY, kVpProj, kVpJitter, kVpBlock, kBlockPos;
extern uintptr_t kCamComp, kCamWorld, kCamView, kObjWorld, kCamPos, kCamTarget, kCamNear, kCamFar, kCamFov;
void* CameraOfViewport(void* vp);   // the Camera_Z of a viewport, nullptr = none
void* CamObjectOfViewport(void* vp);
// the renderer's viewport table (exe+18BCC60): slot +0x40, 0 = the player's view; MainViewport = table[0]
extern uintptr_t kVpIndex, kRendVpTable;
int ViewportSlot(void* vp);   // -1 = unknown
void* MainViewport();         // nullptr = not known (yet)
// the intro logos (exe+136A2DC, the game's own -FastLaunch switch): forced on = logos skipped at start
// the display's render surface ([exe+39B07D8]+0x1D4/+0x1D8): the size the game makes its 3D and targets at
bool DisplaySurface(unsigned& w, unsigned& h);
bool DisplaySetSurface(unsigned fromW, unsigned fromH, unsigned toW, unsigned toH);
// the GUI's widget layout (HUD scale, ui.cpp)
typedef unsigned(__fastcall* PFN_GuiDim)(void* canvas);
typedef void*(__fastcall* PFN_GuiObj)(void* widget);
extern void* g_guiWidgetCalc;      // void(widget, float out[8], bool storeCache, bool)
extern void* g_guiTextScale;       // float(widget)
extern PFN_GuiDim g_guiCanvasW, g_guiCanvasH;
extern PFN_GuiObj g_guiCanvasOf;   // the text scale's canvas of a widget
extern uintptr_t kGuiCanvas;
bool SkipIntroFound();
void SkipIntro(bool on);

// --- game clock (synchronized stereo) ---------------------------------------------------------------------------
// exe+18E8340 Engine::UpdateFrameTime(engine): once a frame on the main thread. engine+0x25C0 scaled frame time
// (float s, what the simulation steps with), +0x25C4 unscaled, +0x2F0 time scale (slow motion), the game time
// accumulates +0x25C0 at the start of the NEXT call. [exe+39ADEF8]+0x10 = "game halted" (pause) flag.
extern void* g_frameTime;
extern uintptr_t kDt, kDtRaw, kTimeScale;
extern uintptr_t g_pauseGlobal; extern uintptr_t kPauseFlag;
bool GameHalted();                  // the game's own pause (pause menu, game over screen ...)

// --- black bars ------------------------------------------------------------------------------------------------
// The renderer clamps the picture's shape to [min, max] (exe+386BDF8 / exe+386BDFC, set to 1.6 .. 2.33 by the
// script command CapAspectRatio exe+1350F60) and letterboxes outside it. A VR eye is ~0.9 wide per 1 high: the mod
// keeps the clamp open (no_black_bars) and asks the renderer to re-layout ([renderer]+0x10D0 = 1).
bool AspectCapFound();
void AspectCapKeepOpen(bool on);    // Present thread, cheap; logs once when the game asked for a cap

// --- out-of-focus frame limiter: [renderer]+0x116A8 bit 63 = "Enable out of focus frame limiter" (read by the
// frame clock exe+18E85A5): while the game window has no focus - always, in VR (the headset software has it) - the
// game caps itself to a low frame rate. run_in_background clears the bit; off puts the game's own value back.
bool FocusLimiterFound();
void RunInBackground(bool on);

// --- post effects (render config [exe+39B0838] + 0x4A4 + preset * 0x14C, bytes found from the settings dump) ----
enum PostFx { PFX_FRINGE = 0, PFX_LENSDIST, PFX_DIRT, PFX_LENSFLARE, PFX_GRAIN, PFX_VIGNETTE, PFX_COUNT };
bool PostFxFound(int fx);
const char* PostFxName(int fx);
void PostFxSet(int fx, int want);   // -1 the game's own, 0 off (restores the game's value when it goes back to -1)

// --- the GUI (NanoVG, RTTI .?AVGuiRendererNanoVG@GUI@@): vtable slot "BeginFrame(renderer, target)" calls
// nvgBeginFrame(ctx, w, h, dpr) (exe+20561F0); nvgTranslate exe+205CC10, nvgScale exe+2059D40 premultiply the current
// state's 2D transform. ui.cpp places the whole UI per eye with them, inside the engine (text stays sharp).
extern void* g_guiBeginFrame;          // the renderer's BeginFrame (hooked)
extern uintptr_t kGuiCtx, kGuiTgtW, kGuiTgtH;   // renderer+ctx, target width / height (ints)
typedef void(__fastcall* PFN_NvgXY)(void* ctx, float x, float y);
extern PFN_NvgXY g_nvgTranslate, g_nvgScale;

// --- render settings (the same object as the post effects, [exe+39B0838]): read only - the setup check and the
// panel's status line. aa: 5 FXAA, 6 DLAA, 7 TAA, 8 DLSS, 9 DLSS RR, 10 FSR, 11 PSSR, other = off;
// fg: 0 none, 1 DLSS frame generation, 2 FSR frame generation
struct RenderSettings { bool known = false; int aa = 0, dlss = 0, fsr = 0, fg = 0; float scale = 1.f; };
RenderSettings RenderSettingsRead();
const char* AaName(int aa);
inline bool AaTemporal(int aa) { return aa >= 6 && aa <= 11; }

extern bool g_otherModPatchedGame;  // another mod patched / hooked game code the mod reads (setup check)
extern volatile unsigned char* g_taaFlag;   // not found in this engine (kept for the shared compositor code: nullptr)
upscale::Settings RenderUpscale();  // not read from this game: known = false (the compositor measures the scene size)

void CompatReport();   // 0.9.3: one line - signatures found / features off (version agnostic)
} // namespace game
