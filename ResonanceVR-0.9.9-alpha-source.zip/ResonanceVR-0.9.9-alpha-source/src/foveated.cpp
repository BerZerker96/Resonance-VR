// Fixed foveated rendering on D3D12 (variable rate shading tier 2: shading-rate images; any GPU that has it - NVIDIA
// RTX 20 and newer, AMD RX 6000 and newer, Intel Arc). DXMDVR's version was NVIDIA-only (NVAPI on D3D11).
// Every pass that renders into an eye-size target (the scene, G-buffer, lighting, post effects) gets a shading-rate
// image: full rate around the current eye's lens centre (its optical axis in the asymmetric frustum), lower rates in
// two outer rings. The final image (back buffer and what the game copies into it), so the UI, is never affected.
// One image per eye + one for head mode; rebuilt when the eye size, the frustum or the settings change.
#include "modtime.h"
#include "d3d.h"
#include <cmath>
#include <vector>
#include "log.h"
#include "camera.h"
#include "settings.h"

// D3D12 VRS declarations (not in the mingw-w64 headers). Values / layout from Microsoft's d3d12.h.
static const D3D12_FEATURE kFeatureOptions6 = (D3D12_FEATURE)30;
struct Options6 { BOOL AdditionalShadingRatesSupported; BOOL PerPrimitiveShadingRateSupportedWithViewportIndexing;
                  int VariableShadingRateTier; UINT ShadingRateImageTileSize; BOOL BackgroundProcessingSupported; };
enum : int { RATE_1X1 = 0, RATE_1X2 = 0x1, RATE_2X1 = 0x4, RATE_2X2 = 0x5, RATE_2X4 = 0x6, RATE_4X2 = 0x9, RATE_4X4 = 0xA };
enum : int { COMBINER_PASSTHROUGH = 0, COMBINER_OVERRIDE = 1 };
static const D3D12_RESOURCE_STATES kStateShadingRateSource = (D3D12_RESOURCE_STATES)0x1000000;
static const GUID kIID_List5 = { 0x55050859, 0x4024, 0x474c, { 0x87, 0xf5, 0x64, 0x72, 0xea, 0xee, 0x44, 0xea } };
// ID3D12GraphicsCommandList5 vtable: 77 RSSetShadingRate(base, const combiners[2]), 78 RSSetShadingRateImage(resource)
typedef void(STDMETHODCALLTYPE* PFN_RSSetShadingRate)(void*, int, const int*);
typedef void(STDMETHODCALLTYPE* PFN_RSSetShadingRateImage)(void*, ID3D12Resource*);

// the 3D scene's own size when it is below the eye size (d3d12hooks measures it from the scene depth), else 0
extern volatile unsigned g_sceneW, g_sceneH;

namespace fov {

static int g_tier = -1;                 // -1 not checked, 0 none, 1, 2
static UINT g_tile = 16;
static bool g_moreRates = false;        // 2x4 / 4x2 / 4x4
// 0.6.35: two sets - [0] the eye's size, [1] the 3D scene's own smaller size (DLSS / FSR / resolution scale draw the
// scene below the eye size: those passes never got the foveation - the tester's log: "passes with reduced shading 0")
static ID3D12Resource* g_img[4][3] = {};   // per set: left, right, mono. [2] / [3]: the same sizes for full-screen passes without a depth target (fov_effects: the lens edge only)
static UINT g_setW[2] = {}, g_setH[2] = {};
static float g_key[24] = {};
static volatile bool g_ready = false;
static unsigned g_applied = 0, g_cleared = 0;

bool Supported() {
    if (g_tier >= 0) return g_tier >= 2;
    g_tier = 0;
    if (!g_dev12) return false;
    Options6 o6 = {};
    if (SUCCEEDED(g_dev12->CheckFeatureSupport(kFeatureOptions6, &o6, sizeof o6))) {
        g_tier = (int)o6.VariableShadingRateTier;
        g_tile = o6.ShadingRateImageTileSize ? o6.ShadingRateImageTileSize : 16;
        g_moreRates = o6.AdditionalShadingRatesSupported != 0;
    }
    LOGI("foveated: variable rate shading tier %d, tile %u px%s", g_tier, g_tile, g_moreRates ? ", 4x4 rates" : "");
    return g_tier >= 2;
}

// resources the GPU may still read (frames in flight) are released a few seconds later
struct Dead { ID3D12Resource* r; ULONGLONG t; };
static std::vector<Dead> g_dead;
static void Retire(ID3D12Resource*& r) { if (r) { g_dead.push_back({ r, ModTick64() }); r = nullptr; } }
static void FlushDead() {
    for (size_t i = 0; i < g_dead.size();) if (ModTick64() - g_dead[i].t > 3000) { g_dead[i].r->Release(); g_dead.erase(g_dead.begin() + i); } else i++;
}
static void Release() {
    g_ready = false;
    for (auto& s : g_img) for (auto*& r : s) Retire(r);
}

// 0.8 (framework 0.6.82): stereo reconstruction's Performance preset shades the one wide centre view at a lower rate away from BOTH
// eyes' lens axes while the player has not turned foveated rendering on (fov_mode off): full rate inside 0.65 half-heights of the nearer axis,
// 2 x 1 to 1.05, 2 x 2 beyond (horizontal x 1.25). The player's own fov_mode is never changed.
static bool ReconAuto() {
    return g_set.fovReconAuto && g_set.fovMode == "off" && g_set.reconPreset == "performance" && g_cam.mode == VRMODE_RECON && g_cam.reconCentre;
}
static bool ReconCentre() { return g_cam.mode == VRMODE_RECON && g_cam.reconCentre; }
// each eye's lens axis as tangents in the head-centre view: the eye's rotation against the head applied to (0, 0, -1)
static bool AxisTan(int e, float& tx, float& ty) {
    // 0.9.9: the eye's rotation RELATIVE TO THE HEAD (the two eyes' mean). The pose is in the room: 0.9.0 - 0.9.7 took the head's own
    // turning as the eye's axis, so the key moved with every head movement and the rate images were rebuilt whenever you looked around
    // (the 0.9.7 log: "key 19 changed" every 33 ms). A canted headset gives a fixed relative rotation; the Dream Air none.
    const xrb::IpcPose& q = g_cam.pose[e & 1];
    const xrb::IpcPose& o = g_cam.pose[(e & 1) ^ 1];
    if (!(q.qx != 0 || q.qy != 0 || q.qz != 0 || q.qw != 0)) return false;
    float ox = o.qx, oy = o.qy, oz = o.qz, ow = o.qw;
    if (ox * q.qx + oy * q.qy + oz * q.qz + ow * q.qw < 0.f) { ox = -ox; oy = -oy; oz = -oz; ow = -ow; }   // same hemisphere
    float hx = q.qx + ox, hy = q.qy + oy, hz = q.qz + oz, hw = q.qw + ow, hn = sqrtf(hx * hx + hy * hy + hz * hz + hw * hw);
    if (hn < 1e-6f) return false;
    hx /= hn; hy /= hn; hz /= hn; hw /= hn;
    // relative = conj(head) * eye
    float w = hw * q.qw + hx * q.qx + hy * q.qy + hz * q.qz;
    float x = hw * q.qx - hx * q.qw - hy * q.qz + hz * q.qy;
    float y = hw * q.qy + hx * q.qz - hy * q.qw - hz * q.qx;
    float z = hw * q.qz - hx * q.qy + hy * q.qx - hz * q.qw;
    float n = sqrtf(x * x + y * y + z * z + w * w);
    if (n < 1e-6f) return false;
    x /= n; y /= n; z /= n; w /= n;
    float c2x = 2.f * (x * z + w * y), c2y = 2.f * (y * z - w * x), c2z = 1.f - 2.f * (x * x + y * y);   // the rotation's third column (the eye's back axis)
    if (c2z < 0.05f) return false;   // more than ~87 degrees off the head's own direction
    tx = -c2x / c2z; ty = -c2y / c2z;
    return true;
}

struct Params { float inner, outer, wide; int mid, outerR; };
static Params Get() {
    const std::string& m = g_set.fovMode;
    Params p = { g_set.fovInner, g_set.fovOuter, g_set.fovWide, RATE_2X1, RATE_2X2 };
    if (m == "off" && ReconAuto()) p = { 0.65f, 1.05f, 1.25f, RATE_2X1, RATE_2X2 };
    else if (m == "quality") p = { 0.65f, 1.05f, 1.25f, RATE_2X1, RATE_2X2 };
    else if (m == "balanced") p = { 0.5f, 0.85f, 1.25f, RATE_2X2, g_moreRates ? RATE_4X2 : RATE_2X2 };
    else if (m == "performance") p = { 0.38f, 0.65f, 1.25f, RATE_2X2, g_moreRates ? RATE_4X4 : RATE_2X2 };
    if (g_set.fovDebug) p.outerR = g_moreRates ? RATE_4X4 : RATE_2X2;
    if (p.outer < p.inner) p.outer = p.inner;
    return p;
}

// one image: rates by the distance from the lens centre (cx, cy in tiles), in half image heights, wider horizontally
// cx2 >= 0: a second lens centre (the centre view covers both eyes): a tile takes the distance to the NEARER one
static void Fill(std::vector<unsigned char>& d, UINT tw, UINT th, float cx, float cy, const Params& p, float cx2 = -1e9f, float cy2 = 0.f) {
    float hh = th * 0.5f;
    for (UINT y = 0; y < th; y++) for (UINT x = 0; x < tw; x++) {
        float dx = (x + 0.5f - cx) / (hh * p.wide), dy = (y + 0.5f - cy) / hh, r = sqrtf(dx * dx + dy * dy);
        if (cx2 > -1e8f) { float ex = (x + 0.5f - cx2) / (hh * p.wide), ey = (y + 0.5f - cy2) / hh; r = fminf(r, sqrtf(ex * ex + ey * ey)); }
        d[y * tw + x] = (unsigned char)(r < p.inner ? RATE_1X1 : r < p.outer ? p.mid : p.outerR);
    }
}

// (re)build the images for this eye size and frustum, recorded on the compositor's list. Always a NEW set: lists the
// game recorded earlier (maybe still waiting to run on another thread) keep the old images in their state. The new
// set is used from Commit() on (after the compositor's list was submitted), the old one retired.
static ID3D12Resource* g_next[4][3] = {};
static UINT g_nextW[2] = {}, g_nextH[2] = {};
static bool g_haveNext = false;
static float g_nextKey[24] = {};
void Prepare(ID3D12GraphicsCommandList* list, UINT w, UINT h) {
    FlushDead();
    const bool autoOn = ReconAuto();
    if ((g_set.fovMode == "off" && !autoOn) || !Supported() || !w || !h) { if (g_ready) Release(); return; }
    if (g_haveNext) return;
    Params p = Get();
    UINT iw = g_sceneW, ih = g_sceneH;
    if (!(iw >= 256 && ih >= 256 && iw < w && ih <= h)) iw = ih = 0;
    float key[24] = { (float)w, (float)h, p.inner, p.outer, p.wide, (float)p.mid, (float)p.outerR };
    for (int e = 0; e < 2; e++) for (int k = 0; k < 4; k++) key[7 + e * 4 + k] = CameraDrawTan(e)[k];
    key[15] = g_cam.monoTan[0]; key[16] = (float)iw; key[17] = (float)ih;
    key[18] = ReconCentre() ? 1.f : 0.f;
    { float tx, ty; for (int e = 0; e < 2; e++) if (AxisTan(e, tx, ty)) { key[19 + e * 2] = tx; key[20 + e * 2] = ty; } }   // the axes (19 .. 22)
    key[23] = g_set.fovEffects == "outer" ? 1.f : 0.f;   // 0.9.1: switching fov_effects rebuilds the images
    // 0.9.4: rounded to 1/500 - the eyes' axes come from the live eye poses, whose last digits change every frame: the 0.9.3 log rebuilt
    // all the rate images every second (134 rebuilds in 2 minutes, a hitch each time). A real change (FOV, cant, size) is far larger.
    // 0.9.6: compared with a tolerance (0.01 - a hundredth of a tangent, far below one 16 px tile at the lens edge), not rounded: a value
    // sitting on a rounding step still flipped and the 0.9.5 log rebuilt every image every second in reconstruction
    if (g_ready) {
        bool same = true;
        for (int k = 0; k < 24 && same; k++) if (fabsf(key[k] - g_key[k]) > 0.01f * fmaxf(1.f, fabsf(g_key[k]))) same = false;
        if (same) return;
        static int s_told = 0;
        if (s_told < 6) { for (int k = 0; k < 24; k++) if (fabsf(key[k] - g_key[k]) > 0.01f * fmaxf(1.f, fabsf(g_key[k]))) { s_told++;
            LOGI("foveated: rebuilt because key %d changed %.4f -> %.4f", k, g_key[k], key[k]); break; } }
    }
    static ULONGLONG last = 0;
    if (g_ready && ModTick64() - last < 1000) return;   // at most one rebuild a second (a setting being dragged)
    last = ModTick64();
    for (int set = 0; set < 4; set++) {
    const int sz = set & 1; const bool fx = set >= 2;   // fx: the 0.9 second image, for full-screen passes (fov_effects)
    if (fx && g_set.fovEffects != "outer") continue;
    UINT sw = sz ? iw : w, sh = sz ? ih : h;
    if (!fx) { g_nextW[sz] = sw; g_nextH[sz] = sh; }
    if (!sw || !sh) continue;
    // the full-screen passes' image: full rate out to the outer ring, then 2 x 1, 2 x 2 beyond 1.25 - the lens edge only (bloom, blur and post passes show
    // their softness at the middle at once; the edge is where the headset cannot show it)
    Params pf = p;
    if (fx) { pf.inner = fmaxf(p.outer, 0.9f); pf.outer = fmaxf(pf.inner + 0.25f, 1.25f); pf.mid = RATE_2X1; pf.outerR = RATE_2X2; }
    const Params& pp = fx ? pf : p;
    UINT tw = (sw + g_tile - 1) / g_tile, th = (sh + g_tile - 1) / g_tile, pitch = (tw + 255) & ~255u;
    D3D12_HEAP_PROPERTIES hp = {}; hp.Type = D3D12_HEAP_TYPE_DEFAULT;
    D3D12_RESOURCE_DESC rd = {}; rd.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D; rd.Width = tw; rd.Height = th; rd.DepthOrArraySize = 1;
    rd.MipLevels = 1; rd.Format = DXGI_FORMAT_R8_UINT; rd.SampleDesc.Count = 1;
    D3D12_HEAP_PROPERTIES uh = {}; uh.Type = D3D12_HEAP_TYPE_UPLOAD;
    D3D12_RESOURCE_DESC bd = {}; bd.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER; bd.Width = pitch * th; bd.Height = 1; bd.DepthOrArraySize = 1;
    bd.MipLevels = 1; bd.SampleDesc.Count = 1; bd.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
    std::vector<unsigned char> d(tw * th);
    for (int i = 0; i < 3; i++) {
        ID3D12Resource* up = nullptr;
        if (FAILED(g_dev12->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_COPY_DEST, nullptr, __uuidof(ID3D12Resource), (void**)&g_next[set][i])) ||
            FAILED(g_dev12->CreateCommittedResource(&uh, D3D12_HEAP_FLAG_NONE, &bd, D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, __uuidof(ID3D12Resource), (void**)&up))) {
            LOGE("foveated: rate image failed"); for (auto& s : g_next) for (auto*& r : s) Retire(r); if (up) up->Release(); return;
        }
        const float* t = i < 2 ? CameraDrawTan(i) : g_cam.monoTan;
        float cx = (t[1] - t[0]) > 0.05f ? -t[0] / (t[1] - t[0]) * tw : tw * 0.5f;   // lens centre = tangent 0
        float cy = (t[2] - t[3]) > 0.05f ? t[2] / (t[2] - t[3]) * th : th * 0.5f;
        float ax[2], ay[2]; bool both = i == 2 && ReconCentre() && AxisTan(0, ax[0], ay[0]) && AxisTan(1, ax[1], ay[1]) && (t[1] - t[0]) > 0.05f && (t[2] - t[3]) > 0.05f;
        if (both) {   // the centre view of stereo reconstruction: the rate follows the nearer of the two eyes' axes
            float c0x = (ax[0] - t[0]) / (t[1] - t[0]) * tw, c0y = (t[2] - ay[0]) / (t[2] - t[3]) * th;
            float c1x = (ax[1] - t[0]) / (t[1] - t[0]) * tw, c1y = (t[2] - ay[1]) / (t[2] - t[3]) * th;
            Fill(d, tw, th, c0x, c0y, pp, c1x, c1y);
        } else Fill(d, tw, th, cx, cy, pp);
        unsigned char* m = nullptr; D3D12_RANGE rr = { 0, 0 };
        if (SUCCEEDED(up->Map(0, &rr, (void**)&m))) { for (UINT y = 0; y < th; y++) memcpy(m + y * pitch, &d[y * tw], tw); up->Unmap(0, nullptr); }
        D3D12_TEXTURE_COPY_LOCATION dst = {}, src = {};
        dst.pResource = g_next[set][i]; dst.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
        src.pResource = up; src.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
        src.PlacedFootprint.Footprint.Format = DXGI_FORMAT_R8_UINT; src.PlacedFootprint.Footprint.Width = tw;
        src.PlacedFootprint.Footprint.Height = th; src.PlacedFootprint.Footprint.Depth = 1; src.PlacedFootprint.Footprint.RowPitch = pitch;
        list->CopyTextureRegion(&dst, 0, 0, 0, &src, nullptr);
        D3D12_RESOURCE_BARRIER b = {}; b.Transition.pResource = g_next[set][i]; b.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        b.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST; b.Transition.StateAfter = kStateShadingRateSource;
        list->ResourceBarrier(1, &b);
        Retire(up);   // released after the copy has long run
    }
    LOGI("foveated: %s, rings %.2f / %.2f, %ux%u tiles of %u px%s%s", autoOn ? "automatic around both eyes (reconstruction, Performance)" : g_set.fovMode.c_str(), pp.inner, pp.outer, tw, th, g_tile,
         sz ? " - for the 3D scene drawn below the eye size (upscaler / resolution scale)" : "", fx ? " - full-screen passes without a depth target (fov_effects: lens edge)" : "");
    }
    memcpy(g_nextKey, key, sizeof key);
    g_haveNext = true;
}
// the compositor's list (with the copies into the new images) was submitted
void Commit() {
    if (!g_haveNext) return;
    for (int s = 0; s < 4; s++) {
        for (int i = 0; i < 3; i++) { Retire(g_img[s][i]); g_img[s][i] = g_next[s][i]; g_next[s][i] = nullptr; }
        if (s < 2) { g_setW[s] = g_nextW[s]; g_setH[s] = g_nextH[s]; }
    }
    memcpy(g_key, g_nextKey, sizeof g_key);
    g_haveNext = false; g_ready = true;
}

// command list hook: an eye-size render target that is not the final image was just bound (or something else was)
// tw / th: the bound target's size - the set whose size it is (the eye's, or the 3D scene's own smaller size)
void OnBind(ID3D12GraphicsCommandList* l, void*& list5, bool& on, bool eyeTarget, UINT tw, UINT th, bool effects) {
    int set = -1;
    if (eyeTarget) for (int s = 0; s < 2; s++) if (g_setW[s] && tw == g_setW[s] && th == g_setH[s] && g_img[s][0]) { set = s; break; }
    if (set >= 0 && effects) { if (g_img[set + 2][0]) set += 2; else set = -1; }   // a pass without a depth target: the lens-edge image (none: unchanged)
    bool want = set >= 0 && g_ready && CameraFrameIsVR();
    if (!want && !on) return;
    if (!list5) {
        IUnknown* l5 = nullptr;
        if (FAILED(l->QueryInterface(kIID_List5, (void**)&l5)) || !l5) { list5 = (void*)1; return; }
        l5->Release(); list5 = l5;   // the same object as the list; the pointer stays valid while it lives
    }
    if (list5 == (void*)1) return;
    void** vt = *(void***)list5;
    auto setRate = (PFN_RSSetShadingRate)vt[77];
    auto setImage = (PFN_RSSetShadingRateImage)vt[78];
    if (want) {
        int fe = 0; bool fm = false; CameraRecordingEye(fe, fm);   // 0.6.33: the eye of the frame being recorded
        int i = fm || g_cam.mode == VRMODE_HEAD ? 2 : fe;
        int c[2] = { COMBINER_PASSTHROUGH, COMBINER_OVERRIDE };
        setRate(list5, RATE_1X1, c);
        setImage(list5, g_img[set][i]);
        on = true; g_applied++;
    } else {
        setImage(list5, nullptr);
        setRate(list5, RATE_1X1, nullptr);
        on = false; g_cleared++;
    }
}

void Report() {
    if (g_set.fovMode != "off" || g_ready) LOGI("foveated: %s - passes with reduced shading %u, switched back %u", g_ready ? "running" : "not running", g_applied, g_cleared);
    g_applied = g_cleared = 0;
}
void OnResize() { Release(); for (auto& s : g_next) for (auto*& r : s) Retire(r); g_haveNext = false; g_setW[0] = g_setW[1] = 0; }

} // namespace fov

void FovPrepare(ID3D12GraphicsCommandList* l, UINT w, UINT h) { fov::Prepare(l, w, h); }
void FovReport() { fov::Report(); }
void FovCommit() { fov::Commit(); }
