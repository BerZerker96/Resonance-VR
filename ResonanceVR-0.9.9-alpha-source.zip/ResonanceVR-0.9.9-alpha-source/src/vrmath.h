#pragma once
// Small 3x3 / pose math for the DXMD camera.
// Engine camera transform (ZCameraEntity +0x50): SMatrix43, rows = local x (right), y (up), z (back) axes in world
// coordinates, then the translation. The camera looks along local -z, the same convention as OpenXR's view space,
// so a head pose in the recentred OpenXR space can be composed straight onto the camera's local frame.
#include <cmath>
#include <cstring>

struct V3 { float x, y, z; };
inline V3 operator+(V3 a, V3 b) { return { a.x + b.x, a.y + b.y, a.z + b.z }; }
inline V3 operator-(V3 a, V3 b) { return { a.x - b.x, a.y - b.y, a.z - b.z }; }
inline V3 operator*(V3 a, float s) { return { a.x * s, a.y * s, a.z * s }; }
inline float Dot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline V3 Cross(V3 a, V3 b) { return { a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x }; }
inline float Len(V3 a) { return sqrtf(Dot(a, a)); }
inline V3 Norm(V3 a) { float l = Len(a); return l > 1e-8f ? a * (1.f / l) : a; }

// camera frame: axis[0] right, axis[1] up, axis[2] back, pos
struct Frame { V3 axis[3]; V3 pos; };

// rotation matrix of a unit quaternion; R[r][c], columns = rotated basis vectors
inline void QuatToMat(float qx, float qy, float qz, float qw, float R[3][3]) {
    R[0][0] = 1 - 2 * (qy * qy + qz * qz); R[0][1] = 2 * (qx * qy - qz * qw); R[0][2] = 2 * (qx * qz + qy * qw);
    R[1][0] = 2 * (qx * qy + qz * qw); R[1][1] = 1 - 2 * (qx * qx + qz * qz); R[1][2] = 2 * (qy * qz - qx * qw);
    R[2][0] = 2 * (qx * qz - qy * qw); R[2][1] = 2 * (qy * qz + qx * qw); R[2][2] = 1 - 2 * (qx * qx + qy * qy);
}

// f expressed in world, then a pose (rotation R, translation t, both in f's local frame): result in world
inline Frame Compose(const Frame& f, const float R[3][3], V3 t) {
    Frame r;
    for (int k = 0; k < 3; k++) r.axis[k] = f.axis[0] * R[0][k] + f.axis[1] * R[1][k] + f.axis[2] * R[2][k];
    r.pos = f.pos + f.axis[0] * t.x + f.axis[1] * t.y + f.axis[2] * t.z;
    return r;
}

inline bool FrameValid(const Frame& f) {
    for (int k = 0; k < 3; k++) {
        float l = Len(f.axis[k]);
        if (!(l > 0.9f && l < 1.1f)) return false;
    }
    if (fabsf(Dot(f.axis[0], f.axis[1])) > 0.1f || fabsf(Dot(f.axis[1], f.axis[2])) > 0.1f) return false;
    float p = fabsf(f.pos.x) + fabsf(f.pos.y) + fabsf(f.pos.z);
    return p == p && p < 1e7f;
}
