#include "modtime.h"
// First person for a third-person game without a first-person camera.
//
// Resonance's gameplay cameras are Camera_Z objects that LOOK AT a target point (camera+0x488, game.h): the
// followed character (Sophia's upper body / head) or a point the camera behaviour places in front of her. The eye is
// put at that point, with offsets of its own (right / up / forward along the camera's heading), turned with the game
// camera (decoupled pitch) and the headset. This needs no skeleton or bone lookup, so it works on every build.
//
// Suspended (the game camera is used) when the camera is not following a character close by: the target farther
// than fp_max_distance from the camera (cutscene / scripted camera), behind the camera, or jumping (a cut). The
// character's body is not hidden - the forward offset (fp_offset_z) moves the eye in front of her head.
#include <windows.h>
#include <cmath>
#include "firstperson.h"
#include "camera.h"
#include "game.h"
#include "log.h"

bool HeadAimCleanTarget(void* cam, float* t);   // camera.cpp
namespace fp {

static bool g_have = false;          // the target offset was found (game.cpp)
static V3 g_target = {}, g_camPos = {}; static bool g_targetOk = false;
static V3 g_smooth = {}; static bool g_smoothHave = false; static long long g_smoothT = 0;
static int g_state = 0;              // 0 off, 1 in the character, 2 waiting (cutscene / no target)
static unsigned g_applied = 0, g_waitFar = 0, g_waitBehind = 0, g_waitNone = 0, g_cuts = 0;

void Install() {
    g_have = game::g_camUpdate != nullptr && game::kCamTarget > 0;
    LOGI("firstperson: %s (eye at the game camera's look-at target +%llx)", g_have ? "available" : "NOT available - the camera update was not found",
         (unsigned long long)game::kCamTarget);
}
bool Available() { return g_have; }
void GameTick() {}

void NoteCamera(void* cam) {
    g_targetOk = false;
    if (!g_have || !cam) return;
    const float* t = (const float*)((char*)cam + game::kCamTarget);
    const float* p = (const float*)((char*)cam + game::kCamPos);
    if (!game::Readable(t, 12) || !game::Readable(p, 12)) return;
    float tc[3];   // camera.cpp: head aim turned the target - the game's own
    if (::HeadAimCleanTarget(cam, tc)) t = tc;
    V3 tv = { t[0], t[1], t[2] }, pv = { p[0], p[1], p[2] };
    float s = fabsf(tv.x) + fabsf(tv.y) + fabsf(tv.z);
    if (!(s == s) || s > 1e7f) return;
    g_target = tv; g_camPos = pv; g_targetOk = true;
}

bool EyeBase(const Frame& cam, const Frame& game, Frame& out) {
    if (!g_cam.firstPerson) { g_state = 0; g_smoothHave = false; return false; }
    if (!g_have || !g_targetOk) { g_state = 2; g_waitNone++; g_smoothHave = false; return false; }
    float u = g_cam.unitsPerMetre;
    V3 d = g_target - game.pos; float dist = Len(d);
    V3 fwdGame = game.axis[2] * -1.f;
    if (dist > g_cam.fpMaxDist * u || dist < 0.05f * u) { g_state = 2; g_waitFar++; g_smoothHave = false; return false; }
    if (Dot(d, fwdGame) < 0.f) { g_state = 2; g_waitBehind++; g_smoothHave = false; return false; }
    // head bob filter: the target's motion relative to its smoothed path, critically damped (time constant <= 0.2 s);
    // a jump of more than 1 m (a cut / teleport) is taken at once
    long long now = (long long)modtime::Now100ns();
    float dt = g_smoothT ? (float)(now - g_smoothT) * 1e-7f : 0.f; g_smoothT = now;
    if (!g_smoothHave || Len(g_target - g_smooth) > 1.f * u || !(dt > 0.f && dt < 0.25f)) { if (g_smoothHave) g_cuts++; g_smooth = g_target; g_smoothHave = true; }
    else if (g_cam.fpSmooth > 0.01f) {
        float a = 1.f - expf(-dt / (0.2f * g_cam.fpSmooth));
        V3 nx = g_smooth + (g_target - g_smooth) * a;
        // only the vertical bob is filtered strongly; walking / turning follow at once (no lag in the direction of travel)
        g_smooth = { g_target.x, nx.y, g_target.z };
    } else g_smooth = g_target;
    out = cam;
    V3 fwd = cam.axis[2] * -1.f;
    V3 flat = Norm(V3{ fwd.x, 0.f, fwd.z });
    if (Len(flat) < 0.5f) flat = fwd;
    out.pos = g_smooth + cam.axis[0] * (g_cam.fpOffset[0] * u) + V3{ 0, 1, 0 } * (g_cam.fpOffset[1] * u) + flat * (g_cam.fpOffset[2] * u);
    g_state = 1; g_applied++;
    return true;
}

void Toggle() {
    g_cam.firstPerson = !g_cam.firstPerson;
    LOGI("firstperson: %s%s", g_cam.firstPerson ? "ON" : "off", g_have ? "" : " (not available on this exe)");
}
const char* Status() {
    if (!g_have) return "not available";
    switch (g_state) {
    case 1: return "at the character";
    case 2: return "waiting (cutscene / no character close by)";
    default: return "off";
    }
}
void Report() {
    if (!g_cam.firstPerson && !g_applied) return;
    LOGI("firstperson: %s - applied %u, waiting: target too far / too close %u, behind the camera %u, no target %u, cuts %u",
         Status(), g_applied, g_waitFar, g_waitBehind, g_waitNone, g_cuts);
    g_applied = g_waitFar = g_waitBehind = g_waitNone = g_cuts = 0;
}

} // namespace fp

void FpReport() { fp::Report(); }
void FpToggleFromMenu() { fp::Toggle(); }
