#pragma once
// key = value config (resonancevr_config.txt next to the mod). Unknown keys are kept; defaults are written on first run.
#include <string>
#include <vector>

void ConfigLoad(const wchar_t* path);
int ConfigInt(const char* key, int def);
float ConfigFloat(const char* key, float def);
std::string ConfigStr(const char* key, const char* def);
bool ConfigBool(const char* key, bool def);
std::vector<std::string> ConfigUnknownKeys(const std::vector<std::string>& known);   // 0.9.3: typos and old keys in the file
