// Screenshots: PNG through the Windows Imaging Component (wincodec, in every Windows since Vista - no extra DLL).
// The Present thread only copies the pixels out; encoding and writing run on a worker thread, so taking a shot never
// costs the headset a frame.
#include <windows.h>
#include <wincodec.h>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include "log.h"

struct ShotJob { std::wstring path; std::vector<uint8_t> bgr; unsigned w, h; };

// 24-bit BGR rows (no alpha: the eye image's alpha is not meaningful and would make the PNG see-through)
bool PngWriteBgr24(const wchar_t* path, const uint8_t* bgr, unsigned w, unsigned h) {
    HRESULT ci = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    bool ok = false;
    IWICImagingFactory* f = nullptr; IWICStream* st = nullptr; IWICBitmapEncoder* enc = nullptr;
    IWICBitmapFrameEncode* fr = nullptr; IPropertyBag2* props = nullptr;
    do {
        if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_IWICImagingFactory, (void**)&f))) break;
        if (FAILED(f->CreateStream(&st)) || FAILED(st->InitializeFromFilename(path, GENERIC_WRITE))) break;
        if (FAILED(f->CreateEncoder(GUID_ContainerFormatPng, nullptr, &enc)) || FAILED(enc->Initialize(st, WICBitmapEncoderNoCache))) break;
        if (FAILED(enc->CreateNewFrame(&fr, &props)) || FAILED(fr->Initialize(props))) break;
        if (FAILED(fr->SetSize(w, h))) break;
        WICPixelFormatGUID pf = GUID_WICPixelFormat24bppBGR;
        if (FAILED(fr->SetPixelFormat(&pf)) || memcmp(&pf, &GUID_WICPixelFormat24bppBGR, sizeof pf)) break;
        UINT stride = w * 3;
        if (FAILED(fr->WritePixels(h, stride, stride * h, (BYTE*)bgr))) break;
        if (FAILED(fr->Commit()) || FAILED(enc->Commit())) break;
        ok = true;
    } while (0);
    if (props) props->Release();
    if (fr) fr->Release();
    if (enc) enc->Release();
    if (st) st->Release();
    if (f) f->Release();
    if (!ok) DeleteFileW(path);   // no half-written file
    if (SUCCEEDED(ci)) CoUninitialize();
    return ok;
}

static DWORD WINAPI ShotThread(LPVOID p) {
    ShotJob* j = (ShotJob*)p;
    DWORD t0 = GetTickCount();
    bool ok = PngWriteBgr24(j->path.c_str(), j->bgr.data(), j->w, j->h);
    if (ok) LOGI("screenshot: %ls saved (%ux%u PNG, %lu ms)", j->path.c_str(), j->w, j->h, (unsigned long)(GetTickCount() - t0));
    else LOGE("screenshot: %ls FAILED (PNG encoder)", j->path.c_str());
    delete j;
    return 0;
}

// rgba: mapped RGBA8 rows (pitch bytes apart); the rectangle (x0, y0, w, h) of it is saved
bool ShotSaveAsync(const std::wstring& path, const uint8_t* rgba, unsigned pitch, unsigned x0, unsigned y0, unsigned w, unsigned h) {
    if (!w || !h) return false;
    ShotJob* j = new ShotJob{ path, {}, w, h };
    j->bgr.resize((size_t)w * h * 3);
    for (unsigned y = 0; y < h; y++) {
        const uint8_t* s = rgba + (size_t)(y0 + y) * pitch + (size_t)x0 * 4;
        uint8_t* d = j->bgr.data() + (size_t)y * w * 3;
        for (unsigned x = 0; x < w; x++, s += 4, d += 3) { d[0] = s[2]; d[1] = s[1]; d[2] = s[0]; }
    }
    HANDLE t = CreateThread(nullptr, 0, ShotThread, j, 0, nullptr);
    if (!t) { delete j; return false; }
    CloseHandle(t);
    return true;
}

// The part of the rendered eye image the headset actually shows: the image covers the frustum `img` (tangents l, r,
// u, d: the headset's FOV widened to the image's aspect and the cull margin, or the shared reconstruction frustum);
// the headset shows `eye`. Pixels are 1:1 (nothing scaled), so the shot is the headset's own view at its resolution.
void ShotCrop(const float img[4], const float eye[4], unsigned W, unsigned H, unsigned& x0, unsigned& y0, unsigned& w, unsigned& h) {
    x0 = 0; y0 = 0; w = W; h = H;
    float iw = img[1] - img[0], ih = img[2] - img[3];
    if (!(iw > 0.01f && ih > 0.01f) || !(eye[1] - eye[0] > 0.01f) || !(eye[2] - eye[3] > 0.01f)) return;
    auto cl = [](float v) { return v < 0.f ? 0.f : v > 1.f ? 1.f : v; };
    float a = cl((eye[0] - img[0]) / iw), b = cl((eye[1] - img[0]) / iw);
    float c = cl((img[2] - eye[2]) / ih), d = cl((img[2] - eye[3]) / ih);   // rows from the top (up tangent)
    unsigned X0 = (unsigned)(a * W + 0.5f), X1 = (unsigned)(b * W + 0.5f), Y0 = (unsigned)(c * H + 0.5f), Y1 = (unsigned)(d * H + 0.5f);
    if (X1 <= X0 + 16 || Y1 <= Y0 + 16) return;
    x0 = X0; y0 = Y0; w = X1 - X0; h = Y1 - Y0;
}
