#include "modtime.h"
// Camera: head / eye pose and the headset frustum on Resonance's render camera (Zouna engine).
//
// Where: Viewport_Z::SetupView (game.h), once per viewport per frame. It inverts the Camera_Z's camera->world matrix
// (camera+0x3F0) into the view matrix (+0x430) and copies both, the camera position and the projection into the
// viewport's view block, which every render pass reads. The mod writes the eye's camera into +0x3F0 right before the
// call; the projection getter (Viewport_Z::GetProjection, 23 call sites: culling, shadows, lights, screen-space
// passes, the view block) gets the eye's frustum; the FOV tangents the culling / LOD use get a frustum that covers
// the eyes (wide culling). Game logic keeps the game's camera: the game camera's own update rewrites +0x3F0 every
// frame, and the mod treats anything else than what it wrote last as the game's new camera ("clean").
//
// Stereo = alternate-eye rendering (AER) or synchronized (the game clock held for the second eye), or stereo
// reconstruction (the head-centre view drawn, both eyes rebuilt from its colour + depth, recon.cpp). Each frame's eye,
// pose and frustum go into a FIFO that Present takes them from (the render thread may run a frame behind).
//
// Matrices: the engine's camera->world rows are right, up, FORWARD, position (world right-handed, +Y up, metres).
// The mod's frames (and RenderedEye.node*) are right, up, BACK, position - OpenXR's own convention - so a head pose
// composes straight onto them; the conversion is back = -forward on the way in and out.

#include <windows.h>
#include <cmath>
#include <cstring>
#include <string>
#include <cstdint>
#include <climits>
#include "log.h"
#include "MinHook.h"
#include "vrmath.h"
#include "camera.h"
#include "game.h"
#include "settings.h"
#include "config.h"
#include "xrbridge/client.h"
#include "firstperson.h"
#include "zouna_math.h"
bool PadsLTHeld();   // padinput.cpp: L2 / LT held on any controller

CamState g_cam;
extern volatile LONG g_presents;
extern DWORD g_presentThread;


// ---------------------------------------------------------------- main node selection
// Several camera nodes render each frame (the gameplay view, render-to-texture cameras of screens / holograms, the
// photo mode preview ...). The main one is the node whose render size is the back buffer's and that updates every
// frame; ties go to the one seen most.
struct NodeTally { void* node; unsigned n; unsigned w, h; int slot; };
static NodeTally g_tally[16];
static SRWLOCK g_tallyLock = SRWLOCK_INIT;
static void* volatile g_mainNode = nullptr;
static volatile LONG g_posedPresent = -100;   // the Present count when a VR pose was last applied (wide culling)
struct VpSnap { void* node; unsigned n, w, h; int slot; };
static VpSnap g_vpSnap[16]; static int g_vpSnapN = 0;   // the viewports of the last Present (report)
static unsigned g_bbW = 0, g_bbH = 0;

static void Tally(void* node) {
    unsigned w = 0, h = 0;
    char* c = (char*)node;
    if (game::Readable(c + game::kVpW, 8)) { w = *(unsigned*)(c + game::kVpW); h = *(unsigned*)(c + game::kVpH); }
    AcquireSRWLockExclusive(&g_tallyLock);
    bool done = false;
    for (auto& t : g_tally) if (t.node == node) { t.n++; t.w = w; t.h = h; done = true; break; }
    if (!done) for (auto& t : g_tally) if (!t.node) { t = { node, 1, w, h, game::ViewportSlot(node) }; done = true; break; }   // 0.5: the slot read once a frame, here
    ReleaseSRWLockExclusive(&g_tallyLock);
}

bool VideoActive(unsigned minW);   // video.cpp
typedef void(__fastcall* PFN_FrameTime)(void* engine);
static PFN_FrameTime o_FrameTime = nullptr;
static volatile bool g_gamePaused = false; static volatile long long g_pausedSeen = 0;
static volatile long long g_lastMove100ns = 0;   // when the game last moved its camera
// Flat screen decision (once per Present). Paused: the game's own "game halted" flag (read by the frame clock,
// exe+18E8402) and the game camera still for 0.3 s - the pause menu, its settings / map / gear screens. If the camera
// moves while paused (photo mode) it stays 3D until the game runs again. Video (not used in this engine): a full-size video decoding while
// the game camera stands still (0.5 s) or the game is paused - a pre-rendered cutscene. 0.25 s either way before a
// change, so a single frame never flips the view.
static void FlatDecide() {
    long long now = (long long)modtime::Now100ns();
    bool paused = g_gamePaused && o_FrameTime && now - g_pausedSeen < 5000000;   // clock ticked in the last 0.5 s
    static bool photo = false;
    static long long pauseStart = 0;
    if (!paused) { photo = false; pauseStart = 0; }
    else {
        if (!pauseStart) pauseStart = now;
        if (g_lastMove100ns > pauseStart + 1000000) photo = true;   // the camera moved after the pause began
    }
    long long still = now - g_lastMove100ns;
    // 0.6.36: a video during which the 3D camera moves or cuts (a new shot) belongs to a REAL-TIME scene - an in-world
    // screen, a video behind a real-time cutscene - and stays in VR until that video ends. A tester's log: a real-time
    // cutscene with a 1920x1080 video decoding, every shot a still camera - the view switched flat / VR nine times in a
    // minute. A pre-rendered cutscene never moves the 3D camera while it plays (three in another log, 40 s each).
    static long long vidStart = 0, vidLast = 0; static bool vid3D = false;
    bool vid = g_cam.flatVideos && VideoActive(g_cam.flatVideoMinW);
    if (vid) {
        if (!vidStart || now - vidLast > 20000000) { vidStart = now; vid3D = false; }   // a new video (2 s without one)
        vidLast = now;
        if (!vid3D && g_lastMove100ns > vidStart + 3000000) { vid3D = true; LOGI("view: the 3D camera moved while a video plays - a real-time scene, stays VR until the video ends"); }
    }
    int want = g_cam.flatHold ? 1 : (g_cam.flatMenus && paused && !photo && still > 3000000) ? 2 :
               (vid && !vid3D && (still > 5000000 || paused)) ? 3 : 0;
    static int pending = 0; static long long since = 0;
    if (want != pending) { pending = want; since = now; }
    bool cur = g_cam.flatNow;
    if ((want != 0) != cur && (want == 1 || now - since > 2500000)) {
        g_cam.flatNow = want != 0; g_cam.flatReason = want;
        static const char* why[] = { "", "held (F6)", "game paused (menu)", "pre-rendered video" };
        if (want) LOGI("view: flat screen - %s", why[want]); else LOGI("view: back to VR");
    } else if (cur && want && want != g_cam.flatReason) g_cam.flatReason = want;
}

// 0.6.56: where the "camera" part of the mod's time at Present goes (0.5-0.7 ms a frame in the 0.6.51 log)
static double g_cpFlat = 0, g_cpNode = 0, g_cpTally = 0; static unsigned g_cpN = 0;
static inline double CpMs(LONGLONG a, LONGLONG b) { static LARGE_INTEGER f = {}; if (!f.QuadPart) QueryPerformanceFrequency(&f); return (double)(b - a) * 1000.0 / (double)f.QuadPart; }
void CameraOnPresent(unsigned bbW, unsigned bbH) {
    g_bbW = bbW; g_bbH = bbH;
    LARGE_INTEGER c0, c1, c2, c3; QueryPerformanceCounter(&c0);
    FlatDecide();
    QueryPerformanceCounter(&c1);
    // near clip (metres -> engine units) only while VR frames are made; the game's own otherwise
    // 0.6.20: the projection getter's near override is never set any more. Since 0.6.14 the picture is drawn from the
    // node's own projection, so the override only changed the depth scale stereo reconstruction reads its depth with
    // (0.6.19 log: depth terms [14] -0.30 = near_clip, the picture drawn with the game's ~0.09) - every distance was
    // taken ~3x too far, the rebuilt eyes had a third of the depth. The near clip is set on the camera node instead.
    if (char* c = (char*)game::CameraOfViewport(g_mainNode)) if (game::Readable(c + game::kCamNear, 16)) { g_cam.nodeNear = *(float*)(c + game::kCamNear); g_cam.nodeFar = *(float*)(c + game::kCamFar); }
    QueryPerformanceCounter(&c2);
    // 0.6.12: the eye frustum is NOT padded to the back buffer's shape any more. 0.6.11 log: the back buffer grows to
    // the wide symmetric view, its shape padded the eye frustum wider, which grew the view again (1.70 -> 2.05 ->
    // 1.99) - and the render size was computed against the padded frustum, so the picture had 1.21 x wider pixels
    // than tall: everything in VR stretched sideways ("very wide"). Shape only from eye_aspect (default: none).
    (void)bbW; (void)bbH;
    AcquireSRWLockExclusive(&g_tallyLock);
    // 0.3: the engine's own answer first - the renderer's viewport table slot 0 (game.cpp), when it was set up this
    // frame. 0.2's pick by size (a viewport the back buffer's size won by 1,000,000 points) latched onto a viewport
    // that is drawn ~3 times a second, the player's view (16:9, not the back buffer's size) never got the head pose.
    // Fallback (table not found): slot 0 beats everything, then draw count, then size.
    void* best = nullptr; long long bestScore = 0;
    void* eng = game::MainViewport();
    bool engSeen = false;
    g_vpSnapN = 0;
    for (auto& t : g_tally) {
        if (!t.node) continue;
        int slot = t.slot;
        if (g_vpSnapN < 16) g_vpSnap[g_vpSnapN++] = { t.node, t.n, t.w, t.h, slot };
        if (t.node == eng) engSeen = true;
        long long s = (long long)t.n * 16 + (slot == 0 ? 100000000 : 0) + ((t.w == bbW && t.h == bbH) ? 8 : 0);
        if (t.node == g_mainNode) s += 4;   // keep the current one on a tie
        if (s > bestScore) { bestScore = s; best = t.node; }
    }
    if (eng && engSeen) { best = eng; g_cam.mainFromEngine = true; } else g_cam.mainFromEngine = false;
    memset(g_tally, 0, sizeof g_tally);
    ReleaseSRWLockExclusive(&g_tallyLock);
    if (best) {   // the player's view's own size (the game's 3D surface) against the back buffer
        char* v = (char*)best;
        if (game::Readable(v + game::kVpW, 8)) { g_cam.mainW = *(unsigned*)(v + game::kVpW); g_cam.mainH = *(unsigned*)(v + game::kVpH); }
    }
    QueryPerformanceCounter(&c3);
    g_cpFlat += CpMs(c0.QuadPart, c1.QuadPart); g_cpNode += CpMs(c1.QuadPart, c2.QuadPart); g_cpTally += CpMs(c2.QuadPart, c3.QuadPart); g_cpN++;
    if (best && best != g_mainNode) {
        g_cam.nodeSwitches++;
        LOGI("camera: main viewport %p (slot %d, %u x %u, %s)", best, game::ViewportSlot(best), g_cam.mainW, g_cam.mainH,
             g_cam.mainFromEngine ? "the renderer's own main viewport" : "picked by slot / draw count");
        g_mainNode = best;
    }
    // 0.3: this engine draws its 3D at the size of its own render surface (its resolution setting), not at the swap
    // chain's: a back buffer forced to another size gets the picture in one corner (eye cut, scene depth and the UI
    // layer all measured against the wrong size). The 0.2 log: back buffer 4440x2722, the game's view 16:9.
    {
        static unsigned s_bad = 0;
        bool posed = g_presents - g_posedPresent <= 3;
        bool bad = best && posed && g_cam.mainW >= 256 && g_cam.mainH >= 256 && (g_cam.mainW != bbW || g_cam.mainH != bbH);
        s_bad = bad ? s_bad + 1 : 0;
        if (s_bad == 90) { void ResolutionGameSizeMismatch(unsigned, unsigned, unsigned, unsigned); ResolutionGameSizeMismatch(g_cam.mainW, g_cam.mainH, bbW, bbH); }
    }
}

// ---------------------------------------------------------------- headset pose / frustum
static bool FetchPoses() {
    xrb::IpcPose pose[2]; xrb::IpcFov fov[2]; int64_t t = 0;
    if (!xrb::ClientGetLatestPoses(pose, fov, &t) || (pose[0].qw == 0 && pose[0].qx == 0 && pose[0].qy == 0 && pose[0].qz == 0)) {
        g_cam.havePose = false; return false;
    }
    bool fovChanged = false;
    for (int e = 0; e < 2; e++) {
        if (fabsf(fov[e].left - g_cam.fov[e].left) > 1e-4f || fabsf(fov[e].right - g_cam.fov[e].right) > 1e-4f ||
            fabsf(fov[e].up - g_cam.fov[e].up) > 1e-4f || fabsf(fov[e].down - g_cam.fov[e].down) > 1e-4f) fovChanged = true;
        g_cam.pose[e] = pose[e]; g_cam.fov[e] = fov[e];
    }
    g_cam.havePose = true;
    // 0.6.10: the frusta also depend on the angle between the eyes (canted displays: the head-centre view must cover
    // both turned eyes). Pimax reports the eyes turned apart (0.6.8 log: the centre view's right eye had a constant
    // 22 % band outside the drawn picture). Recomputed when that angle changes, from live poses only.
    {
        static float s_cant = -1.f;
        const xrb::IpcPose& a0 = pose[0]; const xrb::IpcPose& a1 = pose[1];
        float n0 = a0.qx * a0.qx + a0.qy * a0.qy + a0.qz * a0.qz + a0.qw * a0.qw, n1 = a1.qx * a1.qx + a1.qy * a1.qy + a1.qz * a1.qz + a1.qw * a1.qw;
        if (fabsf(n0 - 1.f) < 0.05f && fabsf(n1 - 1.f) < 0.05f) {
            float d = fabsf(a0.qx * a1.qx + a0.qy * a1.qy + a0.qz * a1.qz + a0.qw * a1.qw) / sqrtf(n0 * n1);
            float cant = 2.f * acosf(fminf(1.f, d)) * 57.2957795f;
            if (fabsf(cant - s_cant) > 0.3f) { s_cant = cant; if (!fovChanged) CameraUpdateFrustum(); }
        }
    }
    if (fovChanged) {
        const float d = 57.2957795f;
        float ipd = sqrtf((pose[0].px - pose[1].px) * (pose[0].px - pose[1].px) + (pose[0].py - pose[1].py) * (pose[0].py - pose[1].py) +
                          (pose[0].pz - pose[1].pz) * (pose[0].pz - pose[1].pz));
        LOGI("headset: left eye FOV L%.1f R%.1f U%.1f D%.1f, right eye L%.1f R%.1f U%.1f D%.1f deg, IPD %.1f mm",
             fov[0].left * d, fov[0].right * d, fov[0].up * d, fov[0].down * d, fov[1].left * d, fov[1].right * d, fov[1].up * d, fov[1].down * d, ipd * 1000.f);
        CameraUpdateFrustum();
    }
    return true;
}

// Each eye's own asymmetric frustum from the headset, widened about its centre to the eye image's aspect (square
// pixels, nothing stretched - 1:1, 5:4 or the headset's own shape), then by the cull margin. Head mode: one
// symmetric frustum that covers both eyes.
static float g_baseW[2] = { 2.f, 2.f }, g_baseH[2] = { 2.f, 2.f };
static float g_eyeViewHx = 0.f;   // 0.9: the eye-size view's half width (tangent), 0 = not used
// 0.6.9: the head's orientation = halfway between the two eyes' (canted displays: Pimax and others turn each eye a few
// degrees outwards). Head mode and reconstruction's centre view are drawn with it, so neither eye is favoured; the
// eyes are rebuilt / shown with their own orientation.
static void HeadQuat(const xrb::IpcPose* p, float q[4]) {
    float a[4] = { p[0].qx, p[0].qy, p[0].qz, p[0].qw }, b[4] = { p[1].qx, p[1].qy, p[1].qz, p[1].qw };
    float dot = a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3], sg = dot < 0.f ? -1.f : 1.f;
    float n = 0.f; for (int i = 0; i < 4; i++) { q[i] = a[i] + sg * b[i]; n += q[i] * q[i]; }
    n = sqrtf(n);
    if (n < 1e-6f) { for (int i = 0; i < 4; i++) q[i] = a[i]; return; }
    for (int i = 0; i < 4; i++) q[i] /= n;
}
void CameraUpdateFrustum() {
    const xrb::IpcFov* f = g_cam.fov;
    float a = g_cam.eyeAspect;   // 0 = the headset's own field of view, no padding
    float m = g_cam.cullMargin < 1.f ? 1.f : g_cam.cullMargin;
    auto tn = [](float x) { return tanf(x < -1.5f ? -1.5f : x > 1.5f ? 1.5f : x); };
    for (int e = 0; e < 2; e++) {
        float l = tn(f[e].left), r = tn(f[e].right), u = tn(f[e].up), d = tn(f[e].down);
        if (!(r - l > 0.05f) || !(u - d > 0.05f)) { l = -1; r = 1; u = 1; d = -1; }
        float cx = 0.5f * (r + l), cy = 0.5f * (u + d), w = r - l, h = u - d;
        if (a > 0.1f) { if (w / h < a) w = h * a; else h = w / a; }
        g_baseW[e] = w; g_baseH[e] = h;   // the headset's own field of view (image shape), before the margin
        w *= m; h *= m;
        // 0.6.13: picture width / height above 1 show more than the headset's field of view, eye align moves the shown
        // window - the rendered view covers both (the compositor cuts the window out: CropToHeadset)
        float sx = g_set.viewWidth, sy = g_set.viewHeight;
        if (!(sx >= 0.5f && sx <= 2.f)) sx = 1.f; if (!(sy >= 0.5f && sy <= 2.f)) sy = 1.f;
        if (sx > m) w *= sx / m; if (sy > m) h *= sy / m;
        auto tn1 = [](float deg) { return fabsf(tanf(fminf(fabsf(deg), 20.f) * 0.0174533f)); };
        float ax = fmaxf(tn1(g_set.reconShiftH), tn1(g_set.aerShiftH)), ay = fmaxf(tn1(g_set.reconShiftV), tn1(g_set.aerShiftV));
        g_cam.eyeTan[e][0] = cx - 0.5f * w - ax; g_cam.eyeTan[e][1] = cx + 0.5f * w + ax;
        g_cam.eyeTan[e][2] = cy + 0.5f * h + ay; g_cam.eyeTan[e][3] = cy - 0.5f * h - ay;
    }
    float hx = 1.f, hy = 1.f;
    {
        // 0.6.8: from the eyes' own frusta (their image shape and cull margin included), so the head-centre view covers
        // every pixel of both eyes - reconstruction's centre view rebuilds them from it; +2 % for the half-IPD parallax.
        // No padding to the eye image's shape (the render size follows each axis: CameraDrawGrowthXY) - the both-eye view
        // is wider than tall, padding it to the eye shape cost ~1.8x the pixels instead of ~1.3x
        // 0.6.9: each eye's frustum corners turned into the head's frame first (canted displays: an eye turned outwards
        // sees further to its side than its own tangents say - the centre view missed that edge, the rebuilt eye had
        // a stretched band there)
        const float (*t)[4] = g_cam.eyeTan;
        float hq[4]; HeadQuat(g_cam.pose, hq);
        bool rot = g_cam.pose[0].qw != 0 || g_cam.pose[0].qx != 0 || g_cam.pose[0].qy != 0 || g_cam.pose[0].qz != 0;
        float Rh[3][3]; QuatToMat(hq[0], hq[1], hq[2], hq[3], Rh);
        hx = hy = 0.f;
        for (int e = 0; e < 2; e++) {
            float Re[3][3]; const xrb::IpcPose& pe = g_cam.pose[e]; QuatToMat(pe.qx, pe.qy, pe.qz, pe.qw, Re);
            for (int c = 0; c < 4; c++) {
                float v[3] = { c & 1 ? t[e][1] : t[e][0], c & 2 ? t[e][2] : t[e][3], -1.f }, w[3] = { v[0], v[1], v[2] };
                if (rot) {   // w = Rh^T * Re * v
                    float u[3]; for (int i = 0; i < 3; i++) u[i] = Re[i][0] * v[0] + Re[i][1] * v[1] + Re[i][2] * v[2];
                    for (int i = 0; i < 3; i++) w[i] = Rh[0][i] * u[0] + Rh[1][i] * u[1] + Rh[2][i] * u[2];
                }
                if (w[2] > -0.05f) { w[0] = v[0]; w[1] = v[1]; w[2] = -1.f; }
                hx = fmaxf(hx, fabsf(w[0] / -w[2])); hy = fmaxf(hy, fabsf(w[1] / -w[2]));
            }
        }
        hx *= 1.02f; hy *= 1.02f;
        hx = fminf(hx, 3.7f); hy = fminf(hy, 3.7f);   // 75 deg: beyond that the pixels are too stretched to be worth it
        if (!(hx > 0.05f) || !(hy > 0.05f)) { hx = 1.f; hy = 1.f; }
        if (rot) {   // log the cant once per change
            float Ro[3][3]; QuatToMat(g_cam.pose[1].qx, g_cam.pose[1].qy, g_cam.pose[1].qz, g_cam.pose[1].qw, Ro);
            float Rl[3][3]; QuatToMat(g_cam.pose[0].qx, g_cam.pose[0].qy, g_cam.pose[0].qz, g_cam.pose[0].qw, Rl);
            float tr = 0.f; for (int i = 0; i < 3; i++) for (int k = 0; k < 3; k++) tr += Rl[k][i] * Ro[k][i];
            float ang = acosf(fmaxf(-1.f, fminf(1.f, (tr - 1.f) * 0.5f))) * 57.2957795f;
            g_cam.cantDeg = ang;   // 0.6.53: recon's adaptive footprint is for parallel eyes only
            // 0.6.35: only when it changes (the tester's log: 872 identical lines - every frustum update logged it)
            static float s_ang = -1.f, s_hx = -1.f, s_hy = -1.f;
            if (fabsf(ang - s_ang) > 0.05f || fabsf(hx - s_hx) > 0.002f || fabsf(hy - s_hy) > 0.002f) {
                s_ang = ang; s_hx = hx; s_hy = hy;
                LOGI("headset: the eyes are turned %.1f deg apart (canted displays when > 0.5) - head view %.3f x %.3f", ang, hx, hy);
            }
        }
    }
    g_cam.monoTan[0] = -hx; g_cam.monoTan[1] = hx; g_cam.monoTan[2] = hy; g_cam.monoTan[3] = -hy;
    // stereo reconstruction: the drawn eye's frustum widened to also hold everything the other eye sees, so the rebuilt
    // eye has a source for every pixel except what is hidden behind close objects. The other eye's frustum corners are
    // turned into the drawn eye's frame (canted displays: Pimax, some WMR) and projected; 3 % for the eyes' parallax.
    // Only the directions that need it grow: the two eyes differ mostly sideways, so the view gets wider but hardly
    // taller (it used to keep the eye image's shape - about 1.3 x wider made it 1.3 x taller too, ~1.7 x the pixels;
    // now ~1.3 x). The render size follows per axis (CameraDrawGrowthXY), so the pixels stay square.
    // 0.6.6 log: the engine renders a SYMMETRIC projection whatever the off-centre terms say (its projection is
    // rebuilt after the getter: depth rows, TAA jitter in [8] / [9]) - the eye screenshots of alternate-eye mode showed
    // both eyes centred on the same point while the Dream Air's eyes look 13 % of the image to the side, so in the
    // headset the two pictures sat side by side and never merged. The engine now always draws a symmetric frustum that
    // covers the eye's own (the AC mods' "symmetric view"), and the compositor cuts the eye's real view out of it.
    // 0.9.8: symmetric view belongs to the eye methods (alternate eye, synchronized, head). Stereo reconstruction keeps its own centre view
    // (its eye-size view is narrower than a symmetric one - the Performance path).
    const bool symOn = g_cam.symmetricView && g_cam.mode != VRMODE_RECON;
    auto sym = [&](const float* in, float* out) {
        if (!symOn) { memcpy(out, in, 16); return; }
        float hx = fmaxf(-in[0], in[1]), hy = fmaxf(in[2], -in[3]);
        out[0] = -hx; out[1] = hx; out[2] = hy; out[3] = -hy;
    };
    for (int e = 0; e < 2; e++) sym(g_cam.eyeTan[e], g_cam.drawTan[e]);
    for (int e = 0; e < 2; e++) {
        const float* ta = g_cam.eyeTan[e]; const float* b = g_cam.eyeTan[e ^ 1];
        float l = ta[0], r = ta[1], u = ta[2], d = ta[3];
        const xrb::IpcPose& pe = g_cam.pose[e]; const xrb::IpcPose& po = g_cam.pose[e ^ 1];
        float Re[3][3], Ro[3][3];
        bool rot = pe.qw != 0 || pe.qx != 0 || pe.qy != 0 || pe.qz != 0;
        QuatToMat(pe.qx, pe.qy, pe.qz, pe.qw, Re); QuatToMat(po.qx, po.qy, po.qz, po.qw, Ro);
        for (int c = 0; c < 4; c++) {
            float v[3] = { c & 1 ? b[1] : b[0], c & 2 ? b[2] : b[3], -1.f }, w[3] = { v[0], v[1], v[2] };
            if (rot) {   // w = Re^T * Ro * v
                float t[3]; for (int i = 0; i < 3; i++) t[i] = Ro[i][0] * v[0] + Ro[i][1] * v[1] + Ro[i][2] * v[2];
                for (int i = 0; i < 3; i++) w[i] = Re[0][i] * t[0] + Re[1][i] * t[1] + Re[2][i] * t[2];
            }
            if (w[2] > -0.05f) continue;   // more than ~87 degrees off: cannot be covered, keep the eye's own
            float tx = w[0] / -w[2], ty = w[1] / -w[2];
            l = fminf(l, tx); r = fmaxf(r, tx); u = fmaxf(u, ty); d = fminf(d, ty);
        }
        float cx = 0.5f * (r + l), cy = 0.5f * (u + d), W = (r - l) * 1.03f, H = (u - d) * 1.03f;
        g_cam.reconTan[e][0] = cx - 0.5f * W; g_cam.reconTan[e][1] = cx + 0.5f * W;
        g_cam.reconTan[e][2] = cy + 0.5f * H; g_cam.reconTan[e][3] = cy - 0.5f * H;
        float tmp[4]; memcpy(tmp, g_cam.reconTan[e], 16); sym(tmp, g_cam.reconTan[e]);
    }
    // 0.6.11: ONE frustum for every stereo method (symmetric view): the widest of the eyes' own and the head-centre
    // view. The render size is made from it (CameraStableGrowthXY), so the picture's shape always equals the render
    // size's shape - square pixels whether the engine takes the projection's x scale from us or works it out from
    // its window shape (a mismatch there is what stretches the 3D "wide"), and no resize when the method changes.
    if (symOn) {
        // 0.9.8: as wide as the eyes need (each eye's view symmetric about its own line of sight), not the head-centre view's wider one -
        // except in head mode, whose one view is the head-centre one
        float HX = g_cam.mode == VRMODE_HEAD ? g_cam.monoTan[1] : 0.f, HY = g_cam.mode == VRMODE_HEAD ? g_cam.monoTan[2] : 0.f;
        for (int e = 0; e < 2; e++) { HX = fmaxf(HX, g_cam.drawTan[e][1]); HY = fmaxf(HY, g_cam.drawTan[e][2]); }
        const float u[4] = { -HX, HX, HY, -HY };
        for (int e = 0; e < 2; e++) { memcpy(g_cam.drawTan[e], u, 16); memcpy(g_cam.reconTan[e], u, 16); }
        memcpy(g_cam.monoTan, u, 16);
    }
    // 0.9 (framework 0.6.97 performance path): recon_view = eye - the one drawn view is about one eye wide, plus recon_eye_cover of the way
    // to the full width: hx = hxEye + cover * (hxFull - hxEye). The part of a rebuilt eye that lies outside it repeats the rim (the
    // shader's edge fill). Only the head-centre view of stereo reconstruction shrinks; the other methods keep their frusta, and the
    // heights stay (the eyes differ sideways). The render size follows through CameraDrawGrowthXY (window.cpp).
    g_eyeViewHx = 0.f;
    if (g_cam.reconCentre && g_set.reconView == "eye") {   // computed whatever the current mode (a pause menu's flat screen must not change the render size)
        float hxEye = 0.f;
        for (int e = 0; e < 2; e++) hxEye = fmaxf(hxEye, 0.5f * (g_cam.eyeTan[e][1] - g_cam.eyeTan[e][0]));   // 0.9.8: symmetric view is not used by reconstruction
        float full = g_cam.monoTan[1], cover = fminf(1.f, fmaxf(0.f, g_set.reconEyeCover));
        if (hxEye > 0.05f && full > hxEye) {
            float hx2 = hxEye + cover * (full - hxEye);
            g_eyeViewHx = hx2;
            if (g_cam.mode == VRMODE_RECON) { g_cam.monoTan[0] = -hx2; g_cam.monoTan[1] = hx2; }
            static float s_full = -1.f, s_hx = -1.f;
            if (fabsf(full - s_full) > 0.002f || fabsf(hx2 - s_hx) > 0.002f) {
                s_full = full; s_hx = hx2;
                LOGI("recon: eye-size view - the drawn view %.3f wide (tangent) instead of %.3f; each eye's outer %.1f %% repeats the rim (recon_eye_cover %.2f)",
                     2.f * hx2, 2.f * full, 100.f * (full - hx2) / (2.f * full), cover);
            }
        }
    }
}
// 0.9.1: the render growth of the eye-size view - from the stored width, not from the current mode, so the render size stays the same
// while a flat pause menu or a loading screen is shown (each change recreates every render target: a hitch)
bool CameraReconEyeGrowthXY(float& gx, float& gy) {
    gx = gy = 1.f;
    if (!(g_eyeViewHx > 0.05f)) return false;
    for (int e = 0; e < 2; e++) {
        if (g_baseW[e] > 0.05f) gx = fmaxf(gx, 2.f * g_eyeViewHx / g_baseW[e]);
        if (g_baseH[e] > 0.05f) gy = fmaxf(gy, (g_cam.monoTan[2] - g_cam.monoTan[3]) / g_baseH[e]);
    }
    if (gx > 3.f) gx = 3.f; if (gy > 3.f) gy = 3.f;
    return true;
}
const float* CameraDrawTan(int e) {
    e &= 1;
    if (g_cam.mode == VRMODE_RECON && g_cam.reconCentre) return g_cam.monoTan;   // the head-centre view (both eyes rebuilt)
    return (g_cam.mode == VRMODE_RECON && g_cam.reconShared) ? g_cam.reconTan[e] : g_cam.drawTan[e];
}

// how much wider than the headset's own field of view the rendered image is (cull margin, the shared frustum of
// stereo reconstruction, head mode's both-eyes view): the render size is grown by this so the headset still gets its
// own pixel density in the part it shows
void CameraDrawGrowthXY(float& gx, float& gy) {
    gx = gy = 1.f;
    for (int e = 0; e < 2; e++) {
        const float* t = g_cam.mode == VRMODE_HEAD ? g_cam.monoTan : CameraDrawTan(e);
        if (g_baseW[e] > 0.05f) gx = fmaxf(gx, (t[1] - t[0]) / g_baseW[e]);
        if (g_baseH[e] > 0.05f) gy = fmaxf(gy, (t[2] - t[3]) / g_baseH[e]);
    }
    if (gx > 3.f) gx = 3.f; if (gy > 3.f) gy = 3.f;
}
// 0.6.9: the largest view any stereo method draws (eye views, the head / centre view; the shared reconstruction view)
// - the render size is set from this ONCE and does not change when the method is switched (manual 7.3: a resize
// recreates every render target - a hitch, and the UI picker lost its target)
void CameraStableGrowthXY(float& gx, float& gy) {
    gx = gy = 1.f;
    for (int e = 0; e < 2; e++) {
        const float* ts[3] = { g_cam.drawTan[e], g_cam.monoTan, (g_cam.reconShared && !g_cam.reconCentre) ? g_cam.reconTan[e] : g_cam.drawTan[e] };
        for (const float* t : ts) {
            if (g_baseW[e] > 0.05f) gx = fmaxf(gx, (t[1] - t[0]) / g_baseW[e]);
            if (g_baseH[e] > 0.05f) gy = fmaxf(gy, (t[2] - t[3]) / g_baseH[e]);
        }
    }
    if (gx > 3.f) gx = 3.f; if (gy > 3.f) gy = 3.f;
}
// width / height of the drawn view (tangents): the render size is made this shape (square pixels)
float CameraDrawAspect() {
    float w = g_cam.monoTan[1] - g_cam.monoTan[0], h = g_cam.monoTan[2] - g_cam.monoTan[3];
    if (g_eyeViewHx > 0.05f && g_set.vrMode == "recon") w = 2.f * g_eyeViewHx;   // 0.9.1: the eye-size view's shape, also while a flat screen is shown
    return (w > 0.05f && h > 0.05f) ? w / h : 0.f;
}
float CameraDrawGrowth() { float gx, gy; CameraDrawGrowthXY(gx, gy); return fmaxf(gx, gy); }

static xrb::IpcFov TanToFov(const float* t) { return { atanf(t[0]), atanf(t[1]), atanf(t[2]), atanf(t[3]) }; }

// ---------------------------------------------------------------- transform
static Frame ReadFrame(const float* T) {
    Frame f;
    const float* row[4] = { T, T + 3, T + 6, T + 9 };
    for (int k = 0; k < 3; k++) {
        const float* r = row[g_cam.axisRow[k]]; float s = g_cam.axisSign[k];
        f.axis[k] = { r[0] * s, r[1] * s, r[2] * s };
    }
    f.pos = { T[9], T[10], T[11] };
    return f;
}
static void WriteFrame(float* T, const Frame& f) {
    for (int k = 0; k < 3; k++) {
        float* r = T + 3 * g_cam.axisRow[k]; float s = g_cam.axisSign[k];
        r[0] = f.axis[k].x * s; r[1] = f.axis[k].y * s; r[2] = f.axis[k].z * s;
    }
    T[9] = f.pos.x; T[10] = f.pos.y; T[11] = f.pos.z;
}

// the game camera with the menu's adjustments. World is Z-up (Dawn engine).

// the game camera with the menu's adjustments. World is Y-up (Zouna).
static const V3 kWorldUp = { 0, 1, 0 };
static Frame CameraBase(Frame f) {
    const Frame game = f;   // the game camera as the game set it (first person's cutscene check)
    if (g_cam.decoupledPitch) {   // keep yaw only: the horizon stays level, the head pitches / rolls the view
        V3 fwd = f.axis[2] * -1.f;
        V3 h = { fwd.x, 0.f, fwd.z };
        if (Len(h) < 1e-3f) { float sg = f.axis[2].y > 0.f ? 1.f : -1.f; h = { f.axis[1].x * sg, 0.f, f.axis[1].z * sg }; }
        if (Len(h) > 1e-6f) {
            h = Norm(h);
            V3 up = kWorldUp, back = h * -1.f, right = Cross(up, back);
            if (Dot(right, f.axis[0]) < 0.f) right = right * -1.f;
            f.axis[0] = right; f.axis[1] = up; f.axis[2] = back;
        }
    }
    // first person: the eye at the character, with its own offsets (camera_offset_* are third person only)
    Frame h;
    if (fp::EyeBase(f, game, h)) { g_cam.fpActive = true; return h; }
    g_cam.fpActive = false;
    // offsets are metres of the game world: world_scale (your size in it) does not change them
    float u = g_cam.unitsPerMetre;
    float ox = g_cam.camOffset[0] * u, oy = g_cam.camOffset[1] * u, oz = g_cam.camOffset[2] * u;
    f.pos = f.pos + f.axis[0] * ox + f.axis[1] * oy - f.axis[2] * oz;
    return f;
}


// on a monitor that sells impact, in a headset it is uncomfortable. A critically damped follower on the camera's
// position and heading removes the fast part and keeps the motion: time constant up to ~120 ms at 1.0. Cuts (the
// camera jumps more than 2 m or turns more than 40 degrees in a frame) are taken at once.
static Frame g_stab; static bool g_stabHave = false; static long long g_stabTick = 0;
static Frame Stabilize(Frame f, bool sameTick) {
    float k = g_cam.stabilize;
    if (!(k > 0.01f)) { g_stabHave = false; return f; }
    long long now = (long long)modtime::Now100ns();
    float dt = g_stabTick ? (float)(now - g_stabTick) * 1e-7f : 0.f;
    if (sameTick && g_stabHave) return g_stab;              // the second eye of a tick: the same camera
    g_stabTick = now;
    float s = g_cam.unitsPerMetre;   // a cut = 2 m of the game world
    V3 d = f.pos - (g_stabHave ? g_stab.pos : f.pos);
    float turn = g_stabHave ? acosf(fmaxf(-1.f, fminf(1.f, Dot(f.axis[2], g_stab.axis[2])))) : 0.f;
    if (!g_stabHave || !(dt > 0.f && dt < 0.25f) || Len(d) > 2.f * s || turn > 0.7f) { g_stab = f; g_stabHave = true; return f; }
    float tau = 0.12f * k, a = 1.f - expf(-dt / tau);
    g_stab.pos = g_cam.fpActive ? f.pos : g_stab.pos + d * a;   // first person: the head is filtered on its own (no lag)
    for (int i = 0; i < 3; i++) g_stab.axis[i] = Norm(g_stab.axis[i] + (f.axis[i] - g_stab.axis[i]) * a);
    // re-orthonormalise (back, then up, then right)
    V3 b = Norm(g_stab.axis[2]), r = Norm(Cross(g_stab.axis[1], b)), u = Cross(b, r);
    if (Dot(r, f.axis[0]) < 0.f) r = r * -1.f;
    g_stab.axis[0] = r; g_stab.axis[1] = u; g_stab.axis[2] = b;
    return g_stab;
}

// 0.6.17 idle-sway lock (camera_settle 0..1): standing still, the game's camera still sways (third person: the idle
// camera drift / breathing; first person: the head bone's idle animation) - small, slow movements the shake filter
// cannot remove (it only takes out fast ones) and that, in a headset, feel like the floor moving. A "rope with
// slack": the camera only moves once the game's moves further than the slack (up to 2.5 degrees / 6 cm at 1.0) and
// then follows 1:1 - real turns and walking pass through, the sway inside the slack is gone.

// Idle-sway lock (camera_settle 0..1): small slow camera sway is held inside a slack of up to 2.5 degrees / 6 cm (at
// 1.0); beyond it the camera follows 1:1. Heading / pitch / roll about the world's +Y up.
static Frame g_settle; static bool g_settleHave = false; static bool g_settleFlip = false;
static float g_settleAng[3];
static float WrapPi(float a) { while (a > 3.14159265f) a -= 6.2831853f; while (a < -3.14159265f) a += 6.2831853f; return a; }
static Frame Settle(Frame f, bool sameTick) {
    float k = g_cam.settle;
    if (!(k > 0.01f)) { g_settleHave = false; return f; }
    if (sameTick && g_settleHave) return g_settle;
    const V3 Y = kWorldUp;
    V3 back = Norm(f.axis[2]), fwd = back * -1.f;
    if (fabsf(fwd.y) > 0.97f) { g_settleHave = false; return f; }   // looking straight up / down: no stable heading
    V3 r0 = Norm(Cross(Y, back)); bool flip = Dot(r0, f.axis[0]) < 0.f; if (flip) r0 = r0 * -1.f;
    V3 u0 = Cross(back, r0);
    float ang[3] = { atan2f(fwd.x, fwd.z), asinf(fmaxf(-1.f, fminf(1.f, fwd.y))), atan2f(Dot(f.axis[0], u0), Dot(f.axis[0], r0)) };
    float dzA = 2.5f * 0.0174533f * k, dzP = 0.06f * k * g_cam.unitsPerMetre;
    if (!g_settleHave || flip != g_settleFlip) { for (int i = 0; i < 3; i++) g_settleAng[i] = ang[i]; g_settle = f; g_settleHave = true; g_settleFlip = flip; return f; }
    for (int i = 0; i < 3; i++) {
        float d = WrapPi(ang[i] - g_settleAng[i]);
        if (d > dzA) g_settleAng[i] = WrapPi(ang[i] - dzA); else if (d < -dzA) g_settleAng[i] = WrapPi(ang[i] + dzA);
    }
    V3 dp = f.pos - g_settle.pos; float L = Len(dp);
    Frame o = f;
    o.pos = L > dzP ? f.pos - dp * (dzP / L) : g_settle.pos;
    float cy = cosf(g_settleAng[0]), sy = sinf(g_settleAng[0]), cp = cosf(g_settleAng[1]), sp = sinf(g_settleAng[1]);
    V3 nf = { cp * sy, sp, cp * cy };   // forward from heading (about +Y, 0 = +Z) and pitch
    V3 nb = nf * -1.f;
    V3 nr0 = Norm(Cross(Y, nb)); if (flip) nr0 = nr0 * -1.f;
    V3 nu0 = Cross(nb, nr0);
    V3 nr = nr0 * cosf(g_settleAng[2]) + nu0 * sinf(g_settleAng[2]);
    o.axis[0] = Norm(nr); o.axis[2] = nb; o.axis[1] = Cross(nb, o.axis[0]);
    if (Dot(o.axis[1], f.axis[1]) < 0.f) o.axis[1] = o.axis[1] * -1.f;   // keep the game's handedness
    g_settle = o;
    return o;
}


struct NodeRec { void* node = nullptr; float clean[12]; float written[12]; bool have = false; };
static NodeRec g_rec;

// ---------------------------------------------------------------- frame FIFO (view update -> Present)
static RenderedEye g_fifo[8];
static volatile LONG g_fifoHead = 0, g_fifoTail = 0;   // head: next to write, tail: next to read
static SRWLOCK g_fifoLock = SRWLOCK_INIT;
static long g_seq = 0;
static volatile LONG g_presentAtLastPush = -1;
static int g_lastEye = 1;
static unsigned g_fifoDropped = 0, g_fifoReplaced = 0, g_fifoEmpty = 0;
static float g_prevBase[3][3]; static long long g_prevBaseTick = 0; static float g_angVel[3] = {};

// the eye for the frame starting now. Same thread as Present and no Present since the last push: this is the same
// frame updating again - keep its eye.
// Updates of the main node between two Presents: normally 1. If (nearly) every frame updates it twice on the Present
// thread, the second one is the same frame again (keep its eye); a single extra update is the next frame's, which
// can come before this frame's Present (pipelined renderer) - the FIFO keeps it for the next Present.
static volatile LONG g_updatesSincePresent = 0;
static unsigned g_multiHist = 0; static bool g_multiUpdate = false;
static void CountPresent() {
    LONG n = InterlockedExchange(&g_updatesSincePresent, 0);
    g_multiHist = (g_multiHist << 1) | (n >= 2 ? 1u : 0u);
    int c = 0; for (unsigned b = g_multiHist; b; b &= b - 1) c++;
    bool m = c >= 26;
    if (m != g_multiUpdate) { g_multiUpdate = m; LOGI("camera: %s view updates per frame", m ? "two or more" : "one"); }
}
static int NextEye(bool& replace) {
    InterlockedIncrement(&g_updatesSincePresent);
    replace = g_multiUpdate && GetCurrentThreadId() == g_presentThread && g_presentAtLastPush == g_presents && g_fifoHead != g_fifoTail;
    if (replace) return g_lastEye;
    g_lastEye ^= 1;
    return g_lastEye;
}

static void Push(const RenderedEye& r, bool replace) {
    AcquireSRWLockExclusive(&g_fifoLock);
    if (replace && g_fifoHead != g_fifoTail) { g_fifo[(g_fifoHead - 1) & 7] = r; g_fifoReplaced++; }
    else {
        if (g_fifoHead - g_fifoTail >= 4) { g_fifoTail = g_fifoHead - 3; g_fifoDropped++; }   // nobody presented: keep the newest
        g_fifo[g_fifoHead & 7] = r; g_fifoHead++;
    }
    g_presentAtLastPush = g_presents;
    ReleaseSRWLockExclusive(&g_fifoLock);
}

bool CameraTakeRendered(RenderedEye& out) {
    CountPresent();
    AcquireSRWLockExclusive(&g_fifoLock);
    bool ok = g_fifoHead - g_fifoTail > g_cam.frameDelay;
    if (ok) {
        // more than one waiting while the producer runs on another thread: the oldest is the one this Present shows
        out = g_fifo[g_fifoTail & 7]; g_fifoTail++;
    } else g_fifoEmpty++;
    ReleaseSRWLockExclusive(&g_fifoLock);
    return ok;
}

bool CameraRenderSize(unsigned& w, unsigned& h) {
    char* c = (char*)g_mainNode;
    if (!c || !game::Readable(c + game::kVpW, 8)) return false;
    w = *(unsigned*)(c + game::kVpW); h = *(unsigned*)(c + game::kVpH);
    return w >= 64 && h >= 64 && w <= 16384 && h <= 16384;
}

bool CameraRecordingEye(int& eye, bool& mono) {
    AcquireSRWLockShared(&g_fifoLock);
    bool ok = g_fifoHead != g_fifoTail;
    if (ok) { const RenderedEye& r = g_fifo[g_fifoTail & 7]; eye = r.drawEye & 1; mono = r.drawMono; }
    ReleaseSRWLockShared(&g_fifoLock);
    if (!ok) { eye = g_cam.curEye & 1; mono = g_cam.curMono; return false; }
    if (eye != (g_cam.curEye & 1) || mono != g_cam.curMono) g_cam.uiEyeAhead++;   // the camera of a later frame was already set
    return true;
}

bool CameraFrameIsVR() { return g_presents - g_cam.lastVrSeq <= 3; }


// ---------------------------------------------------------------- synchronized sequential (same game tick)
// UEVR's "Synchronized Sequential": two frames on the same engine tick, the game world does not advance between them.
// Here: the game clock step (exe+42E890 on the game timer) is held on every second tick - delta 0, the time stays -
// and the held delta is added to the next tick, so game speed is unchanged. The render frame of a held tick draws the
// second eye from the same camera base as the first; everything the game simulates (characters, physics, particles,
// animation) is in the same state for both eyes. World motion then updates at half the frame rate (as in UEVR).
// Ticks -> render frames: the main loop ticks the clock once per frame and the renderer draws each tick once, so
// render frame r shows tick r + c. c is the smallest (ticks - render frames) seen at the main node's view update (the
// renderer can never be ahead of the tick it draws; the main thread may be one tick ahead).

static volatile LONG g_tick = 0;
static volatile LONG g_mainRenders = 0; static int g_uiC = INT_MAX, g_uiWinMin = INT_MAX, g_uiWinN = 0; static volatile DWORD g_uiRenderTid = 0;
// 0.7.3: the eye the HUD being laid out NOW will be drawn in. The game's update (main thread: clock tick, GUI layout) runs
// ahead of its renderer: render frame r shows tick r + c. g_cam.curEye is the eye of the frame the renderer set up LAST, so a
// layout made j frames ahead of it belongs to eye curEye ^ (j & 1) (alternate eye and synchronized pairs both alternate the
// eyes frame by frame) - 0.7.2 used curEye as it was, and in alternate eye / synchronized the HUD of every frame was placed
// for the OTHER eye: the two HUDs landed on the wrong sides, did not fuse and did not converge (0.7.2 log).
static volatile LONG g_uiAheadHist[4] = {};
static volatile LONG g_layEye[3] = {};   // 0.9.5: HUD layouts placed for the left eye, the right eye, the head-centre view
static int LayoutEyeImpl() {
    int e = g_cam.curEye & 1;
    bool alternates = g_cam.mode == VRMODE_STEREO || g_cam.mode == VRMODE_SYNCED;   // reconstruction keeps curEye: its HUD was right in the 0.7.2 log
    if (!alternates || g_cam.curMono) return e;
    // 0.9.4 / 0.9.5: laid out by the renderer itself - the eye of the frame it is RECORDING (the FIFO the D3D12 placement uses), not the camera
    // set last: the renderer can set the next frame's camera before it lays out this frame's GUI (the HUD was then placed for the other eye).
    // 0.9.5: checked before the main-thread prediction's own conditions (in 0.9.4 an uncalibrated prediction returned first)
    if (g_uiRenderTid != 0 && GetCurrentThreadId() == g_uiRenderTid) {
        int re = e; bool rm = false;
        if (CameraRecordingEye(re, rm) && !rm) { InterlockedIncrement(&g_uiAheadHist[(re & 1) != e ? 1 : 0]); return re & 1; }
        InterlockedIncrement(&g_uiAheadHist[0]); return e;
    }
    if (!o_FrameTime || g_uiC == INT_MAX || g_uiRenderTid == 0) return e;
    int j = (int)(g_tick - g_mainRenders) - g_uiC;
    if (j < 0) j = 0;
    if (j > 3) { InterlockedIncrement(&g_uiAheadHist[3]); return e; }   // far ahead (a loading stall): not predictable
    InterlockedIncrement(&g_uiAheadHist[j]);
    return e ^ (j & 1);
}
int CameraLayoutEye() {
    int e = LayoutEyeImpl();
    // 0.9.6: the HUD laid out now is shown with the NEXT frame (the 0.9.3 - 0.9.5 logs: left / right layouts equal, and both the camera set
    // last and the recorded frame - they agree 89 % of the time - gave two HUDs that never fused). ui_eye_next off = the recorded frame's eye.
    if (g_set.uiEyeNext && !g_cam.curMono && (g_cam.mode == VRMODE_STEREO || g_cam.mode == VRMODE_SYNCED)) e ^= 1;
    InterlockedIncrement(&g_layEye[g_cam.curMono ? 2 : (e & 1)]);
    return e;
}
void CameraLayoutEyeCounts(long out[3]) { for (int i = 0; i < 3; i++) out[i] = InterlockedExchange(&g_layEye[i], 0); }
void CameraLayoutEyeStats(long out[4]) { for (int i = 0; i < 4; i++) out[i] = InterlockedExchange(&g_uiAheadHist[i], 0); }   // 0.9.5: per report period
static volatile unsigned char g_holdRing[64];
static long long g_heldDelta = 0;
// the game's render options (game thread), only as the player chose them in game_aa / game_upscaling.
// The game clock (synchronized stereo): Engine::UpdateFrameTime, once a frame on the main thread. engine+kDt is the
// frame time the simulation steps with (float seconds, time scale applied), +kDtRaw the same without the time scale;
// the game time accumulates kDt at the start of the next call. A held tick keeps 1/32 of its step (a step of 0 made
// character controllers drop their momentum in the reference mod) and the held part is added to the next tick, so the
// game's time over a pair is exact and game speed is unchanged.
static float g_heldDt = 0.f, g_heldDtRaw = 0.f;
static volatile LONG g_clockCalls = 0;
static double g_clockGameSum = 0.0, g_clockRealSum = 0.0; static long long g_clockLast = 0;   // clock check (speed hacks)
static void __fastcall H_FrameTime(void* engine) {
    o_FrameTime(engine);
    char* e = (char*)engine;
    if (!game::Readable(e + game::kDt, 8)) return;
    InterlockedIncrement(&g_clockCalls);
    float* dt = (float*)(e + game::kDt); float* raw = (float*)(e + game::kDtRaw);
    bool halted = game::GameHalted() || !(*dt > 0.f);
    g_gamePaused = halted;   // the game's own pause (pause menu, its screens, photo mode)
    long long now = (long long)modtime::Now100ns();
    g_pausedSeen = now;
    if (g_clockLast && now > g_clockLast && *raw > 0.f && *raw < 1.f) { g_clockGameSum += *raw; g_clockRealSum += (double)(now - g_clockLast) * 1e-7; }
    g_clockLast = now;
    LONG n = InterlockedIncrement(&g_tick);
    bool hold = g_cam.mode == VRMODE_SYNCED && CameraFrameIsVR() && (n & 1) && !halted;
    if (hold && *dt > 0.f && *dt < 1.f) {
        // 0.7: a held tick keeps sync_hold of its step (was 1/32: the cloth solver saw a step of 0.5 ms followed by one of 33 ms
        // and jittered); the rest still goes to the next tick, the game time over a pair is exact
        float hk = g_cam.syncHold; if (!(hk >= 0.03f)) hk = 0.03f; if (hk > 1.f) hk = 1.f;
        float keep = *dt * hk, keepRaw = *raw * hk;
        g_heldDt += *dt - keep; g_heldDtRaw += *raw - keepRaw;
        *dt = keep; *raw = keepRaw; g_cam.heldTicks++;
    } else {
        hold = false;
        if (g_heldDt > 0.f) {
            // the held time back on the next real tick; a long pause in between: dropped (never one huge step)
            if (g_heldDt < 0.25f && !halted) { *dt += g_heldDt; *raw += g_heldDtRaw; }
            g_heldDt = g_heldDtRaw = 0.f;
        }
    }
    g_holdRing[n & 63] = hold ? 1 : 0;
    fp::GameTick();   // game thread, once per frame
}

static unsigned g_syncAltFrames = 0;   // 0.6.40: synchronized frames drawn alternating (no clock to pair with)
static long g_renderSeq = 0;
static int g_lagC = INT_MIN, g_lagWinMin = INT_MAX, g_lagWinN = 0, g_lagHigh = 0;
static float g_lagScore[3] = {}; static int g_lagAuto = 0;
// held tick for the frame drawn now (render thread, main node). moved = the game moved its camera since the last frame.
// The counters give the tick up to a constant; which constant is found from the picture: on a held tick the game
// clock stands still, so the game camera does not move (stick / keyboard turning and walking are time based) -
// the right offset k is the one whose held frames are the frames where the camera stood still while it otherwise
// moves. Scores decay so a change (loading screen, a new level) is followed.
static bool RenderFrameIsHeld(bool moved) {
    long r = ++g_renderSeq;
    int d = (int)(g_tick - r);
    if (g_lagC == INT_MIN || d < g_lagC) g_lagC = d;
    if (d > g_lagC + 3) { if (++g_lagHigh > 10) { g_lagC = d; g_lagHigh = 0; } } else g_lagHigh = 0;   // ticks without frames (loading)
    if (d < g_lagWinMin) g_lagWinMin = d;
    if (++g_lagWinN >= 240) { g_lagC = g_lagWinMin; g_lagWinMin = INT_MAX; g_lagWinN = 0; }
    static unsigned motion = 0; motion = (motion << 1) | (moved ? 1u : 0u);
    bool active = (motion & 0xFF) && __builtin_popcount(motion & 0xFF) >= 2;   // the camera is moving these frames
    {   // 0.6.52: no evidence for a while after the clock held no ticks (pause, inventory, loading) or the base moved: the
        // first frames after it scored a wrong offset once (0.6.51 log, 169 s: offset 1 for 7 s right after a pause)
        static unsigned s_lastHeld = 0, s_still = 0; static int s_warm = 0, s_lastC = INT_MIN;
        if (g_cam.heldTicks == s_lastHeld) { if (++s_still > 30) s_warm = 120; } else s_still = 0;
        s_lastHeld = g_cam.heldTicks;
        if (g_lagC != s_lastC) { s_lastC = g_lagC; s_warm = 120; }
        if (s_warm > 0) { s_warm--; active = false; }
    }
    for (int k = 0; k < 3; k++) {
        g_lagScore[k] *= 0.995f;
        if (active && g_holdRing[(r + g_lagC - k) & 63]) g_lagScore[k] += moved ? -1.f : 1.f;
    }
    int best = 0; for (int k = 1; k < 3; k++) if (g_lagScore[k] > g_lagScore[best] + 2.f) best = k;
    // 0.6.48: switch only on clear evidence (well apart), and go back to offset 0 - the one every decisive log found on
    // every runtime - when the evidence for the current one is gone (it could stick on a wrong offset for the whole run)
    if (g_lagScore[best] > 15.f && best != g_lagAuto && g_lagScore[best] > g_lagScore[g_lagAuto] + 20.f) {
        g_lagAuto = best; LOGI("camera: synchronized stereo: clock offset %d (scores %.0f %.0f %.0f)", best, g_lagScore[0], g_lagScore[1], g_lagScore[2]);
    } else if (g_lagAuto != 0 && g_lagScore[g_lagAuto] < 5.f) {
        int was = g_lagAuto; g_lagAuto = 0; LOGI("camera: synchronized stereo: clock offset back to 0 - no clear evidence for %d (scores %.0f %.0f %.0f)", was, g_lagScore[0], g_lagScore[1], g_lagScore[2]);
    }
    int k = g_cam.syncLag >= 0 ? g_cam.syncLag : g_lagAuto;
    g_cam.syncLagNow = (unsigned)k;
    return g_holdRing[(r + g_lagC - k) & 63] != 0;
}


// ---------------------------------------------------------------- head aim (pattern A: the aiming camera)
// The game camera's update (Camera_Z vtable slot, game.h) builds camera+0x3F0 / +0x430 from its position and look
// direction once a frame, before the game logic that aims from it (crossbow / sling reticle, target acquisition) and
// before the render setup. Head aim turns that camera to where the player looks (the rendered base frame + the head's
// orientation, roll removed); the render hook takes the turn back out (the clean / turned pair is remembered), so the
// picture is exactly what it would be without it.
typedef void(__fastcall* PFN_CamUpdate)(void* cam, void* obj);
static PFN_CamUpdate o_CamUpdate = nullptr;
struct AimEntry { float clean[12]; float turned[12]; long long t; };
static AimEntry g_aim[8]; static int g_aimN = 0; static SRWLOCK g_aimLock = SRWLOCK_INIT;
static float g_aimRel[3][3] = { { 1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 1 } };   // render base axes in the camera frame
static float g_aimRelPos[3] = { 0, 0, 0 };
static V3 g_aimSmoothDir = { 0, 0, -1 }; static bool g_aimSmoothHave = false;
static volatile LONG g_aimApplied = 0, g_aimExact = 0, g_aimMiss = 0;
static float g_aimBlend = 0.f; static long long g_aimBlendT = 0, g_aimLastTurned = 0;
static volatile long long g_gameCamMove100ns = 0;   // when the GAME last moved its camera (head aim excluded)

// engine <-> mod matrix conventions: zouna_math.h
using zm::EngToT; using zm::TToEng; using zm::RigidInverse;
static bool HeadAimWanted() {
    int m = g_cam.headAim;
    if (m == 1) return true;
    if (m != 2) return false;
    if (PadsLTHeld()) return true;
    DWORD pid = 0; GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    bool swap = GetSystemMetrics(SM_SWAPBUTTON) != 0;
    return pid == GetCurrentProcessId() && (GetAsyncKeyState(swap ? VK_LBUTTON : VK_RBUTTON) & 0x8000);
}
// 0.5: head aim also turns the camera's look-at target (+0x488): the game's aiming takes the ray from the camera position
// to that point (0.4's log: the matrix was turned 500 times per 10 s and the sling did not follow). The game's own
// target is kept here, given back before the next camera update (nothing builds up) and to first person.
static void* g_aimTgtCam = nullptr; static float g_aimTgtClean[3], g_aimTgtTurned[3]; static bool g_aimTgtSet = false;
static volatile LONG g_aimTgtWrites = 0;
bool HeadAimCleanTarget(void* cam, float* t) {   // firstperson.cpp: the game's own target while head aim turned it
    if (!g_aimTgtSet || cam != g_aimTgtCam) return false;
    const float* cur = (const float*)((char*)cam + game::kCamTarget);
    if (memcmp(cur, g_aimTgtTurned, 12)) return false;
    memcpy(t, g_aimTgtClean, 12); return true;
}
// 0.6: ... and the camera NODE. Camera_Z only follows: its update (exe+18F0A00) takes the position from the node it is
// given (world matrix [node+0x148], translation +0x30) and, without a look-at object, its target from the node's
// orientation quaternion (node+0x50, x y z w, local forward +X). The game's gameplay (sling, throws, the reticle)
// asks that node, not Camera_Z: 0.4 turned Camera_Z's matrix, 0.5 its look-at target, and the aim never followed.
// The node's quaternion and world rotation are turned too - only after checking that the node's forward IS the
// camera's forward (else it is not the camera's node: left alone) - and given back before the next update when
// the game did not write them again itself.
static void* g_aimNode = nullptr; static float g_aimNodeClean[4], g_aimNodeTurned[4], g_aimNodeMClean[12], g_aimNodeMTurned[12];
static float* g_aimNodeM = nullptr; static bool g_aimNodeSet = false, g_aimNodeOff = false;
static volatile LONG g_aimNodeWrites = 0, g_aimNodeNotCam = 0, g_aimNodeRewritten = 0, g_aimNodeLeft = 0;
static V3 QRot(const float* q, V3 v) {   // v + 2w(q x v) + 2 q x (q x v), as the game's update does it
    V3 u = { q[0], q[1], q[2] }; float w = q[3];
    V3 t = Cross(u, v) * 2.f;
    return v + t * w + Cross(u, t);
}
static void QFromMat(const float m[3][3], float* q) {   // m[r][c], column-vector rotation
    float tr = m[0][0] + m[1][1] + m[2][2];
    if (tr > 0.f) { float s = sqrtf(tr + 1.f) * 2.f; q[3] = 0.25f * s; q[0] = (m[2][1] - m[1][2]) / s; q[1] = (m[0][2] - m[2][0]) / s; q[2] = (m[1][0] - m[0][1]) / s; }
    else if (m[0][0] > m[1][1] && m[0][0] > m[2][2]) { float s = sqrtf(1.f + m[0][0] - m[1][1] - m[2][2]) * 2.f; q[3] = (m[2][1] - m[1][2]) / s; q[0] = 0.25f * s; q[1] = (m[0][1] + m[1][0]) / s; q[2] = (m[0][2] + m[2][0]) / s; }
    else if (m[1][1] > m[2][2]) { float s = sqrtf(1.f + m[1][1] - m[0][0] - m[2][2]) * 2.f; q[3] = (m[0][2] - m[2][0]) / s; q[0] = (m[0][1] + m[1][0]) / s; q[1] = 0.25f * s; q[2] = (m[1][2] + m[2][1]) / s; }
    else { float s = sqrtf(1.f + m[2][2] - m[0][0] - m[1][1]) * 2.f; q[3] = (m[1][0] - m[0][1]) / s; q[0] = (m[0][2] + m[2][0]) / s; q[1] = (m[1][2] + m[2][1]) / s; q[2] = 0.25f * s; }
}
static void QMul(const float* a, const float* b, float* o) {   // a then applied after b: rot(a*b, v) = rot(a, rot(b, v))
    o[0] = a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1];
    o[1] = a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0];
    o[2] = a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3];
    o[3] = a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2];
}
static void HeadAimTurnNode(void* obj, const Frame& c, const Frame& aim) {
    if (!obj || !game::kObjWorld) return;
    float* q = (float*)((char*)obj + 0x50);
    if (!game::Readable(q, 16)) return;
    float ql = sqrtf(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]);
    if (!(ql > 0.98f && ql < 1.02f)) { InterlockedIncrement(&g_aimNodeNotCam); return; }
    V3 camFwd = c.axis[2] * -1.f, nodeFwd = QRot(q, V3{ 1.f, 0.f, 0.f });
    if (!(Dot(Norm(nodeFwd), camFwd) > 0.97f)) { InterlockedIncrement(&g_aimNodeNotCam); return; }
    // the turn, in the world: D v = sum_k aim.axis[k] * (c.axis[k] . v)
    float D[3][3];
    for (int r = 0; r < 3; r++) for (int col = 0; col < 3; col++) {
        V3 e = { col == 0 ? 1.f : 0.f, col == 1 ? 1.f : 0.f, col == 2 ? 1.f : 0.f };
        V3 v = aim.axis[0] * Dot(c.axis[0], e) + aim.axis[1] * Dot(c.axis[1], e) + aim.axis[2] * Dot(c.axis[2], e);
        D[r][col] = r == 0 ? v.x : r == 1 ? v.y : v.z;
    }
    float qd[4], qn[4]; QFromMat(D, qd); QMul(qd, q, qn);
    float nl = sqrtf(qn[0] * qn[0] + qn[1] * qn[1] + qn[2] * qn[2] + qn[3] * qn[3]);
    if (!(nl > 0.5f)) return;
    for (int i = 0; i < 4; i++) qn[i] /= nl;
    if (!(Dot(Norm(QRot(qn, V3{ 1.f, 0.f, 0.f })), aim.axis[2] * -1.f) > 0.97f)) { InterlockedIncrement(&g_aimNodeNotCam); return; }
    memcpy(g_aimNodeClean, q, 16); memcpy(q, qn, 16); memcpy(g_aimNodeTurned, qn, 16);
    g_aimNodeM = nullptr;
    float* const* pm = (float* const*)((char*)obj + game::kObjWorld);
    if (game::Readable(pm, 8) && *pm && game::Readable(*pm, 64)) {   // its world matrix: rows are the node's axes
        float* m = *pm; memcpy(g_aimNodeMClean, m, 48);
        for (int r = 0; r < 3; r++) {
            V3 a = { m[r * 4], m[r * 4 + 1], m[r * 4 + 2] };
            V3 b = { D[0][0] * a.x + D[0][1] * a.y + D[0][2] * a.z, D[1][0] * a.x + D[1][1] * a.y + D[1][2] * a.z, D[2][0] * a.x + D[2][1] * a.y + D[2][2] * a.z };
            m[r * 4] = b.x; m[r * 4 + 1] = b.y; m[r * 4 + 2] = b.z;
        }
        memcpy(g_aimNodeMTurned, m, 48); g_aimNodeM = m;
    }
    g_aimNode = obj; g_aimNodeSet = true; InterlockedIncrement(&g_aimNodeWrites);
}
static void HeadAimNodeBack(void* obj) {   // before the camera update: the game's own orientation back, if it is still ours
    if (!g_aimNodeSet) return;
    g_aimNodeSet = false;
    if (obj != g_aimNode) return;
    float* q = (float*)((char*)obj + 0x50);
    if (!game::Readable(q, 16)) return;
    if (memcmp(q, g_aimNodeTurned, 16)) {   // the game set it again itself
        InterlockedIncrement(&g_aimNodeRewritten);
        // feedback guard: a camera that takes its next orientation FROM the node would follow the turn and the view
        // would drift with the head. The new value nearer the turned one than the game's own, with a turn of more
        // than 8 degrees, 30 frames in a row: node turning is switched off for the session.
        auto qd = [](const float* a, const float* b) { float d = fabsf(a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3]); return d > 1.f ? 1.f : d; };
        float toTurned = qd(q, g_aimNodeTurned), toClean = qd(q, g_aimNodeClean), turn = qd(g_aimNodeClean, g_aimNodeTurned);
        static int s_follow = 0;
        if (turn < 0.9976f && toTurned > toClean) { if (++s_follow >= 30 && !g_aimNodeOff) { g_aimNodeOff = true; LOGW("camera: head aim - the game camera follows its own node's turned orientation (it would drift with your head): node turning switched off"); } }
        else s_follow = 0;
        return;
    }
    memcpy(q, g_aimNodeClean, 16); InterlockedIncrement(&g_aimNodeLeft);
    if (g_aimNodeM && game::Readable(g_aimNodeM, 48) && !memcmp(g_aimNodeM, g_aimNodeMTurned, 48)) memcpy(g_aimNodeM, g_aimNodeMClean, 48);
}
// 0.6: cutscene / scripted camera = the game camera does not look at the player close by (the same test first person
// uses: look-at point farther than fp_max_distance, or behind). 0.5 s before "cutscene", back at once.
static volatile bool g_cutscene = false; static long long g_cutFailSince = 0;
static volatile LONG g_cutFrames = 0, g_playFrames = 0;
static void CutsceneStep(void* cam, const float* clean, long long t) {
    if (!game::kCamTarget || !game::kCamPos) return;
    const float* tg = (const float*)((char*)cam + game::kCamTarget); const float* ps = (const float*)((char*)cam + game::kCamPos);
    if (!game::Readable(tg, 12) || !game::Readable(ps, 12)) return;
    Frame c = ReadFrame(clean);
    V3 d = { tg[0] - ps[0], tg[1] - ps[1], tg[2] - ps[2] };
    float l = Len(d), u = g_cam.unitsPerMetre;
    bool follows = l == l && l < g_cam.fpMaxDist * u && (l < 0.05f * u || Dot(c.axis[2] * -1.f, d * (1.f / l)) > 0.5f);
    if (follows) { g_cutFailSince = 0; g_cutscene = false; }
    else { if (!g_cutFailSince) g_cutFailSince = t; if (t - g_cutFailSince > 5000000) g_cutscene = true; }
    InterlockedIncrement(g_cutscene ? &g_cutFrames : &g_playFrames);
}
bool CameraInCutscene() { return g_cutscene; }

// depth of field: params+0xC is the blur amount, the game skips all DOF passes when it is 0 (its own path)
typedef void(__fastcall* PFN_DofPass)(void* self, void* view, float* params);
static PFN_DofPass o_DofPass = nullptr;
static volatile int g_dofMode = 1;
void CameraSetDof(const std::string& m) { g_dofMode = m == "game" ? 0 : m == "off" ? 2 : 1; }
static volatile LONG g_dofRuns = 0, g_dofOff = 0;
static void __fastcall H_DofPass(void* self, void* view, float* params) {
    int m = g_dofMode;   // 0 game, 1 off in cutscenes, 2 off
    bool off = m == 2 || (m == 1 && g_cutscene);
    if (off && g_cam.mode != VRMODE_SCREEN && !g_cam.flatNow && params && game::Readable(params + 3, 4) && params[3] > 0.f) {
        float keep = params[3]; params[3] = 0.f;
        o_DofPass(self, view, params);
        params[3] = keep; InterlockedIncrement(&g_dofOff);
        return;
    }
    if (params && game::Readable(params + 3, 4) && params[3] > 0.f) InterlockedIncrement(&g_dofRuns);
    o_DofPass(self, view, params);
}

static void __fastcall H_CamUpdate(void* cam, void* obj) {
    if (g_aimTgtSet && cam == g_aimTgtCam && game::kCamTarget) {   // the game's target back before the game updates
        float* cur = (float*)((char*)cam + game::kCamTarget);
        if (game::Readable(cur, 12) && !memcmp(cur, g_aimTgtTurned, 12)) memcpy(cur, g_aimTgtClean, 12);
        g_aimTgtSet = false;
    }
    if (g_aimNodeSet && cam == g_aimTgtCam) HeadAimNodeBack(obj);
    o_CamUpdate(cam, obj);
    float* M = (float*)((char*)cam + game::kCamWorld);
    if (!game::Readable(M, 128)) return;
    AimEntry e = {}; EngToT(M, e.clean); memcpy(e.turned, e.clean, 48); e.t = (long long)modtime::Now100ns();
    {   // did the GAME move its camera? (the flat-screen rules: pause menu vs photo mode)
        static float s_prev[12]; static bool s_have = false;
        if (s_have && memcmp(e.clean, s_prev, 48)) g_gameCamMove100ns = e.t;
        memcpy(s_prev, e.clean, 48); s_have = true;
    }
    // only the camera the player looks through (the main viewport's): another camera (cinematic / UI 3D) is left alone
    bool mainCam = game::CameraOfViewport(g_mainNode) == cam;
    if (mainCam) CutsceneStep(cam, e.clean, e.t);
    bool vr = mainCam && g_cam.mode != VRMODE_SCREEN && !g_cam.flatNow && g_cam.havePose && xrb::ClientHostConnected();
    float target = vr && HeadAimWanted() ? 1.f : 0.f;
    float dt = g_aimBlendT ? (float)(e.t - g_aimBlendT) * 1e-7f : 0.f; if (mainCam) g_aimBlendT = e.t;
    if (!(dt > 0.f && dt < 0.25f)) dt = 0.f;
    if (mainCam) g_aimBlend += (target - g_aimBlend) * (1.f - expf(-dt / 0.04f));
    if (target == 0.f && g_aimBlend < 0.01f) { g_aimBlend = 0.f; g_aimSmoothHave = false; }
    xrb::IpcPose pose[2]; xrb::IpcFov fov[2]; int64_t pt = 0;
    if (mainCam && g_aimBlend > 0.f && xrb::ClientGetLatestPoses(pose, fov, &pt) && (pose[0].qw || pose[0].qx || pose[0].qy || pose[0].qz)) {
        Frame c = ReadFrame(e.clean);
        if (FrameValid(c)) {
            float rel[3][3], relP[3];
            AcquireSRWLockShared(&g_aimLock); memcpy(rel, g_aimRel, sizeof rel); memcpy(relP, g_aimRelPos, sizeof relP); ReleaseSRWLockShared(&g_aimLock);
            Frame base;
            for (int k = 0; k < 3; k++) base.axis[k] = c.axis[0] * rel[0][k] + c.axis[1] * rel[1][k] + c.axis[2] * rel[2][k];
            base.pos = c.pos + c.axis[0] * relP[0] + c.axis[1] * relP[1] + c.axis[2] * relP[2];
            float hq[4]; HeadQuat(pose, hq);
            float R[3][3]; QuatToMat(hq[0], hq[1], hq[2], hq[3], R);
            V3 hf = { -R[0][2], -R[1][2], -R[2][2] };
            float sm = g_cam.headAimSmooth;
            if (sm > 0.01f && g_aimSmoothHave) { if (dt > 0.f) { float k = 1.f - expf(-dt / (0.15f * sm)); g_aimSmoothDir = Norm(g_aimSmoothDir + (hf - g_aimSmoothDir) * k); } }
            else g_aimSmoothDir = hf;
            g_aimSmoothHave = true;
            V3 lf = g_aimSmoothDir;
            V3 fwd = Norm(base.axis[0] * lf.x + base.axis[1] * lf.y + base.axis[2] * lf.z), camFwd = c.axis[2] * -1.f;
            fwd = Norm(camFwd * (1.f - g_aimBlend) + fwd * g_aimBlend);
            V3 right = Cross(kWorldUp, fwd * -1.f);   // level aim frame (no head roll)
            if (Len(right) < 1e-3f) right = c.axis[0]; else right = Norm(right);
            if (Dot(right, c.axis[0]) < -0.5f && Dot(fwd, camFwd) > 0.f) right = right * -1.f;
            V3 up = Norm(Cross(fwd * -1.f, right));
            V3 aimPos = c.pos;
            if (g_cam.headAimFromEyes) {
                float s = g_cam.unitsPerMetre * g_cam.worldScale;
                V3 hp = { 0.5f * (pose[0].px + pose[1].px) * s, 0.5f * (pose[0].py + pose[1].py) * s, 0.5f * (pose[0].pz + pose[1].pz) * s };
                V3 eyes = base.pos + base.axis[0] * hp.x + base.axis[1] * hp.y + base.axis[2] * hp.z;
                if (g_cam.fpActive) eyes = eyes + fwd * (0.25f * g_cam.unitsPerMetre);   // clear of the character's own head
                aimPos = c.pos + (eyes - c.pos) * g_aimBlend;
            }
            Frame aim; aim.axis[0] = right; aim.axis[1] = up; aim.axis[2] = fwd * -1.f; aim.pos = aimPos;
            if (FrameValid(aim)) {
                WriteFrame(e.turned, aim);
                float W[16], V[16]; TToEng(e.turned, W); RigidInverse(W, V);
                memcpy(M, W, 64); memcpy((char*)cam + game::kCamView, V, 64);
                g_aimLastTurned = e.t; InterlockedIncrement(&g_aimApplied);
                g_aimTgtCam = cam;
                if (g_cam.headAimTarget && !g_aimNodeOff) HeadAimTurnNode(obj, c, aim);
                if (g_cam.headAimTarget && game::kCamTarget && game::kCamPos) {
                    float* tg = (float*)((char*)cam + game::kCamTarget); const float* ps = (const float*)((char*)cam + game::kCamPos);
                    if (game::Readable(tg, 12) && game::Readable(ps, 12)) {
                        V3 T = { tg[0], tg[1], tg[2] }, P = { ps[0], ps[1], ps[2] };
                        float dist = Len(T - P);
                        if (dist == dist && dist > 0.05f * g_cam.unitsPerMetre && dist < 500.f * g_cam.unitsPerMetre) {
                            V3 nt = P + fwd * dist;
                            memcpy(g_aimTgtClean, tg, 12);
                            tg[0] = nt.x; tg[1] = nt.y; tg[2] = nt.z;
                            memcpy(g_aimTgtTurned, tg, 12); g_aimTgtCam = cam; g_aimTgtSet = true;
                            InterlockedIncrement(&g_aimTgtWrites);
                        }
                    }
                }
            }
        }
    }
    if (mainCam) {
        AcquireSRWLockExclusive(&g_aimLock);
        memmove(&g_aim[1], &g_aim[0], sizeof(AimEntry) * 7); g_aim[0] = e; if (g_aimN < 8) g_aimN++;
        ReleaseSRWLockExclusive(&g_aimLock);
    }
}
// render thread: the camera the game wrote, without the head aim turn
static void HeadAimUnturn(float* clean) {
    if (!o_CamUpdate || !g_aimLastTurned || (long long)modtime::Now100ns() - g_aimLastTurned > 5000000) return;
    AimEntry ring[8]; int n;
    AcquireSRWLockShared(&g_aimLock); n = g_aimN; memcpy(ring, g_aim, sizeof(AimEntry) * n); ReleaseSRWLockShared(&g_aimLock);
    for (int i = 0; i < n; i++) if (!memcmp(ring[i].turned, clean, 48)) {
        if (memcmp(ring[i].turned, ring[i].clean, 48)) { memcpy(clean, ring[i].clean, 48); InterlockedIncrement(&g_aimExact); }
        return;
    }
    InterlockedIncrement(&g_aimMiss);
}
static void HeadAimNoteBase(const float* clean, const Frame& base) {
    if (!o_CamUpdate) return;
    Frame c = ReadFrame(clean);
    float rel[3][3]; for (int j = 0; j < 3; j++) for (int k = 0; k < 3; k++) rel[j][k] = Dot(c.axis[j], base.axis[k]);
    V3 d = base.pos - c.pos; float rp[3] = { Dot(d, c.axis[0]), Dot(d, c.axis[1]), Dot(d, c.axis[2]) };
    AcquireSRWLockExclusive(&g_aimLock); memcpy(g_aimRel, rel, sizeof rel); memcpy(g_aimRelPos, rp, sizeof rp); ReleaseSRWLockExclusive(&g_aimLock);
}


// ---------------------------------------------------------------- hooks
static volatile int g_nodeEye = 0; static volatile bool g_nodeMono = false; static volatile bool g_nodePosed = false;
static bool s_moved = false;
static float s_moveAmt = 0.f, s_moveAvg = 0.f;
static bool s_moveBig = false;
static unsigned g_moveBigN = 0;
static thread_local bool tl_capProj = false, tl_projGot = false;
static thread_local float tl_proj[16];
static float g_gameProj[16]; static bool g_gameProjHave = false;   // the game's own projection of the main viewport (log)
static unsigned g_fovTanWrites = 0, g_projOther = 0, g_projNotPersp = 0;
static float g_gameTan[2] = {};   // the game's own tangents (x, y) of the main viewport, for the log

// the frustum the main viewport is drawn with this frame (l, r, u, d)
static const float* DrawnTan() { return g_nodeMono ? g_cam.monoTan : CameraDrawTan(g_nodeEye); }
// one symmetric frustum covering everything any eye of any method draws (culling, LOD)
static void CoverTan(float& X, float& Y) {
    X = fmaxf(-g_cam.monoTan[0], g_cam.monoTan[1]); Y = fmaxf(g_cam.monoTan[2], -g_cam.monoTan[3]);
    for (int e = 0; e < 2; e++) {
        const float* t = CameraDrawTan(e);
        X = fmaxf(X, fmaxf(-t[0], t[1])); Y = fmaxf(Y, fmaxf(t[2], -t[3]));
        X = fmaxf(X, fmaxf(-g_cam.eyeTan[e][0], g_cam.eyeTan[e][1])); Y = fmaxf(Y, fmaxf(g_cam.eyeTan[e][2], -g_cam.eyeTan[e][3]));
    }
}

typedef void(__fastcall* PFN_ViewSetup)(void* vp, uintptr_t a, uintptr_t b);
typedef float*(__fastcall* PFN_GetProj)(void* vp, uintptr_t idx);
typedef void(__fastcall* PFN_FovTan)(void* vp);
static PFN_ViewSetup o_ViewSetup = nullptr;
static PFN_GetProj o_GetProj = nullptr;
static PFN_FovTan o_FovTan = nullptr;

// x / y terms of the projection = the frustum drawn; the game's depth rows and TAA jitter are kept
static float* __fastcall H_GetProj(void* vp, uintptr_t idx) {
    float* out = o_GetProj(vp, idx);
    if (!out) return out;
    if (vp != g_mainNode) { g_projOther++; return out; }
    if (!(fabsf(out[11] - 1.f) < 1e-3f && fabsf(out[15]) < 1e-3f && out[0] > 0.f && out[5] > 0.f)) { g_projNotPersp++; return out; }   // perspective only
    if (!g_gameProjHave || !g_nodePosed) { memcpy(g_gameProj, out, 64); g_gameProjHave = true; }
    if (!g_nodePosed) return out;
    const float* t = DrawnTan();
    float w = t[1] - t[0], h = t[2] - t[3];
    if (!(w > 0.05f && h > 0.05f)) return out;
    const float* jit = (const float*)((char*)vp + game::kVpJitter);
    float jx = 0.f, jy = 0.f;
    if (game::Readable(jit, 8)) { jx = jit[0]; jy = jit[1]; if (!(fabsf(jx) < 0.1f && fabsf(jy) < 0.1f)) jx = jy = 0.f; }
    // left-handed view (+z forward, w = z): ndc.x = P0 x/z + P8, so P8 = -(r + l) / (r - l) (zouna_math.h)
    zm::ProjXY(out, t, jx, jy);
    g_cam.projPatched++;
    if (tl_capProj && !tl_projGot) {   // reconstruction: the projection the picture is drawn with, in the mod's right-handed
        zm::ProjToRH(out, tl_proj);     // form (view z = -forward: the third row negated, [11] = -1)
        tl_projGot = true;
    }
    return out;
}

// wide culling: the culling and LOD read the viewport's symmetric tangents - they get one frustum that covers both
// eyes, so nothing at an eye's outer side is culled; the picture itself has the eye's own (projection getter)
static void __fastcall H_FovTan(void* vp) {
    o_FovTan(vp);
    if (vp != g_mainNode) return;
    char* v = (char*)vp;
    if (!game::Readable(v + game::kVpTanX, 0x10)) return;
    float* tx = (float*)(v + game::kVpTanX); float* ty = (float*)(v + game::kVpTanY);
    bool vr = g_presents - g_posedPresent <= 3 && g_cam.mode != VRMODE_SCREEN && !g_cam.flatNow;
    if (!vr) { g_gameTan[0] = *tx; g_gameTan[1] = *ty; return; }
    float X, Y;
    if (g_cam.wideCull || g_cam.symmetricView) CoverTan(X, Y);
    else { const float* t = DrawnTan(); X = fmaxf(-t[0], t[1]); Y = fmaxf(t[2], -t[3]); }
    if (!(X > 0.05f && Y > 0.05f && X < 20.f && Y < 20.f)) return;
    *tx = X; *ty = Y;
    g_cam.wideCullCalls++; g_fovTanWrites++;
}

// 0.6: wide culling at the source. UpdateFovTangents builds the camera's culling frustum (camera+0x140) itself, from
// the viewport's tangents, through exe+18F9B40 - before it returns. Widening the tangents after it (0.2 - 0.5) only
// changed what was stored, never the frustum the culling uses: the game's own ~50 deg view was culled against while
// the headset shows ~100 deg (things popped in at the sides). The builder gets the frustum that covers every eye of every
// stereo method - only the culling is wider: the picture keeps its size, nothing is rendered wider.
typedef void(__fastcall* PFN_CullBuild)(void* vp, void* fr, float a2, float nearZ, float farZ, float far2);
static PFN_CullBuild o_CullBuild = nullptr;
static volatile LONG g_cullWide = 0, g_cullGame = 0;
static void __fastcall H_CullBuild(void* vp, void* fr, float a2, float nearZ, float farZ, float far2) {
    if (vp == g_mainNode && g_cam.wideCull && g_cam.mode != VRMODE_SCREEN && !g_cam.flatNow && g_presents - g_posedPresent <= 3) {
        char* v = (char*)vp;
        if (game::Readable(v + game::kVpTanX, 8)) {
            float X, Y; CoverTan(X, Y);
            if (X > 0.05f && Y > 0.05f && X < 20.f && Y < 20.f) {
                float* tx = (float*)(v + game::kVpTanX); float* ty = (float*)(v + game::kVpTanY);
                if (*tx < X) *tx = X;
                if (*ty < Y) *ty = Y;
                InterlockedIncrement(&g_cullWide);
            }
        }
    } else if (vp == g_mainNode) InterlockedIncrement(&g_cullGame);
    o_CullBuild(vp, fr, a2, nearZ, farZ, far2);
}

static unsigned g_camRestored = 0, g_sharedCam = 0;
static void __fastcall H_ViewSetup(void* vp, uintptr_t a, uintptr_t b) {
    g_cam.nodeUpdates++;
    Tally(vp);
    RenderedEye reconRec; bool reconPush = false, reconReplace = false;
    char* cam = vp == g_mainNode ? (char*)game::CameraOfViewport(vp) : nullptr;
    if (vp != g_mainNode && g_mainNode && g_rec.have) {   // another viewport drawing from the main camera (reflections ...)
        static void* s_mainCam = nullptr; static unsigned s_n = 0;
        if (!(s_n++ & 63)) s_mainCam = game::CameraOfViewport(g_mainNode);
        if (s_mainCam && game::CameraOfViewport(vp) == s_mainCam) g_sharedCam++;
    }
    float* M = cam ? (float*)(cam + game::kCamWorld) : nullptr;
    float T[12] = {};
    bool vr = cam && g_cam.mode != VRMODE_SCREEN && !g_cam.flatNow && xrb::ClientHostConnected() && FetchPoses();
    if (cam) {
        if (!(fabsf(M[15] - 1.f) < 1e-3f)) { g_cam.badMatrix++; cam = nullptr; vr = false; }
    }
    if (cam) {
        EngToT(M, T);
        if (g_rec.node != vp || !g_rec.have || memcmp(T, g_rec.written, 48)) {   // the game wrote a new camera
            memcpy(g_rec.clean, T, 48); HeadAimUnturn(g_rec.clean); g_rec.node = vp; g_rec.have = true; g_cam.resyncs++;
        }
        static float s_lastClean[12];
        s_moved = memcmp(g_rec.clean, s_lastClean, 48) != 0;
        {   // amount of motion (rotation rows + position), against a slowly falling peak of recent motion
            float am = 0.f;
            for (int i = 0; i < 9; i++) am += fabsf(g_rec.clean[i] - s_lastClean[i]);
            float dp = 0.f; for (int i = 9; i < 12; i++) dp += fabsf(g_rec.clean[i] - s_lastClean[i]);
            static bool s_haveLast = false;
            bool cut = !s_haveLast || dp > 5.f || am > 1.5f;
            s_haveLast = true;
            s_moveAmt = cut ? 0.f : am + dp;
            if (cut) s_moveAvg = 0.f;
            else s_moveAvg = s_moveAmt > s_moveAvg ? s_moveAmt : s_moveAvg * 0.99f;
            s_moveBig = s_moveAmt > 1e-5f && s_moveAmt > s_moveAvg * 0.35f;
            if (s_moveBig) g_moveBigN++;
        }
        {   // judged on the GAME's camera (the camera update hook's record), never on the mod's turned / posed one
            long long nw = (long long)modtime::Now100ns();
            if (o_CamUpdate) { if (g_gameCamMove100ns > g_lastMove100ns) g_lastMove100ns = g_gameCamMove100ns; }
            else if (s_moved) g_lastMove100ns = nw;
        }
        memcpy(s_lastClean, g_rec.clean, 48);
        fp::NoteCamera(cam);   // the character the camera follows (first person)
        if (!vr) {   // VR off: the game's own camera stays in place
            g_nodePosed = false;
            if (memcmp(T, g_rec.clean, 48)) { TToEng(g_rec.clean, M); RigidInverse(M, (float*)(cam + game::kCamView)); }
            memcpy(g_rec.written, g_rec.clean, 48);
        }
    } else if (vp == g_mainNode) g_nodePosed = false;
    float eyePos[3] = {}; bool posedNow = false;
    float saveM[16], saveV[16]; bool saved = false;   // the camera as it was before the eye was written (keep_game_camera)
    if (vr && cam) { memcpy(saveM, M, 64); memcpy(saveV, cam + game::kCamView, 64); saved = true; }
    if (vr && g_rec.have && g_rec.node == vp) {
        g_cam.mainUpdates++;
        bool reconC = g_cam.mode == VRMODE_RECON && g_cam.reconCentre;
        bool mono = g_cam.mode == VRMODE_HEAD || reconC;
        bool synced = g_cam.mode == VRMODE_SYNCED && o_FrameTime;
        bool replace = false;
        int eye = NextEye(replace);
        if (mono) eye = 0;
        bool held = false;
        if (synced) {
            bool clockHeld = RenderFrameIsHeld(s_moveBig);
            long long nw = (long long)modtime::Now100ns();
            bool noClock = g_gamePaused || nw - g_pausedSeen > 1000000;
            static int s_firstRun = 0; static bool s_alt = false;
            if (clockHeld) s_firstRun = 0; else s_firstRun++;
            bool want = noClock || (s_alt && !clockHeld) || s_firstRun >= 4;
            if (want != s_alt) {
                s_alt = want;
                LOGI("camera: synchronized stereo: %s", want ? (noClock ? "the game clock is paused / stopped while VR is drawn (menus with 3D, photo mode) - the eyes alternate frame by frame"
                                                                      : "no held twin for 4 frames - the eyes alternate frame by frame")
                                                          : "the game clock runs again - eyes paired by the clock");
            }
            held = s_alt ? eye == 1 : clockHeld;
            if (s_alt) g_syncAltFrames++;
            eye = held ? 1 : 0; g_lastEye = eye;
            if (held) g_cam.syncPairs++;
        }
        bool reconm = g_cam.mode == VRMODE_RECON;
        if (reconm && !g_cam.reconAlternate) { eye = 0; g_lastEye = 0; }
        int pe = g_cam.swapEyes ? eye ^ 1 : eye;
        auto eyePose = [&](int e) {
            xrb::IpcPose p = g_cam.pose[e];
            if (mono) {
                p.px = 0.5f * (g_cam.pose[0].px + g_cam.pose[1].px); p.py = 0.5f * (g_cam.pose[0].py + g_cam.pose[1].py);
                p.pz = 0.5f * (g_cam.pose[0].pz + g_cam.pose[1].pz);
                float hq[4]; HeadQuat(g_cam.pose, hq); p.qx = hq[0]; p.qy = hq[1]; p.qz = hq[2]; p.qw = hq[3];
            } else if (g_cam.ipdScale != 1.f) {
                float cx = 0.5f * (g_cam.pose[0].px + g_cam.pose[1].px), cy = 0.5f * (g_cam.pose[0].py + g_cam.pose[1].py), cz = 0.5f * (g_cam.pose[0].pz + g_cam.pose[1].pz);
                p.px = cx + (p.px - cx) * g_cam.ipdScale; p.py = cy + (p.py - cy) * g_cam.ipdScale; p.pz = cz + (p.pz - cz) * g_cam.ipdScale;
            }
            return p;
        };
        xrb::IpcPose p = eyePose(pe);
        auto realPose = [&](int e) {
            xrb::IpcPose q = g_cam.pose[e];
            if (mono) { q.px = 0.5f * (g_cam.pose[0].px + g_cam.pose[1].px); q.py = 0.5f * (g_cam.pose[0].py + g_cam.pose[1].py); q.pz = 0.5f * (g_cam.pose[0].pz + g_cam.pose[1].pz);
                        float hq[4]; HeadQuat(g_cam.pose, hq); q.qx = hq[0]; q.qy = hq[1]; q.qz = hq[2]; q.qw = hq[3]; }
            return q;
        };
        static float s_pairBase[12]; static bool s_havePair = false;
        if (synced && !held) { memcpy(s_pairBase, g_rec.clean, 48); s_havePair = true; }
        Frame base = CameraBase(ReadFrame(synced && held && s_havePair ? s_pairBase : g_rec.clean));
        base = Stabilize(base, synced && held);
        base = Settle(base, synced && held);
        HeadAimNoteBase(synced && held && s_havePair ? s_pairBase : g_rec.clean, base);
        float R[3][3]; QuatToMat(p.qx, p.qy, p.qz, p.qw, R);
        float s = g_cam.unitsPerMetre * g_cam.worldScale;
        Frame fr = Compose(base, R, V3{ p.px * s, p.py * s, p.pz * s });
        if (FrameValid(fr) && FrameValid(base)) {
            WriteFrame(T, fr); memcpy(g_rec.written, T, 48);
            TToEng(T, M);   // the eye's camera: SetupView inverts it into the view matrix itself
            eyePos[0] = fr.pos.x; eyePos[1] = fr.pos.y; eyePos[2] = fr.pos.z; posedNow = true;
            g_cam.posesApplied++;
            g_nodeEye = pe; g_nodeMono = mono; g_nodePosed = true; g_posedPresent = g_presents;
            g_cam.curEye = pe; g_cam.curMono = mono;
            {   // 0.7.3: how far the game's update runs ahead of this render (see CameraLayoutEye)
                g_uiRenderTid = GetCurrentThreadId();
                LONG rr = InterlockedIncrement(&g_mainRenders); int dd = (int)(g_tick - rr);
                if (dd < g_uiC) g_uiC = dd;
                if (dd < g_uiWinMin) g_uiWinMin = dd;
                if (++g_uiWinN >= 240) { g_uiC = g_uiWinMin; g_uiWinMin = INT_MAX; g_uiWinN = 0; }
            }
            long long now = (long long)modtime::Now100ns();
            bool measure = !(synced && held);
            if (measure && g_prevBaseTick && now > g_prevBaseTick) {
                float Mr[3][3];
                for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) { V3 av = { g_prevBase[i][0], g_prevBase[i][1], g_prevBase[i][2] }; Mr[i][j] = Dot(av, base.axis[j]); }
                float tr = Mr[0][0] + Mr[1][1] + Mr[2][2], ang = acosf(fmaxf(-1.f, fminf(1.f, (tr - 1.f) * 0.5f)));
                float dts = (float)(now - g_prevBaseTick) * 1e-7f;
                float ax[3] = { Mr[2][1] - Mr[1][2], Mr[0][2] - Mr[2][0], Mr[1][0] - Mr[0][1] };
                float al = sqrtf(ax[0] * ax[0] + ax[1] * ax[1] + ax[2] * ax[2]);
                float inst[3];
                for (int k = 0; k < 3; k++) inst[k] = (al > 1e-6f && dts > 1e-4f && dts < 0.2f) ? -ax[k] / al * ang / dts : 0.f;
                float vi = sqrtf(inst[0] * inst[0] + inst[1] * inst[1] + inst[2] * inst[2]);
                float vs = sqrtf(g_angVel[0] * g_angVel[0] + g_angVel[1] * g_angVel[1] + g_angVel[2] * g_angVel[2]);
                bool stop = vi < vs * 0.25f || vi < 0.02f;
                for (int k = 0; k < 3; k++) g_angVel[k] = stop ? inst[k] : g_angVel[k] * 0.5f + inst[k] * 0.5f;
            }
            if (measure) {
                for (int k = 0; k < 3; k++) { g_prevBase[k][0] = base.axis[k].x; g_prevBase[k][1] = base.axis[k].y; g_prevBase[k][2] = base.axis[k].z; }
                g_prevBaseTick = now;
            }
            RenderedEye rr;
            rr.seq = ++g_seq; rr.eye = eye; rr.mono = mono && !reconC; rr.pose = realPose(pe);
            rr.drawEye = pe; rr.drawMono = mono;
            rr.synced = synced; rr.pairEnd = !synced || held || !g_cam.syncPairSubmit;
            rr.fov = TanToFov(mono ? g_cam.monoTan : CameraDrawTan(pe));
            { int64_t t = 0; xrb::IpcPose tmp[2]; xrb::IpcFov tf[2]; xrb::ClientGetLatestPoses(tmp, tf, &t); rr.time = t; }
            rr.tick = now;
            for (int k = 0; k < 3; k++) rr.angVel[k] = g_cam.cameraReprojection ? g_angVel[k] : 0.f;
            if (reconC) {
                rr.recon = true; rr.centre = true; rr.physEye = 0; rr.eye = 1;
                memcpy(rr.nodeD, T, 48);
                memcpy(rr.tanD, g_cam.monoTan, 16);
                for (int e = 0; e < 2; e++) {
                    xrb::IpcPose pd = g_cam.pose[e];
                    float ks = g_cam.ipdScale * (g_set.reconParallax >= 0.f && g_set.reconParallax <= 3.f ? g_set.reconParallax : 1.f);
                    if (ks != 1.f) {
                        float cx = 0.5f * (g_cam.pose[0].px + g_cam.pose[1].px), cy = 0.5f * (g_cam.pose[0].py + g_cam.pose[1].py), cz = 0.5f * (g_cam.pose[0].pz + g_cam.pose[1].pz);
                        pd.px = cx + (pd.px - cx) * ks; pd.py = cy + (pd.py - cy) * ks; pd.pz = cz + (pd.pz - cz) * ks;
                    }
                    float Re[3][3]; QuatToMat(pd.qx, pd.qy, pd.qz, pd.qw, Re);
                    Frame fe = Compose(base, Re, V3{ pd.px * s, pd.py * s, pd.pz * s });
                    float Te[12]; memcpy(Te, T, 48); WriteFrame(Te, fe);
                    if (e == 0) { memcpy(rr.nodeO, Te, 48); memcpy(rr.tanO, g_cam.eyeTan[0], 16); rr.poseO = g_cam.pose[0]; rr.fovO = TanToFov(g_cam.eyeTan[0]); }
                    else { memcpy(rr.nodeO1, Te, 48); memcpy(rr.tanO1, g_cam.eyeTan[1], 16); rr.poseO1 = g_cam.pose[1]; rr.fovO1 = TanToFov(g_cam.eyeTan[1]); }
                }
                rr.fov = TanToFov(g_cam.monoTan);
                reconRec = rr; reconPush = true; reconReplace = replace;
            } else if (reconm) {
                rr.recon = true; rr.physEye = pe;
                memcpy(rr.nodeD, T, 48);
                xrb::IpcPose po = eyePose(pe ^ 1);
                rr.poseO = realPose(pe ^ 1);
                float Ro[3][3]; QuatToMat(po.qx, po.qy, po.qz, po.qw, Ro);
                Frame fo = Compose(base, Ro, V3{ po.px * s, po.py * s, po.pz * s });
                float To[12]; memcpy(To, T, 48); WriteFrame(To, fo); memcpy(rr.nodeO, To, 48);
                memcpy(rr.tanD, CameraDrawTan(pe), 16); memcpy(rr.tanO, g_cam.eyeTan[pe ^ 1], 16);
                rr.fovO = TanToFov(g_cam.eyeTan[pe ^ 1]);
                reconRec = rr; reconPush = true; reconReplace = replace;
            } else Push(rr, replace);
            g_cam.lastVrSeq = g_presents;
        } else g_cam.badMatrix++;
    }
    tl_capProj = reconPush; tl_projGot = false;
    o_ViewSetup(vp, a, b);
    tl_capProj = false;
    // the view block now holds the eye; the Camera_Z itself gets the game's camera back, so the game's logic (camera
    // behaviours that start from the last camera, movement relative to it, audio) never sees the head pose - nothing
    // can accumulate. The next view setup compares against what it wrote, so it takes this as the game's camera.
    if (posedNow && saved && g_cam.keepGameCamera) {
        memcpy(M, saveM, 64); memcpy(cam + game::kCamView, saveV, 64);
        EngToT(M, T); memcpy(g_rec.written, T, 48);   // what the camera holds now
        g_camRestored++;
    }
    if (posedNow) {   // the camera position the shading uses (the view block copies the camera OBJECT's position)
        float* bp = (float*)((char*)vp + game::kVpBlock + game::kBlockPos);
        if (game::Readable(bp, 12)) { bp[0] = eyePos[0]; bp[1] = eyePos[1]; bp[2] = eyePos[2]; }
    }
    if (reconPush) {
        if (tl_projGot) { memcpy(reconRec.proj, tl_proj, 64); reconRec.projOk = true; }
        Push(reconRec, reconReplace);
    }
}

bool CameraInstall() {
    bool ok = true;
    if (game::g_viewSetup && MH_CreateHook(game::g_viewSetup, (void*)H_ViewSetup, (void**)&o_ViewSetup) == MH_OK &&
        MH_EnableHook(game::g_viewSetup) == MH_OK) LOGI("camera: view setup hooked");
    else { LOGE("camera: view setup hook FAILED - no head tracking"); ok = false; }
    if (game::g_getProj && MH_CreateHook(game::g_getProj, (void*)H_GetProj, (void**)&o_GetProj) == MH_OK && MH_EnableHook(game::g_getProj) == MH_OK)
        LOGI("camera: projection getter hooked");
    else LOGE("camera: projection hook FAILED - the game's own FOV is used (stereo will be wrong)");
    if (game::g_fovTangents && MH_CreateHook(game::g_fovTangents, (void*)H_FovTan, (void**)&o_FovTan) == MH_OK && MH_EnableHook(game::g_fovTangents) == MH_OK)
        LOGI("camera: FOV tangents hooked (wide culling available)");
    else LOGW("camera: FOV tangents not hooked - the culling uses the game's own FOV (objects may pop in at the sides)");
    if (game::g_cullBuild && MH_CreateHook(game::g_cullBuild, (void*)H_CullBuild, (void**)&o_CullBuild) == MH_OK && MH_EnableHook(game::g_cullBuild) == MH_OK)
        LOGI("camera: culling frustum builder hooked (wide culling at the source: the picture is not made wider)");
    else LOGW("camera: culling frustum builder not hooked - objects can pop in at the sides of the headset's view");
    if (game::g_dofPass && MH_CreateHook(game::g_dofPass, (void*)H_DofPass, (void**)&o_DofPass) == MH_OK && MH_EnableHook(game::g_dofPass) == MH_OK)
        LOGI("camera: depth of field hooked (depth_of_field %s)", g_set.depthOfField.c_str());
    else LOGW("camera: depth of field not hooked - the game's own blur stays");
    if (game::g_frameTime && MH_CreateHook(game::g_frameTime, (void*)H_FrameTime, (void**)&o_FrameTime) == MH_OK && MH_EnableHook(game::g_frameTime) == MH_OK)
        LOGI("camera: game clock hooked (synchronized stereo available)");
    else LOGW("camera: game clock hook not in place - synchronized stereo works as alternate-eye");
    if (game::g_camUpdate && MH_CreateHook(game::g_camUpdate, (void*)H_CamUpdate, (void**)&o_CamUpdate) == MH_OK && MH_EnableHook(game::g_camUpdate) == MH_OK)
        LOGI("camera: game camera update hooked (head aim, first person and the pause-menu check available)");
    else LOGW("camera: game camera update not hooked - head aim off; the pause-menu check uses the render camera");
    return ok;
}

void CameraReport() {
    if (g_cpN) {
        LOGI("perf: camera at Present (avg) - flat-screen decision %.3f ms, camera read %.3f ms, viewport tally %.3f ms",
             g_cpFlat / g_cpN, g_cpNode / g_cpN, g_cpTally / g_cpN);
        g_cpFlat = g_cpNode = g_cpTally = 0; g_cpN = 0;
    }
    LOGI("camera: view setups %u, main %u, poses applied %u, projections patched %u (other viewports %u, not perspective %u), culling tangents set %u, game camera writes %u, bad matrices %u, viewport switches %u",
         g_cam.nodeUpdates, g_cam.mainUpdates, g_cam.posesApplied, g_cam.projPatched, g_projOther, g_projNotPersp, g_fovTanWrites, g_cam.resyncs, g_cam.badMatrix, g_cam.nodeSwitches);
    g_projOther = g_projNotPersp = g_fovTanWrites = 0; g_cam.wideCullCalls = 0;
    LOGI("camera: game camera given back after the eye was set up %u times (keep_game_camera %s), other viewports drawing from the main camera %u",
         g_camRestored, g_cam.keepGameCamera ? "on" : "off", g_sharedCam);
    g_camRestored = g_sharedCam = 0;
    if (g_gameProjHave) LOGI("camera: the game's own projection x %.3f y %.3f -> FOV %.1f x %.1f deg (tangents %.3f %.3f) | depth terms [10] %.4g [14] %.4g | the mod's frustum L %.3f R %.3f U %.3f D %.3f",
         g_gameProj[0], g_gameProj[5], 2.f * atanf(1.f / g_gameProj[0]) * 57.2958f, 2.f * atanf(1.f / g_gameProj[5]) * 57.2958f, g_gameTan[0], g_gameTan[1],
         g_gameProj[10], g_gameProj[14], DrawnTan()[0], DrawnTan()[1], DrawnTan()[2], DrawnTan()[3]);
    LOGI("camera: main camera near %.4g far %.6g (engine units = metres)", g_cam.nodeNear, g_cam.nodeFar);
    if (o_DofPass) LOGI("camera: depth of field (%s) - blurred frames %ld, blur taken off %ld | camera frames in play %ld, in cutscenes / scripted cameras %ld",
                        g_set.depthOfField.c_str(), InterlockedExchange(&g_dofRuns, 0), InterlockedExchange(&g_dofOff, 0),
                        InterlockedExchange(&g_playFrames, 0), InterlockedExchange(&g_cutFrames, 0));
    if (o_CullBuild) LOGI("camera: culling frusta built wide %ld, with the game's own view %ld (cover tangents %.3f x %.3f)",
                          InterlockedExchange(&g_cullWide, 0), InterlockedExchange(&g_cullGame, 0),
                          fmaxf(-g_cam.monoTan[0], g_cam.monoTan[1]), fmaxf(g_cam.monoTan[2], -g_cam.monoTan[3]));
    {   // 0.3: which viewports drew last frame, and which one the head pose goes into
        char buf[900]; int o = 0;
        for (int i = 0; i < g_vpSnapN && o < 820; i++)
            o += snprintf(buf + o, sizeof buf - o, "%s[slot %d %ux%u x%u%s]", i ? " " : "", g_vpSnap[i].slot, g_vpSnap[i].w, g_vpSnap[i].h, g_vpSnap[i].n,
                          g_vpSnap[i].node == g_mainNode ? " MAIN" : "");
        buf[o] = 0;
        LOGI("camera: viewports last frame: %s | main from %s, its size %u x %u, back buffer %u x %u", o ? buf : "none",
             g_cam.mainFromEngine ? "the renderer's table" : "slot / draw count", g_cam.mainW, g_cam.mainH, g_bbW, g_bbH);
    }
    if (g_cam.headAim || g_aimApplied)
        LOGI("camera: head aim %s - aim turned %ld times (look-at target turned %ld), taken out of the view %ld, not matched %ld",
             g_cam.headAim == 1 ? "always" : g_cam.headAim == 2 ? "while aiming" : "off", InterlockedExchange(&g_aimApplied, 0), InterlockedExchange(&g_aimTgtWrites, 0),
             InterlockedExchange(&g_aimExact, 0), InterlockedExchange(&g_aimMiss, 0));
    if (g_cam.headAim && g_cam.headAimTarget)
        LOGI("camera: head aim camera node - turned %ld (the game wrote it again itself %ld, given back %ld), not the camera's node %ld%s",
             InterlockedExchange(&g_aimNodeWrites, 0), InterlockedExchange(&g_aimNodeRewritten, 0), InterlockedExchange(&g_aimNodeLeft, 0),
             InterlockedExchange(&g_aimNodeNotCam, 0), g_aimNodeOff ? " - OFF (the game camera followed it)" : "");
    LOGI("camera: frame FIFO: dropped %u, same-frame updates %u, Presents without a new frame %u | eye frusta L %.3f %.3f %.3f %.3f R %.3f %.3f %.3f %.3f",
         g_fifoDropped, g_fifoReplaced, g_fifoEmpty, g_cam.eyeTan[0][0], g_cam.eyeTan[0][1], g_cam.eyeTan[0][2], g_cam.eyeTan[0][3],
         g_cam.eyeTan[1][0], g_cam.eyeTan[1][1], g_cam.eyeTan[1][2], g_cam.eyeTan[1][3]);
    {   // 0.6.47 clock check: the game's clock against real time (a speed hack shows as a ratio other than 1)
        LONG n = InterlockedExchange(&g_clockCalls, 0);
        if (g_clockRealSum > 1.0) LOGI("clock: %ld game ticks, game time / real time %.3f%s", n, g_clockGameSum / g_clockRealSum,
                                       fabs(g_clockGameSum / g_clockRealSum - 1.0) > 0.1 ? " - the game runs faster / slower than real time (speed hack / slow motion); VR timing is not affected" : "");
        g_clockGameSum = g_clockRealSum = 0.0;
    }
    if (g_cam.mode == VRMODE_SYNCED)
        LOGI("camera: synchronized stereo: held ticks %u, second-eye frames %u, clock offset %u (base %d, scores %.0f %.0f %.0f), frames with real camera motion %u",
             g_cam.heldTicks, g_cam.syncPairs, g_cam.syncLagNow, g_lagC, g_lagScore[0], g_lagScore[1], g_lagScore[2], g_moveBigN);
    g_moveBigN = 0;
    if (g_cam.mode == VRMODE_SYNCED && g_cam.syncLag < 0 && g_cam.syncPairs > 100) {
        float hi = g_lagScore[0] > g_lagScore[1] ? g_lagScore[0] : g_lagScore[1], lo = g_lagScore[0] < g_lagScore[1] ? g_lagScore[0] : g_lagScore[1];
        if (hi - lo < 20.f) LOGW("camera: synchronized stereo: eye-pair check undecided (scores %.0f %.0f) - the camera stood still, or the "
                                 "moves of held ticks are not told apart; offset %u is used", g_lagScore[0], g_lagScore[1], g_cam.syncLagNow);
    }
    if (g_syncAltFrames) LOGI("camera: synchronized stereo: %u frames with the eyes alternating (game clock paused / stopped)", g_syncAltFrames);
    g_syncAltFrames = 0;
    g_cam.heldTicks = g_cam.syncPairs = 0;
    g_cam.nodeUpdates = g_cam.mainUpdates = g_cam.posesApplied = g_cam.projPatched = g_cam.resyncs = g_cam.badMatrix = g_cam.nodeSwitches = 0;
    g_fifoDropped = g_fifoReplaced = g_fifoEmpty = 0;
}
