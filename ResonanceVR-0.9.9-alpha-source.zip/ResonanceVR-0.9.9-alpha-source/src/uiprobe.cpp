// UI pass probe: not used for this engine. Resonance draws its HUD / menus through its own GUI system (CWindow /
// CGameGUIComponent ...) into the final picture after the 3D scene; the UI layer is classified by the D3D12 hooks
// (d3d12hooks.cpp: full-screen target, UI pipeline state, drawn after the 3D scene - a confirmed layer is kept at any
// draw count). These functions keep the shared code's interface.
#include <windows.h>
#include "log.h"

void UiProbeInstall() { LOGI("uiprobe: not used (the UI layer is taken from the D3D12 pipeline state and bind order)"); }
void UiProbeOnBind(void*, unsigned, unsigned, int, bool, bool) {}
void* UiProbeTarget(const char** which) { if (which) *which = nullptr; return nullptr; }
void UiProbeReport() {}
