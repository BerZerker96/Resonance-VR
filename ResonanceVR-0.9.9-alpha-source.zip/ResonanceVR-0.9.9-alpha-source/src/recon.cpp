#include <algorithm>
#include "modtime.h"
// Stereo reconstruction (vr_mode = recon).
//
// The game draws ONE eye per frame, as in alternate-eye rendering, but the headset gets BOTH eyes every frame, of the
// same moment: the other eye is reconstructed from this frame's picture and its depth. Each eye is therefore new at
// the game's full frame rate, the two eyes never show different game ticks (unlike AER) and the game clock is never
// held (unlike synchronized). Depth-based view synthesis is a well known technique (PureDark's AFW builds for UEVR /
// REFramework and the Dark Souls III native VR mod use the same family of ideas); this file is written for ResonanceVR
// from scratch and shares no code with them.
//
// Inputs, all from the game's own D3D12 command lists (no shader or engine patch):
//   * scene depth: the depth target that is bound with colour targets and gets the most draws (the G-buffer depth,
//     D32F_S8 in this game). When the game moves it out of DEPTH_WRITE (its depth is complete), the mod appends to
//     that command list: depth -> buffer -> R32 texture shared with the mod's D3D11 device. Copying plane 0 through
//     a buffer footprint is legal for every depth format (D32, D32S8, D24S8, D16).
//   * the picture without UI: before the first UI draw into the final image (d3d12hooks' UI split) that target is
//     copied; the UI is later separated as "final != scene" and placed where the other eye's UI belongs.
//   * matrices: the camera hook records the drawn eye's camera, the projection the renderer really got (depth rows,
//     jitter) and the other eye's camera / frustum from the SAME head pose.
//   * shared frustum (recon_shared_frustum): the drawn eye is rendered wide enough to hold what the other eye sees,
//     so the reconstructed eye never runs out of picture at its outer edge.
// Reconstruction (D3D11 compute on the mod's own device):
//   1 forward: every depth pixel of the drawn eye -> world -> the other eye's image, the nearest kept (atomic min)
//   2 resolve: each pixel of the other eye reads its distance; where nothing landed (behind a close object) it
//     marches along the row - the direction the eyes are apart - to the nearest real surface on each side and takes
//     the deeper one (the background). With history on, those pixels come from that eye's own last real image,
//     reprojected at that depth (alternating eyes: one frame old). UI pixels are copied to the other eye's UI place.
#include "recon.h"
#include <d3dcompiler.h>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <vector>
#include "log.h"
#include "settings.h"
#include "camera.h"
#include "recon_shaders2.h"

extern volatile LONG g_presents;
extern std::wstring g_gameDir;
bool UiCentreForEye(int eye, const float* tan, UINT W, UINT H, float& cx, float& cy);   // d3d12hooks.cpp
bool HeadsetEyeSize(unsigned& w, unsigned& h);   // window.cpp
bool CameraRenderSize(unsigned& w, unsigned& h);                       // camera.cpp

namespace recon {
template <class T> static void Rel(T*& p) { if (p) { p->Release(); p = nullptr; } }

typedef void(STDMETHODCALLTYPE* PFN_Barrier)(ID3D12GraphicsCommandList*, UINT, const D3D12_RESOURCE_BARRIER*);
typedef void(STDMETHODCALLTYPE* PFN_CopyRegion)(ID3D12GraphicsCommandList*, const D3D12_TEXTURE_COPY_LOCATION*, UINT, UINT, UINT, const D3D12_TEXTURE_COPY_LOCATION*, const D3D12_BOX*);
typedef void(STDMETHODCALLTYPE* PFN_CopyRes)(ID3D12GraphicsCommandList*, ID3D12Resource*, ID3D12Resource*);
static PFN_Barrier r_Barrier = nullptr; static PFN_CopyRegion r_CopyRegion = nullptr; static PFN_CopyRes r_CopyRes = nullptr;
void SetRaw(void* b, void* cr, void* c) { r_Barrier = (PFN_Barrier)b; r_CopyRegion = (PFN_CopyRegion)cr; r_CopyRes = (PFN_CopyRes)c; }

// ---------------------------------------------------------------- D3D12 copies (shared with D3D11)
static const int kSlots = 3;
struct Slot {
    ID3D12Resource* depth12 = nullptr; ID3D11Texture2D* depth11 = nullptr; ID3D11ShaderResourceView* depthSrv = nullptr;
    ID3D12Resource* scene12 = nullptr; ID3D11Texture2D* scene11 = nullptr; ID3D11ShaderResourceView* sceneSrv = nullptr;
    volatile LONG tagDepth = -1, tagScene = -1;   // g_presents when recorded (= the Present that shows that frame)
    volatile LONG depthCopies = 0;
    UINT64 needB = 0;                             // fence B value after D3D11 read this slot
};
struct Set {
    Slot s[kSlots];
    ID3D12Resource* buf = nullptr;
    D3D12_PLACED_SUBRESOURCE_FOOTPRINT fp = {};   // plane 0 of the depth as the game's format
    DXGI_FORMAT copyFmt = DXGI_FORMAT_R32_UINT; int decode = 0;   // 0 float32, 1 unorm24, 2 unorm16
    // The shared copy is an 8-bit-per-channel texture holding the depth's bytes: D3D11 cannot open D3D12 R32_UINT /
    // R16_UINT textures as shared resources on every driver (NVIDIA: E_INVALIDARG), RGBA8 / RG8 always work. The
    // shader puts the bytes back together.
    // (0.6.6: UNORM, not TYPELESS / UINT - the 0.6.5 log showed fmt 27 (RGBA8 typeless) refused with 80070057 on NVIDIA
    // too, while the RGBA8 UNORM eye ring shares fine; the shader turns each channel back into its byte exactly)
    DXGI_FORMAT shareFmt = DXGI_FORMAT_R8G8B8A8_UNORM, shareView = DXGI_FORMAT_R8G8B8A8_UNORM;
    UINT dW = 0, dH = 0; DXGI_FORMAT dFmt = DXGI_FORMAT_UNKNOWN;
    ID3D12Resource* volatile forDepth = nullptr;  // the depth these copies are for (pointer compare only)
    UINT sW = 0, sH = 0; DXGI_FORMAT sFmt = DXGI_FORMAT_UNKNOWN;   // scene copy (0 = none)
    ULONGLONG retiredAt = 0;
};
static Set* volatile g_pub = nullptr;            // read by game threads
static std::vector<Set*> g_retired;
static ID3D12Resource* volatile g_depth = nullptr;   // chosen scene depth (pointer compare only on game threads)
static volatile LONG g_depthState = -1;             // its last known state (from the game's barriers)
static volatile LONG g_depthAlive = -1;             // g_presents when the game last used it (it exists this frame)
static volatile bool g_armed = false;
static D3D12_RESOURCE_DESC g_depthDesc = {}; static bool g_depthDescOk = false;
static D3D12_RESOURCE_DESC g_sceneDesc = {}; static volatile LONG g_sceneDescNew = 0; static int g_sceneSame = 0;
static SRWLOCK g_noteLock = SRWLOCK_INIT;
static unsigned g_stSizeSkips = 0;
static unsigned g_stBarrierCopies = 0, g_stUiCopies = 0, g_stSceneCopies = 0, g_stSceneMismatch = 0, g_stNotDirect = 0;

bool Armed() { return g_armed; }
ID3D12Resource* Depth() { return g_depth; }

// depth candidates: tallied per frame
struct Cand { ID3D12Resource* r; D3D12_RESOURCE_DESC d; unsigned draws; };
static Cand g_cand[64]; static SRWLOCK g_candLock = SRWLOCK_INIT;
// 0.5: the back buffer of the last Present - a depth of another shape is never the scene depth, so it does not take a
// slot. 0.4's log: 1500 depth binds in 10 s (shadow cascades, light maps, the prepass); the 8 slots were full of
// shadow maps before the scene depth was bound, it was never seen.
static volatile LONG g_candBbW = 0, g_candBbH = 0;
static Cand g_candLast[4]; static int g_candLastN = 0; static unsigned g_candShapeSkips = 0;
void TallyDepth(ID3D12Resource* r, const D3D12_RESOURCE_DESC& d, unsigned draws) {
    if (!r || !draws) return;
    LONG bw = g_candBbW, bh = g_candBbH;
    if (bw > 0 && bh > 0 && d.Height) {   // the scene depth has the picture's shape (an upscaler's smaller size included)
        float a = (float)bw / bh, ca = (float)d.Width / d.Height;
        if (!(fabsf(ca - a) < 0.03f * a && d.Width >= (UINT64)bw * 3 / 10 && d.Width <= (UINT64)bw + 64)) { g_candShapeSkips++; return; }
    }
    AcquireSRWLockExclusive(&g_candLock);
    Cand* free = nullptr; Cand* least = nullptr; bool done = false;
    for (auto& c : g_cand) {
        if (c.r == r) { c.draws += draws; c.d = d; done = true; break; }
        if (!c.r) { if (!free) free = &c; }
        else if (!least || c.draws < least->draws) least = &c;
    }
    if (!done) { if (free) *free = { r, d, draws }; else if (least && least->draws < draws) *least = { r, d, draws }; }
    ReleaseSRWLockExclusive(&g_candLock);
}

static D3D12_RESOURCE_BARRIER Tr(ID3D12Resource* r, UINT sub, D3D12_RESOURCE_STATES a, D3D12_RESOURCE_STATES b) {
    D3D12_RESOURCE_BARRIER br = {}; br.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    br.Transition.pResource = r; br.Transition.Subresource = sub; br.Transition.StateBefore = a; br.Transition.StateAfter = b;
    return br;
}
static bool Direct(ID3D12GraphicsCommandList* l) {
    if (l->GetType() == D3D12_COMMAND_LIST_TYPE_DIRECT) return true;
    g_stNotDirect++; return false;
}

// 0.9.3 (framework 0.6.92, 49.2): at each depth barrier only depth -> buffer; the buffer -> shared texture copy runs ONCE a frame on the
// mod's own list at Present (PresentDepthCopy). The game leaves the write state several times a frame; only the last content is used, so
// the second full-size copy at every barrier was wasted (8 barriers x 2 copies). Self-check: more than 20 frames without depth in a report
// period -> both copies at every barrier again (logged).
static volatile bool g_depthAtPresent = true;
static volatile LONG g_bufFrame = -1; static void* volatile g_bufSet = nullptr;
static unsigned g_presentCopies = 0, g_framesNoDepth = 0;
// depth (state st) -> buffer -> shared R32 texture of this frame's slot (full) / -> buffer only (the copy at Present follows)
static void RecordDepth(ID3D12GraphicsCommandList* l, ID3D12Resource* r, UINT sub, D3D12_RESOURCE_STATES st, bool full = true) {
    Set* s = g_pub;
    if (!s || !s->buf || !r_Barrier || !r_CopyRegion || !Direct(l)) return;
    LONG p = g_presents; Slot& sl = s->s[(unsigned)p % kSlots];
    if (!sl.depth12 || r != s->forDepth) return;
    // the copy is sized for this set: never record it for a depth of another size / format (an out-of-bounds GPU copy)
    D3D12_RESOURCE_DESC rd = r->GetDesc();
    if (rd.Width != s->dW || rd.Height != s->dH || rd.Format != s->dFmt) { g_stSizeSkips++; return; }
    bool move = !(st & D3D12_RESOURCE_STATE_COPY_SOURCE) || (st & ~(D3D12_RESOURCE_STATE_COPY_SOURCE | D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE |
                 D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE | D3D12_RESOURCE_STATE_DEPTH_READ));
    D3D12_RESOURCE_BARRIER b[3]; int n = 0;
    if (move) b[n++] = Tr(r, sub, st, D3D12_RESOURCE_STATE_COPY_SOURCE);
    b[n++] = Tr(s->buf, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_DEST);
    r_Barrier(l, n, b);
    D3D12_TEXTURE_COPY_LOCATION src = {}, dst = {};
    src.pResource = r; src.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX; src.SubresourceIndex = 0;
    dst.pResource = s->buf; dst.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT; dst.PlacedFootprint = s->fp;
    r_CopyRegion(l, &dst, 0, 0, 0, &src, nullptr);
    n = 0;
    if (move) b[n++] = Tr(r, sub, D3D12_RESOURCE_STATE_COPY_SOURCE, st);
    if (!full) {   // stage only: the buffer back to COMMON, the shared texture is written at Present
        b[n++] = Tr(s->buf, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COMMON);
        r_Barrier(l, n, b);
        g_bufSet = s; InterlockedExchange(&g_bufFrame, p);
        InterlockedIncrement(&sl.depthCopies);
        return;
    }
    b[n++] = Tr(s->buf, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COPY_SOURCE);
    b[n++] = Tr(sl.depth12, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_DEST);
    r_Barrier(l, n, b);
    D3D12_TEXTURE_COPY_LOCATION bs = {}, td = {};
    bs.pResource = s->buf; bs.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT; bs.PlacedFootprint = s->fp; bs.PlacedFootprint.Footprint.Format = s->shareView;   // same bytes, read as RGBA8 / RG8
    td.pResource = sl.depth12; td.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX; td.SubresourceIndex = 0;
    r_CopyRegion(l, &td, 0, 0, 0, &bs, nullptr);
    b[0] = Tr(sl.depth12, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COMMON);
    b[1] = Tr(s->buf, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_COMMON);
    r_Barrier(l, 2, b);
    InterlockedExchange(&sl.tagDepth, p);
    InterlockedIncrement(&sl.depthCopies);
}

// on the mod's own direct list at Present, after every list of the frame: the staged buffer -> this frame's shared depth texture
void PresentDepthCopy(ID3D12GraphicsCommandList* l) {
    Set* s = g_pub;
    LONG p = g_presents;
    if (!s || !s->buf || !r_Barrier || !r_CopyRegion || g_bufFrame != p || g_bufSet != (void*)s) return;
    Slot& sl = s->s[(unsigned)p % kSlots];
    if (!sl.depth12 || sl.tagDepth == p) return;
    D3D12_RESOURCE_BARRIER b[2] = { Tr(s->buf, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_SOURCE),
                                    Tr(sl.depth12, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_DEST) };
    r_Barrier(l, 2, b);
    D3D12_TEXTURE_COPY_LOCATION bs = {}, td = {};
    bs.pResource = s->buf; bs.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT; bs.PlacedFootprint = s->fp; bs.PlacedFootprint.Footprint.Format = s->shareView;
    td.pResource = sl.depth12; td.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX; td.SubresourceIndex = 0;
    r_CopyRegion(l, &td, 0, 0, 0, &bs, nullptr);
    b[0] = Tr(sl.depth12, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COMMON);
    b[1] = Tr(s->buf, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_COMMON);
    r_Barrier(l, 2, b);
    InterlockedExchange(&sl.tagDepth, p);
    g_presentCopies++;
}

void NoteDepthUsed(ID3D12Resource* r) { if (r && r == g_depth) g_depthAlive = g_presents; }
void OnDepthBarrier(ID3D12GraphicsCommandList* l, ID3D12Resource* r, UINT sub, D3D12_RESOURCE_STATES before, D3D12_RESOURCE_STATES after) {
    if (r != g_depth) return;
    g_depthAlive = g_presents;
    if (sub == D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES || sub == 0) InterlockedExchange(&g_depthState, (LONG)after);
    if (!g_armed || (sub != D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES && sub != 0)) return;
    if ((before & D3D12_RESOURCE_STATE_DEPTH_WRITE) && !(after & D3D12_RESOURCE_STATE_DEPTH_WRITE) &&
        after != D3D12_RESOURCE_STATE_COMMON) {   // COMMON: end of frame / aliasing - not a read of the finished depth
        RecordDepth(l, r, sub, after, !g_depthAtPresent); g_stBarrierCopies++;
    }
}

void OnFirstUiDraw(ID3D12GraphicsCommandList* l, ID3D12Resource* rt) {
    if (!g_armed || !rt) return;
    Set* s = g_pub;
    LONG p = g_presents;
    D3D12_RESOURCE_DESC d = rt->GetDesc();
    if (!s || !s->sW || d.Width != s->sW || d.Height != s->sH || d.Format != s->sFmt) {   // (re)created at the next Present
        // the same new target several frames running before the copies are rebuilt (a target that changes from frame
        // to frame must not rebuild them every frame)
        AcquireSRWLockExclusive(&g_noteLock);
        if (g_sceneDesc.Width == d.Width && g_sceneDesc.Height == d.Height && g_sceneDesc.Format == d.Format) g_sceneSame++;
        else { g_sceneDesc = d; g_sceneSame = 1; }
        if (g_sceneSame >= 8 || !s || !s->sW) g_sceneDescNew = 1;
        ReleaseSRWLockExclusive(&g_noteLock);
        if (s && s->sW) g_stSceneMismatch++;
    } else if (r_Barrier && r_CopyRes && Direct(l)) {
        Slot& sl = s->s[(unsigned)p % kSlots];
        D3D12_RESOURCE_BARRIER b[2] = { Tr(rt, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_COPY_SOURCE),
                                        Tr(sl.scene12, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_DEST) };
        r_Barrier(l, 2, b);
        r_CopyRes(l, sl.scene12, rt);
        b[0] = Tr(rt, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_RENDER_TARGET);
        b[1] = Tr(sl.scene12, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COMMON);
        r_Barrier(l, 2, b);
        InterlockedExchange(&sl.tagScene, p);
        g_stSceneCopies++;
    }
    // the depth never left DEPTH_WRITE this frame (no barrier copy): take it now, in its last known state - only if
    // the game used it this frame (a depth target freed on a resolution change must never be touched)
    // and only in a state the game's own barriers told us (a guessed state would be an invalid barrier)
    ID3D12Resource* dep = g_depth;
    LONG st = g_depthState;
    if (s && dep && st >= 0 && s->s[(unsigned)p % kSlots].tagDepth != p && g_depthAlive == p && !(g_depthAtPresent && g_bufFrame == p)) {   // a staged copy is pending: the copy at Present takes it
        RecordDepth(l, dep, 0, (D3D12_RESOURCE_STATES)st);
        g_stUiCopies++;
    }
}

// ---------------------------------------------------------------- Present thread: depth choice, copy targets
static void FreeSet(Set* s) {
    if (!s) return;
    for (auto& sl : s->s) { Rel(sl.depthSrv); Rel(sl.depth11); Rel(sl.depth12); Rel(sl.sceneSrv); Rel(sl.scene11); Rel(sl.scene12); }
    Rel(s->buf);
    delete s;
}
static void Retire(Set* s) { if (s) { s->retiredAt = ModTick64(); g_retired.push_back(s); } }

static int DepthFamily(DXGI_FORMAT f, DXGI_FORMAT& copy) {
    switch (f) {
    case DXGI_FORMAT_D16_UNORM: case DXGI_FORMAT_R16_TYPELESS: case DXGI_FORMAT_R16_UNORM: copy = DXGI_FORMAT_R16_UINT; return 2;
    case DXGI_FORMAT_D24_UNORM_S8_UINT: case DXGI_FORMAT_R24G8_TYPELESS: case DXGI_FORMAT_R24_UNORM_X8_TYPELESS: copy = DXGI_FORMAT_R32_UINT; return 1;
    case DXGI_FORMAT_D32_FLOAT: case DXGI_FORMAT_R32_TYPELESS: case DXGI_FORMAT_R32_FLOAT: case DXGI_FORMAT_D32_FLOAT_S8X24_UINT:
    case DXGI_FORMAT_R32G8X24_TYPELESS: case DXGI_FORMAT_R32_FLOAT_X8X24_TYPELESS: copy = DXGI_FORMAT_R32_UINT; return 0;
    default: copy = DXGI_FORMAT_UNKNOWN; return -1;
    }
}
static DXGI_FORMAT SrvFmt(DXGI_FORMAT f) {
    switch (f) {
    case DXGI_FORMAT_R8G8B8A8_TYPELESS: return DXGI_FORMAT_R8G8B8A8_UNORM;
    case DXGI_FORMAT_B8G8R8A8_TYPELESS: return DXGI_FORMAT_B8G8R8A8_UNORM;
    case DXGI_FORMAT_R10G10B10A2_TYPELESS: return DXGI_FORMAT_R10G10B10A2_UNORM;
    case DXGI_FORMAT_R16G16B16A16_TYPELESS: return DXGI_FORMAT_R16G16B16A16_FLOAT;
    case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB: return DXGI_FORMAT_R8G8B8A8_UNORM;   // the bytes as they are (no decode)
    case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB: return DXGI_FORMAT_B8G8R8A8_UNORM;
    default: return f;
    }
}
static DXGI_FORMAT Typeless(DXGI_FORMAT f) {
    switch (f) {
    case DXGI_FORMAT_R8G8B8A8_UNORM: case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB: return DXGI_FORMAT_R8G8B8A8_TYPELESS;
    case DXGI_FORMAT_B8G8R8A8_UNORM: case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB: return DXGI_FORMAT_B8G8R8A8_TYPELESS;
    case DXGI_FORMAT_R10G10B10A2_UNORM: return DXGI_FORMAT_R10G10B10A2_TYPELESS;
    case DXGI_FORMAT_R16G16B16A16_FLOAT: return DXGI_FORMAT_R16G16B16A16_TYPELESS;
    default: return f;
    }
}

static bool SharedTex(ID3D12Device* d12, ID3D11Device5* d11, UINT w, UINT h, DXGI_FORMAT f, DXGI_FORMAT srvF, D3D12_RESOURCE_FLAGS fl,
                      ID3D12Resource*& r12, ID3D11Texture2D*& t11, ID3D11ShaderResourceView*& srv) {
    D3D12_HEAP_PROPERTIES hp = {}; hp.Type = D3D12_HEAP_TYPE_DEFAULT;
    D3D12_RESOURCE_DESC rd = {}; rd.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D; rd.Width = w; rd.Height = h; rd.DepthOrArraySize = 1;
    rd.MipLevels = 1; rd.Format = f; rd.SampleDesc.Count = 1; rd.Flags = fl;
    HANDLE hd = nullptr;
    HRESULT hr = d12->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_SHARED, &rd, D3D12_RESOURCE_STATE_COMMON, nullptr, __uuidof(ID3D12Resource), (void**)&r12);
#ifdef ResonanceVR_TEST_RECON
    if (!d11) { if (FAILED(hr)) LOGE("recon: test: shared texture failed %08lx", (unsigned long)hr); return SUCCEEDED(hr); }   // D3D12 side only
#endif
    if (SUCCEEDED(hr)) hr = d12->CreateSharedHandle(r12, nullptr, GENERIC_ALL, nullptr, &hd);
    if (SUCCEEDED(hr)) hr = d11->OpenSharedResource1(hd, __uuidof(ID3D11Texture2D), (void**)&t11);
    if (hd) CloseHandle(hd);
    if (SUCCEEDED(hr)) {
        D3D11_SHADER_RESOURCE_VIEW_DESC sv = {}; sv.Format = srvF; sv.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D; sv.Texture2D.MipLevels = 1;
        hr = d11->CreateShaderResourceView(t11, &sv, &srv);
    }
    if (FAILED(hr)) { LOGE("recon: shared texture %ux%u fmt %d failed %08lx", w, h, (int)f, (unsigned long)hr); return false; }
    return true;
}

static Set* MakeSet(ID3D12Device* d12, ID3D11Device5* d11, ID3D12Resource* depth, const D3D12_RESOURCE_DESC& dd, const D3D12_RESOURCE_DESC* sd) {
    Set* s = new Set();
    s->forDepth = depth;
    s->decode = DepthFamily(dd.Format, s->copyFmt);
    if (s->decode == 2) { s->shareFmt = DXGI_FORMAT_R8G8_UNORM; s->shareView = DXGI_FORMAT_R8G8_UNORM; }
    if (s->decode < 0) { LOGW("recon: depth format %d not handled", (int)dd.Format); delete s; return nullptr; }
    UINT rows = 0; UINT64 rowSize = 0, total = 0;
    D3D12_RESOURCE_DESC one = dd; one.MipLevels = 1;
    d12->GetCopyableFootprints(&one, 0, 1, 0, &s->fp, &rows, &rowSize, &total);
    if (!total) { LOGE("recon: no copy footprint for the depth"); delete s; return nullptr; }
    D3D12_HEAP_PROPERTIES hp = {}; hp.Type = D3D12_HEAP_TYPE_DEFAULT;
    D3D12_RESOURCE_DESC bd = {}; bd.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER; bd.Width = total; bd.Height = 1; bd.DepthOrArraySize = 1;
    bd.MipLevels = 1; bd.SampleDesc.Count = 1; bd.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
    if (FAILED(d12->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &bd, D3D12_RESOURCE_STATE_COMMON, nullptr, __uuidof(ID3D12Resource), (void**)&s->buf))) {
        LOGE("recon: depth copy buffer failed"); delete s; return nullptr;
    }
    s->dW = (UINT)dd.Width; s->dH = dd.Height; s->dFmt = dd.Format;
    for (auto& sl : s->s)
        if (!SharedTex(d12, d11, s->dW, s->dH, s->shareFmt, s->shareView, D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET, sl.depth12, sl.depth11, sl.depthSrv)) { FreeSet(s); return nullptr; }
    if (sd) {
        bool ok = true;
        for (auto& sl : s->s)
            if (!SharedTex(d12, d11, (UINT)sd->Width, sd->Height, SrvFmt(sd->Format), SrvFmt(sd->Format),
                           D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET, sl.scene12, sl.scene11, sl.sceneSrv)) { ok = false; break; }
        if (ok) { s->sW = (UINT)sd->Width; s->sH = sd->Height; s->sFmt = sd->Format; }
        else for (auto& sl : s->s) { Rel(sl.sceneSrv); Rel(sl.scene11); Rel(sl.scene12); }
    }
    LOGI("recon: depth copies %ux%u fmt %d (%s), footprint row %u; picture-without-UI copies %s", s->dW, s->dH, (int)s->dFmt,
         s->decode == 0 ? "float" : s->decode == 1 ? "24-bit" : "16-bit", s->fp.Footprint.RowPitch,
         s->sW ? "ready" : "not yet (the UI is warped with the picture)");
    return s;
}

static ID3D12Resource* g_chosen = nullptr; static unsigned g_chosenDraws = 0; static int g_chosenMiss = 0;
static UINT g_bbW = 0, g_bbH = 0;
void OnPresent(ID3D12Device* d12, ID3D11Device5* d11, UINT bbW, UINT bbH, DXGI_FORMAT) {
    PrepareShaders();   // 0.7.3: from the first Present in any mode (a no-op after the first call)
    g_bbW = bbW; g_bbH = bbH;
    for (size_t i = 0; i < g_retired.size();) {   // sets the game threads may still have looked at a moment ago
        if (ModTick64() - g_retired[i]->retiredAt > 3000) { FreeSet(g_retired[i]); g_retired.erase(g_retired.begin() + i); } else i++;
    }
    bool want = g_cam.mode == VRMODE_RECON && CameraFrameIsVR();
#ifdef ResonanceVR_TEST_RECON
    want = g_cam.mode == VRMODE_RECON;   // test build: no headset needed
#endif
    // the scene depth: the depth target bound with colour targets that got the most draws, near the back buffer's shape
    Cand best = {}; bool chosenSeen = false;
    g_candBbW = (LONG)bbW; g_candBbH = (LONG)bbH;
    AcquireSRWLockExclusive(&g_candLock);
    {   // the busiest candidates of this frame (report)
        Cand tmp[64]; int n = 0;
        for (auto& c : g_cand) if (c.r) tmp[n++] = c;
        std::sort(tmp, tmp + n, [](const Cand& a, const Cand& b) { return a.draws > b.draws; });
        g_candLastN = n < 4 ? n : 4;
        for (int k = 0; k < g_candLastN; k++) g_candLast[k] = tmp[k];
    }
    float a = bbH ? (float)bbW / bbH : 1.f;
    for (auto& c : g_cand) {
        if (!c.r) continue;
        float ca = c.d.Height ? (float)c.d.Width / c.d.Height : 0.f;
        bool shape = fabsf(ca - a) < 0.03f * a && c.d.Width >= bbW * 3 / 10 && c.d.Width <= bbW + 64;
        if (shape && c.draws > best.draws) best = c;
        if (c.r == g_chosen) chosenSeen = true;
    }
    memset(g_cand, 0, sizeof g_cand);
    ReleaseSRWLockExclusive(&g_candLock);
    // switch: no depth yet, the current one was not drawn into this frame (released / replaced), or a clearly busier one
    if (best.r && best.r != g_chosen && (!g_chosen || !chosenSeen || best.draws > g_chosenDraws * 3 / 2)) {
        g_chosen = best.r; g_chosenMiss = 0;
        g_depth = best.r; g_depthState = -1;
        g_depthDesc = best.d; g_depthDescOk = true;
        LOGI("recon: scene depth %p %llux%u fmt %d (%u draws a frame)", (void*)best.r, (unsigned long long)best.d.Width, best.d.Height, (int)best.d.Format, best.draws);
    }
    if (best.r == g_chosen) { g_chosenDraws = best.draws; g_chosenMiss = 0; if (best.r) g_depthDesc = best.d; }
    else if (g_chosen && ++g_chosenMiss > 120) { g_chosen = nullptr; g_depth = nullptr; g_depthDescOk = false; LOGI("recon: scene depth gone"); }
    if (!want) { g_armed = false; return; }
    Set* s = g_pub;
    D3D12_RESOURCE_DESC sd = {}; bool sNew = false;
    AcquireSRWLockExclusive(&g_noteLock); if (g_sceneDescNew) { sd = g_sceneDesc; sNew = true; g_sceneDescNew = 0; } ReleaseSRWLockExclusive(&g_noteLock);
    if (g_depthDescOk) {
        bool depthChanged = !s || s->dW != g_depthDesc.Width || s->dH != g_depthDesc.Height || s->dFmt != g_depthDesc.Format;
        bool sceneChanged = sNew && (!s || s->sW != sd.Width || s->sH != sd.Height || s->sFmt != sd.Format);
        if (depthChanged || sceneChanged) {
            D3D12_RESOURCE_DESC keepScene = {}; bool haveScene = false;
            if (sNew) { keepScene = sd; haveScene = true; }
            else if (s && s->sW) { keepScene.Width = s->sW; keepScene.Height = s->sH; keepScene.Format = s->sFmt; haveScene = true; }
            Set* n = MakeSet(d12, d11, g_depth, g_depthDesc, haveScene ? &keepScene : nullptr);
            if (n) { g_pub = n; Retire(s); s = n; }
            else { static int fails = 0; if (++fails > 3) { g_depthDescOk = false; LOGE("recon: copies could not be made - the other eye keeps its last image"); } }
        } else if (s && s->forDepth != g_depth) s->forDepth = g_depth;   // a new depth of the same size: same copies
    }
    s = g_pub;
    g_armed = s && g_depth && s->forDepth == g_depth && s->dW == g_depthDesc.Width && s->dH == g_depthDesc.Height && s->dFmt == g_depthDesc.Format;
}

UINT64 NeedBForNextFrame() {
    Set* s = g_pub;
    return s ? s->s[(unsigned)(g_presents + 1) % kSlots].needB : 0;
}

// ---------------------------------------------------------------- D3D11 reconstruction
static ID3D11Device* g_dev = nullptr;
static ID3D11ComputeShader* g_csForward = nullptr, * g_csResolve = nullptr;
static ID3D11Buffer* g_cbFwd = nullptr, * g_cbRes = nullptr, * g_cb2 = nullptr;
static ID3D11SamplerState* g_bilinear = nullptr;
struct Tex { ID3D11Texture2D* t = nullptr; ID3D11ShaderResourceView* srv = nullptr; ID3D11UnorderedAccessView* uav = nullptr; UINT w = 0, h = 0; DXGI_FORMAT f = DXGI_FORMAT_UNKNOWN; };
static void Drop(Tex& x) { Rel(x.uav); Rel(x.srv); Rel(x.t); x.w = x.h = 0; x.f = DXGI_FORMAT_UNKNOWN; }
static Tex g_nearest, g_nearest2, g_result, g_history[2];
static LONG g_dualFrame = -1; static bool g_dualReady = false;   // the second eye's key map was filled by the first eye's forward pass
struct EyeHist { bool ok = false; float T[12]; double P[16]; LONG at = 0; };
static EyeHist g_hist[2];
static ID3D11Buffer* g_counters = nullptr; static ID3D11UnorderedAccessView* g_countersU = nullptr;
static ID3D11Buffer* g_readback[3] = {}; static bool g_rbPending[3] = {}; static int g_rbNext = 0;
// 0.8.0: eight timestamps around the passes of one rebuilt eye (memory, forward, tiles, PatchMatch, membrane, resolve, finish)
struct GpuTimer { ID3D11Query* dj = nullptr; ID3D11Query* ts[8] = {}; bool pending = false; };
static double g_passMs[7] = {}; static unsigned g_passN = 0;
struct Stp { GpuTimer* q = nullptr; bool on = false; int idx = 0; void to(ID3D11DeviceContext* c, int upto) { if (!on) return; while (idx <= upto && idx < 8) c->End(q->ts[idx++]); } };
static GpuTimer g_timers[4]; static int g_timerNext = 0; static double g_gpuMs = 0; static unsigned g_gpuN = 0;
static bool g_newActive = false;   // the last rebuilt eye came from the new infill pipeline
static int g_ready = 0;   // 0 not tried, 1 ready, -1 failed
static unsigned g_made = 0, g_noDepth = 0, g_noScene = 0, g_noMatrix = 0;
static float g_pctGap = 0, g_pctHist = 0, g_pctUi = 0, g_pctKept = 0;   // g_pctKept: filled pixels that kept last frame's fill (steady infill)
// 0.6.12: depth direction. The 0.6.11 log + screenshots: the centre view's two rebuilt eyes were turned ~20 deg apart
// (crossed), near and far alike, "gaps stretched" ~10 % in every scene - every pixel was rebuilt as if it were at the
// near plane: the depth buffer runs the other way (reversed Z / standard Z) than the projection the game hands out.
// Measured on the depth itself: at a few metres a standard-Z depth is > 0.5, a reversed-Z depth < 0.5.
static int g_flip = -1;              // -1 not known yet, 0 as the projection says, 1 turned round
static bool g_dirExact = false;      // the direction was decided from exact far-value samples
static int g_flipVotes = 0; static float g_farHalf = -1.f; static bool g_projFarHigh = true; static bool g_projKnown = false;
static bool g_uiSplitOff = false; static int g_uiAll = 0; static ULONGLONG g_uiRetryAt = 0;

static const char* kHlsl = R"(
#pragma pack_matrix(row_major)
// ---- pass 1 (render size): forward-project the drawn eye's depth into the other eye, nearest distance kept
Texture2D<float4> DepthIn : register(t0);   // the depth's bytes as UNORM channels
RWTexture2D<uint> Nearest : register(u0);
RWByteAddressBuffer Counters : register(u1);
cbuffer Fwd : register(b0) { float4x4 ClipToWorld; float4x4 WorldToOther; float4 Size; float4 Fmt; float4 Foot; };
// Foot (0.6.53): x / y = how close (in target pixels) to a cell edge a point also writes the neighbouring cell - the
// source grid's spacing in the target minus 1, plus a margin; z = 1: that adaptive footprint, 0: the full 2 x 2
float Depth01(float4 v) {
    uint4 b = (uint4)round(saturate(v) * 255.0);
    uint raw = (b.x & 0xFFu) | ((b.y & 0xFFu) << 8);
    if (Fmt.x < 1.5) raw |= ((b.z & 0xFFu) << 16) | ((b.w & 0xFFu) << 24);   // RGBA8 bytes of a 32-bit depth
    if (Fmt.x < 0.5) return asfloat(raw);
    if (Fmt.x < 1.5) return float(raw & 0xFFFFFF) * (1.0 / 16777215.0);
    return float(raw & 0xFFFF) * (1.0 / 65535.0);
}
// 0.6.12: Fmt.y = 1: the depth buffer uses the other depth direction than the projection the game hands out
// (reversed Z <-> standard Z) - turned round so the depth matches the matrices; Fmt.z = 1: count (1 pixel in 256)
float DepthFixed(float4 v) { float d = Depth01(v); return Fmt.y > 0.5 ? 1.0 - d : d; }
[numthreads(16, 8, 1)] void forward(uint3 t : SV_DispatchThreadID) {
    if (t.x >= (uint)Size.x || t.y >= (uint)Size.y) return;
    float2 ndc = float2((t.x + 0.5) * Size.z, (t.y + 0.5) * Size.w) * float2(2, -2) + float2(-1, 1);
    float4 raw4 = DepthIn.Load(int3(t.xy, 0));
    if (Fmt.z > 0.5 && (t.x & 15u) == 0 && (t.y & 15u) == 0) {   // which way the depth runs: far half / near half
        float d0 = Depth01(raw4); uint o;
        if (d0 > 0.0 && d0 < 1.0) { Counters.InterlockedAdd(16, 1u, o); if (d0 > 0.5) Counters.InterlockedAdd(20, 1u, o); } else if (d0 <= 0.0) Counters.InterlockedAdd(28, 1u, o); else Counters.InterlockedAdd(32, 1u, o);   /* exact 0 / 1: cleared or sky pixels hold only the far value */
    }
    float4 wp = mul(float4(ndc, DepthFixed(raw4), 1.0), ClipToWorld);
    wp *= sign(wp.w + 1e-30);                            // w >= 0; w = 0 is a direction (sky at infinity)
    float4 oc = mul(wp, WorldToOther);
    if (oc.w <= 1e-9) return;                            // behind the other eye
    float dist = wp.w > 1e-20 ? oc.w / wp.w : 1e30;
    float2 px = (oc.xy / oc.w * float2(0.5, -0.5) + 0.5) * Size.xy;
    uint key = asuint(min(dist, 1e30)); uint was;
    // a 2 x 2 footprint: the four pixels whose centres surround the point, so a source grid that is coarser than the
    // other eye's (shared frustum, canted displays) leaves no empty rows or columns
    // 0.6.53: only where a hole could open. A point always lands in the cell that holds it; it also writes the cell
    // beside it only when it lies within Foot.x / Foot.y of that edge - where the source grid (coarser than the
    // target by that much) could leave the next cell empty. ~2.3 instead of 4 atomic writes a pixel on a wide centre
    // view, the same cells filled. Foot.z = 0 (a much coarser source): the full 2 x 2 as before.
    if (Foot.z > 0.5) {
        int2 c0 = int2(floor(px));
        float2 fr = px - floor(px);
        int dx = fr.x < Foot.x ? -1 : fr.x > 1.0 - Foot.x ? 1 : 0;
        int dy = fr.y < Foot.y ? -1 : fr.y > 1.0 - Foot.y ? 1 : 0;
        [unroll] for (int j = 0; j < 4; j++) {
            int ox = (j & 1) ? dx : 0, oy = (j >> 1) ? dy : 0;
            if (j > 0 && (((j & 1) != 0 && dx == 0) || ((j >> 1) != 0 && dy == 0))) continue;
            int2 q = c0 + int2(ox, oy);
            if (q.x >= 0 && q.y >= 0 && q.x < (int)Size.x && q.y < (int)Size.y) InterlockedMin(Nearest[q], key, was);
        }
        return;
    }
    int2 q0 = int2(floor(px - 0.5));
    [unroll] for (int j = 0; j < 4; j++) {
        int2 q = q0 + int2(j & 1, j >> 1);
        if (q.x >= 0 && q.y >= 0 && q.x < (int)Size.x && q.y < (int)Size.y) InterlockedMin(Nearest[q], key, was);
    }
}

// ---- pass 2 (eye size): every pixel of the other eye
Texture2D<uint> NearestIn : register(t0);
Texture2D<float4> Scene : register(t1);     // drawn eye, without UI
Texture2D<float4> History : register(t2);   // this eye's own last real image (without UI)
Texture2D<float4> Final : register(t3);     // drawn eye, with UI
RWTexture2D<float4> Result : register(u0);
SamplerState Bilinear : register(s0);
cbuffer Res : register(b0) { float4x4 OtherToDrawn; float4x4 OtherToHistory; float4 OutSize; float4 KeySize; float4 Z; float4 Opt; float4 UiC; float4 Fill; };
// Fill (0.6.53): x = infill method (0 soft background, 1 clone, 2 stretch, 3 scatter, 4 seamless - 0.6.56), y = edge guard (key px)
// Z: ndc depth = Z.x + Z.y / distance, march reach (key pixels), history usable
// Opt: debug, UI split on, UI change threshold, UI scale drawn / other;  UiC: UI centre drawn (px), other (px)
static const uint NONE = 0xFFFFFFFF;
uint NearAt(int2 q) { return (q.x < 0 || q.y < 0 || q.x >= (int)KeySize.x || q.y >= (int)KeySize.y) ? NONE : NearestIn.Load(int3(q, 0)); }
float2 ClipUv(float4 c) { return c.xy / c.w * float2(0.5, -0.5) + 0.5; }
bool Inside(float2 u) { return u.x >= 0.0 && u.y >= 0.0 && u.x <= 1.0 && u.y <= 1.0; }
groupshared uint gsCount[4];
[numthreads(16, 8, 1)] void resolve(uint3 t : SV_DispatchThreadID, uint gi : SV_GroupIndex) {
    if (gi < 4) gsCount[gi] = 0;
    GroupMemoryBarrierWithGroupSync();
    bool live = t.x < (uint)OutSize.x && t.y < (uint)OutSize.y;
    int kind = 0;   // 0 seen by the drawn eye, 1 gap: background stretched, 2 gap: from history, 3 nothing
    bool isUi = false;
    if (live) {
        float2 uv = (t.xy + 0.5) * OutSize.zw;
        int2 kp = min(int2(uv * KeySize.xy), int2(KeySize.xy) - 1);
        uint key = NearAt(kp);
        bool gap = false;
        int bgDir = 0, bgDist = 0;   // 0.6.16: which side the background is on and how far its edge is (key px)
        int fgDist = 0; uint kFg = NONE;   // 0.6.53: the other (foreground) side of the gap - stretch / clone need the gap's width
        if (key == NONE) {
            uint kl = NONE, kr = NONE; int reach = (int)Z.z, stride = max(1, (int)((uint)reach / 24u)), i = 1, firstL = 0, firstR = 0;
            [loop] for (; i <= reach && (kl == NONE || kr == NONE); i += (i < 4 ? 1 : stride)) {
                if (kl == NONE) { kl = NearAt(kp - int2(i, 0)); firstL = i; }
                if (kr == NONE) { kr = NearAt(kp + int2(i, 0)); firstR = i; }
            }
            if (kl != NONE && kr != NONE) {
                float dl = asfloat(kl), dr = asfloat(kr);
                // close on both sides at nearly the same distance: a crack in one surface, not something hidden
                bool crack = firstL + firstR <= 6 && abs(dl - dr) <= 0.03 * min(dl, dr);
                key = crack ? min(kl, kr) : max(kl, kr);   // hidden: the deeper side is the background
                gap = !crack;
                if (gap) { bgDir = kl >= kr ? -1 : 1; bgDist = kl >= kr ? firstL : firstR; fgDist = kl >= kr ? firstR : firstL; kFg = kl >= kr ? kr : kl; }
            }
            else if (kl != NONE || kr != NONE) { key = kl != NONE ? kl : kr; gap = true; bgDir = kl != NONE ? -1 : 1; bgDist = kl != NONE ? firstL : firstR; }
            else { key = asuint(1e30); gap = true; kind = 3; }
        }
        float dist = asfloat(key);
        float4 p = float4(uv * float2(2, -2) + float2(-1, 1), dist >= 1e29 ? Z.x : Z.x + Z.y / max(dist, 1e-6), 1.0);
        float4 dc = mul(p, OtherToDrawn);
        float2 su = dc.w > 1e-9 ? ClipUv(dc) : float2(-1, -1);
        bool seen = Inside(su);
        float4 col = Scene.SampleLevel(Bilinear, saturate(su), 0);
        // 0.6.17 hole fill (after SuperDepth3D's background infill, softer): a hidden area is filled from the background
        // beyond the occluder's edge - several taps reaching further into the background (the reach grows with the
        // hole's width), each kept only when it is the same background (its depth within 15 %, or deeper), each read
        // from the drawn picture at its own depth and spread up / down; the edge tap weighs most, so the fill starts
        // as the background's own edge and fades into its blurred continuation - like the out-of-focus background the
        // other eye would see, no stretched streaks, no mirrored copies
        // 0.6.53: four infill methods (ideas in the family of SuperDepth3D's occlusion modes, written for ResonanceVR): the gap
        // is what the drawn eye could not see behind a closer object. Every method reads the BACKGROUND beside the gap at
        // its own depth, starting Fill.y pixels past the edge (the edge pixel is often blended with the object in front:
        // the halo outline). 0 soft: fading blurred continuation; 1 clone: the background patch beside the gap moved in,
        // sharp, texture kept; 2 stretch: a sheet from the background edge to the foreground edge; 3 scatter: stable
        // dithered background taps (foliage, busy texture). If a method has nothing valid it falls back to soft.
        int method = (int)(Fill.x + 0.5);
        int guard = (int)(Fill.y + 0.5);
        bool filled = false;
        if (gap && bgDir != 0 && kind != 3 && method == 1 && kFg != NONE) {   // clone
            int w = bgDist + fgDist - 1;                                       // the gap's width (key px)
            float2 uvT = uv + float2(bgDir * (float)(w + guard) / KeySize.x, 0);
            uint kT = NearAt(int2(uvT * KeySize.xy));
            float dBg = asfloat(key);
            if (kT != NONE && asfloat(kT) >= dBg * 0.85) {
                float dT = asfloat(kT);
                float4 pT = float4(uvT * float2(2, -2) + float2(-1, 1), dT >= 1e29 ? Z.x : Z.x + Z.y / max(dT, 1e-6), 1.0);
                float4 cT = mul(pT, OtherToDrawn);
                if (cT.w > 1e-9) { float2 s2 = ClipUv(cT); if (Inside(s2)) { col = Scene.SampleLevel(Bilinear, s2, 0); filled = true; } }
            }
        }
        if (gap && bgDir != 0 && kind != 3 && method == 2 && kFg != NONE) {   // stretch
            float2 uvB = uv + float2(bgDir * (float)(bgDist + guard) / KeySize.x, 0);
            float2 uvF = uv - float2(bgDir * (float)fgDist / KeySize.x, 0);
            uint kB = NearAt(int2(uvB * KeySize.xy));
            if (kB == NONE) kB = key;
            float dB = asfloat(kB), dF = asfloat(kFg);
            float4 pB = float4(uvB * float2(2, -2) + float2(-1, 1), dB >= 1e29 ? Z.x : Z.x + Z.y / max(dB, 1e-6), 1.0);
            float4 pF = float4(uvF * float2(2, -2) + float2(-1, 1), dF >= 1e29 ? Z.x : Z.x + Z.y / max(dF, 1e-6), 1.0);
            float4 cB = mul(pB, OtherToDrawn), cF = mul(pF, OtherToDrawn);
            if (cB.w > 1e-9 && cF.w > 1e-9) {
                float2 sB = ClipUv(cB), sF = ClipUv(cF);
                if (Inside(sB) && Inside(sF)) {
                    float tt = saturate((float)bgDist / max(1.0, (float)(bgDist + fgDist)));
                    tt = tt * tt;   // mostly background: the object's colour only near its own edge
                    col = lerp(Scene.SampleLevel(Bilinear, sB, 0), Scene.SampleLevel(Bilinear, sF, 0), tt);
                    filled = true;
                }
            }
        }
        if (gap && bgDir != 0 && kind != 3 && method == 3) {   // scatter
            uint sw3, sh3; Scene.GetDimensions(sw3, sh3);
            float dBg = asfloat(key);
            uint h = (t.x * 73856093u) ^ (t.y * 19349663u); h ^= h >> 13; h *= 0x5bd1e995u; h ^= h >> 15;
            float4 acc = 0; float n = 0;
            [unroll] for (int j = 0; j < 3; j++) {
                uint hj = h * (uint(j) * 2u + 1u) + 0x9e3779b9u * uint(j); hj ^= hj >> 16;
                float rx = (float)(hj & 1023u) / 1023.0, ry = (float)((hj >> 10) & 1023u) / 1023.0 - 0.5;
                float off = (float)(bgDist + guard) + rx * max(2.0, (float)bgDist * 1.5);
                float2 uvT = uv + float2(bgDir * off / KeySize.x, 0);
                uint kT = NearAt(int2(uvT * KeySize.xy));
                if (kT == NONE || asfloat(kT) < dBg * 0.85) continue;
                float dT = asfloat(kT);
                float4 pT = float4(uvT * float2(2, -2) + float2(-1, 1), dT >= 1e29 ? Z.x : Z.x + Z.y / max(dT, 1e-6), 1.0);
                float4 cT = mul(pT, OtherToDrawn);
                if (cT.w <= 1e-9) continue;
                float2 s2 = ClipUv(cT) + float2(0, ry * (2.0 + min((float)bgDist, 24.0) * 0.25) / (float)sh3);
                if (!Inside(s2)) continue;
                acc += Scene.SampleLevel(Bilinear, s2, 0); n += 1;
            }
            if (n > 0) { col = acc / n; filled = true; }
        }
        if (gap && kind != 3 && method == 4) {   // 0.6.56 seamless (default)
            // multi-direction background prediction: march 8 directions for the first real pixel, keep only the far
            // (background) ones - the closer side is the object that made the gap - weight by distance, the sideways
            // (parallax) directions a little more; then fine grain matched to the background's own contrast, so the
            // fill carries texture instead of a smooth patch. Only gap pixels run this.
            static const float2 dirs[8] = { float2(1, 0), float2(-1, 0), float2(0, 1), float2(0, -1),
                                            float2(0.7071, 0.7071), float2(-0.7071, 0.7071), float2(0.7071, -0.7071), float2(-0.7071, -0.7071) };
            static const float steps[10] = { 1, 2, 3, 5, 8, 12, 18, 27, 40, 60 };
            float reach = max(Z.z, 8.0);   // the gap reach (key px)
            float2 kp = uv * KeySize.xy;
            float candD[8]; float2 candUv[8]; float candDist[8]; bool candOk[8];
            float far = 0;
            [unroll] for (int di = 0; di < 8; di++) {
                candOk[di] = false; candD[di] = 0; candUv[di] = uv; candDist[di] = 0;
                [loop] for (int si = 0; si < 10; si++) {
                    float dd = steps[si] * (si >= 4 ? reach / 60.0 : 1.0);
                    if (dd > reach) break;
                    int2 q = int2(kp + dirs[di] * dd);
                    uint kq = NearAt(q);
                    if (kq == NONE) continue;
                    float dq = asfloat(kq);
                    // edge guard: step past the blended edge pixel when the surface continues
                    float dg = dd + (float)guard;
                    uint kg = NearAt(int2(kp + dirs[di] * dg));
                    if (guard > 0 && kg != NONE && abs(asfloat(kg) - dq) < dq * 0.1) { dd = dg; dq = asfloat(kg); }
                    candOk[di] = true; candD[di] = dq; candDist[di] = dd;
                    candUv[di] = (kp + dirs[di] * dd) / KeySize.xy;
                    far = max(far, dq);
                    break;
                }
            }
            float4 acc = 0; float wsum = 0; float4 acc2 = 0;
            [unroll] for (int dj = 0; dj < 8; dj++) {
                if (!candOk[dj] || candD[dj] < far * 0.85) continue;   // the near side is the object in front
                float dT = candD[dj];
                float4 pT = float4(candUv[dj] * float2(2, -2) + float2(-1, 1), dT >= 1e29 ? Z.x : Z.x + Z.y / max(dT, 1e-6), 1.0);
                float4 cT = mul(pT, OtherToDrawn);
                if (cT.w <= 1e-9) continue;
                float2 s2 = ClipUv(cT);
                if (!Inside(s2)) continue;
                float4 c = Scene.SampleLevel(Bilinear, s2, 0);
                float w = (dj < 2 ? 1.5 : 1.0) / max(candDist[dj], 1.0);
                acc += c * w; acc2 += c * c * w; wsum += w;
            }
            if (wsum > 0) {
                float4 m = acc / wsum;
                float3 sd = sqrt(max(acc2.rgb / wsum - m.rgb * m.rgb, 0));
                uint h = (t.x * 73856093u) ^ (t.y * 19349663u); h ^= h >> 13; h *= 0x5bd1e995u; h ^= h >> 15;
                float n = (float)(h & 1023u) / 1023.0 - 0.5;   // stable per pixel (no flicker)
                col = float4(m.rgb + sd * n * 0.7, m.a);
                filled = true;
            }
        }
        if (gap && bgDir != 0 && kind != 3 && !filled) {   // soft background (the 0.6.17 fill; also every fallback)
            uint sw, sh; Scene.GetDimensions(sw, sh);

            float dBg = asfloat(key);
            float step = max(1.5, (float)bgDist * 0.35);
            float spread = (1.0 + min((float)bgDist, 32.0) * 0.3) / sh;
            float4 acc = 0; float wsum = 0;
            [unroll] for (int j = 0; j < 6; j++) {
                float2 uvT = uv + float2(bgDir * ((float)(bgDist + guard) + j * step) / KeySize.x, 0);
                uint kT = NearAt(int2(uvT * KeySize.xy));
                if (kT == NONE) continue;
                float dT = asfloat(kT);
                if (j > 0 && dT < dBg * 0.85) continue;   // something closer again: not this background
                float4 pT = float4(uvT * float2(2, -2) + float2(-1, 1), dT >= 1e29 ? Z.x : Z.x + Z.y / max(dT, 1e-6), 1.0);
                float4 cT = mul(pT, OtherToDrawn);
                if (cT.w <= 1e-9) continue;
                float2 s2 = ClipUv(cT);
                if (!Inside(s2)) continue;
                float w = exp(-0.45 * j);
                float oy = spread * (0.5 + 0.5 * j) * ((j & 1) ? 1.0 : -1.0);
                acc += w * 0.5 * (Scene.SampleLevel(Bilinear, saturate(s2 + float2(0, oy)), 0) +
                                  Scene.SampleLevel(Bilinear, saturate(s2 - float2(0, oy * 0.5)), 0));
                wsum += w;
            }
            if (wsum > 0) col = acc / wsum;
        }
        if (gap || !seen) {
            if (kind != 3) kind = 1;
            if (Z.w > 0.5) {
                float4 hc = mul(p, OtherToHistory);
                if (hc.w > 1e-9) { float2 hu = ClipUv(hc); if (Inside(hu)) { col = History.SampleLevel(Bilinear, hu, 0); kind = 2; } }
            }
        }
        if (Opt.y > 0.5) {   // the UI: what the UI changed in the drawn eye, at this eye's UI place (copied, never moved by depth)
            float2 dp = UiC.xy + (t.xy + 0.5 - UiC.zw) * Opt.w;
            uint fw, fh; Final.GetDimensions(fw, fh);   // dp is in the drawn picture's pixels (not this eye's)
            if (dp.x >= 0 && dp.y >= 0 && dp.x < (float)fw && dp.y < (float)fh) {
                int3 q = int3(dp, 0);
                float4 f = Final.Load(q), d4 = abs(f - Scene.Load(q));
                if (max(max(d4.r, d4.g), max(d4.b, d4.a)) > Opt.z) { col = f; isUi = true; }
            }
        }
        if (Opt.x > 0.5 && Opt.x < 1.5 && !isUi) {   // debug 1: gaps tinted - orange stretched, blue history, red nothing
            float3 tint = kind == 1 ? float3(1, 0.45, 0) : kind == 2 ? float3(0.1, 0.4, 1) : kind == 3 ? float3(1, 0, 0) : col.rgb;
            col.rgb = lerp(col.rgb, tint, 0.6);
        } else if (Opt.x > 1.5 && !isUi) {           // debug 2: picture grey, the UI in colour (checks the UI split)
            float g = dot(col.rgb, float3(0.299, 0.587, 0.114)); col.rgb = float3(g, g, g);
        }
        Result[t.xy] = col;
        uint o;
        InterlockedAdd(gsCount[0], 1u, o);
        if (kind == 1 || kind == 3) InterlockedAdd(gsCount[1], 1u, o);
        if (kind == 2) InterlockedAdd(gsCount[2], 1u, o);
        if (isUi) InterlockedAdd(gsCount[3], 1u, o);
    }
    GroupMemoryBarrierWithGroupSync();
    if (gi < 4 && gsCount[gi]) { uint o; Counters.InterlockedAdd(gi * 4, gsCount[gi], o); }
}
)";

// 0.7.3: the compute shaders are compiled in the background from the start of the game and cached on disk (framework
// guide, Part AF / AG): the first switch to reconstruction used to compile them on the Present thread - a hold in the
// headset. The frame only reads the state: not ready = this frame shows the drawn view.
// 0.8.0: two sources. kHlsl (above) is the older two-pass reconstruction and stays the fallback; kHlsl2 (recon_shaders2.h) is the
// infill pipeline of the 0.6.84 reference. They are compiled separately so that a problem in the new one on some machine
// (the log then names the entry point and the compiler's message) switches only the new pipeline off - never the mode.
static const char* const kEntries[2] = { "forward", "resolve" };
static const char* const kEntries2[] = { "fwd2", "memory", "tiles", "tilefix", "pminit", "pmiter", "ppseed", "ppdown", "ppup", "res2", "finish" };
enum { E_FWD2, E_MEMORY, E_TILES, E_TILEFIX, E_PMINIT, E_PMITER, E_PPSEED, E_PPDOWN, E_PPUP, E_RES2, E_FINISH, kN2 };
static const int kJobs = 2 + kN2;
static std::vector<char> g_blob[kJobs];
static ID3D11ComputeShader* g_cs2[kN2] = {};
static volatile LONG g_prep = 0;   // 0 not started, 1 working, 2 blobs ready, -1 failed
static volatile LONG g_obj = 0;    // shader objects: 0 not started, 1 working, 2 done, -1 failed
static bool g_newReq = false, g_haveMem = false, g_haveTiles = false, g_havePm = false;   // which parts of the new pipeline exist
static unsigned long long Fnv(const void* d, size_t n, unsigned long long h = 1469598103934665603ULL) {
    const unsigned char* p = (const unsigned char*)d; for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 1099511628211ULL; } return h;
}
static std::wstring CachePath() {
    unsigned long long h = Fnv("cs_5_0/O3", 9, Fnv(kHlsl2, strlen(kHlsl2), Fnv(kHlsl, strlen(kHlsl))));
    wchar_t nm[96]; swprintf(nm, 96, L"\\resonancevr_shaders_%016llx.bin", h);
    return g_gameDir + nm;
}
static bool LoadCache() {   // true: a valid file; entries of size 0 are compiled again
    FILE* f = _wfopen(CachePath().c_str(), L"rb"); if (!f) return false;
    bool ok = true; unsigned n = 0;
    if (fread(&n, 4, 1, f) != 1 || n != (unsigned)kJobs) ok = false;
    for (int i = 0; ok && i < kJobs; i++) {
        unsigned sz = 0;
        if (fread(&sz, 4, 1, f) != 1 || sz > (16u << 20) || (sz && sz < 8)) { ok = false; break; }
        if (!sz) continue;
        g_blob[i].resize(sz);
        if (fread(g_blob[i].data(), 1, sz, f) != sz || memcmp(g_blob[i].data(), "DXBC", 4)) ok = false;   // not DXBC: damaged
    }
    fclose(f);
    if (!ok) { for (auto& b : g_blob) b.clear(); DeleteFileW(CachePath().c_str()); }
    return ok;
}
static void SaveCache() {
    std::wstring path = CachePath(), tmp = path + L".tmp";
    FILE* f = _wfopen(tmp.c_str(), L"wb"); if (!f) return;
    unsigned n = (unsigned)kJobs; fwrite(&n, 4, 1, f);
    for (int i = 0; i < kJobs; i++) { unsigned sz = (unsigned)g_blob[i].size(); fwrite(&sz, 4, 1, f); if (sz) fwrite(g_blob[i].data(), 1, sz, f); }
    fclose(f);
    MoveFileExW(tmp.c_str(), path.c_str(), MOVEFILE_REPLACE_EXISTING);
}
static volatile LONG g_jobNext = 0, g_jobFailedOld = 0, g_jobFailedNew = 0, g_jobDone = 0;
static DWORD WINAPI CompileWorker(LPVOID) {
    for (;;) {
        LONG i = InterlockedIncrement(&g_jobNext) - 1; if (i >= kJobs) return 0;
        if (!g_blob[i].empty()) continue;   // from the cache
        const char* src = i < 2 ? kHlsl : kHlsl2; const char* entry = i < 2 ? kEntries[i] : kEntries2[i - 2];
        ID3DBlob* code = nullptr, * msg = nullptr;
        HRESULT hr = D3DCompile(src, strlen(src), i < 2 ? "resonancevr_recon" : "resonancevr_recon2", nullptr, nullptr, entry, "cs_5_0", D3DCOMPILE_OPTIMIZATION_LEVEL3, 0, &code, &msg);
        if (FAILED(hr) || !code) {
            LOGE("recon: shader %s: %s", entry, msg ? (const char*)msg->GetBufferPointer() : "compile failed");
            if (i < 2) InterlockedExchange(&g_jobFailedOld, 1); else InterlockedExchange(&g_jobFailedNew, 1);
            Rel(msg); continue;
        }
        Rel(msg);
        g_blob[i].assign((const char*)code->GetBufferPointer(), (const char*)code->GetBufferPointer() + code->GetBufferSize());
        code->Release();
    }
}
static DWORD WINAPI PrepThread(LPVOID) {
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);
    ULONGLONG t0 = GetTickCount64();
    bool cached = LoadCache();
    int missing = 0; for (auto& b : g_blob) if (b.empty()) missing++;
    if (!missing) { InterlockedExchange(&g_prep, 2); LOGI("recon: shaders loaded from the cache (%llu ms)", GetTickCount64() - t0); return 0; }
    HANDLE th[3] = {};
    for (int k = 0; k < 3; k++) th[k] = CreateThread(nullptr, 0, CompileWorker, nullptr, 0, nullptr);   // up to 4 compile at once (D3DCompile is thread-safe)
    CompileWorker(nullptr);
    for (int k = 0; k < 3; k++) if (th[k]) { WaitForSingleObject(th[k], INFINITE); CloseHandle(th[k]); }
    if (g_jobFailedOld) { InterlockedExchange(&g_prep, -1); return 0; }
    SaveCache(); InterlockedExchange(&g_prep, 2);
    LOGI("recon: shaders compiled in %llu ms (game start, background%s) - saved to the cache for the next start%s", GetTickCount64() - t0,
         cached ? ", the entries the cache lacked" : "", g_jobFailedNew ? "; the new infill pipeline has entry points that did not compile (see above) - the classic infill runs" : "");
    return 0;
}
void PrepareShaders() {   // the first Present (any mode): nothing is compiled on a frame
    if (InterlockedCompareExchange(&g_prep, 1, 0) != 0) return;
    HANDLE h = CreateThread(nullptr, 0, PrepThread, nullptr, 0, nullptr);
    if (h) CloseHandle(h); else InterlockedExchange(&g_prep, -1);
}

// 0.8.0 (framework guide, Part AG): the shader OBJECTS are made off the frame too - creating one makes the driver translate the
// bytecode, tens of milliseconds each, 13 of them. The frame only reads the state.
static ID3D11Device* g_objDev = nullptr;
static DWORD WINAPI ObjThread(LPVOID) {
    ID3D11Device* dev = g_objDev;
    ULONGLONG t0 = GetTickCount64();
    bool fail = false;
    auto makeOld = [&](int i, ID3D11ComputeShader** cs) {
        HRESULT hr = dev->CreateComputeShader(g_blob[i].data(), g_blob[i].size(), nullptr, cs);
        if (FAILED(hr)) { LOGW("recon: the driver refused the cached shader %s (%08lx) - compiling it again", kEntries[i], (unsigned long)hr);
                          DeleteFileW(CachePath().c_str()); }
        return SUCCEEDED(hr);
    };
    if (!makeOld(0, &g_csForward) || !makeOld(1, &g_csResolve)) {   // refused cached bytecode: once more from the source, on this thread
        Rel(g_csForward); Rel(g_csResolve);
        for (int i = 0; i < 2; i++) {
            ID3DBlob* code = nullptr, * msg = nullptr;
            HRESULT hr = D3DCompile(kHlsl, strlen(kHlsl), "resonancevr_recon", nullptr, nullptr, kEntries[i], "cs_5_0", D3DCOMPILE_OPTIMIZATION_LEVEL3, 0, &code, &msg);
            Rel(msg); if (FAILED(hr) || !code) { fail = true; break; }
            hr = dev->CreateComputeShader(code->GetBufferPointer(), code->GetBufferSize(), nullptr, i ? &g_csResolve : &g_csForward);
            code->Release(); if (FAILED(hr)) { fail = true; break; }
        }
    }
    for (int k = 0; k < kN2 && !fail; k++) {
        if (g_blob[2 + k].empty()) continue;
        HRESULT hr = dev->CreateComputeShader(g_blob[2 + k].data(), g_blob[2 + k].size(), nullptr, &g_cs2[k]);
        if (FAILED(hr)) { LOGW("recon: the driver refused the new shader %s (%08lx) - that part of the new infill is off", kEntries2[k], (unsigned long)hr); g_cs2[k] = nullptr; }
    }
    g_newReq = g_cs2[E_FWD2] && g_cs2[E_RES2] && g_cs2[E_FINISH];
    g_haveMem = g_newReq && g_cs2[E_MEMORY];
    g_haveTiles = g_newReq && g_cs2[E_TILES] && g_cs2[E_TILEFIX];
    g_havePm = g_haveTiles && g_cs2[E_PMINIT] && g_cs2[E_PMITER] && g_cs2[E_PPSEED] && g_cs2[E_PPDOWN] && g_cs2[E_PPUP];
    if (!fail) {
        D3D11_BUFFER_DESC cb = {}; cb.Usage = D3D11_USAGE_DEFAULT; cb.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
        cb.ByteWidth = 176; if (FAILED(dev->CreateBuffer(&cb, nullptr, &g_cbFwd))) fail = true;
        cb.ByteWidth = 224; if (!fail && FAILED(dev->CreateBuffer(&cb, nullptr, &g_cbRes))) fail = true;
        cb.ByteWidth = 784; if (!fail && FAILED(dev->CreateBuffer(&cb, nullptr, &g_cb2))) fail = true;
        D3D11_SAMPLER_DESC sd = {}; sd.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR; sd.MaxLOD = D3D11_FLOAT32_MAX;
        sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
        if (!fail && FAILED(dev->CreateSamplerState(&sd, &g_bilinear))) fail = true;
        D3D11_BUFFER_DESC bd = {}; bd.ByteWidth = 48; bd.Usage = D3D11_USAGE_DEFAULT; bd.BindFlags = D3D11_BIND_UNORDERED_ACCESS;   // 12 counters
        bd.MiscFlags = D3D11_RESOURCE_MISC_BUFFER_ALLOW_RAW_VIEWS;
        if (!fail && FAILED(dev->CreateBuffer(&bd, nullptr, &g_counters))) fail = true;
        D3D11_UNORDERED_ACCESS_VIEW_DESC ud = {}; ud.Format = DXGI_FORMAT_R32_TYPELESS; ud.ViewDimension = D3D11_UAV_DIMENSION_BUFFER;
        ud.Buffer.NumElements = 12; ud.Buffer.Flags = D3D11_BUFFER_UAV_FLAG_RAW;
        if (!fail && FAILED(dev->CreateUnorderedAccessView(g_counters, &ud, &g_countersU))) fail = true;
        bd.Usage = D3D11_USAGE_STAGING; bd.BindFlags = 0; bd.MiscFlags = 0; bd.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
        if (!fail) for (auto& r : g_readback) dev->CreateBuffer(&bd, nullptr, &r);
    }
    if (!fail) LOGI("recon: shaders ready in %llu ms (made in the background - nothing was compiled or created on a frame); new infill: %s "
                    "(real pixels %s, matched tiles %s, PatchMatch %s)", GetTickCount64() - t0, g_newReq ? "available" : "NOT available - the classic infill runs",
                    g_haveMem ? "yes" : "no", g_haveTiles ? "yes" : "no", g_havePm ? "yes" : "no");
    dev->Release(); g_objDev = nullptr;
    InterlockedExchange(&g_obj, fail ? -1 : 2);
    return 0;
}
static bool Ready(ID3D11Device* dev) {
    if (g_ready) return g_ready > 0;
    PrepareShaders();
    if (g_prep == -1) { g_ready = -1; return false; }
    if (g_prep != 2) return false;   // still preparing: this frame shows the drawn view
    if (g_obj == 0) {
        if (InterlockedCompareExchange(&g_obj, 1, 0) == 0) {
            g_dev = dev; g_objDev = dev; dev->AddRef();
            HANDLE h = CreateThread(nullptr, 0, ObjThread, nullptr, 0, nullptr);
            if (h) CloseHandle(h); else { dev->Release(); g_objDev = nullptr; InterlockedExchange(&g_obj, -1); }
        }
        return false;
    }
    if (g_obj == 1) return false;
    if (g_obj < 0) { g_ready = -1; return false; }
    g_ready = 1;
    return true;
}

// 0.9.1 (framework 49.5): the eye image and the blend input in R10G10B10A2_UNORM when the picture is 8 / 10-bit and the GPU stores that
// format from compute (typed UAV store) - half the bytes of RGBA16F. An HDR (float) picture keeps RGBA16F. The fill images stay RGBA16F
// (their alpha holds the fill's distance).
static DXGI_FORMAT g_eyeFmt = DXGI_FORMAT_R16G16B16A16_FLOAT;
static int g_eyeFmt10 = -1;   // -1 not checked, 0 no, 1 yes
static DXGI_FORMAT EyeFormat(ID3D11Device* dev, DXGI_FORMAT picture) {
    DXGI_FORMAT t = Typeless(picture);
    bool low = t == DXGI_FORMAT_R8G8B8A8_TYPELESS || t == DXGI_FORMAT_B8G8R8A8_TYPELESS || t == DXGI_FORMAT_R10G10B10A2_TYPELESS;
    if (g_eyeFmt10 < 0 && dev) {
        UINT fs = 0;
        g_eyeFmt10 = SUCCEEDED(dev->CheckFormatSupport(DXGI_FORMAT_R10G10B10A2_UNORM, &fs)) && (fs & D3D11_FORMAT_SUPPORT_TYPED_UNORDERED_ACCESS_VIEW) &&
                     (fs & D3D11_FORMAT_SUPPORT_SHADER_LOAD) ? 1 : 0;
        LOGI("recon: 10-bit eye image %s", g_eyeFmt10 ? "available (used when the picture is 8 / 10-bit)" : "not stored from compute on this GPU - RGBA16F");
    }
    DXGI_FORMAT f = (low && g_eyeFmt10 == 1) ? DXGI_FORMAT_R10G10B10A2_UNORM : DXGI_FORMAT_R16G16B16A16_FLOAT;
    if (f != g_eyeFmt) { g_eyeFmt = f; LOGI("recon: eye image %s", f == DXGI_FORMAT_R10G10B10A2_UNORM ? "R10G10B10A2 (10-bit)" : "RGBA16F"); }
    return f;
}
static bool MakeTex(Tex& x, UINT w, UINT h, DXGI_FORMAT f, bool uav, const char* what) {
    if (x.t && x.w == w && x.h == h && x.f == f) return true;
    Drop(x);
    D3D11_TEXTURE2D_DESC d = {}; d.Width = w; d.Height = h; d.MipLevels = 1; d.ArraySize = 1; d.Format = Typeless(f); d.SampleDesc.Count = 1;
    d.BindFlags = D3D11_BIND_SHADER_RESOURCE | (uav ? D3D11_BIND_UNORDERED_ACCESS : 0);
    D3D11_SHADER_RESOURCE_VIEW_DESC sv = {}; sv.Format = SrvFmt(f); sv.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D; sv.Texture2D.MipLevels = 1;
    D3D11_UNORDERED_ACCESS_VIEW_DESC uv = {}; uv.Format = SrvFmt(f); uv.ViewDimension = D3D11_UAV_DIMENSION_TEXTURE2D;
    if (FAILED(g_dev->CreateTexture2D(&d, nullptr, &x.t)) || FAILED(g_dev->CreateShaderResourceView(x.t, &sv, &x.srv)) ||
        (uav && FAILED(g_dev->CreateUnorderedAccessView(x.t, &uv, &x.uav)))) {
        LOGE("recon: %s %ux%u fmt %d failed", what, w, h, (int)f); Drop(x); return false;
    }
    x.w = w; x.h = h; x.f = f;
    LOGI("recon: %s %ux%u", what, w, h);
    return true;
}

// ---- matrices (row vectors: clip = [x y z 1] * View * Proj; node matrix rows = right, up, back, position)
static void Mul(const double* a, const double* b, double* o) {
    double t[16];
    for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) { double v = 0; for (int k = 0; k < 4; k++) v += a[i * 4 + k] * b[k * 4 + j]; t[i * 4 + j] = v; }
    memcpy(o, t, sizeof t);
}
static bool Inv(const double* m, double* o) {   // Gauss-Jordan, partial pivoting
    double a[4][8];
    for (int i = 0; i < 4; i++) for (int j = 0; j < 8; j++) a[i][j] = j < 4 ? m[i * 4 + j] : (j - 4 == i ? 1.0 : 0.0);
    for (int c = 0; c < 4; c++) {
        int p = c; for (int r = c + 1; r < 4; r++) if (fabs(a[r][c]) > fabs(a[p][c])) p = r;
        if (fabs(a[p][c]) < 1e-300) return false;
        if (p != c) for (int j = 0; j < 8; j++) { double t = a[c][j]; a[c][j] = a[p][j]; a[p][j] = t; }
        double d = a[c][c]; for (int j = 0; j < 8; j++) a[c][j] /= d;
        for (int r = 0; r < 4; r++) if (r != c) { double f = a[r][c]; if (f != 0) for (int j = 0; j < 8; j++) a[r][j] -= f * a[c][j]; }
    }
    for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) o[i * 4 + j] = a[i][j + 4];
    return true;
}
// world -> view of a node matrix, with the world origin moved to `o` (float precision on the GPU stays good)
static bool View(const float* T, const double* o, double* V) {
    double W[16] = { T[0], T[1], T[2], 0, T[3], T[4], T[5], 0, T[6], T[7], T[8], 0, T[9] - o[0], T[10] - o[1], T[11] - o[2], 1 };
    return Inv(W, V);
}
// the projection the renderer got (cap, drawn with frustum capTan), with frustum `tan`'s x / y terms; jit = keep the
// game's sub-pixel jitter (only what the depth was drawn with has it)
static void ProjFor(const float* cap, const float* capTan, const float* tan, bool jit, double* P) {
    for (int i = 0; i < 16; i++) P[i] = cap[i];
    double wc = capTan[1] - capTan[0], hc = capTan[2] - capTan[3];
    double jx = cap[8] - (capTan[1] + capTan[0]) / wc, jy = cap[9] - (capTan[2] + capTan[3]) / hc;
    double w = tan[1] - tan[0], h = tan[2] - tan[3];
    P[0] = 2.0 / w; P[5] = 2.0 / h; P[1] = P[4] = 0;
    P[8] = (jit ? jx : 0.0) + (tan[1] + tan[0]) / w;
    P[9] = (jit ? jy : 0.0) + (tan[2] + tan[3]) / h;
}
static void ToF(const double* d, float* f) { for (int i = 0; i < 16; i++) f[i] = (float)d[i]; }

static void Collect(ID3D11DeviceContext* c) {   // counters / timing of a few frames ago, never waiting
    for (int i = 0; i < 3; i++) {
        if (!g_rbPending[i]) continue;
        D3D11_MAPPED_SUBRESOURCE m = {};
        if (c->Map(g_readback[i], 0, D3D11_MAP_READ, D3D11_MAP_FLAG_DO_NOT_WAIT, &m) != S_OK) continue;
        const UINT* n = (const UINT*)m.pData;   // [0] pixels, [1] gap fill, [2] remembered, [3] UI, [4] / [5] depth side, [6] fill that kept last frame's fill, [7] / [8] depth exactly 0 / 1
        // 0.9.3 (Framework Boost 12, 0.6.64): the depth direction from decisive evidence only. Cleared / sky pixels hold exactly the far value,
        // so whichever extreme appears (at least 1 % of the samples, 90 % of them on one side) tells the direction. The "upper half" count
        // is used only before anything is decided and only with a clear majority (75 %): close to a wall almost every sample sits near the
        // near end and that count says the opposite of the truth - it flipped the depth there (everything inside-out).
        {
            UINT n0 = n[7], n1 = n[8], mid = n[4], tot = n0 + n1 + mid;
            int dir = -1; bool exact = false; const char* why = "";   // dir: 1 standard (far = 1), 0 reversed (far = 0)
            if (tot > 50 && (n0 + n1) * 100 >= tot && (n0 + n1) > 4) {
                if (n1 * 10 >= (n0 + n1) * 9) { dir = 1; exact = true; why = "samples at exactly 1"; }
                else if (n0 * 10 >= (n0 + n1) * 9) { dir = 0; exact = true; why = "samples at exactly 0"; }
            }
            if (mid > 50) g_farHalf = (float)n[5] / (float)mid;
            if (dir < 0 && !g_dirExact && mid > 50 && (g_farHalf >= 0.75f || g_farHalf <= 0.25f)) { dir = g_farHalf >= 0.75f ? 1 : 0; why = "the upper-half count (nothing decisive yet)"; }
            int want = (dir >= 0 && g_projKnown) ? ((dir == 1) != g_projFarHigh ? 1 : 0) : -1;
            if (want >= 0 && (want != g_flip || (exact && !g_dirExact))) {
                if (++g_flipVotes >= (g_flip < 0 ? 2 : 6)) {
                    bool changed = want != g_flip;
                    g_flip = want; g_flipVotes = 0; if (exact) g_dirExact = true;
                    LOGI("recon: depth runs %s (%s: exact 0 %u, exact 1 %u, upper half %.0f %% of %u), the game's projection says %s - %s%s",
                         dir == 1 ? "standard (far = 1)" : "reversed (far = 0)", why, n0, n1, g_farHalf * 100.f, mid, g_projFarHigh ? "standard" : "reversed",
                         want ? "depth turned round to match" : "used as it is", changed ? "" : " (now decided by the far value)");
                }
            } else g_flipVotes = 0;
        }
        if (n[0]) {
            g_pctGap = 100.f * n[1] / n[0]; g_pctHist = 100.f * n[2] / n[0]; g_pctUi = 100.f * n[3] / n[0];
            g_pctKept = n[1] ? 100.f * n[6] / n[1] : 0.f;
            // a pass over the whole picture after the UI split (a final colour pass) would make every pixel "UI"
            // a pass over the whole picture after the UI split (a final colour pass) makes every pixel "UI" for good; a
            // full-screen menu does it for a while. ~10 s of it: the split goes off and is tried again 20 s later.
            if (g_pctUi > 60.f) {
                if (++g_uiAll > 30 && !g_uiSplitOff) {
                    g_uiSplitOff = true; g_uiRetryAt = ModTick64() + 20000;
                    LOGW("recon: nearly the whole picture counts as UI for 10 s - UI reconstructed with the picture, split retried in 20 s");
                }
            } else g_uiAll = 0;
        }
        c->Unmap(g_readback[i], 0); g_rbPending[i] = false;
    }
    for (auto& q : g_timers) {
        if (!q.pending) continue;
        D3D11_QUERY_DATA_TIMESTAMP_DISJOINT dj = {}; UINT64 st[8] = {}; bool got = c->GetData(q.dj, &dj, sizeof dj, D3D11_ASYNC_GETDATA_DONOTFLUSH) == S_OK;
        for (int k = 0; got && k < 8; k++) got = c->GetData(q.ts[k], &st[k], sizeof st[k], D3D11_ASYNC_GETDATA_DONOTFLUSH) == S_OK;
        if (!got) continue;
        q.pending = false;
        if (!dj.Disjoint && dj.Frequency && st[7] > st[0]) {
            g_gpuMs += (double)(st[7] - st[0]) * 1000.0 / (double)dj.Frequency; g_gpuN++;
            for (int k = 0; k < 7; k++) if (st[k + 1] >= st[k]) g_passMs[k] += (double)(st[k + 1] - st[k]) * 1000.0 / (double)dj.Frequency;
            g_passN++;
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// 0.8.0 stereo reconstruction: the infill pipeline of the framework's 0.6.84 reference (shaders: recon_shaders2.h)
//   memory (once per drawn frame) -> forward -> matched tiles -> PatchMatch + membrane -> resolve -> finish
// Presets (framework 0.6.84): performance = matched tiles only; balanced = PatchMatch 1 pass, 3 x 3 vote, 21 tile offsets;
// quality = PatchMatch 3 passes, 5 x 5 vote, 63 tile offsets, four-level membrane. Passes a preset does not need do not run.
static Tex g_big, g_fillCurE[2], g_fillPrev[2];   // 0.9 (framework 0.6.96): each rebuilt eye its own pair of fill images, swapped per eye, never shared
static Tex g_tiles, g_tileCorr, g_tilesFix, g_corrFix;
static Tex g_heldTile[2], g_heldCorr[2];            // 0.9: each rebuilt eye's tile offsets of its last frame (the held candidate)
static LONG g_heldAt[2] = { -100, -100 }; static UINT g_heldW[2] = {}, g_heldH[2] = {};

static Tex g_pmCol[2], g_pmSt[2], g_dn[4], g_up[3];
static Tex g_memCol[2], g_memDist[2], g_memOff[2];
static int g_memLast = -1; static LONG g_memFrame = -1; static ULONGLONG g_memTick = 0;
struct PrevCam { bool ok = false; float T[12] = {}; double P[16] = {}; LONG at = 0; };
static PrevCam g_prevDrawn, g_fillCam[2];
static int g_newMode = -1, g_newPasses = 0; static unsigned g_newMemPts = 0; static bool g_newMem = false;
struct Cb2 {
    float clipToWorld[16], worldToOther[16], otherToDrawn[16], drawnToOther[16], otherToPrev[16], curToPrev[16], prevToCur[16];
    float dsize[4], ksize[4], osize[4], hsize[4], fmt[4], foot[4], z[4], zd[4], opt[4], uic[4], pre[4], mix[4], mem[4], misc[4];
    float worldToOther2[16], foot2[4];   // shared forward pass: the second rebuilt eye
    float edge[4], edge2[4];             // 0.9: edge fill on, held tiles valid, performance path | reserved
};
static_assert(sizeof(Cb2) == 784, "constant buffer layout");
struct NewIn {
    ID3D11DeviceContext* c; const RenderedEye* re; Slot* sl; Set* s;
    ID3D11ShaderResourceView* sceneSrv; ID3D11ShaderResourceView* finalSrv;
    UINT rw, rh, ow, oh; int o; LONG now; int flip; int reach;
    const double* org; const double* Pdj; const double* Pd; const double* Po;
    const double* VPdj; const double* VPo; const double* clipToWorld; const double* toDrawn; const double* otherInv;
    bool uiOn; float cdx, cdy, cox, coy, uiK; const float* foot; bool count;
    bool dualFirst = false, dualSecond = false;     // shared forward pass: this eye also fills the other eye's key map / that map is already filled
    const double* VPo2 = nullptr; float foot2[4] = {};
    bool headsetView = false;                       // recon_view = headset: the drawn view is at the headset's size (sharpened more)
    bool upscaled = false;                          // the depth is smaller than the picture (upscaler / render scale): steady edges
};
static UINT Lv(UINT n, int i) { return (n + (1u << i) - 1) >> i; }
static bool ReconNew(const NewIn& in, Stp& stp) {
    ID3D11DeviceContext* c = in.c;
    const bool perf = g_set.reconPreset == "performance", qual = g_set.reconPreset == "quality";
    int mode = perf ? 1 : 2;                                  // 0 none (soft taps only), 1 matched tiles, 2 PatchMatch + ring
    if (mode == 2 && !g_havePm) mode = g_haveTiles ? 1 : 0;
    if (mode == 1 && !g_haveTiles) mode = 0;
    const bool memOn = g_set.reconFill == "history" && g_haveMem && !perf;   // 0.9: the remembered pixels belong to balanced / quality (framework 0.6.97)
    const unsigned memPts = perf ? 1000000u : qual ? 4000000u : 2000000u;
    const int passes = qual ? 3 : 1, voteR = qual ? 2 : 1, tileOffs = perf ? 35 : qual ? 63 : 21;
    const UINT kw = in.rw, kh = in.rh, hw = (kw + 1) / 2, hh = (kh + 1) / 2, tx = (kw + 31) / 32, ty = (kh + 31) / 32;
    UINT mw = kw, mh = kh;
    if (memOn) {
        double sc = sqrt((double)memPts / ((double)kw * kh)); if (sc > 1.0) sc = 1.0;
        mw = (UINT)(kw * sc); mh = (UINT)(kh * sc); if (mw < 64) mw = 64; if (mh < 64) mh = 64; if (mw > kw) mw = kw; if (mh > kh) mh = kh;
    }
    const bool steady = g_set.reconSteady;
    // ---- textures (all before the first dispatch: a refusal here leaves the older pipeline to run this frame)
    const DXGI_FORMAT F16 = DXGI_FORMAT_R16G16B16A16_FLOAT;
    void* memBefore = g_memCol[0].t; void* fillBefore = g_fillPrev[in.o].t;
    bool ok = MakeTex(g_big, in.ow, in.oh, g_eyeFmt, true, "reconstructed eye (before the blend)") && MakeTex(g_fillCurE[in.o & 1], in.ow, in.oh, F16, true, "fill of this frame");
    if (ok && steady) ok = MakeTex(g_fillPrev[0], in.ow, in.oh, F16, true, "steady fill, left") && MakeTex(g_fillPrev[1], in.ow, in.oh, F16, true, "steady fill, right");
    if (!steady) { Drop(g_fillPrev[0]); Drop(g_fillPrev[1]); }
    if (ok && mode >= 1) ok = MakeTex(g_tiles, tx, ty, F16, true, "patch tiles") && MakeTex(g_tileCorr, tx, ty, F16, true, "patch tile colour") &&
                              MakeTex(g_tilesFix, tx, ty, F16, true, "patch tiles (completed)") && MakeTex(g_corrFix, tx, ty, F16, true, "patch tile colour (completed)");
    if (ok && mode == 2) {
        for (int i = 0; i < 2 && ok; i++) ok = MakeTex(g_pmCol[i], hw, hh, F16, true, "PatchMatch colours") && MakeTex(g_pmSt[i], hw, hh, F16, true, "PatchMatch offsets");
        for (int i = 0; i < 4 && ok; i++) ok = MakeTex(g_dn[i], Lv(hw, i), Lv(hh, i), F16, true, "membrane level");
        for (int i = 0; i < 3 && ok; i++) ok = MakeTex(g_up[i], Lv(hw, i), Lv(hh, i), F16, true, "membrane result");
    } else if (mode != 2) { for (auto& t : g_pmCol) Drop(t); for (auto& t : g_pmSt) Drop(t); for (auto& t : g_dn) Drop(t); for (auto& t : g_up) Drop(t); }
    if (mode < 1) { Drop(g_tiles); Drop(g_tileCorr); Drop(g_tilesFix); Drop(g_corrFix); }
    const bool heldOn = perf && mode == 1;
    bool heldOk = false;
    if (ok && heldOn) {
        const int ho = in.o & 1;
        void* hb = g_heldTile[ho].t;
        ok = MakeTex(g_heldTile[ho], tx, ty, F16, true, "held tile offsets") && MakeTex(g_heldCorr[ho], tx, ty, F16, true, "held tile colours");
        if (ok) heldOk = hb == (void*)g_heldTile[ho].t && g_heldW[ho] == tx && g_heldH[ho] == ty && in.now - g_heldAt[ho] <= 3 && in.now != g_heldAt[ho];
    } else if (!heldOn) { for (int e = 0; e < 2; e++) { Drop(g_heldTile[e]); Drop(g_heldCorr[e]); g_heldW[e] = 0; } }
    if (ok && memOn)
        for (int i = 0; i < 2 && ok; i++) ok = MakeTex(g_memCol[i], mw, mh, F16, true, "remembered pixels") && MakeTex(g_memDist[i], mw, mh, DXGI_FORMAT_R32_FLOAT, true, "remembered distances") &&
                                               MakeTex(g_memOff[i], mw, mh, F16, true, "remembered offsets");
    if (!memOn) { for (auto& t : g_memCol) Drop(t); for (auto& t : g_memDist) Drop(t); for (auto& t : g_memOff) Drop(t); g_memLast = -1; g_prevDrawn.ok = false; }
    if (!ok) { static int said = 0; if (said++ < 3) LOGW("recon: the new infill's textures could not be made - the classic infill runs"); return false; }
    if (memBefore != (void*)g_memCol[0].t) { g_memLast = -1; g_prevDrawn.ok = false; }   // new memory: nothing remembered yet
    if (fillBefore != (void*)g_fillPrev[in.o].t) g_fillCam[0].ok = g_fillCam[1].ok = false;
    if (g_newMode != mode || g_newPasses != passes || g_newMemPts != memPts || g_newMem != memOn) {
        g_newMode = mode; g_newPasses = passes; g_newMemPts = memPts; g_newMem = memOn;
        LOGI("recon: infill %s - %s%s (preset %s: PatchMatch passes %d, vote %d x %d, tile offsets %d, remembered points %u)",
             g_set.reconFill.c_str(), mode == 2 ? "PatchMatch + membrane + ring" : mode == 1 ? "matched tiles" : "background taps only",
             memOn ? ", real remembered pixels" : "", g_set.reconPreset.c_str(), mode == 2 ? passes : 0, 2 * voteR + 1, 2 * voteR + 1, mode ? tileOffs : 0, memOn ? mw * mh : 0u);
    }
    // ---- the constant buffer
    Cb2 cb = {};
    ToF(in.clipToWorld, cb.clipToWorld); ToF(in.VPo, cb.worldToOther); ToF(in.toDrawn, cb.otherToDrawn);
    { double dto[16]; if (Inv(in.toDrawn, dto)) ToF(dto, cb.drawnToOther); }
    bool steadyOk = false;
    if (steady) {
        PrevCam& fc = g_fillCam[in.o];
        if (fc.ok && in.now - fc.at <= 3 && g_fillPrev[in.o].t) {
            double Vh[16], VPh[16], op[16];
            if (View(fc.T, in.org, Vh)) { Mul(Vh, fc.P, VPh); Mul(in.otherInv, VPh, op); ToF(op, cb.otherToPrev); steadyOk = true; }
        }
    }
    const bool newFrame = g_memFrame != in.now;
    bool histOk = false;
    if (memOn && newFrame && g_prevDrawn.ok && g_memLast >= 0 && in.now - g_prevDrawn.at <= 4) {
        double Vh[16], VPh[16], iph[16], a[16], b[16];
        if (View(g_prevDrawn.T, in.org, Vh)) {
            Mul(Vh, g_prevDrawn.P, VPh);
            if (Inv(VPh, iph)) { Mul(in.clipToWorld, VPh, a); Mul(iph, in.VPdj, b); ToF(a, cb.curToPrev); ToF(b, cb.prevToCur); histOk = true; }
        }
    }
    cb.dsize[0] = (float)in.rw; cb.dsize[1] = (float)in.rh; cb.dsize[2] = 1.f / in.rw; cb.dsize[3] = 1.f / in.rh;
    cb.ksize[0] = (float)kw; cb.ksize[1] = (float)kh; cb.ksize[2] = 1.f / kw; cb.ksize[3] = 1.f / kh;
    cb.osize[0] = (float)in.ow; cb.osize[1] = (float)in.oh; cb.osize[2] = 1.f / in.ow; cb.osize[3] = 1.f / in.oh;
    cb.hsize[0] = (float)hw; cb.hsize[1] = (float)hh; cb.hsize[2] = (float)tx; cb.hsize[3] = (float)ty;
    cb.fmt[0] = (float)in.s->decode; cb.fmt[1] = (float)in.flip; cb.fmt[2] = in.count ? 1.f : 0.f;
    cb.fmt[3] = g_set.reconNearLimit > 0.f ? g_set.reconNearLimit * (g_cam.unitsPerMetre > 0.f ? g_cam.unitsPerMetre : 1.f) : 0.f;
    cb.foot[0] = in.foot[0]; cb.foot[1] = in.foot[1]; cb.foot[2] = in.foot[2]; cb.foot[3] = g_set.reconEdgePixels ? 1.f : 0.f;
    cb.z[0] = (float)-in.Po[10]; cb.z[1] = (float)in.Po[14]; cb.z[2] = (float)in.reach * kw / 1920.f + 2.f; cb.z[3] = steadyOk ? 1.f : 0.f;
    cb.zd[0] = (float)-in.Pd[10]; cb.zd[1] = (float)in.Pd[14];
    cb.opt[0] = (float)g_set.reconDebug; cb.opt[1] = in.uiOn ? 1.f : 0.f; cb.opt[2] = 1.5f / 255.f; cb.opt[3] = in.uiK;
    cb.uic[0] = in.cdx; cb.uic[1] = in.cdy; cb.uic[2] = in.cox; cb.uic[3] = in.coy;
    cb.pre[0] = (float)voteR; cb.pre[1] = (float)tileOffs; cb.pre[2] = (float)passes; cb.pre[3] = (float)mode;
    cb.mix[0] = (float)(g_set.reconEdgeGuard < 0 ? 0 : g_set.reconEdgeGuard > 4 ? 4 : g_set.reconEdgeGuard); cb.mix[1] = steady ? 1.f : 0.f;
    cb.mix[2] = g_set.reconBlend; cb.mix[3] = g_set.reconDetail;
    ULONGLONG tk = ModTick64(); float dt = g_memTick ? (float)(tk - g_memTick) * 0.001f : 0.016f; if (dt > 0.1f) dt = 0.1f;
    cb.mem[0] = histOk ? 1.f : 0.f; cb.mem[1] = (float)mw; cb.mem[2] = (float)mh; cb.mem[3] = dt;
    cb.misc[0] = 0.f; cb.misc[1] = 4.f; cb.misc[2] = 0.f; cb.misc[3] = 0.f;   // 0.9 (framework 0.6.85): the sharpening runs in the headset blit (BlitSharpen), not here
    cb.edge[0] = g_set.reconEdgeFill ? 1.f : 0.f; cb.edge[1] = heldOk ? 1.f : 0.f; cb.edge[2] = heldOn ? 1.f : 0.f; cb.edge[3] = in.upscaled ? 1.f : 0.f;
    // 49.9: the blend input is written only by resolve groups near a gap tile, the blend pass writes only band pixels - needs the tiles and no
    // sharpening (sharpening reads every pixel's neighbours)
    cb.edge2[0] = (mode >= 1 && cb.misc[0] <= 0.001f) ? 1.f : 0.f;
    if (in.dualFirst && in.VPo2) { ToF(in.VPo2, cb.worldToOther2); memcpy(cb.foot2, in.foot2, sizeof cb.foot2); cb.foot2[3] = 1.f; }
    auto upload = [&]() { c->UpdateSubresource(g_cb2, 0, nullptr, &cb, 0, 0); };
    ID3D11ShaderResourceView* sv[17]; ID3D11UnorderedAccessView* uv[7];
    auto clearB = [&]() { memset(sv, 0, sizeof sv); memset(uv, 0, sizeof uv); };
    auto run = [&](int e, UINT gx, UINT gy) {
        c->CSSetShader(g_cs2[e], nullptr, 0);
        c->CSSetShaderResources(0, 17, sv); c->CSSetUnorderedAccessViews(0, 7, uv, nullptr);
        c->Dispatch(gx ? gx : 1, gy ? gy : 1, 1);
        ID3D11ShaderResourceView* ns[17] = {}; ID3D11UnorderedAccessView* nu[7] = {};
        c->CSSetUnorderedAccessViews(0, 7, nu, nullptr); c->CSSetShaderResources(0, 17, ns);
    };
    upload();
    c->CSSetConstantBuffers(0, 1, &g_cb2);
    c->CSSetSamplers(0, 1, &g_bilinear);
    ID3D11ShaderResourceView* depthSrv = in.sl->depthSrv;
    // ---- 0 memory: once per drawn frame
    if (memOn && newFrame) {
        int w = g_memLast < 0 ? 0 : g_memLast ^ 1, r = g_memLast;
        clearB(); sv[0] = depthSrv; sv[2] = in.sceneSrv;
        if (histOk && r >= 0) { sv[10] = g_memCol[r].srv; sv[11] = g_memDist[r].srv; sv[12] = g_memOff[r].srv; }
        uv[1] = g_memCol[w].uav; uv[5] = g_memDist[w].uav; uv[6] = g_memOff[w].uav;
        run(E_MEMORY, (mw + 15) / 16, (mh + 7) / 8);
        g_memLast = w;
        memcpy(g_prevDrawn.T, in.re->nodeD, sizeof g_prevDrawn.T); memcpy(g_prevDrawn.P, in.Pdj, sizeof g_prevDrawn.P);
        g_prevDrawn.at = in.now; g_prevDrawn.ok = true;
    }
    g_memFrame = in.now; g_memTick = tk;
    stp.to(c, 1);
    // ---- 1 forward (the key map was cleared by the caller)
    if (!in.dualSecond) {   // (the second eye of a centre view takes the key map the first eye's pass filled)
        clearB(); sv[0] = depthSrv; sv[2] = in.sceneSrv; uv[0] = g_nearest.uav; uv[3] = (in.dualFirst && g_nearest2.uav) ? g_nearest2.uav : nullptr; uv[4] = g_countersU;
        run(E_FWD2, (in.rw + 15) / 16, (in.rh + 7) / 8);
        if (in.dualFirst) { g_dualFrame = in.now; g_dualReady = true; }
    }
    stp.to(c, 2);
    // ---- 1b matched tiles
    if (mode >= 1) {
        clearB(); sv[1] = g_nearest.srv; sv[2] = in.sceneSrv; uv[1] = g_tiles.uav; uv[2] = g_tileCorr.uav;
        if (heldOk) { sv[6] = g_heldTile[in.o & 1].srv; sv[7] = g_heldCorr[in.o & 1].srv; }
        run(E_TILES, tx, ty);
        clearB(); sv[6] = g_tiles.srv; sv[7] = g_tileCorr.srv; uv[1] = g_tilesFix.uav; uv[2] = g_corrFix.uav;
        run(E_TILEFIX, (tx + 7) / 8, (ty + 7) / 8);
        if (heldOn) {   // this frame's completed tiles are the next frame's held candidate
            const int ho = in.o & 1;
            c->CopyResource(g_heldTile[ho].t, g_tilesFix.t); c->CopyResource(g_heldCorr[ho].t, g_corrFix.t);
            g_heldAt[ho] = in.now; g_heldW[ho] = tx; g_heldH[ho] = ty;
        }
    }
    stp.to(c, 3);
    // ---- 1c / 1d PatchMatch on the half map
    int fin = 0;
    if (mode == 2) {
        clearB(); sv[1] = g_nearest.srv; sv[2] = in.sceneSrv; sv[6] = g_tilesFix.srv; sv[7] = g_corrFix.srv; uv[1] = g_pmCol[0].uav; uv[2] = g_pmSt[0].uav;
        run(E_PMINIT, (hw + 15) / 16, (hh + 7) / 8);
        c->CopyResource(g_pmCol[1].t, g_pmCol[0].t); c->CopyResource(g_pmSt[1].t, g_pmSt[0].t);   // non-gap cells never change: both maps agree
        for (int p = 0; p < passes; p++) {
            cb.misc[1] = (float)(passes == 1 ? 4 : p == 0 ? 8 : p == 1 ? 4 : 2); cb.misc[2] = (float)(p + 1 + (in.now & 15)); upload();
            int a = p & 1, b = a ^ 1;
            clearB(); sv[1] = g_nearest.srv; sv[2] = in.sceneSrv; sv[4] = g_pmCol[a].srv; sv[5] = g_pmSt[a].srv; uv[1] = g_pmCol[b].uav; uv[2] = g_pmSt[b].uav;
            run(E_PMITER, (hw + 15) / 16, (hh + 7) / 8);
        }
        fin = passes & 1;
    }
    stp.to(c, 4);
    // ---- 1e membrane
    if (mode == 2) {
        clearB(); sv[1] = g_nearest.srv; sv[2] = in.sceneSrv; sv[5] = g_pmSt[fin].srv; uv[1] = g_dn[0].uav;
        run(E_PPSEED, (hw + 15) / 16, (hh + 7) / 8);
        for (int i = 0; i < 3; i++) { clearB(); sv[14] = g_dn[i].srv; uv[1] = g_dn[i + 1].uav; run(E_PPDOWN, (Lv(hw, i + 1) + 15) / 16, (Lv(hh, i + 1) + 7) / 8); }
        for (int i = 2; i >= 0; i--) {
            clearB(); sv[14] = g_dn[i].srv; sv[15] = i == 2 ? g_dn[3].srv : g_up[i + 1].srv; uv[1] = g_up[i].uav;
            run(E_PPUP, (Lv(hw, i) + 15) / 16, (Lv(hh, i) + 7) / 8);
        }
    }
    stp.to(c, 5);
    // ---- 2 resolve
    cb.misc[3] = (memOn && g_memLast >= 0) ? 1.f : 0.f; upload();
    clearB();
    sv[1] = g_nearest.srv; sv[2] = in.sceneSrv; sv[3] = in.finalSrv;
    if (mode == 2) { sv[5] = g_pmSt[fin].srv; sv[8] = g_up[0].srv; }
    if (mode >= 1) { sv[6] = g_tilesFix.srv; sv[7] = g_corrFix.srv; }
    if (steady && steadyOk) sv[9] = g_fillPrev[in.o].srv;
    if (memOn && g_memLast >= 0) { sv[10] = g_memCol[g_memLast].srv; sv[11] = g_memDist[g_memLast].srv; sv[12] = g_memOff[g_memLast].srv; }
    uv[1] = g_big.uav; uv[2] = g_fillCurE[in.o & 1].uav; uv[4] = g_countersU; uv[6] = g_result.uav;   // u6: the eye image itself (every group); u1: the blend input (groups near gaps)
    if (g_set.reconResolveSplit && mode >= 1) {   // config only (framework 49.12): the slower two-dispatch resolve, for comparison in the log
        cb.edge2[1] = 1.f; upload(); run(E_RES2, (in.ow + 15) / 16, (in.oh + 7) / 8);
        cb.edge2[1] = 2.f; upload(); run(E_RES2, (in.ow + 15) / 16, (in.oh + 7) / 8);
        cb.edge2[1] = 0.f; upload();
    } else run(E_RES2, (in.ow + 15) / 16, (in.oh + 7) / 8);
    stp.to(c, 6);
    // ---- 3 finish
    clearB(); sv[13] = g_big.srv; sv[16] = g_fillCurE[in.o & 1].srv; uv[1] = g_result.uav;
    if (mode >= 1) sv[6] = g_tilesFix.srv;   // 0.9.4: the blend pass skips groups without a gap tile in reach
    run(E_FINISH, (in.ow + 31) / 32, (in.oh + 7) / 8);
    c->CSSetShader(nullptr, nullptr, 0);
    stp.to(c, 7);
    if (steady) {   // this frame's fill is the next frame's steady infill
        std::swap(g_fillCurE[in.o & 1], g_fillPrev[in.o]);
        PrevCam& fc = g_fillCam[in.o];
        memcpy(fc.T, in.re->nodeO, sizeof fc.T); memcpy(fc.P, in.Po, sizeof fc.P); fc.at = in.now; fc.ok = true;
    }
    return true;
}

// 0.9 (framework 0.6.85): sharpening of the rebuilt eyes fused into the headset blit. Amount = max(Sharpness, 0.35 with the headset-size
// view: each eye shows ~77 % of its pixels across, magnified); the blit's step is capped at 0.035 + 0.08 x max(0, amount - 0.3)
float BlitSharpen(bool centre, float& cap) {
    float a = g_set.reconSharpen;
    if (centre && g_set.reconView == "headset" && a < 0.35f) a = 0.35f;
    cap = 0.035f + 0.08f * (a > 0.3f ? a - 0.3f : 0.f);
    return a;
}

static Slot* g_usedSlot = nullptr;
bool Reconstruct(ID3D11DeviceContext* c, const RenderedEye& re, ID3D11Texture2D* finalTex, ID3D11ShaderResourceView* finalSrv, ID3D11ShaderResourceView** out) {
    g_usedSlot = nullptr; *out = nullptr;
    if (!re.recon || re.mono || !re.projOk) { g_noMatrix++; return false; }
    Set* s = g_pub;
    LONG now = g_presents;
    Slot* sl = s ? &s->s[(unsigned)now % kSlots] : nullptr;
    if (!sl || sl->tagDepth != now) {
        g_noDepth++;
        static LONG s_lastNo = -1; if (now != s_lastNo) { s_lastNo = now; g_framesNoDepth++; }
        return false;
    }
    ID3D11Device* dev = nullptr; c->GetDevice(&dev); if (!dev) return false;
    bool ok = Ready(dev); dev->Release();
    if (!ok) return false;
    D3D11_TEXTURE2D_DESC fd; finalTex->GetDesc(&fd);
    // the depth's drawn area: the camera's render size (a depth target can be padded); a depth smaller than that is
    // an upscaler's internal resolution and is used whole
    unsigned rw = 0, rh = 0;
    if (!CameraRenderSize(rw, rh)) { rw = s->dW; rh = s->dH; }
    if (s->dW < rw * 95 / 100 || s->dH < rh * 95 / 100) { rw = s->dW; rh = s->dH; }
    rw = rw > s->dW ? s->dW : rw; rh = rh > s->dH ? s->dH : rh;
    // 0.6.8: the rebuilt eye is made at its own view only (the drawn picture is wider: the shared / centre view), at
    // the drawn picture's pixel density - every pixel computed is one the headset shows
    UINT ow = fd.Width, oh = fd.Height;
    unsigned hw = 0, hh = 0;
    if (::HeadsetEyeSize(hw, hh)) { ow = hw; oh = hh; }   // 0.6.14: the rebuilt eye at the headset's own size (the drawn picture is squeezed)
    else {
        float wD = re.tanD[1] - re.tanD[0], hD = re.tanD[2] - re.tanD[3], wO = re.tanO[1] - re.tanO[0], hO = re.tanO[2] - re.tanO[3];
        if (wD > 0.05f && hD > 0.05f && wO > 0.05f && hO > 0.05f) {
            ow = (UINT)(fd.Width * (wO / wD) + 0.5f); oh = (UINT)(fd.Height * (hO / hD) + 0.5f);
            if (ow > fd.Width) ow = fd.Width; if (oh > fd.Height) oh = fd.Height;
            if (ow < 256) ow = 256; if (oh < 256) oh = 256;
            ow = (ow + 1) & ~1u; oh = (oh + 1) & ~1u;
        }
    }
    if (!MakeTex(g_nearest, rw, rh, DXGI_FORMAT_R32_UINT, true, "nearest-distance map") ||
        !MakeTex(g_result, ow, oh, EyeFormat(g_dev, fd.Format), true, "reconstructed eye")) return false;
    for (int e = 0; e < 2 && !re.centre; e++) {   // the centre view never uses an eye history (no VRAM for it)
        bool had = g_history[e].t != nullptr && g_history[e].f == fd.Format && g_history[e].w == fd.Width && g_history[e].h == fd.Height;
        if (!MakeTex(g_history[e], fd.Width, fd.Height, fd.Format, false, "eye history")) return false;
        if (!had) g_hist[e].ok = false;
    }
    bool sceneOk = sl->sceneSrv && sl->tagScene == now && s->sW == fd.Width && s->sH == fd.Height && Typeless(s->sFmt) == Typeless(fd.Format);
    if (!sceneOk) g_noScene++;
    ID3D11ShaderResourceView* sceneSrv = sceneOk ? sl->sceneSrv : finalSrv;
    ID3D11Texture2D* sceneTex = sceneOk ? sl->scene11 : finalTex;

    const int d = re.eye & 1, o = d ^ 1;
    double org[3] = { re.nodeD[9], re.nodeD[10], re.nodeD[11] };
    double Vd[16], Vo[16], Pdj[16], Pd[16], Po[16];
    if (!View(re.nodeD, org, Vd) || !View(re.nodeO, org, Vo)) { g_noMatrix++; return false; }
    ProjFor(re.proj, re.tanD, re.tanD, true, Pdj);
    ProjFor(re.proj, re.tanD, re.tanD, false, Pd);
    ProjFor(re.proj, re.tanD, re.tanO, false, Po);
    if (fabs(Po[11] + 1.0) > 1e-3 || fabs(Po[15]) > 1e-3 || fabs(Po[3]) > 1e-6 || fabs(Po[7]) > 1e-6) { g_noMatrix++; return false; }
    double VPdj[16], VPd[16], VPo[16], clipToWorld[16], otherInv[16], toDrawn[16], toHist[16];
    Mul(Vd, Pdj, VPdj); Mul(Vd, Pd, VPd); Mul(Vo, Po, VPo);
    if (!Inv(VPdj, clipToWorld) || !Inv(VPo, otherInv)) { g_noMatrix++; return false; }
    Mul(otherInv, VPd, toDrawn);
    EyeHist& h = g_hist[o];
    bool histOk = !re.centre && g_set.reconHistory && h.ok && now - h.at <= 3;   // centre view: no eye is ever drawn for real
    if (histOk) { double Vh[16], VPh[16]; if (View(h.T, org, Vh)) { Mul(Vh, h.P, VPh); Mul(otherInv, VPh, toHist); } else histOk = false; }
    if (!histOk) memcpy(toHist, toDrawn, sizeof toHist);

    // the UI: this eye's UI centre / size against the drawn eye's (the drawn eye may use the wider shared frustum)
    if (g_uiSplitOff && ModTick64() >= g_uiRetryAt) { g_uiSplitOff = false; g_uiAll = 0; LOGI("recon: UI split on again"); }
    // 0.6.12: the centre view splits the UI too - the UI the game drew into the centre picture (placed at its middle,
    // scaled) is copied flat into each rebuilt eye at that eye's UI place (ui_depth), never moved by the scene's depth
    bool uiOn = sceneOk && !g_uiSplitOff && g_set.reconHudSplit;   // 0.9 recon_hud_split off: the HUD is part of the picture and moves with the depth under it
    const bool headsetView = re.centre && g_set.reconView == "headset";
    // 0.8: the drawn view is the headset's size (the game draws fewer pixels)
    if (!g_set.reconHudSplit) { sceneSrv = finalSrv; sceneTex = finalTex; }   // 0.9 recon_hud_split off: the picture holds the HUD
    float cdx = fd.Width * 0.5f, cdy = fd.Height * 0.5f, cox = cdx, coy = cdy, uiK = 1.f;
    if (uiOn && re.centre) {
        cdy = fd.Height * 0.5f - g_set.uiOffsetY * (float)fd.Height;
        UiCentreForEye(re.physEye ^ 1, re.tanO, ow, oh, cox, coy);
        uiK = 1.f;   // the rebuilt eye has the centre picture's pixel density (wide view)
        if (headsetView) {   // headset-size view: the drawn picture is less dense than the eye; a drawn pixel is uiK eye pixels' worth of angle
            float wD = re.tanD[1] - re.tanD[0], wE = re.tanO[1] - re.tanO[0];
            if (wD > 0.05f && wE > 0.05f && ow) { float k = (fd.Width / wD) / (ow / wE); if (k > 0.3f && k < 3.f && fabsf(k - 1.f) > 0.03f) uiK = k; }
        }
    } else if (uiOn) {
        UiCentreForEye(re.physEye, re.tanD, fd.Width, fd.Height, cdx, cdy);
        UiCentreForEye(re.physEye ^ 1, re.tanO, fd.Width, fd.Height, cox, coy);
        // UI pixels per UI unit: drawn image = scale x (its eye's headset width / drawn width), this image = scale
        // (its frustum is the headset's): a step of 1 pixel here is we / wd pixels in the drawn image
        float wd = re.tanD[1] - re.tanD[0], we = g_cam.eyeTan[re.physEye][1] - g_cam.eyeTan[re.physEye][0];
        if (wd > 0.05f && we > 0.05f) uiK = we / wd;
    }

    struct { float clipToWorld[16], worldToOther[16], size[4], fmt[4], foot[4]; } cf = {};   // 0.9 (framework 0.6.96): every constant struct zeroed before it is filled
    ToF(clipToWorld, cf.clipToWorld); ToF(VPo, cf.worldToOther);
    cf.size[0] = (float)rw; cf.size[1] = (float)rh; cf.size[2] = 1.f / rw; cf.size[3] = 1.f / rh;
    {   // which way the game's projection runs (at 5 m): standard Z gives a depth near 1 there, reversed Z near 0
        double dist = 5.0 * (g_cam.unitsPerMetre > 0.f ? g_cam.unitsPerMetre : 1.f);
        double ndc = -Pd[10] + Pd[14] / dist;
        bool farHigh = ndc > 0.5;
        if (!g_projKnown || farHigh != g_projFarHigh) {
            g_projFarHigh = farHigh; g_projKnown = true; g_flipVotes = 0;
            LOGI("recon: the game's projection: depth terms [10] %.6g [11] %.3g [14] %.6g [15] %.3g - %s Z (depth %.4f at 5 m)",
                 Pd[10], Pd[11], Pd[14], Pd[15], farHigh ? "standard" : "reversed", ndc);
        }
    }
    const std::string& dm = g_set.reconDepth;
    int flip = dm == "flip" ? 1 : dm == "game" ? 0 : (g_flip > 0 ? 1 : 0);
    cf.fmt[0] = (float)s->decode; cf.fmt[1] = (float)flip; cf.fmt[2] = 0; cf.fmt[3] = 0;
    {   // 0.6.53: the source grid's spacing in the target (both rw x rh): drawn frustum / other eye's frustum, per axis
        float wD = re.tanD[1] - re.tanD[0], hD = re.tanD[2] - re.tanD[3], wO = re.tanO[1] - re.tanO[0], hO = re.tanO[2] - re.tanO[3];
        float sx = wO > 0.05f ? wD / wO : 9.f, sy = hO > 0.05f ? hD / hO : 9.f;
        float mx = (sx > 1.f ? sx - 1.f : 0.f) + 0.12f, my = (sy > 1.f ? sy - 1.f : 0.f) + 0.12f;   // margin: slants, canted displays
        bool adapt = g_set.reconFootprint && mx < 0.5f && my < 0.5f && g_cam.cantDeg < 0.5f;   // canted displays: spacing not uniform
        cf.foot[0] = mx; cf.foot[1] = my; cf.foot[2] = adapt ? 1.f : 0.f; cf.foot[3] = 0.f;
        static int s_said = -1;
        if ((int)adapt != s_said) { s_said = adapt;
            LOGI("recon: forward footprint %s (source grid %.2f x %.2f target pixels)", adapt ? "adaptive - fewer writes" : "full 2 x 2", sx, sy); }
    }
    struct { float toDrawn[16], toHist[16], outSize[4], keySize[4], z[4], opt[4], uiC[4], fill[4]; } cr = {};
    ToF(toDrawn, cr.toDrawn); ToF(toHist, cr.toHist);
    cr.outSize[0] = (float)ow; cr.outSize[1] = (float)oh; cr.outSize[2] = 1.f / ow; cr.outSize[3] = 1.f / oh;
    cr.keySize[0] = (float)rw; cr.keySize[1] = (float)rh; cr.keySize[2] = 1.f / rw; cr.keySize[3] = 1.f / rh;
    int reach = g_set.reconGapReach < 4 ? 4 : g_set.reconGapReach > 256 ? 256 : g_set.reconGapReach;
    cr.z[0] = (float)-Po[10]; cr.z[1] = (float)Po[14]; cr.z[2] = (float)reach * rw / 1920.f + 2.f; cr.z[3] = histOk ? 1.f : 0.f;
    cr.opt[0] = (float)g_set.reconDebug; cr.opt[1] = uiOn ? 1.f : 0.f; cr.opt[2] = 1.5f / 255.f; cr.opt[3] = uiK;
    cr.uiC[0] = cdx; cr.uiC[1] = cdy; cr.uiC[2] = cox; cr.uiC[3] = coy;
    {   // 0.6.53: infill method + edge guard
        const std::string& fm = g_set.reconFill;
        cr.fill[0] = fm == "clone" ? 1.f : fm == "stretch" ? 2.f : fm == "scatter" ? 3.f : fm == "soft" ? 0.f : 4.f;   // seamless (default)
        cr.fill[1] = (float)(g_set.reconEdgeGuard < 0 ? 0 : g_set.reconEdgeGuard > 4 ? 4 : g_set.reconEdgeGuard);
        cr.fill[2] = cr.fill[3] = 0.f;
    }

    Collect(c);
    GpuTimer& q = g_timers[g_timerNext++ & 3];
    bool timed = !q.pending;
    if (timed && !q.dj) {
        D3D11_QUERY_DESC qd = { D3D11_QUERY_TIMESTAMP_DISJOINT, 0 }; g_dev->CreateQuery(&qd, &q.dj);
        qd.Query = D3D11_QUERY_TIMESTAMP; for (auto& t : q.ts) g_dev->CreateQuery(&qd, &t);
    }
    if (timed) { for (auto t : q.ts) if (!t) timed = false; }
    timed = timed && q.dj;
    Stp stp; stp.q = &q; stp.on = timed; stp.idx = 0;
    if (timed) { c->Begin(q.dj); stp.to(c, 0); }
    const bool newWanted = g_newReq && (g_set.reconFill == "history" || g_set.reconFill == "patch");
    // 0.8 shared forward pass (centre view): the first rebuilt eye splats every drawn pixel into BOTH eyes' key maps, the second
    // takes the finished map - one depth read, one edge / hole test, one close-object limit per drawn pixel instead of two
    const bool dualSecond = newWanted && re.centre && o == 1 && g_dualReady && g_dualFrame == now && g_nearest2.t;
    bool dualFirst = newWanted && re.centre && o == 0;
    double VPo2[16] = {}; float foot2[4] = {};
    if (dualFirst) {
        double Vo1[16], Po1[16];
        if (View(re.nodeO1, org, Vo1)) {
            ProjFor(re.proj, re.tanD, re.tanO1, false, Po1);
            Mul(Vo1, Po1, VPo2);
            float wD = re.tanD[1] - re.tanD[0], hD = re.tanD[2] - re.tanD[3], wO = re.tanO1[1] - re.tanO1[0], hO = re.tanO1[2] - re.tanO1[3];
            float sx = wO > 0.05f ? wD / wO : 9.f, sy = hO > 0.05f ? hD / hO : 9.f;
            float mx = (sx > 1.f ? sx - 1.f : 0.f) + 0.12f, my = (sy > 1.f ? sy - 1.f : 0.f) + 0.12f;
            bool adapt = g_set.reconFootprint && mx < 0.5f && my < 0.5f && g_cam.cantDeg < 0.5f;
            foot2[0] = mx; foot2[1] = my; foot2[2] = adapt ? 1.f : 0.f;
        } else dualFirst = false;
        if (dualFirst && !MakeTex(g_nearest2, rw, rh, DXGI_FORMAT_R32_UINT, true, "nearest-distance map of the second eye")) dualFirst = false;
    }
    if (!re.centre || !newWanted) Drop(g_nearest2);
    g_dualReady = g_dualReady && dualSecond;   // consumed (or stale)
    bool count = (g_made % 30) == 0 && !g_rbPending[g_rbNext] && !dualSecond;
    cf.fmt[2] = count ? 1.f : 0.f;
    c->UpdateSubresource(g_cbFwd, 0, nullptr, &cf, 0, 0);
    c->UpdateSubresource(g_cbRes, 0, nullptr, &cr, 0, 0);
    const UINT far4[4] = { 0xFFFFFFFFu, 0xFFFFFFFFu, 0xFFFFFFFFu, 0xFFFFFFFFu };
    if (dualSecond) std::swap(g_nearest, g_nearest2);   // the second eye's key map, filled by the first eye's pass
    else {
        c->ClearUnorderedAccessViewUint(g_nearest.uav, far4);
        if (dualFirst) c->ClearUnorderedAccessViewUint(g_nearest2.uav, far4);
    }
    if (count) { const UINT zero[4] = {}; c->ClearUnorderedAccessViewUint(g_countersU, zero); }
    bool newOk = false;
    if (newWanted) {
        NewIn ni = {};
        ni.c = c; ni.re = &re; ni.sl = sl; ni.s = s; ni.sceneSrv = sceneSrv; ni.finalSrv = finalSrv;
        ni.upscaled = rw < fd.Width * 95 / 100 && rw * (float)fd.Height < fd.Width * (float)rh * 1.05f + 1.f;   // smaller, same shape
        {   static int s_up = -1; if ((int)ni.upscaled != s_up) { s_up = (int)ni.upscaled;
            LOGI(ni.upscaled ? "recon: depth %ux%u, picture %ux%u - upscaled depth (an upscaler / the game's render scale): steady edges on"
                             : "recon: depth %ux%u, picture %ux%u - full-size depth: steady edges off", rw, rh, fd.Width, fd.Height); } }
        ni.rw = rw; ni.rh = rh; ni.ow = ow; ni.oh = oh; ni.o = o; ni.now = now; ni.flip = flip; ni.reach = reach;
        ni.org = org; ni.Pdj = Pdj; ni.Pd = Pd; ni.Po = Po; ni.VPdj = VPdj; ni.VPo = VPo; ni.clipToWorld = clipToWorld; ni.toDrawn = toDrawn; ni.otherInv = otherInv;
        ni.uiOn = uiOn; ni.cdx = cdx; ni.cdy = cdy; ni.cox = cox; ni.coy = coy; ni.uiK = uiK; ni.foot = cf.foot; ni.count = count;
        ni.dualFirst = dualFirst; ni.dualSecond = dualSecond; ni.VPo2 = dualFirst ? VPo2 : nullptr; memcpy(ni.foot2, foot2, sizeof foot2);
        ni.headsetView = headsetView;
        newOk = ReconNew(ni, stp);
        if (dualFirst && !newOk) g_dualReady = false;
    }
    if (!newOk) {
        ID3D11ShaderResourceView* noSrv[4] = {}; ID3D11UnorderedAccessView* noUav[2] = {};
        c->CSSetShader(g_csForward, nullptr, 0);
        c->CSSetConstantBuffers(0, 1, &g_cbFwd);
        c->CSSetShaderResources(0, 1, &sl->depthSrv);
        { ID3D11UnorderedAccessView* fw[2] = { g_nearest.uav, g_countersU }; c->CSSetUnorderedAccessViews(0, 2, fw, nullptr); }
        c->Dispatch((rw + 15) / 16, (rh + 7) / 8, 1);
        c->CSSetUnorderedAccessViews(0, 2, noUav, nullptr);
        c->CSSetShaderResources(0, 4, noSrv);
        stp.to(c, 2);
        ID3D11ShaderResourceView* in[4] = { g_nearest.srv, sceneSrv, g_history[o].srv, finalSrv };
        ID3D11UnorderedAccessView* outs[2] = { g_result.uav, g_countersU };
        c->CSSetShader(g_csResolve, nullptr, 0);
        c->CSSetConstantBuffers(0, 1, &g_cbRes);
        c->CSSetShaderResources(0, 4, in);
        c->CSSetUnorderedAccessViews(0, 2, outs, nullptr);
        c->CSSetSamplers(0, 1, &g_bilinear);
        c->Dispatch((ow + 15) / 16, (oh + 7) / 8, 1);
        c->CSSetUnorderedAccessViews(0, 2, noUav, nullptr);
        c->CSSetShaderResources(0, 4, noSrv);
        c->CSSetShader(nullptr, nullptr, 0);
        stp.to(c, 6);
    }
    g_newActive = newOk;
    if (timed) { stp.to(c, 7); c->End(q.dj); q.pending = true; }
    if (count && g_readback[g_rbNext]) { c->CopyResource(g_readback[g_rbNext], g_counters); g_rbPending[g_rbNext] = true; g_rbNext = (g_rbNext + 1) % 3; }
    // the drawn eye's real image (without UI) becomes its history for the frame that reconstructs it
    if (!re.centre) {
        c->CopyResource(g_history[d].t, sceneTex);
        EyeHist& hd = g_hist[d];
        memcpy(hd.T, re.nodeD, sizeof hd.T); memcpy(hd.P, Pd, sizeof hd.P); hd.at = now; hd.ok = true;
    }
    g_usedSlot = sl;
    g_made++;
    *out = g_result.srv;
    return true;
}

void AfterSignal(UINT64 vB) { if (g_usedSlot) g_usedSlot->needB = vB; g_usedSlot = nullptr; }

void Report() {
    if (g_cam.mode != VRMODE_RECON) return;
    Set* s = g_pub;
    double ms = g_gpuN ? g_gpuMs / g_gpuN : 0; g_gpuMs = 0; g_gpuN = 0;
    unsigned dc = 0; if (s) for (auto& sl : s->s) dc += (unsigned)InterlockedExchange(&sl.depthCopies, 0);
    LOGI("recon: %s | reconstructed %u (%.2f ms GPU), no depth %u, no picture-without-UI %u, no matrices %u | depth copies %u (at its barrier %u, "
         "at the UI %u), picture copies %u (other size %u), copies on non-direct lists skipped %u | shared frustum %s",
         g_armed ? "running" : g_depth ? "depth known, copies not ready" : "no scene depth found yet", g_made, ms, g_noDepth, g_noScene, g_noMatrix,
         dc, g_stBarrierCopies, g_stUiCopies, g_stSceneCopies, g_stSceneMismatch, g_stNotDirect, g_cam.reconShared ? "on" : "off");
    // 0.9.3 self-check of the depth copy at Present: frames without depth -> both copies at every barrier again
    if (g_depthAtPresent && g_armed && g_depth && g_framesNoDepth > 20) {
        g_depthAtPresent = false;
        LOGW("recon: %u frames without depth with the depth copied once at Present - back to both copies at every depth barrier", g_framesNoDepth);
    } else if (g_presentCopies)
        LOGI("recon: depth %s - %u shared copies at Present, frames without depth %u",
             g_depthAtPresent ? "staged at every barrier, copied once a frame at Present" : "copied at every barrier", g_presentCopies, g_framesNoDepth);
    g_presentCopies = 0; g_framesNoDepth = 0;
    if (!g_depth) {   // 0.5: what was seen, so a missed scene depth shows in the log
        char b[400]; int o = 0;
        for (int k = 0; k < g_candLastN && o < 360; k++)
            o += snprintf(b + o, sizeof b - o, "%s%llux%u fmt %d %u draws", k ? ", " : "", (unsigned long long)g_candLast[k].d.Width, g_candLast[k].d.Height,
                          (int)g_candLast[k].d.Format, g_candLast[k].draws);
        LOGI("recon: depth candidates of the picture's shape: %s | other shapes skipped %u", g_candLastN ? b : "none", g_candShapeSkips);
    }
    g_candShapeSkips = 0;
    if (g_stSizeSkips) LOGW("recon: %u depth copies skipped (depth of another size than the copies)", g_stSizeSkips);
    g_stSizeSkips = 0;
    LOGI("recon: reconstructed eye pixels: gaps filled from the picture %.1f %%, from remembered real pixels / the eye's own last image %.1f %%, UI %.1f %%%s "
         "(of the filled pixels %.1f %% kept from last frame)",
         g_pctGap, g_pctHist, g_pctUi, !g_set.reconHudSplit ? " (HUD part of the picture)" : g_uiSplitOff ? " (UI split off)" : "", g_pctKept);
    if (g_passN) {   // framework guide: the GPU time of every pass on this GPU, so the preset can be chosen by measurement
        double n = (double)g_passN;
        LOGI("recon: GPU per rebuilt eye (ms): memory %.2f, forward %.2f, tiles %.2f, PatchMatch %.2f, membrane %.2f, resolve %.2f, finish %.2f (total %.2f) | "
             "infill %s, preset %s", g_passMs[0] / n, g_passMs[1] / n, g_passMs[2] / n, g_passMs[3] / n, g_passMs[4] / n, g_passMs[5] / n, g_passMs[6] / n, ms,
             g_newActive ? "new (real pixels / PatchMatch)" : "classic", g_set.reconPreset.c_str());
    }
    if (g_passN >= 2) {   // 0.9: the whole frame (both rebuilt eyes), per frame
        double fr = (double)g_passN * 0.5, tot = 0;
        for (int k = 0; k < 7; k++) tot += g_passMs[k];
        LOGI("recon: GPU per frame, both eyes (ms): memory %.2f, forward %.2f, tiles %.2f, PatchMatch %.2f, membrane %.2f, resolve %.2f, finish %.2f | total %.2f",
             g_passMs[0] / fr, g_passMs[1] / fr, g_passMs[2] / fr, g_passMs[3] / fr, g_passMs[4] / fr, g_passMs[5] / fr, g_passMs[6] / fr, tot / fr);
    }
    for (auto& v : g_passMs) v = 0; g_passN = 0;
    g_made = g_noDepth = g_noScene = g_noMatrix = 0;
    g_stBarrierCopies = g_stUiCopies = g_stSceneCopies = g_stSceneMismatch = g_stNotDirect = 0;
}

void Release() {   // before ResizeBuffers (the compositor has waited for its last GPU work)
    g_armed = false;
    Set* s = g_pub; g_pub = nullptr; Retire(s);
    Drop(g_result); for (int e = 0; e < 2; e++) { Drop(g_history[e]); g_hist[e].ok = false; }
    Drop(g_nearest2); g_dualReady = false; g_dualFrame = -1;
    Drop(g_big); Drop(g_fillCurE[0]); Drop(g_fillCurE[1]); Drop(g_tiles); Drop(g_tileCorr); Drop(g_tilesFix); Drop(g_corrFix);
    for (int e = 0; e < 2; e++) { Drop(g_heldTile[e]); Drop(g_heldCorr[e]); g_heldW[e] = 0; }
    for (auto& t : g_fillPrev) Drop(t); for (auto& t : g_pmCol) Drop(t); for (auto& t : g_pmSt) Drop(t);
    for (auto& t : g_dn) Drop(t); for (auto& t : g_up) Drop(t);
    for (auto& t : g_memCol) Drop(t); for (auto& t : g_memDist) Drop(t); for (auto& t : g_memOff) Drop(t);
    g_memLast = -1; g_memFrame = -1; g_prevDrawn.ok = false; g_fillCam[0].ok = g_fillCam[1].ok = false; g_newMode = -1;
    g_uiSplitOff = false; g_uiAll = 0;
}
}   // namespace recon
