#include "modtime.h"
// D3D12 / DXGI hooks.
//   * swap chain creation (IDXGIFactory::CreateSwapChain / IDXGIFactory2::CreateSwapChainForHwnd, hooked through a
//     factory of our own - every factory object shares the implementation): the game's command queue (the swap
//     chain's "device" on D3D12), its device, its back buffers, its window. In VR modes the swap chain is created at
//     the per-eye render size and the window is resized to it (the game renders at its window size, as IGCS's
//     hotsampling shows).
//   * Present / Present1: the frame goes to the compositor (compositor.cpp) first, then to the monitor - without
//     vsync while VR frames are made (the frame limiter paces at the headset's rate instead).
//   * UI placement (ui_mode = eyes): the game draws its UI into the final image. Draws into the back buffer (or into
//     the image the game copies into it) after the 3D image get their viewport / scissor moved onto the current
//     eye's optical axis, scaled by ui_scale and shifted so both eyes converge at ui_depth - one sharp UI at a fixed
//     distance instead of a double image at the screen edges. Command list hooks: OMSetRenderTargets,
//     RSSetViewports, RSSetScissorRects, DrawInstanced, DrawIndexedInstanced, CopyResource, CopyTextureRegion;
//     device: CreateRenderTargetView (which descriptor is which texture).
#include "d3d.h"
#include <cmath>
#include <cstring>
#include <string>
#include "log.h"
#include "MinHook.h"
#include "camera.h"
#include "settings.h"
#include "config.h"
#include "xrbridge/client.h"
#include "recon.h"
#include "refresh.h"
#include "game.h"
namespace fov { void OnBind(ID3D12GraphicsCommandList* l, void*& list5, bool& on, bool eyeTarget, UINT tw, UINT th, bool effects); void OnResize(); }

ID3D12Device* g_dev12 = nullptr;
ID3D12CommandQueue* g_queue = nullptr;
IDXGISwapChain3* g_swap = nullptr;
HWND g_hwnd = nullptr;
ID3D12Resource* g_bb[8] = {};
UINT g_bbCount = 0, g_bbW = 0, g_bbH = 0;
DXGI_FORMAT g_bbFmt = DXGI_FORMAT_UNKNOWN;
volatile int g_colorSpace = 0;
volatile LONG g_presents = 0;
DWORD g_presentThread = 0;
static bool g_tearing = false;

// ---------------------------------------------------------------- RTV descriptor -> resource (only final-size targets)
static const int kRtvSlots = 16384;
static volatile LONG64 g_rtvKey[kRtvSlots];
static ID3D12Resource* volatile g_rtvRes[kRtvSlots];
static inline unsigned HashPtr(uintptr_t p) { p ^= p >> 33; p *= 0xff51afd7ed558ccdULL; p ^= p >> 29; return (unsigned)p; }
static void RtvPut(SIZE_T h, ID3D12Resource* r) {
    if (!h) return;
    unsigned i = HashPtr(h) & (kRtvSlots - 1);
    for (int n = 0; n < 64; n++, i = (i + 1) & (kRtvSlots - 1)) {
        LONG64 k = g_rtvKey[i];
        if (k == (LONG64)h) { g_rtvRes[i] = r; return; }
        if (k == 0) {
            if (!r) return;   // not known, nothing to clear
            if (InterlockedCompareExchange64(&g_rtvKey[i], (LONG64)h, 0) == 0) { g_rtvRes[i] = r; return; }
            if (g_rtvKey[i] == (LONG64)h) { g_rtvRes[i] = r; return; }
        }
    }
}
static ID3D12Resource* RtvGet(SIZE_T h) {
    if (!h) return nullptr;
    unsigned i = HashPtr(h) & (kRtvSlots - 1);
    for (int n = 0; n < 64; n++, i = (i + 1) & (kRtvSlots - 1)) {
        LONG64 k = g_rtvKey[i];
        if (k == (LONG64)h) return g_rtvRes[i];
        if (k == 0) return nullptr;
    }
    return nullptr;
}
static void RtvClear() { for (int i = 0; i < kRtvSlots; i++) { g_rtvRes[i] = nullptr; g_rtvKey[i] = 0; } }

// DSV descriptor -> depth texture (stereo reconstruction: which depth target is the scene's)
static const int kDsvSlots = 4096;
struct DsvEnt { volatile LONG64 key; ID3D12Resource* volatile res; D3D12_RESOURCE_DESC desc; };
static DsvEnt g_dsv[kDsvSlots];
static void DsvPut(SIZE_T h, ID3D12Resource* r, const D3D12_RESOURCE_DESC* d) {
    if (!h) return;
    unsigned i = HashPtr(h) & (kDsvSlots - 1);
    for (int n = 0; n < 64; n++, i = (i + 1) & (kDsvSlots - 1)) {
        LONG64 k = g_dsv[i].key;
        bool mine = k == (LONG64)h;
        if (!mine && k == 0) {
            if (!r) return;   // not known, nothing to clear
            mine = InterlockedCompareExchange64(&g_dsv[i].key, (LONG64)h, 0) == 0 || g_dsv[i].key == (LONG64)h;
        }
        if (mine) { g_dsv[i].res = nullptr; if (d) g_dsv[i].desc = *d; g_dsv[i].res = r; return; }
    }
}
static DsvEnt* DsvGet(SIZE_T h) {
    if (!h) return nullptr;
    unsigned i = HashPtr(h) & (kDsvSlots - 1);
    for (int n = 0; n < 64; n++, i = (i + 1) & (kDsvSlots - 1)) {
        LONG64 k = g_dsv[i].key;
        if (k == (LONG64)h) return g_dsv[i].res ? &g_dsv[i] : nullptr;
        if (k == 0) return nullptr;
    }
    return nullptr;
}

// textures that end up on screen: the back buffers and what the game copies into them
static ID3D12Resource* volatile g_final[4] = {};
static bool IsFinal(ID3D12Resource* r) {
    if (!r) return false;
    for (UINT i = 0; i < g_bbCount; i++) if (g_bb[i] == r) return true;
    for (auto* f : g_final) if (f == r) return true;
    return false;
}
static void AddFinal(ID3D12Resource* r) {
    if (!r || IsFinal(r)) return;
    for (auto& f : g_final) if (!f) { f = r; LOGI("ui: %p is copied into the back buffer - its draws count as final image", (void*)r); return; }
}

// ---------------------------------------------------------------- per command list state
struct ListState {
    void* list = nullptr;
    bool target = false;          // render target 0 is a final image
    UINT tw = 0, th = 0;          // its size
    D3D12_VIEWPORT vp[1] = {}; UINT nvp = 0; bool haveVp = false;
    D3D12_RECT sc[1] = {}; UINT nsc = 0; bool haveSc = false;
    bool applied = false;         // our transformed viewport / scissor is set on the list right now
    void* list5 = nullptr;        // ID3D12GraphicsCommandList5 (foveated rendering), (void*)1 = not available
    bool vrsOn = false;           // a shading-rate image is bound on the list
    ID3D12Resource* rt = nullptr; // render target 0 (when final)
    // stereo reconstruction: the depth target bound with colour targets, and draws into it since it was bound
    ID3D12Resource* dsv = nullptr; D3D12_RESOURCE_DESC dsvDesc = {}; unsigned dsvDraws = 0;
    bool uiOnly = false;          // the target is the game's separate UI layer: every draw is UI
    int candDsv = -1;             // that target's depth-buffer slot (UI layer search)
    int cand = -1;                // index of the bound eye-size target in this frame's table (UI layer search)
    bool pso2D = false;           // the pipeline set now is a 2D one (no depth test, blending, one display-format target)
    ID3D12Resource* bound = nullptr; UINT bw = 0, bh = 0; DXGI_FORMAT bfmt = DXGI_FORMAT_UNKNOWN;   // colour target 0
};
static const int kListSlots = 4096;
static ListState g_lists[kListSlots];
static volatile LONG64 g_listKey[kListSlots];
static thread_local ListState* tl_list = nullptr;
static ListState* State(void* l) {
    if (tl_list && tl_list->list == l) return tl_list;
    unsigned i = HashPtr((uintptr_t)l) & (kListSlots - 1);
    for (int n = 0; n < 128; n++, i = (i + 1) & (kListSlots - 1)) {
        LONG64 k = g_listKey[i];
        if (k == (LONG64)(uintptr_t)l) { tl_list = &g_lists[i]; return tl_list; }
        if (k == 0 && InterlockedCompareExchange64(&g_listKey[i], (LONG64)(uintptr_t)l, 0) == 0) {
            g_lists[i] = ListState{}; g_lists[i].list = l; tl_list = &g_lists[i]; return tl_list;
        }
    }
    return nullptr;
}

// ---------------------------------------------------------------- UI classification and placement
static volatile LONG g_uiFrameDraws = 0;    // draws into a final image this frame
static volatile LONG g_sceneSeen = 0;       // the 3D image's pass was seen this frame
static volatile LONG g_firstUiDone = 0;     // stereo reconstruction: the picture without UI was taken this frame
static unsigned g_uiDraws = 0, g_sceneDraws = 0, g_uiMoved = 0, g_uiNoVp = 0, g_uiNoPlace = 0;
static int g_split = 0;                     // 0 auto, 1 count, 2 all

static bool IsUiDraw(ListState* st, UINT count, UINT inst) {
    // 0.6.17: every draw into a UI layer is UI. (0.6.16 left full-screen 6-vertex draws alone as "composites" - but the
    // game draws each UI sprite with a full-screen viewport and a 6-vertex quad, so nothing was scaled any more)
    if (st->uiOnly) return true;   // 0.6.19: the HUD layer's draws are not UI pipelines (0.6.18 log) - all of them
    LONG n = InterlockedIncrement(&g_uiFrameDraws);
    if (g_split == 2) return true;
    if (g_split == 1) return n > g_set.hudSceneDraws;
    // auto: the first full-target pass with a full-screen triangle / quad is the 3D image; everything after it is UI
    if (!g_sceneSeen) {
        bool full = !st->haveVp || st->vp[0].TopLeftX < 1.f && st->vp[0].TopLeftY < 1.f &&
                    fabsf(st->vp[0].Width - st->tw) < 2.f && fabsf(st->vp[0].Height - st->th) < 2.f;
        if (full && count <= 6 && inst == 1) { g_sceneSeen = 1; return false; }   // triangle (3), quad (4 / 6 indices)
    }
    // 0.6.17: a later full-screen pass without a UI pipeline (post effect / composite) is not UI either
    if (!st->pso2D && count <= 6 && inst == 1 && (!st->haveVp || (st->vp[0].TopLeftX < 1.f && st->vp[0].TopLeftY < 1.f &&
        fabsf(st->vp[0].Width - st->tw) < 2.f && fabsf(st->vp[0].Height - st->th) < 2.f))) return false;
    return true;
}

// where the UI centre goes in the eye image (pixels) and its scale
static bool UiPlacement(UINT W, UINT H, float& cx, float& cy, float& s) {
#ifndef ResonanceVR_TEST_UI
    if (!CameraFrameIsVR()) return false;
#endif
    s = g_set.uiScale < 0.2f ? 0.2f : g_set.uiScale > 1.f ? 1.f : g_set.uiScale;

    float yoff = g_set.uiOffsetY * (float)H;
    // 0.6.33: the eye of the frame being recorded = the one the next Present shows (the FIFO), not the last camera
    // update - the renderer can set the next frame's camera before this frame's UI is drawn (a busy CPU): the UI was
    // then placed for the other eye (Quest 3: about a quarter of the picture off, the two eyes' HUDs apart)
    int ue = 0; bool um = false;
    CameraRecordingEye(ue, um);
    if (um || g_cam.mode == VRMODE_HEAD) {   // the head-centre view (head mode, reconstruction's centre view)
        float k = (g_cam.eyeTan[0][1] - g_cam.eyeTan[0][0]) / (g_cam.monoTan[1] - g_cam.monoTan[0]);   // keeps its size in each eye's view
        if (k > 0.2f && k < 1.f) s *= k;
        cx = W * 0.5f; cy = H * 0.5f - yoff; return true;
    }
    extern bool UiCentreForEye(int eye, const float* tan, UINT W, UINT H, float& cx, float& cy);
    int e = ue & 1;
    const float* t = CameraDrawTan(e);
    // stereo reconstruction draws this eye wider than the headset shows: the UI keeps its size in the view
    float k = (g_cam.eyeTan[e][1] - g_cam.eyeTan[e][0]) / (t[1] - t[0]);
    if (k > 0.2f && k < 1.f) s *= k;
    return UiCentreForEye(e, t, W, H, cx, cy);
}
bool UiPlacementFor(UINT W, UINT H, float& cx, float& cy, float& s) { return UiPlacement(W, H, cx, cy, s); }   // ui.cpp
// 0.5: the same for the frame the game is laying out NOW (the camera set last: the GUI layout runs with the frame's
// setup, one Present before the picture is shown - the render thread draws one frame behind)
bool UiCentreForEye(int e, const float* t, UINT W, UINT H, float& cx, float& cy);
bool UiPlacementForSetup(UINT W, UINT H, float& cx, float& cy, float& s) {
    if (!CameraFrameIsVR()) return false;
    s = g_set.uiScale < 0.2f ? 0.2f : g_set.uiScale > 1.f ? 1.f : g_set.uiScale;
    float yoff = g_set.uiOffsetY * (float)H;
    if (g_cam.curMono || g_cam.mode == VRMODE_HEAD) {
        float k = (g_cam.eyeTan[0][1] - g_cam.eyeTan[0][0]) / (g_cam.monoTan[1] - g_cam.monoTan[0]);
        if (k > 0.2f && k < 1.f) s *= k;
        cx = W * 0.5f; cy = H * 0.5f - yoff; return true;
    }
    int e = CameraLayoutEye();
    const float* t = CameraDrawTan(e);
    float k = (g_cam.eyeTan[e][1] - g_cam.eyeTan[e][0]) / (t[1] - t[0]);
    if (k > 0.2f && k < 1.f) s *= k;
    // 0.9.8: the game draws its GUI in screen space - the same pixels in every eye's picture, whatever the projection. So a HUD that both eyes
    // fuse needs both pictures centred on their own line of sight: a symmetric frustum per eye (symmetric view, default on for the eye
    // methods). Then the HUD stays where the game lays it out (scaled about the centre) and sits at infinity in both eyes - the same in every
    // frame, so it can never be placed for the wrong eye. ui_converge adds the small per-eye shift for a nearer HUD depth (ui_depth); it
    // needs every layout to know its eye. With an off-centre (asymmetric) frustum the HUD must move onto each eye's line of sight per eye
    // (0.6.20 - 0.9.6), which only works when each layout knows its eye - the 0.9.4 - 0.9.7 logs show it does not reliably.
    // (0.9.7 assumed the engine moved the GUI with the projection - it does not.)
    float w = t[1] - t[0];
    if (!(w > 0.05f)) return false;
    const bool symmetric = fabsf(t[0] + t[1]) < 0.01f * w;
    if (!symmetric) return UiCentreForEye(e, t, W, H, cx, cy);
    cx = W * 0.5f; cy = H * 0.5f - yoff;
    if (g_set.uiConverge) {
        float ipd = sqrtf((g_cam.pose[0].px - g_cam.pose[1].px) * (g_cam.pose[0].px - g_cam.pose[1].px) +
                          (g_cam.pose[0].py - g_cam.pose[1].py) * (g_cam.pose[0].py - g_cam.pose[1].py) +
                          (g_cam.pose[0].pz - g_cam.pose[1].pz) * (g_cam.pose[0].pz - g_cam.pose[1].pz));
        if (!(ipd > 0.04f && ipd < 0.09f)) ipd = 0.064f;
        float d = g_set.uiDepth > 0.3f ? g_set.uiDepth : 0.3f;
        cx += ((e & 1) == 0 ? 0.5f : -0.5f) * ipd / d * (float)W / w;
    }
    return true;
}
// the UI centre in an image of eye `e` drawn with frustum `t` (pixels): on the eye's optical axis, shifted so both
// eyes converge at ui_depth
bool UiCentreForEye(int e, const float* t, UINT W, UINT H, float& cx, float& cy) {
    // 0.6.20: always on each eye's own line of sight, converged at ui_depth (0.6.19 "flat" put it in the middle of each
    // eye's picture - with the headset's off-centre eyes those are far apart: two HUDs in alternate eye / synchronized)
    float yoff = g_set.uiOffsetY * (float)H;
    e &= 1;
    float w = t[1] - t[0], h = t[2] - t[3];
    if (!(w > 0.05f && h > 0.05f)) return false;
    // half the IPD at ui_depth: the left eye sees the UI centre slightly to its right, the right eye to its left
    float ipd = sqrtf((g_cam.pose[0].px - g_cam.pose[1].px) * (g_cam.pose[0].px - g_cam.pose[1].px) +
                      (g_cam.pose[0].py - g_cam.pose[1].py) * (g_cam.pose[0].py - g_cam.pose[1].py) +
                      (g_cam.pose[0].pz - g_cam.pose[1].pz) * (g_cam.pose[0].pz - g_cam.pose[1].pz));
    if (!(ipd > 0.04f && ipd < 0.09f)) ipd = 0.064f;
    float d = g_set.uiDepth > 0.3f ? g_set.uiDepth : 0.3f;
    // the real IPD: the UI's depth comes from how your own eyes see the two images (ipd_scale only changes the 3D)
    float tc = (e == 0 ? 0.5f : -0.5f) * ipd / d;
    if (fabsf(t[0] + t[1]) < 0.01f * w && !g_set.uiConverge) tc = 0.f;   // 0.9.9: a symmetric frustum - the HUD at infinity, the same in both eyes (ui_converge off)
    float xn = (2.f * tc - (t[1] + t[0])) / w;          // NDC of that direction in this eye's frustum
    float yn = -(t[2] + t[3]) / h;                       // straight ahead vertically
    cx = (xn + 1.f) * 0.5f * (float)W;
    cy = (1.f - yn) * 0.5f * (float)H - yoff;
    return true;
}

typedef void(STDMETHODCALLTYPE* PFN_RSSetViewports)(ID3D12GraphicsCommandList*, UINT, const D3D12_VIEWPORT*);
typedef void(STDMETHODCALLTYPE* PFN_RSSetScissorRects)(ID3D12GraphicsCommandList*, UINT, const D3D12_RECT*);
typedef void(STDMETHODCALLTYPE* PFN_OMSetRenderTargets)(ID3D12GraphicsCommandList*, UINT, const D3D12_CPU_DESCRIPTOR_HANDLE*, BOOL, const D3D12_CPU_DESCRIPTOR_HANDLE*);
typedef void(STDMETHODCALLTYPE* PFN_DrawInstanced)(ID3D12GraphicsCommandList*, UINT, UINT, UINT, UINT);
typedef void(STDMETHODCALLTYPE* PFN_DrawIndexedInstanced)(ID3D12GraphicsCommandList*, UINT, UINT, UINT, INT, UINT);
typedef void(STDMETHODCALLTYPE* PFN_CopyResource)(ID3D12GraphicsCommandList*, ID3D12Resource*, ID3D12Resource*);
typedef void(STDMETHODCALLTYPE* PFN_CopyTextureRegion)(ID3D12GraphicsCommandList*, const D3D12_TEXTURE_COPY_LOCATION*, UINT, UINT, UINT, const D3D12_TEXTURE_COPY_LOCATION*, const D3D12_BOX*);
typedef HRESULT(STDMETHODCALLTYPE* PFN_ListReset)(ID3D12GraphicsCommandList*, ID3D12CommandAllocator*, ID3D12PipelineState*);
typedef void(STDMETHODCALLTYPE* PFN_CreateRTV)(ID3D12Device*, ID3D12Resource*, const D3D12_RENDER_TARGET_VIEW_DESC*, D3D12_CPU_DESCRIPTOR_HANDLE);
typedef void(STDMETHODCALLTYPE* PFN_CreateDSV)(ID3D12Device*, ID3D12Resource*, const D3D12_DEPTH_STENCIL_VIEW_DESC*, D3D12_CPU_DESCRIPTOR_HANDLE);
typedef void(STDMETHODCALLTYPE* PFN_ResourceBarrier)(ID3D12GraphicsCommandList*, UINT, const D3D12_RESOURCE_BARRIER*);
static PFN_CreateDSV o_CreateDSV; static PFN_ResourceBarrier o_ResourceBarrier;
static PFN_RSSetViewports o_RSSetViewports; static PFN_RSSetScissorRects o_RSSetScissorRects; static PFN_OMSetRenderTargets o_OMSetRenderTargets;
static PFN_DrawInstanced o_DrawInstanced; static PFN_DrawIndexedInstanced o_DrawIndexedInstanced;
static PFN_CopyResource o_CopyResource; static PFN_CopyTextureRegion o_CopyTextureRegion; static PFN_ListReset o_ListReset;
static PFN_CreateRTV o_CreateRTV;

volatile LONG g_d3dUiMovedPresent = 0;   // the Present count when the D3D12 hooks last moved a UI draw (ui.cpp: the game's own layout takes over when none is found)
static void ApplyUi(ID3D12GraphicsCommandList* l, ListState* st, bool ui) {
    float cx, cy, s;
    // 0.6.12 log: 1200 UI draws a frame, none moved - the UI's viewport was not seen on its command list (set on
    // another list / before the bind we follow). A draw always has one: the whole target is taken then.
    if (ui && !st->haveVp && st->tw && st->th) {
        st->vp[0] = { 0.f, 0.f, (float)st->tw, (float)st->th, 0.f, 1.f }; st->nvp = 1; st->haveVp = true; g_uiNoVp++;
    }
    // the engine already placed this frame's GUI (ui.cpp): the draws stay where it put them
    extern bool UiEngineActive();
    bool placed = ui && st->haveVp && !UiEngineActive() && UiPlacement(st->tw, st->th, cx, cy, s);
    if (ui && !placed) g_uiNoPlace++;
    if (placed) {
        float hw = st->tw * 0.5f, hh = st->th * 0.5f;
        D3D12_VIEWPORT v = st->vp[0];
        v.TopLeftX = cx + (v.TopLeftX - hw) * s; v.TopLeftY = cy + (v.TopLeftY - hh) * s; v.Width *= s; v.Height *= s;
        o_RSSetViewports(l, 1, &v);
        D3D12_RECT r = st->haveSc ? st->sc[0] : D3D12_RECT{ 0, 0, (LONG)st->tw, (LONG)st->th };
        D3D12_RECT q = { (LONG)floorf(cx + (r.left - hw) * s), (LONG)floorf(cy + (r.top - hh) * s),
                         (LONG)ceilf(cx + (r.right - hw) * s), (LONG)ceilf(cy + (r.bottom - hh) * s) };
        if (q.left < 0) q.left = 0; if (q.top < 0) q.top = 0;
        if (q.right > (LONG)st->tw) q.right = st->tw; if (q.bottom > (LONG)st->th) q.bottom = st->th;
        o_RSSetScissorRects(l, 1, &q);
        st->applied = true; g_uiMoved++; g_d3dUiMovedPresent = g_presents;
    } else if (st->applied) {   // back to the game's own
        if (st->haveVp) o_RSSetViewports(l, st->nvp, st->vp);
        if (st->haveSc) o_RSSetScissorRects(l, st->nsc, st->sc);
        st->applied = false;
    }
}

// stereo reconstruction: the first UI draw of the frame (after the 3D picture's pass) - the picture without UI is copied before it
static void FirstUi(ID3D12GraphicsCommandList* l, ListState* st) {
    if (!recon::Armed() || g_split != 0 || !g_sceneSeen || g_firstUiDone) return;
    if (InterlockedCompareExchange(&g_firstUiDone, 1, 0) != 0) return;
    recon::OnFirstUiDraw(l, st->rt);
}
static void STDMETHODCALLTYPE H_ResourceBarrier(ID3D12GraphicsCommandList* l, UINT n, const D3D12_RESOURCE_BARRIER* b) {
    o_ResourceBarrier(l, n, b);
    ID3D12Resource* d = recon::Depth();
    if (!d || !b) return;
    for (UINT i = 0; i < n; i++)
        if (b[i].Type == D3D12_RESOURCE_BARRIER_TYPE_TRANSITION && b[i].Transition.pResource == d && !(b[i].Flags & D3D12_RESOURCE_BARRIER_FLAG_BEGIN_ONLY))
            recon::OnDepthBarrier(l, d, b[i].Transition.Subresource, b[i].Transition.StateBefore, b[i].Transition.StateAfter);
}
static void STDMETHODCALLTYPE H_CreateDSV(ID3D12Device* dv, ID3D12Resource* r, const D3D12_DEPTH_STENCIL_VIEW_DESC* desc, D3D12_CPU_DESCRIPTOR_HANDLE h) {
    o_CreateDSV(dv, r, desc, h);
    if (r) {
        D3D12_RESOURCE_DESC rd = r->GetDesc();
        bool keep = rd.Dimension == D3D12_RESOURCE_DIMENSION_TEXTURE2D && rd.DepthOrArraySize == 1 && rd.SampleDesc.Count == 1 && rd.Width >= 256 &&
                    (!desc || desc->ViewDimension == D3D12_DSV_DIMENSION_TEXTURE2D);
        DsvPut(h.ptr, keep ? r : nullptr, &rd);
    } else DsvPut(h.ptr, nullptr, nullptr);
}

static void STDMETHODCALLTYPE H_RSSetViewports(ID3D12GraphicsCommandList* l, UINT n, const D3D12_VIEWPORT* v) {
    o_RSSetViewports(l, n, v);
    if (ListState* st = State(l)) { st->nvp = n ? 1 : 0; st->haveVp = n && v; if (st->haveVp) st->vp[0] = v[0]; st->applied = false; }
}
static void STDMETHODCALLTYPE H_RSSetScissorRects(ID3D12GraphicsCommandList* l, UINT n, const D3D12_RECT* r) {
    o_RSSetScissorRects(l, n, r);
    if (ListState* st = State(l)) { st->nsc = n ? 1 : 0; st->haveSc = n && r; if (st->haveSc) st->sc[0] = r[0]; st->applied = false; }
}
// binds seen (diagnostics: why UI placement does or does not see the game's final image)
static volatile LONG g_bindAll = 0, g_bindKnown = 0, g_bindFinal = 0, g_bindPass = 0, g_rtvCopies = 0;
static void OnBindTargets(ID3D12GraphicsCommandList* l, UINT n, SIZE_T rt0, const D3D12_CPU_DESCRIPTOR_HANDLE* ds);
static void STDMETHODCALLTYPE H_OMSetRenderTargets(ID3D12GraphicsCommandList* l, UINT n, const D3D12_CPU_DESCRIPTOR_HANDLE* rt, BOOL single, const D3D12_CPU_DESCRIPTOR_HANDLE* ds) {
    o_OMSetRenderTargets(l, n, rt, single, ds);
    OnBindTargets(l, n, (n && rt) ? rt[0].ptr : 0, ds);
}
// D3D12 render passes (ID3D12GraphicsCommandList4::BeginRenderPass) bind targets too
// (declared here: older SDK headers lack ID3D12GraphicsCommandList4; both descriptors start with the CPU handle)
typedef void(STDMETHODCALLTYPE* PFN_BeginRenderPass)(void*, UINT, const void*, const void*, UINT);
static PFN_BeginRenderPass o_BeginRenderPass;
static void STDMETHODCALLTYPE H_BeginRenderPass(void* l, UINT n, const void* rt, const void* ds, UINT f) {
    o_BeginRenderPass(l, n, rt, ds, f);
    InterlockedIncrement(&g_bindPass);
    D3D12_CPU_DESCRIPTOR_HANDLE dh = {}; if (ds) dh.ptr = *(const SIZE_T*)ds;
    OnBindTargets((ID3D12GraphicsCommandList*)l, n, (n && rt) ? *(const SIZE_T*)rt : 0, ds ? &dh : nullptr);
}
// ---- the game's UI layer. The reference game drew its UI into a target of its own and blends it into the picture in a later
// (compute) pass, so no UI draw ever lands in the final image - why the UI could be hidden (the game's HUD flag) but
// not scaled (no draw of it was seen). The UI layer: while the final image gets no draws, the colour target with the
// most draws that is never drawn with the scene's depth (UI masks may bind a stencil buffer of their own; command
// lists are recorded on several threads, so bind order says nothing). 8-bit targets win over HDR / float ones (the
// UI is drawn in display colour). Kept for 30 frames in a row -> its draws are moved / scaled like UI drawn into the
// final image would be (ui_target = auto | off).
struct FrameRt { ID3D12Resource* volatile res; volatile LONG draws; volatile LONG draws2d; volatile LONG order; volatile LONG depth; DXGI_FORMAT fmt; UINT w, h;
                 ID3D12Resource* volatile dsv[4]; volatile LONG dsvDraws[4]; };
static FrameRt g_frt[32]; static volatile LONG g_frtN = 0, g_frtOrder = 0;
volatile int g_scenePct = 100;
volatile unsigned g_sceneW = 0, g_sceneH = 0;   // 0.6.35: the 3D scene's own size when below the eye size (else 0)   // 0.6.34: 3D scene width / eye width (upscaler / resolution scale), 100 = full size
static char g_uiFullDesc[320] = "";
static char g_uiAllDesc[900] = "";   // 0.6.33: every target of the last sampled frame after the scene (logged while no UI layer is found)   // 0.6.19 log: the full-screen UI-format layers of the last sampled frame, in bind order
static LONG g_uiSearchTargets = 0, g_uiSearchBestDraws = 0, g_uiSearchSceneDraws = 0; static int g_uiSearchBestFmt = 0;
static ID3D12Resource* volatile g_uiTarget = nullptr; static ID3D12Resource* g_uiCand = nullptr; static int g_uiCandFrames = 0, g_uiMissFrames = 0;
// which depth buffers a target is drawn with (up to 4) - slot index returned for the draw counts
static int FrameRtDsv(FrameRt& f, ID3D12Resource* d) {
    if (!d) return -1;
    for (int k = 0; k < 4; k++) if (f.dsv[k] == d) return k;
    for (int k = 0; k < 4; k++) if (!f.dsv[k] && InterlockedCompareExchangePointer((PVOID volatile*)&f.dsv[k], d, nullptr) == nullptr) return k;
    for (int k = 0; k < 4; k++) if (f.dsv[k] == d) return k;
    return -1;
}
static int FrameRtIndex(ID3D12Resource* r, ID3D12Resource* dsv, int& dsvSlot) {
    dsvSlot = -1;
    LONG n = g_frtN; if (n > 32) n = 32;
    for (LONG i = 0; i < n; i++) if (g_frt[i].res == r) {
        g_frt[i].order = InterlockedIncrement(&g_frtOrder); if (dsv) g_frt[i].depth = 1;
        dsvSlot = FrameRtDsv(g_frt[i], dsv); return (int)i;
    }
    LONG i = InterlockedIncrement(&g_frtN) - 1;
    if (i >= 32) return -1;
    D3D12_RESOURCE_DESC d = r->GetDesc();
    g_frt[i].fmt = d.Format; g_frt[i].w = (UINT)d.Width; g_frt[i].h = d.Height; g_frt[i].draws = 0; g_frt[i].draws2d = 0; g_frt[i].depth = dsv ? 1 : 0; g_frt[i].order = InterlockedIncrement(&g_frtOrder);
    for (int k = 0; k < 4; k++) { g_frt[i].dsv[k] = nullptr; g_frt[i].dsvDraws[k] = 0; }
    g_frt[i].res = r;
    dsvSlot = FrameRtDsv(g_frt[i], dsv);
    return (int)i;
}
static bool UiFormat(DXGI_FORMAT f) {
    switch (f) {
    case DXGI_FORMAT_R8G8B8A8_TYPELESS: case DXGI_FORMAT_R8G8B8A8_UNORM: case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB:
    case DXGI_FORMAT_B8G8R8A8_TYPELESS: case DXGI_FORMAT_B8G8R8A8_UNORM: case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB:
    case DXGI_FORMAT_R10G10B10A2_TYPELESS: case DXGI_FORMAT_R10G10B10A2_UNORM: return true;
    default: return false;
    }
}

// ---- 2D pipelines (ui_2d). As the AC mods find the HUD by its 2D shaders, the UI here is found by its pipelines:
// a pipeline with no depth test, blending on colour target 0 and one display-format target is a 2D (UI / HUD) one.
// Its draws into a screen-size target are moved / scaled like the rest of the UI - one ratio for every UI layer and
// texture the game draws its HUD into. Full-target full-screen passes are left alone (post effects).
static const int kPso = 1 << 15;
static void* volatile g_psoKey[kPso]; static volatile unsigned char g_psoFlag[kPso];
static volatile LONG g_psoSeen = 0, g_pso2D = 0, g_psoStream = 0, g_psoStreamBad = 0;
static volatile LONG g_ui2dDraws = 0, g_ui2dMoved = 0, g_indirect = 0;
// 0.7: every draw-like call the hooks see, counted whatever the target (tells a log whether the draw hooks fire at all)
static volatile LONG g_anyDraw = 0, g_anyIndexed = 0, g_anyIndirect = 0, g_anyMesh = 0;
static volatile LONG g_dsvBinds = 0, g_dsvUnknown = 0, g_dsvDepthOnly = 0;   // 0.4: depth binds (report)
static unsigned PsoHash(void* p) { uintptr_t v = (uintptr_t)p >> 4; v ^= v >> 15; v *= 0x9E3779B1u; return (unsigned)(v ^ (v >> 13)) & (kPso - 1); }
static void PsoPut(void* p, unsigned char f) {
    if (!p) return;
    unsigned h = PsoHash(p);
    for (int k = 0; k < 64; k++, h = (h + 1) & (kPso - 1)) {
        void* cur = g_psoKey[h];
        if (cur == p) { g_psoFlag[h] = f; return; }
        if (!cur && InterlockedCompareExchangePointer((PVOID volatile*)&g_psoKey[h], p, nullptr) == nullptr) { g_psoFlag[h] = f; return; }
        if (g_psoKey[h] == p) { g_psoFlag[h] = f; return; }
    }
    g_psoKey[PsoHash(p)] = p; g_psoFlag[PsoHash(p)] = f;   // table full here: overwrite
}
static unsigned char PsoGet(void* p) {
    if (!p) return 0;
    unsigned h = PsoHash(p);
    for (int k = 0; k < 64; k++, h = (h + 1) & (kPso - 1)) { void* cur = g_psoKey[h]; if (cur == p) return g_psoFlag[h]; if (!cur) return 0; }
    return 0;
}
static unsigned char Flags2D(BOOL depth, BOOL blend, UINT numRt, DXGI_FORMAT f0) {
    InterlockedIncrement(&g_psoSeen);
    bool is2d = !depth && blend && numRt == 1 && UiFormat(f0);
    if (is2d) InterlockedIncrement(&g_pso2D);
    return is2d ? 1 : 0;
}
static unsigned char FlagsFromDesc(const D3D12_GRAPHICS_PIPELINE_STATE_DESC* d) {
    if (!d) return 0;
    return Flags2D(d->DepthStencilState.DepthEnable, d->BlendState.RenderTarget[0].BlendEnable, d->NumRenderTargets, d->RTVFormats[0]);
}
// pipeline state streams (ID3D12Device2::CreatePipelineState): subobjects {type, inner} each aligned to 8 bytes
static unsigned char FlagsFromStream(const void* data, SIZE_T size) {
    InterlockedIncrement(&g_psoStream);
    const unsigned char* b = (const unsigned char*)data; SIZE_T o = 0;
    BOOL depth = TRUE, blend = FALSE; UINT nrt = 0; DXGI_FORMAT f0 = DXGI_FORMAT_UNKNOWN; bool graphics = false;
    while (b && o + 4 <= size) {
        UINT t = *(const UINT*)(b + o);
        SIZE_T in4 = o + 4, in8 = o + 8, len;
        switch (t) {
        case 0: len = 16; break;                                     // root signature
        case 1: case 2: case 3: case 4: case 5: graphics = true; len = 24; break;   // VS PS DS HS GS
        case 6: len = 24; break;                                     // CS
        case 7: len = 40; break;                                     // stream output
        case 8: blend = *(const BOOL*)(b + in4 + 8); len = 336; break;   // blend: RenderTarget[0].BlendEnable
        case 9: len = 8; break;
        case 10: len = 48; break;                                    // rasterizer
        case 11: depth = *(const BOOL*)(b + in4); len = 56; break;   // depth stencil
        case 12: len = 24; break;                                    // input layout
        case 13: case 14: case 16: case 18: case 20: len = 8; break;
        case 15: f0 = *(const DXGI_FORMAT*)(b + in4); nrt = *(const UINT*)(b + in4 + 32); len = 40; break;   // RT formats
        case 17: len = 16; break;                                    // sample desc
        case 19: len = 24; break;                                    // cached PSO
        case 21: depth = *(const BOOL*)(b + in4); len = 64; break;   // depth stencil 1
        case 22: len = 32; break;                                    // view instancing
        case 24: case 25: graphics = true; len = 24; break;          // AS / MS
        default: InterlockedIncrement(&g_psoStreamBad); return 0;    // a newer subobject: not classified (left alone)
        }
        (void)in8;
        o += len;
    }
    return graphics ? Flags2D(depth, blend, nrt, f0) : 0;
}
// manual 12 (hook cost): the per-draw bookkeeping of the UI-layer search (interlocked counters shared by every
// recording thread) runs on one frame in eight only; the other frames' draw hooks do almost nothing
static volatile bool g_sampleUi = true; static unsigned g_sampleFrame = 0;
// UI picker (ui_pick, HUD tab): every display-format target the game draws into that is not the scene - the user steps
// through them in game until the HUD scales; 0 = automatic
struct UiCand { ID3D12Resource* res; UINT w, h; DXGI_FORMAT fmt; LONG draws; UINT bbW, bbH; unsigned seen; };
static UiCand g_uiCands[16]; static int g_uiCandN = 0; static int g_uiPickLogged = -1;
static unsigned g_uiSample = 0;   // sampled frames counted (candidates' "last seen")
// 0.6.14: the picked target is remembered by WHAT it is - size relative to the back buffer, format, and which one of
// the targets with that shape it was - not by its place in the list. The 0.6.13 log: candidate 3 (full size,
// format 27, 4 draws) was the HUD; after dying / reloading the game made new targets, the list (full at 16 with the
// old ones) took no new entries, and the pick pointed at a target that was gone. Now stale entries are replaced and
// the same kind of target is found again (also after a restart: ui_pick_sig in the config).
struct UiPickSig { bool have; float rw, rh; DXGI_FORMAT fmt; int nth; };
static UiPickSig g_pickSig = {};
static bool SigMatch(const UiPickSig& g, const UiCand& c) {
    if (c.fmt != g.fmt || !c.bbW || !c.bbH) return false;
    return fabsf((float)c.w / c.bbW - g.rw) < 0.02f && fabsf((float)c.h / c.bbH - g.rh) < 0.02f;
}
static bool CandRecent(const UiCand& c) { return g_uiSample - c.seen <= 40; }   // seen in the last ~5 s
static void SigFromPick() {
    int k = g_set.uiPick;
    if (k < 1 || k > g_uiCandN) return;
    const UiCand& c = g_uiCands[k - 1];
    if (!c.bbW || !c.bbH) return;
    g_pickSig = { true, (float)c.w / c.bbW, (float)c.h / c.bbH, c.fmt, 0 };
    for (int i = 0; i < k; i++) if (SigMatch(g_pickSig, g_uiCands[i]) && CandRecent(g_uiCands[i])) g_pickSig.nth++;
    char b[64]; snprintf(b, sizeof b, "%.3f,%.3f,%d,%d", g_pickSig.rw, g_pickSig.rh, (int)g_pickSig.fmt, g_pickSig.nth);
    g_set.uiPickSig = b;
}
static void SigLoad() {
    static bool done = false; if (done) return; done = true;
    float rw, rh; int f, n;
    if (g_set.uiPick > 0 && sscanf(g_set.uiPickSig.c_str(), "%f,%f,%d,%d", &rw, &rh, &f, &n) == 4)
        g_pickSig = { true, rw, rh, (DXGI_FORMAT)f, n < 1 ? 1 : n };
}
// the picked candidate, found again by its kind when the one at its number is gone
static ID3D12Resource* PickedTarget() {
    int k = g_set.uiPick;
    if (k < 1) return nullptr;
    if (k <= g_uiCandN && CandRecent(g_uiCands[k - 1]) && (!g_pickSig.have || SigMatch(g_pickSig, g_uiCands[k - 1]))) return g_uiCands[k - 1].res;
    if (!g_pickSig.have) return k <= g_uiCandN ? g_uiCands[k - 1].res : nullptr;
    int nth = 0;
    for (int i = 0; i < g_uiCandN; i++) {
        if (!CandRecent(g_uiCands[i]) || !SigMatch(g_pickSig, g_uiCands[i])) continue;
        if (++nth == g_pickSig.nth || i == g_uiCandN - 1) {
            if (g_set.uiPick != i + 1) {
                g_set.uiPick = i + 1; g_uiPickLogged = i + 1;
                LOGI("ui: picker - the picked UI element (%.2f x %.2f of the screen, format %d) is candidate %d now", g_pickSig.rw, g_pickSig.rh, (int)g_pickSig.fmt, i + 1);
            }
            return g_uiCands[i].res;
        }
    }
    return nullptr;
}
int UiPickCount() { return g_uiCandN; }
static ID3D12Resource* volatile g_uiAuto[16]; static volatile LONG g_uiAutoN = 0;
// 0.6.41: the layers already confirmed as the UI (since the last resize). The HUD layer can have a single draw a frame
// (only subtitles / one HUD batch): the 2-draw minimum for a NEW layer dropped it after ~7 s and never took it back -
// the game then put the subtitles into each eye at the same screen spot (wrong depth, cross-eyed; Quest 3 log, 0.6.40)
static ID3D12Resource* g_uiKnown[8] = {}; static int g_uiKnownN = 0;
static bool UiKnown(ID3D12Resource* r) { if (!r) return false; for (int i = 0; i < g_uiKnownN; i++) if (g_uiKnown[i] == r) return true; return false; }
static void UiKnownAdd(ID3D12Resource* r) { if (!r || UiKnown(r)) return; if (g_uiKnownN < 8) g_uiKnown[g_uiKnownN++] = r; else { for (int i = 1; i < 8; i++) g_uiKnown[i - 1] = g_uiKnown[i]; g_uiKnown[7] = r; } }
static bool UiAutoLayer(ID3D12Resource* r) {
    return false;   // 0.6.25: one layer only ("all" also took the game's effect layers)
    LONG n = g_uiAutoN; for (LONG i = 0; i < n && i < 16; i++) if (g_uiAuto[i] == r) return true;
    return false;
}
static void UiAutoRebuild() {   // the full-screen UI-format layers seen in the last ~5 s that are not the scene
    LONG n = 0;
    for (int i = 0; i < g_uiCandN && n < 16; i++) {
        const UiCand& c = g_uiCands[i];
        if (CandRecent(c) && c.w == g_bbW && c.h == g_bbH) g_uiAuto[n++] = c.res;
    }
    for (LONG i = n; i < 16; i++) g_uiAuto[i] = nullptr;
    g_uiAutoN = n;
}
static void UiCandNote(const FrameRt& f) {
    // 0.6.17: only full-screen layers are offered (the 0.6.16 log: 365x349 / 1127x349 render-to-texture targets -
    // portraits, prompts - filled the list, moved the numbers around, and scaling inside them squashed their content)
    if (f.w != g_bbW || f.h != g_bbH) return;
    for (int i = 0; i < g_uiCandN; i++) if (g_uiCands[i].res == f.res) { g_uiCands[i].draws = f.draws; g_uiCands[i].seen = g_uiSample; return; }
    int slot = g_uiCandN;
    if (slot >= 16) {   // full: the entry not seen for the longest time (a target the game has let go)
        slot = -1; unsigned oldest = 0;
        for (int i = 0; i < 16; i++) { unsigned age = g_uiSample - g_uiCands[i].seen; if (age > 40 && age > oldest && i + 1 != g_set.uiPick) { oldest = age; slot = i; } }
        if (slot < 0) return;
    } else g_uiCandN++;
    g_uiCands[slot] = { f.res, f.w, f.h, f.fmt, f.draws, g_bbW, g_bbH, g_uiSample };
    LOGI("ui: picker candidate %d: %ux%u format %d (%ld draws in a frame)", slot + 1, f.w, f.h, (int)f.fmt, f.draws);
}
static void UiLayerFrameEnd() {   // Present: look at the frame's eye-size targets
    bool sampled = g_sampleUi;
    g_sampleUi = ((++g_sampleFrame) & 7) == 0;
    if (sampled) { g_uiSample++; UiAutoRebuild(); }
    SigLoad();
    if (g_set.uiPick != g_uiPickLogged) {
        g_uiPickLogged = g_set.uiPick;
        if (g_set.uiPick >= 1 && g_set.uiPick <= g_uiCandN) SigFromPick(); else if (g_set.uiPick <= 0) { g_pickSig.have = false; g_set.uiPickSig.clear(); }
        if (g_set.uiPick <= 0) LOGI("ui: picker off - automatic UI layer");
        else if (g_set.uiPick > g_uiCandN) LOGI("ui: picker %d - no such candidate yet (%d seen)", g_set.uiPick, g_uiCandN);
        else { const UiCand& c = g_uiCands[g_set.uiPick - 1]; LOGI("ui: picker %d of %d: %ux%u format %d - its draws are scaled as UI", g_set.uiPick, g_uiCandN, c.w, c.h, (int)c.fmt); }
    }
    if (!sampled) return;   // not counted this frame
    // 0.6.37: an INCOMPLETE sample. The targets are recorded between two Presents; when the game records most of a
    // frame before that window (slow frames: a log at 14 MP / 30 fps saw 1 - 2 targets instead of 23 for 80 s) the
    // sample holds a fragment - the HUD layer was dropped and never found again until the size went back. A sample with
    // far fewer targets than a full frame changes nothing; the next frame is sampled at once.
    {
        static LONG s_full = 0; static unsigned s_incomplete = 0, s_saidT = 0, s_inRow = 0;
        LONG nn = g_frtN; if (nn > 32) nn = 32;
        // six short samples in a row: the scene itself is simpler now (a menu) - that count is the full frame
        if (s_full >= 8 && nn < s_full / 2 && ++s_inRow > 6) { s_full = nn; s_inRow = 0; }
        if (s_full >= 8 && nn < s_full / 2) {
            s_incomplete++;
            if (GetTickCount() - s_saidT > 10000) { s_saidT = GetTickCount(); LOGI("ui: %u incomplete samples (%ld of ~%ld targets: the frame was recorded before the sample) - UI layer kept, sampled again", s_incomplete, nn, s_full); s_incomplete = 0; }
            for (LONG i = 0; i < nn; i++) g_frt[i].res = nullptr;
            g_frtN = 0; g_sampleUi = true;   // the next frame
            return;
        }
        s_inRow = 0;
        if (nn >= 8) s_full = s_full ? (s_full * 3 + nn + 2) / 4 : nn;   // a full frame's target count (smoothed)
    }
    if (g_set.uiTarget == "off") { g_uiTarget = nullptr; }
    else {   // 0.6.14: searched every sampled frame (it used to stop while anything was drawn into the final image)
        LONG n = g_frtN; if (n > 32) n = 32;
        // the scene depth: the depth buffer with the most draws this frame
        ID3D12Resource* sd = nullptr; LONG sdN = 0;
        {
            ID3D12Resource* ds[64]; LONG dn[64]; int m = 0;
            for (LONG i = 0; i < n; i++) for (int k = 0; k < 4; k++) {
                ID3D12Resource* d = g_frt[i].dsv[k]; if (!d) continue;
                int j = 0; while (j < m && ds[j] != d) j++;
                if (j == m) { if (m == 64) continue; ds[m] = d; dn[m] = 0; m++; }
                dn[j] += g_frt[i].dsvDraws[k];
            }
            for (int j = 0; j < m; j++) if (dn[j] > sdN) { sdN = dn[j]; sd = ds[j]; }
        }
        // 0.6.34: the 3D scene's own size against the eye's. Below ~95 %: an upscaler (DLSS / FSR / XeSS) or a resolution
        // scale draws the scene smaller and builds the eye image from it and the frames BEFORE it. The tester's 0.6.25
        // log (DLSS Quality): scene 1283x1256 for a 1924x1884 eye - the game's settings read gave "upscaling 0", so the
        // size is measured here instead. Reported only (log, panel status line); no option is changed.
        if (sd && sdN >= 8 && g_bbW && g_bbH) {
            D3D12_RESOURCE_DESC dd = sd->GetDesc();
            int pct = (int)(100.0 * (double)dd.Width / (double)g_bbW + 0.5);
            if (pct > 100) pct = 100;
            static int s_last = -1, s_same = 0, s_cand = -1;
            int bucket = pct >= 95 ? 100 : pct;
            if (bucket == s_cand) s_same++; else { s_cand = bucket; s_same = 1; }
            if (s_same == 4 && bucket != s_last) {   // 4 sampled frames (32 frames) the same
                s_last = bucket; g_scenePct = bucket;
                if (bucket < 100) { g_sceneW = (unsigned)dd.Width; g_sceneH = dd.Height; } else { g_sceneW = g_sceneH = 0; }
                if (bucket < 100) {
                    upscale::Settings us = game::RenderUpscale();
                    LOGW("render: the game draws its 3D scene at %llux%u = %d %% of the eye (%ux%u) - %s.%s",
                         (unsigned long long)dd.Width, dd.Height, bucket, g_bbW, g_bbH, upscale::Describe(us).c_str(),
                         upscale::Temporal(us)
                             ? " DLSS is temporal: it builds each picture from the frames before it - in synchronized / alternate eye those "
                               "are the OTHER eye's (ghosting, flicker, things fading): Graphics -> Game upscaling: Off (native), or FSR "
                               "instead (spatial). Stereo reconstruction works with it. The game's DLSS is an old version: it leaves "
                               "trails / a second copy behind moving characters in every method."
                             : " Spatial (FSR 1.0 / resolution scale): fine in every stereo method.");
                }
                else LOGI("render: the game draws its 3D scene at the eye's full size (%ux%u)", g_bbW, g_bbH);
            }
        }
        {   // full-screen UI-format layers in the order they were last bound: draws / UI-pipeline draws / depth
            int idx[32], m = 0;
            for (LONG i = 0; i < n; i++) if (g_frt[i].res && g_frt[i].w == g_bbW && g_frt[i].h == g_bbH && UiFormat(g_frt[i].fmt)) idx[m++] = (int)i;
            for (int a = 1; a < m; a++) for (int b = a; b > 0 && g_frt[idx[b]].order < g_frt[idx[b - 1]].order; b--) { int t = idx[b]; idx[b] = idx[b - 1]; idx[b - 1] = t; }
            int o = 0; g_uiFullDesc[0] = 0;
            for (int a = 0; a < m && o < (int)sizeof g_uiFullDesc - 40; a++) {
                const FrameRt& f = g_frt[idx[a]];
                bool sc = false; for (int k = 0; k < 4; k++) if (sd && f.dsv[k] == sd && f.dsvDraws[k] > 0) sc = true;
                o += snprintf(g_uiFullDesc + o, sizeof g_uiFullDesc - o, " [%d: %ld draws, %ld UI-pipeline%s%s]", a + 1, f.draws, f.draws2d,
                              f.depth ? ", depth" : "", sc ? ", scene" : "");
            }
        }
        // 0.6.25: the HUD layer is drawn AFTER the 3D picture. The logs (Pimax, Quest / VDXR, Epic and Steam) show a
        // full-screen RGBA8 layer with 1 draw bound BEFORE the scene every frame - a lighting / effect pass. When the HUD
        // layer was not there (menus, cutscenes, a moment without HUD) "the last one bound" was that pass, it was
        // scaled as UI, and the lighting broke ("lighting destroyed"). Now: after the scene, and at least 2 draws.
        LONG sceneOrder = -1;
        for (LONG i = 0; i < n; i++) for (int k = 0; k < 4; k++)
            if (sd && g_frt[i].dsv[k] == sd && g_frt[i].dsvDraws[k] > 0 && g_frt[i].order > sceneOrder) sceneOrder = g_frt[i].order;
        int best = -1;
        for (LONG i = 0; i < n; i++) {
            const FrameRt& f = g_frt[i];
            if (f.draws < 1 || !UiFormat(f.fmt)) continue;
            // 0.6.17: a UI layer is drawn with UI pipelines (2D: no depth, blended) - mostly. 0.6.14 took any full-screen
            // layer at any draw count: the game's own effect buffers (shadow / AO / reflection masks, the same size and
            // format, 1-4 full-screen passes) were taken as "UI" and their passes scaled into the middle of the screen -
            // the missing shadows and surface effects since 0.6.14, worse in 0.6.16 (every such layer)
            // 0.6.19: (0.6.18 required UI pipelines - the 0.6.18 log: the HUD layer has none, nothing was found)
            // 0.6.14: a full-screen-size layer is a UI layer at any number of draws (the HUD layer the picker found had
            // 4 to 15 draws a frame - under the old 12-draw minimum after a reload); smaller ones need 12
            bool fullSize = f.w == g_bbW && f.h == g_bbH;
            if (f.draws < 12 && !fullSize) {   // too few for the automatic choice - still a picker candidate when not the scene
                bool scene = false; for (int k = 0; k < 4; k++) if (sd && f.dsv[k] == sd && f.dsvDraws[k] > 0) scene = true;
                if (!scene && f.w >= 256 && f.h >= 256) UiCandNote(f);
                continue;
            }   // 0.6.6 log: an HDR scene target (R11G11B10) was taken - its draws were scaled: a flat copy of the scene in front
            bool scene = false; for (int k = 0; k < 4; k++) if (sd && f.dsv[k] == sd && f.dsvDraws[k] > 0) scene = true;
            if (scene) continue;
            UiCandNote(f);
            if (fullSize && ((f.draws < 2 && !UiKnown(f.res)) || (sceneOrder >= 0 && f.order < sceneOrder))) continue;   // 0.6.25: picker only (0.6.41: a known UI layer at 1 draw)
            if (best < 0) { best = (int)i; continue; }
            bool bFull = g_frt[best].w == g_bbW && g_frt[best].h == g_bbH;
            // 0.6.19: among the full-screen layers the one bound LAST in the frame is the HUD (the game composes its
            // HUD after the 3D picture and its effects; the effect buffers of the same size / format are bound
            // earlier - the busiest one, taken before, could be one of them)
            if ((fullSize && !bFull) || (fullSize && bFull && f.order > g_frt[best].order) || (!fullSize && !bFull && f.draws > g_frt[best].draws)) best = (int)i;
        }
        ID3D12Resource* c = best >= 0 ? g_frt[best].res : nullptr;
        // 0.6.43: the target the game's own UI pass draws into (uiprobe), when it is steady and passes the same checks as
        // any UI layer: eye size, a UI format, not the 3D scene. It replaces the draw-count guess; without a steady answer
        // the guess above stays.
        {
            extern void* UiProbeTarget(const char**);
            const char* which = nullptr;
            ID3D12Resource* pt = (ID3D12Resource*)UiProbeTarget(&which);
            static ID3D12Resource* s_saidPt = nullptr; static int s_rejectSaid = 0;
            if (pt) {
                int at = -1;
                for (LONG i = 0; i < n; i++) if (g_frt[i].res == pt) { at = (int)i; break; }
                if (at >= 0) {
                    const FrameRt& f = g_frt[at];
                    bool scene = false; for (int k = 0; k < 4; k++) if (sd && f.dsv[k] == sd && f.dsvDraws[k] > 0) scene = true;
                    bool after = sceneOrder < 0 || f.order > sceneOrder;   // drawn after the 3D scene (the lighting pass is before it)
                    bool ok = f.w == g_bbW && f.h == g_bbH && UiFormat(f.fmt) && !scene && after;
                    if (ok) {
                        c = pt; best = at; UiKnownAdd(pt);
                        if (s_saidPt != pt) { s_saidPt = pt; LOGI("ui: UI layer taken from the game's own UI pass (%s): %p, %ux%u format %d - no guessing", which, (void*)pt, f.w, f.h, (int)f.fmt); }
                    } else if (s_rejectSaid < 3) {
                        s_rejectSaid++;
                        LOGI("ui: the UI pass's target %p (%ux%u format %d%s%s) does not pass the checks - the usual choice is kept", (void*)pt, f.w, f.h, (int)f.fmt, scene ? ", the 3D scene" : "", after ? "" : ", drawn before the 3D scene");
                    }
                } else if (g_uiTarget == pt) c = pt;   // not bound this frame (nothing to draw): keep it, no miss
            }
        }
        // 0.6.33: the Quest 3 / Epic log (0.6.25) had no UI layer in 167 of 171 reports - the game drew its scene at
        // 2/3 of the eye size there. What was drawn after the 3D scene (size, format, draws) shows where the HUD went.
        if (!c) {
            int o = 0; g_uiAllDesc[0] = 0;
            for (LONG i = 0; i < n && o < (int)sizeof g_uiAllDesc - 48; i++) {
                const FrameRt& f = g_frt[i];
                if (!f.res || f.draws < 1 || (sceneOrder >= 0 && f.order < sceneOrder)) continue;
                o += snprintf(g_uiAllDesc + o, sizeof g_uiAllDesc - o, " %ux%u f%d %ld%s%s", f.w, f.h, (int)f.fmt, f.draws,
                              f.draws2d ? "(2D)" : "", f.depth ? "(depth)" : "");
            }
        } else g_uiAllDesc[0] = 0;
        g_uiSearchTargets = n; g_uiSearchBestDraws = best >= 0 ? g_frt[best].draws : 0; g_uiSearchBestFmt = best >= 0 ? (int)g_frt[best].fmt : 0; g_uiSearchSceneDraws = sdN;
        if (c && c == g_uiCand) g_uiCandFrames++; else { g_uiCand = c; g_uiCandFrames = c ? 1 : 0; }
        // 4 sampled frames in a row (32 frames) for a new layer; one already confirmed is taken back at once (0.6.41)
        if (c && (g_uiCandFrames == 4 || UiKnown(c)) && g_uiTarget != c) {
            bool again = UiKnown(c);
            g_uiTarget = c; UiKnownAdd(c);
            if (!again) LOGI("ui: the game draws its UI into a layer of its own (%p, format %d, %ld draws a frame) - UI placement / scale use it",
                             (void*)c, (int)g_frt[best].fmt, g_frt[best].draws);
            else { static unsigned s_back = 0; static DWORD s_t = 0; s_back++;
                   if (GetTickCount() - s_t > 10000) { s_t = GetTickCount(); LOGI("ui: UI layer taken back %u times (a known layer, %ld draws a frame)", s_back, g_frt[best].draws); s_back = 0; } }
        }
        if (g_uiTarget && !c) { if (++g_uiMissFrames > 75) { g_uiTarget = nullptr; g_uiMissFrames = 0; LOGI("ui: UI layer not seen any more"); } }
        else g_uiMissFrames = 0;
    }
    LONG n = g_frtN; if (n > 32) n = 32;
    for (LONG i = 0; i < n; i++) g_frt[i].res = nullptr;
    g_frtN = 0;
}
void UiLayerForget() {
    SigFromPick();   // remember what was picked (found again among the new targets)
    g_uiTarget = nullptr; g_uiCand = nullptr; g_uiCandFrames = 0; g_frtN = 0; g_uiCandN = 0; g_uiPickLogged = g_set.uiPick;
    g_uiKnownN = 0;   // new targets after a resize
    g_uiAutoN = 0; }

static void OnBindTargets(ID3D12GraphicsCommandList* l, UINT n, SIZE_T rt0, const D3D12_CPU_DESCRIPTOR_HANDLE* ds) {
    ListState* st = State(l);
    if (!st) return;
    ID3D12Resource* r = (n && rt0) ? RtvGet(rt0) : nullptr;
    if (g_sampleUi) { InterlockedIncrement(&g_bindAll); if (r) InterlockedIncrement(&g_bindKnown); if (r && IsFinal(r)) InterlockedIncrement(&g_bindFinal); }
    bool fin = IsFinal(r);
    if (st->applied && !fin) { if (st->haveVp) o_RSSetViewports(l, st->nvp, st->vp); if (st->haveSc) o_RSSetScissorRects(l, st->nsc, st->sc); st->applied = false; }
    ID3D12Resource* pick = PickedTarget();
    // 0.6.16: automatic = EVERY full-screen UI layer (the 0.6.15 log: the main menu's UI was candidate 3, the gameplay HUD
    // candidate 5 - all full-screen format-27 layers; one pick could only ever hold one of them)
    bool uiLayer = r && !fin && (pick ? r == pick : (r == g_uiTarget || UiAutoLayer(r)));
    st->target = fin || uiLayer; st->uiOnly = uiLayer; st->rt = fin ? r : nullptr;
    st->bound = r; st->bw = st->bh = 0; st->bfmt = DXGI_FORMAT_UNKNOWN;
    if (r) { D3D12_RESOURCE_DESC d = r->GetDesc(); st->bw = (UINT)d.Width; st->bh = d.Height; st->bfmt = d.Format; }
    { extern void UiProbeOnBind(void*, unsigned, unsigned, int, bool, bool); UiProbeOnBind(r, st->bw, st->bh, (int)st->bfmt, r && r == g_uiTarget, fin); }
    if (st->target) { st->tw = st->bw; st->th = st->bh; }
    {
        DsvEnt* be = (ds && ds->ptr) ? DsvGet(ds->ptr) : nullptr;
        ID3D12Resource* bd = be ? be->res : nullptr;
        int slot = -1;
        st->cand = (g_sampleUi && r && !fin) ? FrameRtIndex(r, bd ? bd : ((ds && ds->ptr) ? (ID3D12Resource*)(uintptr_t)1 : nullptr), slot) : -1;
        st->candDsv = slot;
    }
    if (g_cam.mode == VRMODE_RECON) {   // a depth target with colour targets = a candidate for the scene depth
        if (st->dsv && st->dsvDraws) recon::TallyDepth(st->dsv, st->dsvDesc, st->dsvDraws);
        st->dsv = nullptr; st->dsvDraws = 0;
        // 0.4: depth-only passes count too. This engine draws its scene GPU-driven (ExecuteIndirect) with a depth
        // prepass that binds no colour target - 0.3's log: every full-screen pass "depth" only, scene depth never found.
        // The shape / draw-count choice in recon.cpp still picks the scene depth among them.
        DsvEnt* de = (ds && ds->ptr) ? DsvGet(ds->ptr) : nullptr;
        if (ds && ds->ptr) { InterlockedIncrement(&g_dsvBinds); if (!de) InterlockedIncrement(&g_dsvUnknown); else if (!n) InterlockedIncrement(&g_dsvDepthOnly); }
        if (de) {
            st->dsv = de->res; st->dsvDesc = de->desc; recon::NoteDepthUsed(de->res);
            // 0.6: every bind counts, not only draws. The 0.5 log: 9 750 depth binds in 10 s, not one draw counted against
            // any of them (this engine's scene draws do not reach the per-pass counters) - the candidate list stayed
            // empty. The scene depth is the picture-shaped depth bound most often (prepass, G-buffer, forward, effects).
            recon::TallyDepth(de->res, de->desc, 1);
        }
    }
    // eye-size targets that are not the final image get the foveation (the map only holds eye-size targets)
    // 0.6.35: or the 3D scene's own size when an upscaler / resolution scale draws it smaller (foveated has a set for it)
    bool eyeSize = false;
    if (r && !fin) { eyeSize = (st->bw == g_bbW && st->bh == g_bbH) || (g_sceneW && st->bw == g_sceneW && st->bh == g_sceneH); }
    // 0.6.21: only passes that draw geometry (a depth buffer bound) - full-screen lighting / effect passes shaded at a
    // lower rate gave a ring of moving green specks where the rate drops
    bool geo = ds && ds->ptr;
    // 0.9 fov_effects: a full-screen pass without a depth target gets the lens-edge image (the geometry passes keep their own)
    fov::OnBind(l, st->list5, st->vrsOn, eyeSize && !uiLayer && (geo || g_set.fovEffects == "outer"), st->bw, st->bh, !geo);
}
struct ListState; static void Draw2D(ID3D12GraphicsCommandList* l, ListState* st, UINT count, UINT inst);
static void STDMETHODCALLTYPE H_DrawInstanced(ID3D12GraphicsCommandList* l, UINT vc, UINT ic, UINT sv, UINT si) {
    if (g_sampleUi) InterlockedIncrement(&g_anyDraw);
    ListState* st = tl_list && tl_list->list == l ? tl_list : State(l);
    if (st && st->cand >= 0 && st->cand < 32) { InterlockedIncrement(&g_frt[st->cand].draws); if (st->pso2D) InterlockedIncrement(&g_frt[st->cand].draws2d); if (st->candDsv >= 0) InterlockedIncrement(&g_frt[st->cand].dsvDraws[st->candDsv]); }
    if (st && st->target) { bool ui = IsUiDraw(st, vc, ic); if (ui) { g_uiDraws++; if (!st->uiOnly) FirstUi(l, st); } else g_sceneDraws++; ApplyUi(l, st, ui); }
    else if (st) Draw2D(l, st, vc, ic);
    if (st && st->dsv) st->dsvDraws++;
    o_DrawInstanced(l, vc, ic, sv, si);
}
static void STDMETHODCALLTYPE H_DrawIndexedInstanced(ID3D12GraphicsCommandList* l, UINT ic, UINT inst, UINT si, INT bv, UINT sinst) {
    if (g_sampleUi) InterlockedIncrement(&g_anyIndexed);
    ListState* st = tl_list && tl_list->list == l ? tl_list : State(l);
    if (st && st->cand >= 0 && st->cand < 32) { InterlockedIncrement(&g_frt[st->cand].draws); if (st->pso2D) InterlockedIncrement(&g_frt[st->cand].draws2d); if (st->candDsv >= 0) InterlockedIncrement(&g_frt[st->cand].dsvDraws[st->candDsv]); }
    if (st && st->target) { bool ui = IsUiDraw(st, ic, inst); if (ui) { g_uiDraws++; if (!st->uiOnly) FirstUi(l, st); } else g_sceneDraws++; ApplyUi(l, st, ui); }
    else if (st) Draw2D(l, st, ic, inst);
    if (st && st->dsv) st->dsvDraws++;
    o_DrawIndexedInstanced(l, ic, inst, si, bv, sinst);
}
// A whole-resource copy needs identical sizes. If the game's frame is not the back buffer's size (it rendered at its
// own idea of the window size) the copy is cut to the common area - an invalid CopyResource corrupts memory on the GPU
// (colour streaks, then a device removal).
static volatile LONG g_copyFixed = 0;
static void STDMETHODCALLTYPE H_CopyResource(ID3D12GraphicsCommandList* l, ID3D12Resource* dst, ID3D12Resource* src) {
    if (dst && src && g_bbCount) for (UINT i = 0; i < g_bbCount; i++) if (g_bb[i] == dst) {
        AddFinal(src);
        D3D12_RESOURCE_DESC dd = dst->GetDesc(), sd = src->GetDesc();
        if (dd.Dimension == D3D12_RESOURCE_DIMENSION_TEXTURE2D && sd.Dimension == D3D12_RESOURCE_DIMENSION_TEXTURE2D &&
            (dd.Width != sd.Width || dd.Height != sd.Height)) {
            D3D12_TEXTURE_COPY_LOCATION d = {}, s2 = {};
            d.pResource = dst; d.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
            s2.pResource = src; s2.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
            D3D12_BOX b = { 0, 0, 0, (UINT)(dd.Width < sd.Width ? dd.Width : sd.Width), dd.Height < sd.Height ? dd.Height : sd.Height, 1 };
            // 0.6.37: at start-up (logos, 1280x720 before the game takes the eye size) this is expected - a warning only in VR
            if (InterlockedIncrement(&g_copyFixed) <= 3 || CameraFrameIsVR()) {
                static DWORD s_vrSaid = 0; bool vr = CameraFrameIsVR();
                if (!vr) LOGI("swapchain: the game copies a %llux%u frame into the %llux%u back buffer - cut to fit (start-up / not VR yet: expected)",
                              (unsigned long long)sd.Width, sd.Height, (unsigned long long)dd.Width, dd.Height);
                else if (GetTickCount() - s_vrSaid > 10000) { s_vrSaid = GetTickCount();
                    LOGW("swapchain: in VR the game copies a %llux%u frame into the %llux%u back buffer - cut to fit (the game is not rendering at the eye size)",
                         (unsigned long long)sd.Width, sd.Height, (unsigned long long)dd.Width, dd.Height); }
            }
            o_CopyTextureRegion(l, &d, 0, 0, 0, &s2, &b);
            return;
        }
        break;
    }
    o_CopyResource(l, dst, src);
}
static void STDMETHODCALLTYPE H_CopyTextureRegion(ID3D12GraphicsCommandList* l, const D3D12_TEXTURE_COPY_LOCATION* dst, UINT x, UINT y, UINT z,
                                                 const D3D12_TEXTURE_COPY_LOCATION* src, const D3D12_BOX* box) {
    if (dst && src && dst->pResource && src->pResource && src->Type == D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX)
        for (UINT i = 0; i < g_bbCount; i++) if (g_bb[i] == dst->pResource) { AddFinal(src->pResource); break; }
    o_CopyTextureRegion(l, dst, x, y, z, src, box);
}
static HRESULT STDMETHODCALLTYPE H_ListReset(ID3D12GraphicsCommandList* l, ID3D12CommandAllocator* a, ID3D12PipelineState* p) {
    if (ListState* st = State(l)) {
        if (st->dsv && st->dsvDraws) recon::TallyDepth(st->dsv, st->dsvDesc, st->dsvDraws);
        st->target = false; st->uiOnly = false; st->cand = -1; st->candDsv = -1; st->pso2D = false; st->bound = nullptr; st->haveVp = st->haveSc = false; st->applied = false; st->vrsOn = false; st->rt = nullptr; st->dsv = nullptr; st->dsvDraws = 0;
    }
    return o_ListReset(l, a, p);
}
static void STDMETHODCALLTYPE H_CreateRTV(ID3D12Device* d, ID3D12Resource* r, const D3D12_RENDER_TARGET_VIEW_DESC* desc, D3D12_CPU_DESCRIPTOR_HANDLE h) {
    o_CreateRTV(d, r, desc, h);
    ID3D12Resource* keep = nullptr;
    if (r) {   // (also before the swap chain exists: the UI canvas, cached targets)
        D3D12_RESOURCE_DESC rd = r->GetDesc();
        if (rd.Dimension == D3D12_RESOURCE_DIMENSION_TEXTURE2D && rd.Width >= 256 && rd.Height >= 256 && rd.SampleDesc.Count == 1) keep = r;   // (the UI layer may be another size)
    }
    RtvPut(h.ptr, keep);
}

// Engines often create views in a CPU-only staging heap and copy them into the heap they bind from
// (CopyDescriptors / CopyDescriptorsSimple): the copy points at the same resource.
static UINT g_incRtv = 0, g_incDsv = 0;
typedef void(STDMETHODCALLTYPE* PFN_CopyDescriptorsSimple)(ID3D12Device*, UINT, D3D12_CPU_DESCRIPTOR_HANDLE, D3D12_CPU_DESCRIPTOR_HANDLE, D3D12_DESCRIPTOR_HEAP_TYPE);
typedef void(STDMETHODCALLTYPE* PFN_CopyDescriptors)(ID3D12Device*, UINT, const D3D12_CPU_DESCRIPTOR_HANDLE*, const UINT*, UINT, const D3D12_CPU_DESCRIPTOR_HANDLE*, const UINT*, D3D12_DESCRIPTOR_HEAP_TYPE);
static PFN_CopyDescriptorsSimple o_CopyDescriptorsSimple; static PFN_CopyDescriptors o_CopyDescriptors;
static void CopyOne(SIZE_T dst, SIZE_T src, D3D12_DESCRIPTOR_HEAP_TYPE t) {
    if (t == D3D12_DESCRIPTOR_HEAP_TYPE_RTV) { RtvPut(dst, RtvGet(src)); if (g_sampleUi) InterlockedIncrement(&g_rtvCopies); }
    else if (t == D3D12_DESCRIPTOR_HEAP_TYPE_DSV) { DsvEnt* e = DsvGet(src); DsvPut(dst, e ? e->res : nullptr, e ? &e->desc : nullptr); }
}
static void STDMETHODCALLTYPE H_CopyDescriptorsSimple(ID3D12Device* d, UINT n, D3D12_CPU_DESCRIPTOR_HANDLE dst, D3D12_CPU_DESCRIPTOR_HANDLE src, D3D12_DESCRIPTOR_HEAP_TYPE t) {
    o_CopyDescriptorsSimple(d, n, dst, src, t);
    if (t != D3D12_DESCRIPTOR_HEAP_TYPE_RTV && t != D3D12_DESCRIPTOR_HEAP_TYPE_DSV) return;
    UINT inc = t == D3D12_DESCRIPTOR_HEAP_TYPE_RTV ? g_incRtv : g_incDsv;
    for (UINT i = 0; i < n && i < 4096; i++) CopyOne(dst.ptr + (SIZE_T)i * inc, src.ptr + (SIZE_T)i * inc, t);
}
static void STDMETHODCALLTYPE H_CopyDescriptors(ID3D12Device* d, UINT nd, const D3D12_CPU_DESCRIPTOR_HANDLE* ds, const UINT* dsz, UINT ns,
                                               const D3D12_CPU_DESCRIPTOR_HANDLE* ss, const UINT* ssz, D3D12_DESCRIPTOR_HEAP_TYPE t) {
    o_CopyDescriptors(d, nd, ds, dsz, ns, ss, ssz, t);
    if (t != D3D12_DESCRIPTOR_HEAP_TYPE_RTV && t != D3D12_DESCRIPTOR_HEAP_TYPE_DSV) return;
    UINT inc = t == D3D12_DESCRIPTOR_HEAP_TYPE_RTV ? g_incRtv : g_incDsv;
    UINT di = 0, dOff = 0, si = 0, sOff = 0, guard = 0;
    while (di < nd && si < ns && guard++ < 65536) {
        UINT dn = dsz ? dsz[di] : 1, sn = ssz ? ssz[si] : 1;
        CopyOne(ds[di].ptr + (SIZE_T)dOff * inc, ss[si].ptr + (SIZE_T)sOff * inc, t);
        if (++dOff >= dn) { di++; dOff = 0; }
        if (++sOff >= sn) { si++; sOff = 0; }
    }
}

static bool g_listHooked = false;
// (older SDK headers lack the stream API: D3D12_PIPELINE_STATE_STREAM_DESC, ID3D12Device2, ID3D12PipelineLibrary1)
struct PsoStreamDesc { SIZE_T SizeInBytes; void* pPipelineStateSubobjectStream; };
static const GUID kIID_Device2 = { 0x74eaee3f, 0x2f4b, 0x476d, { 0x82, 0xba, 0x2b, 0x85, 0xcb, 0x49, 0xe3, 0x10 } };
static const GUID kIID_Device1 = { 0x77acce80, 0x638e, 0x4e65, { 0x88, 0x95, 0xc1, 0xf2, 0x33, 0x86, 0x86, 0x3e } };
static const GUID kIID_PipelineLibrary = { 0xc64226a8, 0x9201, 0x46af, { 0xb4, 0xcc, 0x53, 0xfb, 0x9f, 0xf7, 0x41, 0x4f } };
static const GUID kIID_PipelineLibrary1 = { 0x80eabf42, 0x2568, 0x4e5e, { 0xbd, 0x82, 0xc3, 0x7f, 0x86, 0x96, 0x1d, 0xc3 } };
typedef HRESULT(STDMETHODCALLTYPE* PFN_CreateGPSO)(ID3D12Device*, const D3D12_GRAPHICS_PIPELINE_STATE_DESC*, REFIID, void**);
typedef HRESULT(STDMETHODCALLTYPE* PFN_CreatePSOStream)(ID3D12Device*, const PsoStreamDesc*, REFIID, void**);
typedef HRESULT(STDMETHODCALLTYPE* PFN_LoadGPSO)(void*, LPCWSTR, const D3D12_GRAPHICS_PIPELINE_STATE_DESC*, REFIID, void**);
typedef HRESULT(STDMETHODCALLTYPE* PFN_LoadPSO)(void*, LPCWSTR, const PsoStreamDesc*, REFIID, void**);
typedef void(STDMETHODCALLTYPE* PFN_SetPSO)(ID3D12GraphicsCommandList*, ID3D12PipelineState*);
typedef void(STDMETHODCALLTYPE* PFN_ExecIndirect)(ID3D12GraphicsCommandList*, ID3D12CommandSignature*, UINT, ID3D12Resource*, UINT64, ID3D12Resource*, UINT64);
static PFN_CreateGPSO o_CreateGPSO; static PFN_CreatePSOStream o_CreatePSOStream; static PFN_LoadGPSO o_LoadGPSO; static PFN_LoadPSO o_LoadPSO;
static PFN_SetPSO o_SetPSO; static PFN_ExecIndirect o_ExecIndirect;
static void* OutPtr(REFIID, void** pp) { return pp ? *pp : nullptr; }
static HRESULT STDMETHODCALLTYPE H_CreateGPSO(ID3D12Device* d, const D3D12_GRAPHICS_PIPELINE_STATE_DESC* desc, REFIID iid, void** pp) {
    HRESULT hr = o_CreateGPSO(d, desc, iid, pp);
    if (SUCCEEDED(hr)) PsoPut(OutPtr(iid, pp), FlagsFromDesc(desc));
    return hr;
}
static HRESULT STDMETHODCALLTYPE H_CreatePSOStream(ID3D12Device* d, const PsoStreamDesc* desc, REFIID iid, void** pp) {
    HRESULT hr = o_CreatePSOStream(d, desc, iid, pp);
    if (SUCCEEDED(hr) && desc) PsoPut(OutPtr(iid, pp), FlagsFromStream(desc->pPipelineStateSubobjectStream, desc->SizeInBytes));
    return hr;
}
static HRESULT STDMETHODCALLTYPE H_LoadGPSO(void* lib, LPCWSTR n, const D3D12_GRAPHICS_PIPELINE_STATE_DESC* desc, REFIID iid, void** pp) {
    HRESULT hr = o_LoadGPSO(lib, n, desc, iid, pp);
    if (SUCCEEDED(hr)) PsoPut(OutPtr(iid, pp), FlagsFromDesc(desc));
    return hr;
}
static HRESULT STDMETHODCALLTYPE H_LoadPSO(void* lib, LPCWSTR n, const PsoStreamDesc* desc, REFIID iid, void** pp) {
    HRESULT hr = o_LoadPSO(lib, n, desc, iid, pp);
    if (SUCCEEDED(hr) && desc) PsoPut(OutPtr(iid, pp), FlagsFromStream(desc->pPipelineStateSubobjectStream, desc->SizeInBytes));
    return hr;
}
static void STDMETHODCALLTYPE H_SetPSO(ID3D12GraphicsCommandList* l, ID3D12PipelineState* p) {
    if (ListState* st = State(l)) st->pso2D = (PsoGet(p) & 1) != 0;
    o_SetPSO(l, p);
}
// a 2D-pipeline draw into a screen-size display-format target (not the final image / UI layer: those have their own path)
// the size of the target a 2D draw goes to: the known target, else (a view made before the mod's hooks) the viewport
static bool Target2D(const ListState* st, UINT& w, UINT& h) {
    if (st->bound) { w = st->bw; h = st->bh; return UiFormat(st->bfmt); }
    if (!st->haveVp) return false;
    w = (UINT)(st->vp[0].TopLeftX + st->vp[0].Width + 0.5f); h = (UINT)(st->vp[0].TopLeftY + st->vp[0].Height + 0.5f);
    return true;
}
// a 2D-pipeline draw into a screen-like target (the UI canvas may be a fixed 1920x1080, much smaller than the eye image)
static bool Capture2D(ListState* st, UINT count, UINT inst, UINT& tw, UINT& th) {
    if (!g_set.ui2d || !st->pso2D || st->target) return false;
    UINT minW = g_bbW && g_bbW / 2 < 1280 ? g_bbW / 2 : 1280, minH = g_bbH && g_bbH / 2 < 720 ? g_bbH / 2 : 720;
    if (!Target2D(st, tw, th) || tw < minW || th < minH) return false;
    bool full = st->haveVp && st->vp[0].TopLeftX < 1.f && st->vp[0].TopLeftY < 1.f &&
                fabsf(st->vp[0].Width - tw) < 2.f && fabsf(st->vp[0].Height - th) < 2.f && count <= 6 && inst == 1;
    return !full;
}
static void ApplyUi(ID3D12GraphicsCommandList* l, ListState* st, bool ui);
static void Draw2D(ID3D12GraphicsCommandList* l, ListState* st, UINT count, UINT inst) {
    if (st->target) return;
    UINT cw = 0, ch = 0;
    bool cap = Capture2D(st, count, inst, cw, ch);
    if (cap) { InterlockedIncrement(&g_ui2dDraws); UINT tw = st->tw, th = st->th; st->tw = cw; st->th = ch; ApplyUi(l, st, true); if (st->applied) InterlockedIncrement(&g_ui2dMoved); st->tw = tw; st->th = th; }
    else if (st->applied) ApplyUi(l, st, false);
}
static void STDMETHODCALLTYPE H_ExecIndirect(ID3D12GraphicsCommandList* l, ID3D12CommandSignature* sig, UINT maxc, ID3D12Resource* args, UINT64 ao, ID3D12Resource* cnt, UINT64 co) {
    if (g_sampleUi) InterlockedIncrement(&g_anyIndirect);
    if (g_sampleUi) InterlockedIncrement(&g_indirect);
    ListState* st = tl_list && tl_list->list == l ? tl_list : State(l);
    if (st && st->cand >= 0 && st->cand < 32) { InterlockedIncrement(&g_frt[st->cand].draws); if (st->pso2D) InterlockedIncrement(&g_frt[st->cand].draws2d); if (st->candDsv >= 0) InterlockedIncrement(&g_frt[st->cand].dsvDraws[st->candDsv]); }
    if (st && st->target) { bool ui = IsUiDraw(st, 100, 1); if (ui) g_uiDraws++; else g_sceneDraws++; ApplyUi(l, st, ui); }
    else if (st) Draw2D(l, st, 100, 1);
    if (st && st->dsv) st->dsvDraws++;
    o_ExecIndirect(l, sig, maxc, args, ao, cnt, co);
}
// 0.7: mesh-shader draws (ID3D12GraphicsCommandList6::DispatchMesh, vtable slot 79). The engine has a mesh-shader path
// (bUseMeshShaders): draws made that way reach none of the draw hooks above, and the 0.6 log counted no draw on any target.
typedef void(STDMETHODCALLTYPE* PFN_DispatchMesh)(ID3D12GraphicsCommandList*, UINT, UINT, UINT);
static PFN_DispatchMesh o_DispatchMesh;
static void STDMETHODCALLTYPE H_DispatchMesh(ID3D12GraphicsCommandList* l, UINT x, UINT y, UINT z) {
    if (g_sampleUi) InterlockedIncrement(&g_anyMesh);
    ListState* st = tl_list && tl_list->list == l ? tl_list : State(l);
    if (st && st->cand >= 0 && st->cand < 32) { InterlockedIncrement(&g_frt[st->cand].draws); if (st->candDsv >= 0) InterlockedIncrement(&g_frt[st->cand].dsvDraws[st->candDsv]); }
    if (st && st->dsv) st->dsvDraws++;
    o_DispatchMesh(l, x, y, z);
}
static void HookCommandLists(ID3D12Device* dev) {
    if (g_listHooked || !dev) return;
    g_listHooked = true;
    if (!ConfigBool("ui_hooks", true)) { LOGI("ui: command list hooks off (ui_hooks = false)"); return; }
    ID3D12CommandAllocator* a = nullptr; ID3D12GraphicsCommandList* l = nullptr;
    if (FAILED(dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, __uuidof(ID3D12CommandAllocator), (void**)&a)) ||
        FAILED(dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, a, nullptr, __uuidof(ID3D12GraphicsCommandList), (void**)&l))) {
        LOGE("ui: could not create a command list - UI placement off"); if (a) a->Release(); return;
    }
    void** vt = *(void***)l;
    struct H { int slot; void* fn; void** orig; const char* n; } hs[] = {
        { 10, (void*)H_ListReset, (void**)&o_ListReset, "Reset" },
        { 12, (void*)H_DrawInstanced, (void**)&o_DrawInstanced, "DrawInstanced" },
        { 13, (void*)H_DrawIndexedInstanced, (void**)&o_DrawIndexedInstanced, "DrawIndexedInstanced" },
        { 16, (void*)H_CopyTextureRegion, (void**)&o_CopyTextureRegion, "CopyTextureRegion" },
        { 17, (void*)H_CopyResource, (void**)&o_CopyResource, "CopyResource" },
        { 21, (void*)H_RSSetViewports, (void**)&o_RSSetViewports, "RSSetViewports" },
        { 22, (void*)H_RSSetScissorRects, (void**)&o_RSSetScissorRects, "RSSetScissorRects" },
        { 26, (void*)H_ResourceBarrier, (void**)&o_ResourceBarrier, "ResourceBarrier" },
        { 46, (void*)H_OMSetRenderTargets, (void**)&o_OMSetRenderTargets, "OMSetRenderTargets" },
        { 25, (void*)H_SetPSO, (void**)&o_SetPSO, "SetPipelineState" },
        { 59, (void*)H_ExecIndirect, (void**)&o_ExecIndirect, "ExecuteIndirect" } };
    int ok = 0;
    for (auto& h : hs) if (MH_CreateHook(vt[h.slot], h.fn, h.orig) == MH_OK && MH_EnableHook(vt[h.slot]) == MH_OK) ok++;
        else LOGE("ui: hook %s failed", h.n);
    l->Close(); l->Release(); a->Release();
    LOGI("ui: %d of %zu command list hooks in place", ok, sizeof hs / sizeof hs[0]);
    void** dv = *(void***)dev;
    if (MH_CreateHook(dv[20], (void*)H_CreateRTV, (void**)&o_CreateRTV) == MH_OK && MH_EnableHook(dv[20]) == MH_OK) LOGI("ui: CreateRenderTargetView hooked");
    else LOGE("ui: CreateRenderTargetView hook failed - UI placement off");
    g_incRtv = dev->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV); g_incDsv = dev->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_DSV);
    if (MH_CreateHook(dv[23], (void*)H_CopyDescriptors, (void**)&o_CopyDescriptors) == MH_OK && MH_EnableHook(dv[23]) == MH_OK &&
        MH_CreateHook(dv[24], (void*)H_CopyDescriptorsSimple, (void**)&o_CopyDescriptorsSimple) == MH_OK && MH_EnableHook(dv[24]) == MH_OK)
        LOGI("ui: descriptor copies followed");
    {   // render passes: ID3D12GraphicsCommandList4 slot 68
        static const GUID kList4 = { 0x8754318e, 0xd3a9, 0x4541, { 0x98, 0xcf, 0x64, 0x5b, 0x50, 0xdc, 0x48, 0x74 } };
        ID3D12CommandAllocator* a4 = nullptr; ID3D12GraphicsCommandList* l4 = nullptr;
        if (SUCCEEDED(dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, __uuidof(ID3D12CommandAllocator), (void**)&a4)) &&
            SUCCEEDED(dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, a4, nullptr, kList4, (void**)&l4))) {
            void** v4 = *(void***)l4;
            if (MH_CreateHook(v4[68], (void*)H_BeginRenderPass, (void**)&o_BeginRenderPass) == MH_OK && MH_EnableHook(v4[68]) == MH_OK) LOGI("ui: BeginRenderPass hooked");
            l4->Close();
        }
        if (l4) l4->Release();
        if (a4) a4->Release();
    }
    {   // mesh shaders: ID3D12GraphicsCommandList6 slot 79 (only where the runtime has the interface)
        static const GUID kList6 = { 0xc3827890, 0xe548, 0x4cfa, { 0x96, 0xcf, 0x56, 0x89, 0xa9, 0x37, 0x0f, 0x80 } };
        ID3D12CommandAllocator* a6 = nullptr; ID3D12GraphicsCommandList* l6 = nullptr;
        if (SUCCEEDED(dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, __uuidof(ID3D12CommandAllocator), (void**)&a6)) &&
            SUCCEEDED(dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, a6, nullptr, __uuidof(ID3D12GraphicsCommandList), (void**)&l6))) {
            IUnknown* q6 = nullptr;
            if (SUCCEEDED(l6->QueryInterface(kList6, (void**)&q6)) && q6) {
                void** v6 = *(void***)q6;
                if (MH_CreateHook(v6[79], (void*)H_DispatchMesh, (void**)&o_DispatchMesh) == MH_OK && MH_EnableHook(v6[79]) == MH_OK) LOGI("ui: DispatchMesh hooked (mesh-shader draws are counted)");
                q6->Release();
            } else LOGI("ui: no ID3D12GraphicsCommandList6 on this runtime - no mesh-shader draw counting");
            l6->Close();
        }
        if (l6) l6->Release();
        if (a6) a6->Release();
    }
    {   // pipelines: which are 2D (ui_2d) - plain descriptions, pipeline streams, and pipeline libraries (cached PSOs)
        int n = 0;
        if (MH_CreateHook(dv[10], (void*)H_CreateGPSO, (void**)&o_CreateGPSO) == MH_OK && MH_EnableHook(dv[10]) == MH_OK) n++;
        IUnknown* d2 = nullptr;
        if (SUCCEEDED(dev->QueryInterface(kIID_Device2, (void**)&d2)) && d2) {
            void** v2 = *(void***)d2;
            if (MH_CreateHook(v2[47], (void*)H_CreatePSOStream, (void**)&o_CreatePSOStream) == MH_OK && MH_EnableHook(v2[47]) == MH_OK) n++;
            d2->Release();
        }
        IUnknown* d1 = nullptr;
        if (SUCCEEDED(dev->QueryInterface(kIID_Device1, (void**)&d1)) && d1) {
            typedef HRESULT(STDMETHODCALLTYPE* PFN_CreateLib)(void*, const void*, SIZE_T, REFIID, void**);
            IUnknown* lib = nullptr;
            PFN_CreateLib cl = (PFN_CreateLib)(*(void***)d1)[44];   // ID3D12Device1::CreatePipelineLibrary
            if (SUCCEEDED(cl(d1, nullptr, 0, kIID_PipelineLibrary, (void**)&lib)) && lib) {
                void** lv = *(void***)lib;
                if (MH_CreateHook(lv[9], (void*)H_LoadGPSO, (void**)&o_LoadGPSO) == MH_OK && MH_EnableHook(lv[9]) == MH_OK) n++;
                IUnknown* lib1 = nullptr;
                if (SUCCEEDED(lib->QueryInterface(kIID_PipelineLibrary1, (void**)&lib1)) && lib1) {
                    void** lv1 = *(void***)lib1;
                    if (MH_CreateHook(lv1[13], (void*)H_LoadPSO, (void**)&o_LoadPSO) == MH_OK && MH_EnableHook(lv1[13]) == MH_OK) n++;
                    lib1->Release();
                }
                lib->Release();
            }
            d1->Release();
        }
        LOGI("ui: %d pipeline creation hooks in place (2D pipelines = UI / HUD)", n);
    }
    if (MH_CreateHook(dv[21], (void*)H_CreateDSV, (void**)&o_CreateDSV) == MH_OK && MH_EnableHook(dv[21]) == MH_OK) LOGI("recon: CreateDepthStencilView hooked");
    else LOGE("recon: CreateDepthStencilView hook failed - stereo reconstruction has no depth");
    recon::SetRaw((void*)o_ResourceBarrier, (void*)o_CopyTextureRegion, (void*)o_CopyResource);
}

// ---------------------------------------------------------------- frame limiter (headset refresh rate, never half)
// At most the headset's REAL refresh rate - never the rate the runtime's motion smoothing runs the app at. The host
// passes on OpenXR's predictedDisplayPeriod, and on several runtimes that doubles while smoothing is active (Meta ASW,
// Virtual Desktop SSW, Pimax Smart Smoothing, SteamVR motion smoothing when forced, WMR reprojection) - following it
// would halve the game. So the cap is the headset's own rate:
//   * the shortest period ever seen for this headset - kept across sessions (ResonanceVR\refresh.txt), so a session with
//     smoothing forced on from the first frame still uses the full rate;
//   * a reported rate PC VR headsets do not refresh at (under 66 Hz: 60 / 45 / 40 / 36 ...) is a divided rate:
//     multiplied back to the refresh it divides (the saved one, else the nearest common VR rate) - refresh.h;
//   * headset_refresh_hz overrides all of it.
// The game itself never waits for the host or the runtime: a slot the host is still reading is skipped, not waited
// for, and the host's frame loop (xrWaitFrame, its pacing) runs in its own process. So no smoothing mode - full,
// runtime, repeat - can slow the game; only this cap could, and it never goes below the headset's refresh.
extern std::wstring g_modDir;
static double g_limitMs = -1; static int64_t g_bestNs = 0, g_savedNs = 0; static LONGLONG g_limNext = 0;
// 0.6.49 pair_rate: synchronized / alternate eye at twice the refresh rate while the game's own frame work (the time
// between limiter calls, the wait taken out) fits comfortably in half a refresh. Measured where the limiter already
// runs - no extra work per frame beyond a few arithmetic operations.
static bool g_pairPerEye = false, g_pairDouble = false; static double g_pairHalfMs = 0.0, g_pairWork = 0.0;
static int g_pairRun = 0; static LONGLONG g_pairBackoff = 0, g_pairLastEnd = 0;
static unsigned g_pairFramesD = 0, g_pairFramesS = 0;
static void PairRateTick(LONGLONG now) {
    if (!g_set.pairRate || !g_pairPerEye || g_pairHalfMs <= 0.5) {
        if (g_pairDouble) { g_pairDouble = false; LOGI("pair rate: off for this mode / setting - the headset's refresh rate"); }
        g_pairLastEnd = 0; return;
    }
    if (g_pairLastEnd) {
        double work = (double)(now - g_pairLastEnd) / 10000.0;
        if (work > 0.0 && work < 200.0) g_pairWork = g_pairWork <= 0.0 ? work : g_pairWork * 0.95 + work * 0.05;
    }
    if (g_pairDouble) {
        g_pairFramesD++;
        if (g_pairWork > g_pairHalfMs * 0.97) { if (++g_pairRun > 36) {
            g_pairDouble = false; g_pairRun = 0; g_pairBackoff = now + 100000000LL;   // try again in 10 s
            LOGI("pair rate: the game needs %.1f ms a frame, more than half a refresh (%.1f ms) - back to the refresh rate, "
                 "both eyes every second refresh (trying again in 10 s)", g_pairWork, g_pairHalfMs); } }
        else g_pairRun = 0;
    } else {
        g_pairFramesS++;
        if (now >= g_pairBackoff && g_pairWork > 0.0 && g_pairWork < g_pairHalfMs * 0.80) { if (++g_pairRun > 144) {
            g_pairDouble = true; g_pairRun = 0;
            LOGI("pair rate: the game needs %.1f ms a frame, half a refresh is %.1f ms - twice the refresh rate, both eyes "
                 "new every refresh", g_pairWork, g_pairHalfMs); } }
        else g_pairRun = 0;
    }
}
static HANDLE g_limTimer = nullptr; static unsigned g_limWaits = 0; static double g_limWaitMs = 0;
static int64_t g_lastReported = 0; static bool g_divided = false; static std::string g_refreshFor;
bool FpsRuntimeSmoothing() { return g_divided; }   // 0.6.44: setup check
static bool g_fpsUnlocked = false, g_fpsExact = false;
void FpsLimitSet(const std::string& v) {
    // 0.6.23: unlocked = no cap at all, also in VR (the game runs as fast as it can; the headset takes the newest
    // image each refresh); a number = exactly that cap, also in VR (the player's choice, above or below the refresh)
    g_fpsUnlocked = g_set.fpsUnlocked || v == "unlocked";
    g_fpsExact = !g_fpsUnlocked && v != "headset" && atof(v.c_str()) > 1.0;
    g_limitMs = v == "headset" ? 0.0 : g_fpsExact ? 1000.0 / atof(v.c_str()) : 1e9;
    g_limNext = 0;
    LOGI("fps limiter: %s", g_fpsUnlocked ? "uncapped (fps_unlocked) - no cap, also in VR" : v.c_str());
    if (g_fpsUnlocked)   // 0.6.51: seen in a 0.6.50 log - the headset dropped from 72 to 48 Hz, half its frames late
        LOGW("UNCAPPED FRAME RATE IN VR: the game takes the time the headset's own frame thread needs - frames go late and "
             "the headset can drop to a lower rate. For more fps use \"both eyes every refresh\" (pair_rate) with the cap on.");
}
static void RefreshLoad(const std::string& sys) {   // saved shortest period for this headset
    g_refreshFor = sys; g_savedNs = 0;
    if (FILE* f = _wfopen((g_modDir + L"\\refresh.txt").c_str(), L"r")) {
        char name[128]; long long ns;
        while (fscanf(f, " %lld %127[^\n]", &ns, name) == 2) if (sys == name && ns > 1000000 && ns < 100000000) g_savedNs = ns;
        fclose(f);
    }
    if (g_savedNs) LOGI("fps limiter: %s refreshes at %.1f Hz (saved)", sys.c_str(), 1e9 / (double)g_savedNs);
}
static void RefreshSave(const std::string& sys, int64_t ns) {
    std::string out; bool done = false;
    if (FILE* f = _wfopen((g_modDir + L"\\refresh.txt").c_str(), L"r")) {
        char name[128]; long long v;
        while (fscanf(f, " %lld %127[^\n]", &v, name) == 2) {
            char line[200];
            if (sys == name) { snprintf(line, sizeof line, "%lld %s\n", (long long)ns, name); done = true; }
            else snprintf(line, sizeof line, "%lld %s\n", v, name);
            out += line;
        }
        fclose(f);
    }
    if (!done) { char line[200]; snprintf(line, sizeof line, "%lld %s\n", (long long)ns, sys.c_str()); out += line; }
    if (FILE* f = _wfopen((g_modDir + L"\\refresh.txt").c_str(), L"w")) { fputs(out.c_str(), f); fclose(f); }
}
// the headset's refresh period from what the runtime reports now (ns), never a divided (smoothing) rate
static int64_t HeadsetPeriodNs() {
    if (g_set.headsetHz > 20.f) return (int64_t)(1e9 / g_set.headsetHz);
    // 0.9.3 (Framework Boost 3): the display's own rate from XR_FB_display_refresh_rate, never divided by smoothing - preferred when offered
    {
        float fb = xrb::ClientDisplayRefreshHz();
        static float s_fbLogged = 0.f;
        if (fb > 20.f && fb < 500.f) {
            if (fabsf(fb - s_fbLogged) > 0.05f) { s_fbLogged = fb; LOGI("fps limiter: the runtime reports the display's own rate, %.1f Hz (smoothing cannot halve it)", fb); }
            int64_t per = xrb::ClientDisplayPeriodNs(), full = (int64_t)(1e9 / fb);
            static ULONGLONG s_smLog = 0;
            if (per > full + full / 3 && (!s_smLog || ModTick64() - s_smLog > 30000)) { s_smLog = ModTick64();
                LOGE("SETUP: MOTION SMOOTHING ON - the runtime runs the app at %.1f Hz instead of %.1f Hz (Oculus ASW / SteamVR smoothing / SSW) - "
                     "not supported, turn it off", 1e9 / (double)per, fb); }
            return full;
        }
    }
    std::string sys = xrb::ClientSystemName();
    if (sys != g_refreshFor) RefreshLoad(sys);
    int64_t p = xrb::ClientDisplayPeriodNs();
    if (p > 0 && (1e9 / (double)p < 30.0 || 1e9 / (double)p > 250.0)) p = 0;   // runtime noise / stalls (manual 9.1)
    int64_t rep = p;
    bool divided = false;
    // manual 9.2: "a low rate means smoothing" holds for Pimax (it reports the halved rate from the start when Smart
    // Smoothing is forced on); Quest / VDXR / SteamVR / WMR really run at 60 Hz when set to it - there smoothing only
    // shows as a drop from a higher rate this headset has reported (saved or seen)
    std::string rtl = xrb::ClientRuntimeName(); for (auto& c : rtl) c = (char)tolower((unsigned char)c);
    bool pimax = rtl.find("pimax") != std::string::npos;
    int64_t known = g_savedNs ? g_savedNs : g_bestNs;
    static bool s_ruleLogged = false;
    if (!s_ruleLogged && !rtl.empty()) { s_ruleLogged = true;
        LOGI("pacing: runtime '%s' - %s", rtl.c_str(), pimax ? "a report under 66 Hz is its halved (smoothing) rate" : "its reported rate is real; smoothing is a drop from the full rate seen"); }
    if (pimax) p = RefreshUndivide(rep, known, &divided, RefreshMinNative(sys.c_str()));
    else if (p && known && p > known + known / 33) {   // slower than the full rate seen: the runtime is smoothing
        divided = true; p = known;
    }
    if (p) {
        double hz = 1e9 / (double)rep;
        if (divided != g_divided || (p != g_lastReported && !divided && (!g_bestNs || p < g_bestNs))) {
            g_divided = divided;
            static ULONGLONG s_lastLog = 0; ULONGLONG now = ModTick64();   // 0.6.25: at most every 30 s (67 lines in a log)
            if (divided && (!s_lastLog || now - s_lastLog > 30000)) { s_lastLog = now;
                LOGE("SETUP: MOTION SMOOTHING ON - the runtime runs the app at %.1f Hz instead of %.1f Hz (Oculus ASW / SteamVR smoothing / SSW) - "
                     "not supported, turn it off", hz, 1e9 / (double)p); }
        }
        g_lastReported = p;
        // a faster rate than the one known is taken after 30 consistent reports (within 3 %), the first one at once
        static int64_t s_candNs = 0; static int s_candN = 0;
        bool take = !g_bestNs;
        if (g_bestNs && p < g_bestNs - g_bestNs / 100) {
            if (s_candNs && llabs(p - s_candNs) <= s_candNs / 33) { if (++s_candN >= 30) take = true; }
            else { s_candNs = p; s_candN = 1; }
        }
        if (take) {
            g_bestNs = p; s_candNs = 0; s_candN = 0;
            LOGI("fps limiter: %.1f fps (the headset's refresh rate%s)", 1e9 / (double)p, divided ? ", from a divided report" : "");
            if (!sys.empty() && !divided && (!g_savedNs || p < g_savedNs - 20000)) { g_savedNs = p; RefreshSave(sys, p); }
        }
    }
    // 0.6.22: the headset was set to a LOWER refresh rate (e.g. 90 -> 72 Hz, 120 -> 90 Hz): the saved / best rate only
    // ever went up, so the fps cap stayed at the old, faster rate. A slower report, steady for 20 s and not a smoothing
    // ratio of the known rate (1/2, 2/3, 1/3), is the headset's new rate.
    {
        static int64_t s_slowNs = 0; static ULONGLONG s_slowSince = 0;
        int64_t ref = g_savedNs && (!g_bestNs || g_savedNs < g_bestNs) ? g_savedNs : g_bestNs;
        int64_t c = pimax ? p : rep;
        if (c > 0 && ref > 0 && c > ref + ref / 33) {
            double k = (double)ref / (double)c;
            bool smoothRatio = fabs(k - 0.5) < 0.02 || fabs(k - 2.0 / 3.0) < 0.02 || fabs(k - 1.0 / 3.0) < 0.02;
            ULONGLONG now = ModTick64();
            if (smoothRatio) s_slowNs = 0;
            else if (!s_slowNs || llabs(c - s_slowNs) > s_slowNs / 33) { s_slowNs = c; s_slowSince = now; }
            else if (now - s_slowSince > 20000) {
                g_bestNs = c; g_savedNs = c; s_slowNs = 0;
                if (!sys.empty()) RefreshSave(sys, c);
                LOGI("fps limiter: the headset now refreshes at %.1f Hz (set lower) - the cap follows", 1e9 / (double)c);
            }
        } else s_slowNs = 0;
    }
    int64_t r = g_bestNs;
    if (g_savedNs && (!r || g_savedNs < r)) r = g_savedNs;   // a saved full rate beats anything measured while smoothing
    return r;
}
// manual 9.3: in VR the cap follows the headset. Alternate eye / synchronized: exactly its refresh, whatever was set
// (each headset frame needs one new eye: a lower cap shows the eyes unevenly, a higher one throws frames away at
// irregular points). Reconstruction / head: a lower cap is allowed, a higher one or "off" is clamped to the refresh
// (faster frames are only thrown away and take GPU time from the runtime / a streaming encoder). Flat: the user's value.
static double FpsLimitMs() {   // the frame interval to keep now (ms), 0 = no cap
    if (g_fpsUnlocked) return 0.0;                      // 0.6.23: unlocked - no cap anywhere
    bool vr = CameraFrameIsVR() && g_cam.mode != VRMODE_SCREEN;
    if (g_fpsExact) {                                   // 0.6.23: the player's own number, also in VR
        static bool s_l = false; if (vr && !s_l) { s_l = true; LOGI("fps limiter: %.1f fps (set in the VR panel, also in VR)", 1000.0 / g_limitMs); }
        return g_limitMs;
    }
    bool perEye = vr && (g_cam.mode == VRMODE_STEREO || g_cam.mode == VRMODE_SYNCED);
    g_pairPerEye = perEye;
    double ms = g_limitMs;
    if (vr) {
        int64_t p = HeadsetPeriodNs();
        if (!p) return ms == 0.0 || ms >= 1e8 ? 0.0 : ms;   // refresh not known yet
        double hms = p / 1e6;
        double want = perEye || ms == 0.0 || ms >= 1e8 || ms < hms ? hms : ms;   // ms < hms: above the refresh; 1e9: off
        g_pairHalfMs = hms / 2.0;
        if (perEye && g_set.pairRate && g_pairDouble) return hms / 2.0;   // 0.6.49: a whole pair every refresh
        static int s_rule = -1; int rule = perEye ? 1 : (ms != 0.0 && want != ms) ? 2 : 0;
        if (rule != s_rule) { s_rule = rule;
            if (rule == 1 && g_limitMs != 0.0) LOGI("fps limiter: alternate eye / synchronized - exactly the headset's %.1f Hz (fps_limit is for flat mode)", 1000.0 / hms);
            else if (rule == 2) LOGI("fps limiter: fps_limit above the headset's %.1f Hz or off - clamped to it in VR", 1000.0 / hms); }
        return want;
    }
    if (ms == 0.0) { int64_t p = HeadsetPeriodNs(); return p ? p / 1e6 : 0.0; }
    return ms >= 1e8 ? 0.0 : ms;
}
// 0.9.3 (Framework Boost 14, pace_lock): synchronized / alternate eye - each release is nudged (10 % of the error a frame, at most 0.3 ms) so
// that release + the measured frame work lands a margin (2 ms or 15 % of a refresh) before the host's next frame. Without it the hand-over
// drifted through the host's frame: a pair showed for one refresh, then three - judder.
static LONGLONG g_lockLastRel = 0; static double g_lockWork = 0.0;
static double g_lockErrSum = 0.0, g_lockErrSq = 0.0; static unsigned g_lockN = 0, g_lockNear = 0;
static double Wrap(double x, double p) { x = fmod(x, p); if (x > p * 0.5) x -= p; if (x < -p * 0.5) x += p; return x; }
static void FpsLimit() {
    LARGE_INTEGER entry; ModQpc(&entry);
    const bool lockMode = g_set.paceLock && (g_cam.mode == VRMODE_SYNCED || g_cam.mode == VRMODE_STEREO);
    const int64_t wake = lockMode ? xrb::ClientHostWake100ns() : 0;
    double hostPer = 0.0;   // 100 ns
    if (lockMode) { float hz = xrb::ClientDisplayRefreshHz(); int64_t pn = xrb::ClientDisplayPeriodNs(); hostPer = hz > 20.f ? 1e7 / hz : pn > 0 ? pn / 100.0 : 0.0; }
    if (lockMode && wake && hostPer > 1000.0 && g_lockLastRel) {   // this frame's hand-over (its Present) against the host's frame grid
        double work = (double)(entry.QuadPart - g_lockLastRel);
        if (work > 0 && work < 2e6) g_lockWork = g_lockWork <= 0 ? work : g_lockWork * 0.9 + work * 0.1;
        double d = Wrap((double)(entry.QuadPart - wake), hostPer);
        if (fabs(d) < 5000.0) g_lockNear++;   // within 0.5 ms of the headset's frame
    }
    if (g_limitMs < 0) {
        FpsLimitSet(g_set.fpsLimit);
        g_limTimer = CreateWaitableTimerExW(nullptr, nullptr, 0x00000002 /*HIGH_RESOLUTION*/, TIMER_ALL_ACCESS);
        if (!g_limTimer) g_limTimer = CreateWaitableTimerW(nullptr, TRUE, nullptr);
    }
    { LARGE_INTEGER t0; ModQpc(&t0); PairRateTick(t0.QuadPart); }
    double ms = FpsLimitMs();
    if (!(ms > 0.5)) { g_limNext = 0; { LARGE_INTEGER t; ModQpc(&t); g_pairLastEnd = t.QuadPart; } return; }
    LARGE_INTEGER now; ModQpc(&now);
    LONGLONG iv = (LONGLONG)(ms * 10000.0);   // 100 ns units
    if (!g_limNext || now.QuadPart - g_limNext > iv * 2) g_limNext = now.QuadPart;
    if (now.QuadPart < g_limNext) {
        double leftMs = (double)(g_limNext - now.QuadPart) / 10000.0;
        if (leftMs > 1.5 && g_limTimer) {
            LARGE_INTEGER due; due.QuadPart = -(LONGLONG)((leftMs - 1.0) * 10000.0);
            if (SetWaitableTimer(g_limTimer, &due, 0, nullptr, nullptr, FALSE)) WaitForSingleObject(g_limTimer, 50);
        }
        do { YieldProcessor(); ModQpc(&now); } while (now.QuadPart < g_limNext);
        g_limWaits++; g_limWaitMs += leftMs;
    }
    double kk = hostPer > 1000.0 && iv > 0 ? hostPer / (double)iv : 0.0;   // 1: cap = the refresh; 2: two frames a refresh (pair rate)
    double kr = floor(kk + 0.5);
    if (lockMode && wake && kr >= 1.0 && kr <= 2.0 && fabs(kk - kr) < 0.02 * kr && g_lockWork > 0) {   // only with the cap at the headset's rate
        double margin = std::max(20000.0, 0.15 * hostPer);
        double h = (double)(g_limNext + iv) + g_lockWork;            // the next frame's predicted hand-over
        double err = Wrap(h - ((double)wake - margin), (double)iv);    // > 0: too late against "margin before a host frame" (grid of the cap)
        double step = std::max(-3000.0, std::min(3000.0, 0.1 * err));
        g_limNext -= (LONGLONG)step;
        g_lockErrSum += err; g_lockErrSq += err * err; g_lockN++;
    }
    g_limNext += iv;
    g_pairLastEnd = now.QuadPart;
    g_lockLastRel = now.QuadPart;
}
void FpsLimitReport() {
    if (g_set.paceLock && (g_cam.mode == VRMODE_SYNCED || g_cam.mode == VRMODE_STEREO)) {
        if (g_lockN) {
            double m = g_lockErrSum / g_lockN, sd = sqrt(std::max(0.0, g_lockErrSq / g_lockN - m * m));
            LOGI("pacing: lock error %.2f ms (spread %.2f), hand-overs within 0.5 ms of the headset's frame %u of %u", m / 10000.0, sd / 10000.0, g_lockNear, g_lockN);
        } else {
            static ULONGLONG s_t = 0; ULONGLONG now = ModTick64();
            if (!s_t || now - s_t > 60000) { s_t = now; LOGI("pacing: the phase lock needs the frame cap at the headset's rate (Uncapped frame rate off) and the host's frame time - not active"); }
        }
    }
    g_lockErrSum = g_lockErrSq = 0; g_lockN = g_lockNear = 0;
    if (g_limitMs == 0.0 && g_bestNs)
        LOGI("fps limiter: cap %.1f fps (headset)%s", 1e9 / (double)(g_savedNs && g_savedNs < g_bestNs ? g_savedNs : g_bestNs),
             g_divided ? " - runtime smoothing active, the game keeps the full rate" : "");
    // 0.6.41: Quest 3 / Oculus log - the runtime sat at 45 Hz with ASW for 18 min in synchronized (back to 90 Hz only when
    // the headset was taken off and on). Synchronized / alternate eye draw two game frames per headset image; when the
    // GPU cannot do that at the headset rate, Oculus ASW halves the rate and invents every other frame (warped motion,
    // the world seems to change scale while turning). OpenXR cannot switch ASW off - said here, nothing is changed.
    if (g_divided && (g_cam.mode == VRMODE_SYNCED || g_cam.mode == VRMODE_STEREO)) {
        static ULONGLONG s_t = 0; ULONGLONG now = ModTick64();
        if (!s_t || now - s_t > 60000) { s_t = now;
            LOGW("fps limiter: the headset runtime is at half rate with its motion smoothing (Oculus ASW / spacewarp) in %s - this "
                 "method draws two game frames per headset image; the smoothing's invented frames warp the motion. Turn ASW off "
                 "(Oculus: Ctrl+Numpad1 while the game runs, or the Oculus Debug Tool), lower the render resolution, or use stereo "
                 "reconstruction (one game frame per headset image)", g_cam.mode == VRMODE_SYNCED ? "synchronized" : "alternate eye"); }
    }
    if (g_limWaits) LOGI("fps limiter: waited in %u frames, %.2f ms on average", g_limWaits, g_limWaitMs / g_limWaits);
    g_limWaits = 0; g_limWaitMs = 0;
    if (g_set.pairRate && (g_pairFramesD || g_pairFramesS)) {
        LOGI("pair rate: %u frames at twice the refresh rate, %u at the refresh rate | the game's frame work %.1f ms (half a refresh %.1f ms)",
             g_pairFramesD, g_pairFramesS, g_pairWork, g_pairHalfMs);
        // 0.6.51: what it would take (if the GPU sets the pace: its work grows with the pixels, i.e. the render scale squared)
        if (!g_pairFramesD && g_pairWork > g_pairHalfMs * 0.8 && g_pairWork < 100.0 && g_set.renderScale > 0.f) {
            double sc = g_set.renderScale * sqrt(g_pairHalfMs * 0.78 / g_pairWork);
            LOGI("pair rate: to reach twice the refresh rate the frame work must drop to %.1f ms - about render scale %.2f (now %.2f), "
                 "or foveated rendering, or a lower headset refresh rate", g_pairHalfMs * 0.8, sc, g_set.renderScale);
        }
    }
    g_pairFramesD = g_pairFramesS = 0;
}
void UiReport() {
    LOGI("ui: draws into the final image: 3D %u, UI %u (moved onto the eye %u; viewport taken as the whole target %u, not placed %u - ui_mode %s, VR frame %d)",
         g_sceneDraws, g_uiDraws, g_uiMoved, g_uiNoVp, g_uiNoPlace, g_set.uiMode.c_str(), (int)CameraFrameIsVR());
    LOGI("ui: target binds %ld (known %ld, final image %ld, render passes %ld), view copies %ld", g_bindAll, g_bindKnown, g_bindFinal, g_bindPass, g_rtvCopies);
    LOGI("ui: 2D pipelines %ld of %ld (streams %ld, unparsed %ld) | 2D draws into screen-size targets %ld, moved %ld | indirect draws %ld",
         g_pso2D, g_psoSeen, g_psoStream, g_psoStreamBad, g_ui2dDraws, g_ui2dMoved, g_indirect);
    LOGI("ui: every draw the hooks saw in the last interval: direct %ld, indexed %ld, indirect %ld, mesh %ld",
         InterlockedExchange(&g_anyDraw, 0), InterlockedExchange(&g_anyIndexed, 0), InterlockedExchange(&g_anyIndirect, 0), InterlockedExchange(&g_anyMesh, 0));
    g_ui2dDraws = g_ui2dMoved = g_indirect = 0;
    if (g_cam.mode == VRMODE_RECON) LOGI("recon: depth binds %ld (unknown view %ld, depth-only passes %ld)", InterlockedExchange(&g_dsvBinds, 0), InterlockedExchange(&g_dsvUnknown, 0), InterlockedExchange(&g_dsvDepthOnly, 0));
    LOGI("ui: UI layer %s | last frame: %ld targets, scene depth %ld draws, best UI candidate %ld draws (format %d)",
         g_uiTarget ? "in use" : "not found", g_uiSearchTargets, g_uiSearchSceneDraws, g_uiSearchBestDraws, g_uiSearchBestFmt);
    if (g_uiFullDesc[0]) LOGI("ui: full-screen layers (bind order, last = HUD):%s", g_uiFullDesc);
    if (!g_uiTarget && CameraFrameIsVR()) LOGI("ui: no UI layer - targets drawn after the 3D scene (size, format, draws), back buffer %ux%u:%s",
                                               g_bbW, g_bbH, g_uiAllDesc[0] ? g_uiAllDesc : " none");
    g_bindAll = g_bindKnown = g_bindFinal = g_bindPass = g_rtvCopies = 0;
    if (g_cam.uiEyeAhead) LOGI("ui: %u UI / 3D draws recorded while the next frame's camera was already set - placed for the frame being shown (0.6.33)", g_cam.uiEyeAhead);
    g_cam.uiEyeAhead = 0;
    g_sceneDraws = g_uiDraws = g_uiMoved = g_uiNoVp = g_uiNoPlace = 0;
}

// ---------------------------------------------------------------- swap chain
typedef HRESULT(STDMETHODCALLTYPE* PFN_CreateSwapChain)(IDXGIFactory*, IUnknown*, DXGI_SWAP_CHAIN_DESC*, IDXGISwapChain**);
typedef HRESULT(STDMETHODCALLTYPE* PFN_CreateSwapChainForHwnd)(IDXGIFactory2*, IUnknown*, HWND, const DXGI_SWAP_CHAIN_DESC1*,
                                                               const DXGI_SWAP_CHAIN_FULLSCREEN_DESC*, IDXGIOutput*, IDXGISwapChain1**);
typedef HRESULT(STDMETHODCALLTYPE* PFN_Present)(IDXGISwapChain*, UINT, UINT);
typedef HRESULT(STDMETHODCALLTYPE* PFN_Present1)(IDXGISwapChain1*, UINT, UINT, const DXGI_PRESENT_PARAMETERS*);
typedef HRESULT(STDMETHODCALLTYPE* PFN_ResizeBuffers)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);
typedef HRESULT(STDMETHODCALLTYPE* PFN_ResizeBuffers1)(IDXGISwapChain3*, UINT, UINT, UINT, DXGI_FORMAT, UINT, const UINT*, IUnknown* const*);
typedef HRESULT(STDMETHODCALLTYPE* PFN_SetFullscreenState)(IDXGISwapChain*, BOOL, IDXGIOutput*);
typedef HRESULT(STDMETHODCALLTYPE* PFN_SetColorSpace1)(IDXGISwapChain3*, DXGI_COLOR_SPACE_TYPE);
static PFN_CreateSwapChain o_CreateSwapChain; static PFN_CreateSwapChainForHwnd o_CreateSwapChainForHwnd;
static PFN_Present o_Present; static PFN_Present1 o_Present1; static PFN_ResizeBuffers o_ResizeBuffers; static PFN_ResizeBuffers1 o_ResizeBuffers1;
static PFN_SetFullscreenState o_SetFullscreenState; static PFN_SetColorSpace1 o_SetColorSpace1;

bool StartupForceWindowed();
static bool VrSized() { unsigned w, h; return ResolutionTarget(w, h); }
// windowed whenever VR sizes the window, and from the very first swap chain when force_windowed is on
static bool KeepWindowed() { return StartupForceWindowed() || VrSized(); }

static void GrabBuffers() {
    for (auto*& b : g_bb) if (b) { b->Release(); b = nullptr; }
    g_bbCount = 0;
    if (!g_swap) return;
    DXGI_SWAP_CHAIN_DESC1 d = {}; g_swap->GetDesc1(&d);
    g_bbW = d.Width; g_bbH = d.Height; g_bbFmt = d.Format;
    for (UINT i = 0; i < d.BufferCount && i < 8; i++)
        if (SUCCEEDED(g_swap->GetBuffer(i, __uuidof(ID3D12Resource), (void**)&g_bb[i]))) g_bbCount = i + 1;
    for (auto& f : g_final) f = nullptr;
    LOGI("swapchain: %u buffers %u x %u format %d", g_bbCount, g_bbW, g_bbH, (int)g_bbFmt);
}

static int g_xrOutput = -1;
static bool XrOutput() { if (g_xrOutput < 0) { g_xrOutput = ConfigBool("xr_output", true) ? 1 : 0; if (!g_xrOutput) LOGI("xr: output off (xr_output = false)"); } return g_xrOutput == 1; }

static void BeforePresent(IDXGISwapChain* sc, UINT& sync, UINT& flags) {
    if (!g_presentThread) { g_presentThread = GetCurrentThreadId(); LOGI("first Present (thread %lu, sync %u, flags %x)", g_presentThread, sync, flags); }
    if ((IDXGISwapChain*)g_swap != sc || (flags & DXGI_PRESENT_TEST) || !XrOutput()) return;
    UINT idx = g_swap->GetCurrentBackBufferIndex();
#ifdef ResonanceVR_TEST_RECON
    recon::OnPresent(g_dev12, nullptr, g_bbW, g_bbH, g_bbFmt);   // test build: the D3D12 capture side without a headset
#endif
    XrOnPresent(idx);
    UiLayerFrameEnd();
    g_uiFrameDraws = 0; g_sceneSeen = 0; g_firstUiDone = 0;
    // the headset sets the pace whenever it is connected (also the flat screen / menus): no monitor vsync, the
    // limiter below holds the game at the headset's highest refresh rate
    if (g_set.vsyncOff && (CameraFrameIsVR() || xrb::ClientHostConnected())) {
        sync = 0;
        BOOL fs = FALSE; g_swap->GetFullscreenState(&fs, nullptr);
        if (g_tearing && !fs) flags |= DXGI_PRESENT_ALLOW_TEARING;
    }
}
static void AfterPresent(IDXGISwapChain* sc) {
    if ((IDXGISwapChain*)g_swap != sc) return;
    InterlockedIncrement(&g_presents);
    if (XrOutput() && (CameraFrameIsVR() || xrb::ClientHostConnected())) FpsLimit();
}
static HRESULT STDMETHODCALLTYPE H_Present(IDXGISwapChain* sc, UINT sync, UINT flags) {
    BeforePresent(sc, sync, flags);
    HRESULT hr = o_Present(sc, sync, flags);
    if (hr == DXGI_ERROR_DEVICE_REMOVED || hr == DXGI_ERROR_DEVICE_RESET) { extern void DiagDeviceLost(HRESULT); DiagDeviceLost(hr); }   // 0.6.47
    AfterPresent(sc);
    return hr;
}
static HRESULT STDMETHODCALLTYPE H_Present1(IDXGISwapChain1* sc, UINT sync, UINT flags, const DXGI_PRESENT_PARAMETERS* p) {
    BeforePresent((IDXGISwapChain*)sc, sync, flags);
    HRESULT hr = o_Present1(sc, sync, flags, p);
    if (hr == DXGI_ERROR_DEVICE_REMOVED || hr == DXGI_ERROR_DEVICE_RESET) { extern void DiagDeviceLost(HRESULT); DiagDeviceLost(hr); }   // 0.6.47
    AfterPresent((IDXGISwapChain*)sc);
    return hr;
}

static void ForceSize(UINT& w, UINT& h) {
    unsigned tw, th;
    if (ResolutionTarget(tw, th)) {
        if (w != tw || h != th) {
            // the first swap chain is made before the window is the eye size; a request with the eye's WIDTH but not
            // its height means something still keeps the window inside the monitor
            if (w == tw) LOGW("swapchain: %u x %u requested -> %u x %u (the game's window was cut to the monitor)", w, h, tw, th);
            else LOGI("swapchain: %u x %u requested -> %u x %u (VR eye size)", w, h, tw, th);
        }
        // 0.4: the game's render surface with it - this engine makes its 3D and targets at the surface's size, not the
        // swap chain's (game.cpp DisplaySetSurface), so the forced size reaches the 3D (headset size and shape)
        if (w != tw || h != th) game::DisplaySetSurface(w, h, tw, th);
        w = tw; h = th;
    }
}
static HRESULT STDMETHODCALLTYPE H_ResizeBuffers(IDXGISwapChain* sc, UINT n, UINT w, UINT h, DXGI_FORMAT f, UINT fl) {
    bool ours = (IDXGISwapChain*)g_swap == sc;
    if (ours) { XrReleaseForResize(); fov::OnResize(); for (auto*& b : g_bb) if (b) { b->Release(); b = nullptr; } g_bbCount = 0; RtvClear(); UiLayerForget(); ForceSize(w, h); }
    HRESULT hr = o_ResizeBuffers(sc, n, w, h, f, fl);
    LOGI("ResizeBuffers %u x %u fmt %d n %u -> %08lx", w, h, (int)f, n, (unsigned long)hr);
    if (ours) GrabBuffers();
    return hr;
}
static HRESULT STDMETHODCALLTYPE H_ResizeBuffers1(IDXGISwapChain3* sc, UINT n, UINT w, UINT h, DXGI_FORMAT f, UINT fl, const UINT* mask, IUnknown* const* q) {
    bool ours = g_swap == sc;
    if (ours) { XrReleaseForResize(); fov::OnResize(); for (auto*& b : g_bb) if (b) { b->Release(); b = nullptr; } g_bbCount = 0; RtvClear(); UiLayerForget(); ForceSize(w, h); }   // 0.9.3: as ResizeBuffers (the shading-rate images and the UI layer were kept at the old size)
    HRESULT hr = o_ResizeBuffers1(sc, n, w, h, f, fl, mask, q);
    LOGI("ResizeBuffers1 %u x %u fmt %d n %u -> %08lx", w, h, (int)f, n, (unsigned long)hr);
    if (ours) GrabBuffers();
    return hr;
}
// 0.9.3 (Framework Boost 1): ResizeTarget (slot 14) - a game asking DXGI for a monitor-sized mode could resize the output; the mode's size is
// replaced by the VR target while VR keeps the window at the eye size
typedef HRESULT(STDMETHODCALLTYPE* PFN_ResizeTarget)(IDXGISwapChain*, const DXGI_MODE_DESC*);
static PFN_ResizeTarget o_ResizeTarget = nullptr;
static HRESULT STDMETHODCALLTYPE H_ResizeTarget(IDXGISwapChain* sc, const DXGI_MODE_DESC* m) {
    unsigned tw = 0, th = 0;
    if (m && (IDXGISwapChain*)g_swap == sc && KeepWindowed() && ResolutionTarget(tw, th) && (m->Width != tw || m->Height != th)) {
        DXGI_MODE_DESC d = *m;
        LOGI("swapchain: ResizeTarget %u x %u -> %u x %u (VR eye size)", m->Width, m->Height, tw, th);
        d.Width = tw; d.Height = th;
        return o_ResizeTarget(sc, &d);
    }
    return o_ResizeTarget(sc, m);
}
// exclusive fullscreen would stop the window from being the eye size: VR modes stay windowed (borderless)
static HRESULT STDMETHODCALLTYPE H_SetFullscreenState(IDXGISwapChain* sc, BOOL fs, IDXGIOutput* o) {
    if (fs && KeepWindowed()) { LOGI("swapchain: exclusive fullscreen refused (VR renders in a borderless window at the eye size)"); fs = FALSE; o = nullptr; }
    return o_SetFullscreenState(sc, fs, o);
}
static HRESULT STDMETHODCALLTYPE H_SetColorSpace1(IDXGISwapChain3* sc, DXGI_COLOR_SPACE_TYPE cs) {
    HRESULT hr = o_SetColorSpace1(sc, cs);
    if (sc == g_swap) {
        int v = cs == DXGI_COLOR_SPACE_RGB_FULL_G2084_NONE_P2020 ? 1 : cs == DXGI_COLOR_SPACE_RGB_FULL_G10_NONE_P709 ? 2 : 0;
        if (v != g_colorSpace) LOGI("swapchain: color space %d (%s)", (int)cs, v == 1 ? "HDR10 PQ" : v == 2 ? "scRGB linear" : "sRGB");
        g_colorSpace = v;
    }
    return hr;
}

static void HookSwapChain(IDXGISwapChain* sc, ID3D12CommandQueue* q, HWND hwnd) {
    IDXGISwapChain3* s3 = nullptr;
    if (FAILED(sc->QueryInterface(__uuidof(IDXGISwapChain3), (void**)&s3)) || !s3) { LOGE("swapchain: no IDXGISwapChain3"); return; }
    if (g_swap) g_swap->Release();
    g_swap = s3;
    if (g_queue) g_queue->Release();
    g_queue = q; q->AddRef();
    ID3D12Device* dev = nullptr;
    if (SUCCEEDED(q->GetDevice(__uuidof(ID3D12Device), (void**)&dev)) && dev) { if (g_dev12) g_dev12->Release(); g_dev12 = dev; }
    D3D12_COMMAND_QUEUE_DESC qd = q->GetDesc();
    LOGI("swapchain %p on queue %p (type %d) device %p", (void*)sc, (void*)q, (int)qd.Type, (void*)g_dev12);
    if (KeepWindowed() && hwnd) {   // Alt+Enter would switch DXGI to exclusive fullscreen behind the game's back
        IDXGIFactory1* f = nullptr;
        if (SUCCEEDED(sc->GetParent(__uuidof(IDXGIFactory1), (void**)&f)) && f) {
            HRESULT hr = f->MakeWindowAssociation(hwnd, DXGI_MWA_NO_ALT_ENTER);
            LOGI("swapchain: Alt+Enter fullscreen off (%08lx)", (unsigned long)hr); f->Release();
        }
        BOOL fsNow = FALSE;
        if (SUCCEEDED(sc->GetFullscreenState(&fsNow, nullptr)) && fsNow) { o_SetFullscreenState ? o_SetFullscreenState(sc, FALSE, nullptr) : sc->SetFullscreenState(FALSE, nullptr); LOGI("swapchain: was fullscreen - switched to windowed"); }
    }
    {
        IDXGIFactory5* f5 = nullptr; BOOL allow = FALSE;
        if (SUCCEEDED(sc->GetParent(__uuidof(IDXGIFactory5), (void**)&f5)) && f5) {
            f5->CheckFeatureSupport(DXGI_FEATURE_PRESENT_ALLOW_TEARING, &allow, sizeof allow); f5->Release();
        }
        DXGI_SWAP_CHAIN_DESC1 d = {}; s3->GetDesc1(&d);
        g_tearing = allow && (d.Flags & DXGI_SWAP_CHAIN_FLAG_ALLOW_TEARING);
        // frames the CPU may queue ahead of the GPU: fewer = the head pose of a frame is fresher when it is shown.
        // Only possible on a swap chain with a frame-latency waitable object (the game waits on it).
        if ((d.Flags & DXGI_SWAP_CHAIN_FLAG_FRAME_LATENCY_WAITABLE_OBJECT) && g_set.maxFrameLatency > 0) {
            HRESULT hl = s3->SetMaximumFrameLatency((UINT)(g_set.maxFrameLatency > 16 ? 16 : g_set.maxFrameLatency));
            LOGI("swapchain: maximum frame latency %d %s", g_set.maxFrameLatency, SUCCEEDED(hl) ? "set" : "FAILED");
        } else LOGI("swapchain: no frame-latency waitable object - the game's own queue depth is used");
        LOGI("swapchain: flags %x, tearing %s", d.Flags, g_tearing ? "allowed" : "not allowed (vsync off still works, without tearing)");
    }
    HookCommandLists(g_dev12);
    GrabBuffers();
    WindowHook(hwnd);
    void** vt = *(void***)s3;
    if (!o_Present) {
        struct Hk { int slot; void* fn; void** orig; const char* n; } hs[] = {
            { 8, (void*)H_Present, (void**)&o_Present, "Present" }, { 10, (void*)H_SetFullscreenState, (void**)&o_SetFullscreenState, "SetFullscreenState" },
            { 13, (void*)H_ResizeBuffers, (void**)&o_ResizeBuffers, "ResizeBuffers" }, { 14, (void*)H_ResizeTarget, (void**)&o_ResizeTarget, "ResizeTarget" }, { 22, (void*)H_Present1, (void**)&o_Present1, "Present1" },
            { 38, (void*)H_SetColorSpace1, (void**)&o_SetColorSpace1, "SetColorSpace1" }, { 39, (void*)H_ResizeBuffers1, (void**)&o_ResizeBuffers1, "ResizeBuffers1" } };
        for (auto& h : hs) {
            if (MH_CreateHook(vt[h.slot], h.fn, h.orig) == MH_OK && MH_EnableHook(vt[h.slot]) == MH_OK) LOGI("%s hooked", h.n);
            else LOGE("%s hook failed", h.n);
        }
    }
    WindowApplyTarget();
}

static HRESULT STDMETHODCALLTYPE H_CreateSwapChainForHwnd(IDXGIFactory2* f, IUnknown* dev, HWND hwnd, const DXGI_SWAP_CHAIN_DESC1* d,
                                                          const DXGI_SWAP_CHAIN_FULLSCREEN_DESC* fs, IDXGIOutput* o, IDXGISwapChain1** out) {
    ID3D12CommandQueue* q = nullptr;
    if (dev) dev->QueryInterface(__uuidof(ID3D12CommandQueue), (void**)&q);
    HRESULT hr;
    if (q && d) {
        DXGI_SWAP_CHAIN_DESC1 d2 = *d;
        ForceSize(d2.Width, d2.Height);
        DXGI_SWAP_CHAIN_FULLSCREEN_DESC fs2 = {}; const DXGI_SWAP_CHAIN_FULLSCREEN_DESC* pfs = fs;
        if (fs && KeepWindowed()) { fs2 = *fs; fs2.Windowed = TRUE; pfs = &fs2; }
        hr = o_CreateSwapChainForHwnd(f, dev, hwnd, &d2, pfs, o, out);
        if (FAILED(hr)) hr = o_CreateSwapChainForHwnd(f, dev, hwnd, d, fs, o, out);
    } else hr = o_CreateSwapChainForHwnd(f, dev, hwnd, d, fs, o, out);
    LOGI("IDXGIFactory2::CreateSwapChainForHwnd %ux%u fmt %d (%s) -> %08lx", d ? d->Width : 0, d ? d->Height : 0, d ? (int)d->Format : 0,
         q ? "D3D12" : "not D3D12", (unsigned long)hr);
    if (SUCCEEDED(hr) && out && *out && q) { HookSwapChain(*out, q, hwnd); extern void ResolutionKickHost(HWND, const char*); ResolutionKickHost(hwnd, "CreateSwapChainForHwnd"); }
    if (q) q->Release();
    return hr;
}
static HRESULT STDMETHODCALLTYPE H_CreateSwapChain(IDXGIFactory* f, IUnknown* dev, DXGI_SWAP_CHAIN_DESC* d, IDXGISwapChain** out) {
    ID3D12CommandQueue* q = nullptr;
    if (dev) dev->QueryInterface(__uuidof(ID3D12CommandQueue), (void**)&q);
    HRESULT hr;
    if (q && d) {
        DXGI_SWAP_CHAIN_DESC d2 = *d; ForceSize(d2.BufferDesc.Width, d2.BufferDesc.Height);
        if (KeepWindowed()) d2.Windowed = TRUE;
        hr = o_CreateSwapChain(f, dev, &d2, out);
        if (FAILED(hr)) hr = o_CreateSwapChain(f, dev, d, out);
    } else hr = o_CreateSwapChain(f, dev, d, out);
    LOGI("IDXGIFactory::CreateSwapChain (%s) -> %08lx", q ? "D3D12" : "not D3D12", (unsigned long)hr);
    if (SUCCEEDED(hr) && out && *out && q) { HookSwapChain(*out, q, d ? d->OutputWindow : nullptr); extern void ResolutionKickHost(HWND, const char*); ResolutionKickHost(d ? d->OutputWindow : nullptr, "CreateSwapChain"); }
    if (q) q->Release();
    return hr;
}

void D3DHooksInstall() {
    wchar_t sys[MAX_PATH]; GetSystemDirectoryW(sys, MAX_PATH);
    HMODULE dxgi = LoadLibraryW((std::wstring(sys) + L"\\dxgi.dll").c_str());
    LoadLibraryW((std::wstring(sys) + L"\\d3d12.dll").c_str());
    if (!dxgi) { LOGE("dxgi not loaded"); return; }
    {   // 0.6.6 log: hooked only when the swap chain came, the pipelines and render-target views the game made before
        // that (its UI canvas, its cached pipelines) were never seen - "known" binds were under 4 %. A short-lived
        // device of our own installs the device / command list hooks now (MinHook patches the code: every device).
        typedef HRESULT(WINAPI * PFN_CD)(IUnknown*, D3D_FEATURE_LEVEL, REFIID, void**);
        HMODULE d12 = GetModuleHandleW((std::wstring(sys) + L"\\d3d12.dll").c_str());
        PFN_CD cd = d12 ? (PFN_CD)GetProcAddress(d12, "D3D12CreateDevice") : nullptr;
        ID3D12Device* tmp = nullptr;
        if (cd && SUCCEEDED(cd(nullptr, D3D_FEATURE_LEVEL_11_0, __uuidof(ID3D12Device), (void**)&tmp)) && tmp) {
            HookCommandLists(tmp);
            tmp->Release();
            LOGI("d3d12: device / command list hooks in place before the game's device");
        } else LOGW("d3d12: early hooks not possible - they follow with the swap chain");
    }
    typedef HRESULT(WINAPI * PFN_CF1)(REFIID, void**);
    PFN_CF1 cf1 = (PFN_CF1)GetProcAddress(dxgi, "CreateDXGIFactory1");
    IDXGIFactory1* f = nullptr;
    if (cf1 && SUCCEEDED(cf1(__uuidof(IDXGIFactory1), (void**)&f)) && f) {
        void** vt = *(void***)f;
        if (MH_CreateHook(vt[10], (void*)H_CreateSwapChain, (void**)&o_CreateSwapChain) == MH_OK && MH_EnableHook(vt[10]) == MH_OK)
            LOGI("IDXGIFactory::CreateSwapChain hooked");
        IDXGIFactory2* f2 = nullptr;
        if (SUCCEEDED(f->QueryInterface(__uuidof(IDXGIFactory2), (void**)&f2)) && f2) {
            void** v2 = *(void***)f2;
            if (MH_CreateHook(v2[15], (void*)H_CreateSwapChainForHwnd, (void**)&o_CreateSwapChainForHwnd) == MH_OK && MH_EnableHook(v2[15]) == MH_OK)
                LOGI("IDXGIFactory2::CreateSwapChainForHwnd hooked");
            f2->Release();
        }
        f->Release();
    } else LOGE("CreateDXGIFactory1 failed - no swap chain hooks");
    g_split = g_set.hudSplit == "count" ? 1 : g_set.hudSplit == "all" ? 2 : 0;
}
void UiSplitSet() { g_split = g_set.hudSplit == "count" ? 1 : g_set.hudSplit == "all" ? 2 : 0; }
// the mod's own copies go around the UI bookkeeping (a copy into the back buffer would mark its source "final")
void ModCopyResource(ID3D12GraphicsCommandList* l, ID3D12Resource* dst, ID3D12Resource* src) {
    if (o_CopyResource) o_CopyResource(l, dst, src); else l->CopyResource(dst, src);
}
