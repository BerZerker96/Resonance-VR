#pragma once
// The headset's real refresh period from what the OpenXR runtime reports (predictedDisplayPeriod). While a runtime's
// motion smoothing / ASW / SSW runs the app at a divided rate it reports the divided period (22.2 ms on a 90 Hz
// headset). PC VR headsets refresh at 72 Hz or more (60 Hz modes are rare), so a report under 66 Hz is a divided rate
// and is multiplied back: to the known full rate of this headset if it divides it, else to the nearest common VR rate.
#include <cmath>
#include <cstdint>

#include <cstring>
#include <cctype>
// the lowest rate a headset refreshes at natively, from its OpenXR system name (default 66: anything under it is a
// divided rate). Index: 80 / 90 / 120 / 144; Reverb G2, Vive Pro 2, Varjo, Bigscreen Beyond, PSVR2: 75 / 90 and up.
inline double RefreshMinNative(const char* name) {
    if (!name || !*name) return 66.0;
    char l[128]; size_t i = 0; for (; name[i] && i < sizeof l - 1; i++) l[i] = (char)tolower((unsigned char)name[i]); l[i] = 0;
    if (strstr(l, "index")) return 79.0;
    if (strstr(l, "reverb") || strstr(l, "vive pro 2") || strstr(l, "varjo") || strstr(l, "beyond") || strstr(l, "playstation vr2") || strstr(l, "psvr2")) return 74.0;
    return 66.0;
}
inline int64_t RefreshUndivide(int64_t reportedNs, int64_t knownNs, bool* divided = nullptr, double minNativeHz = 66.0) {
    if (divided) *divided = false;
    if (reportedNs <= 1000000 || reportedNs >= 100000000) return 0;   // nonsense: unknown
    double hz = 1e9 / (double)reportedNs;
    if (hz >= minNativeHz) return reportedNs;
    if (divided) *divided = true;
    static const double rates[] = { 72, 75, 80, 90, 96, 100, 110, 120, 144, 165, 180 };
    double known = knownNs > 0 ? 1e9 / (double)knownNs : 0, best = 0;
    for (int k = 2; k <= 4 && !best; k++) if (known && fabs(hz * k - known) < known * 0.03) best = known;
    for (int k = 2; k <= 4 && !best; k++) for (double c : rates) if (fabs(hz * k - c) < c * 0.02) { best = c; break; }
    if (!best) { int k = 2; while (hz * k < minNativeHz) k++; best = hz * k; }
    return (int64_t)(1e9 / best);
}
