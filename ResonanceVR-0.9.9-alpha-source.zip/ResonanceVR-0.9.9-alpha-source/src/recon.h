#pragma once
// Stereo reconstruction: one eye drawn per game frame, the other eye reconstructed from that same frame's picture and
// depth, so BOTH eyes get a new image of the SAME moment at the game's full frame rate (see recon.cpp).
#include "d3d.h"
#include <d3d11_4.h>
#include "camera.h"

namespace recon {
// ---- game threads (D3D12 command list hooks, d3d12hooks.cpp)
bool Armed();                                         // stereo reconstruction is running and a scene depth is known
void SetRaw(void* barrier, void* copyRegion, void* copyRes);   // the un-hooked list functions
ID3D12Resource* Depth();                              // the scene depth chosen at the last Present
// the game moved the scene depth out of depth-write (its depth is final): copy it now, in state `st`
void OnDepthBarrier(ID3D12GraphicsCommandList* l, ID3D12Resource* r, UINT sub, D3D12_RESOURCE_STATES before, D3D12_RESOURCE_STATES after);
// the first UI draw of the frame is about to be recorded into final image `rt` (state RENDER_TARGET): keep the
// picture without UI, and the depth if no barrier gave it yet
void OnFirstUiDraw(ID3D12GraphicsCommandList* l, ID3D12Resource* rt);
// depth candidates (a depth target bound together with colour targets): draws per frame
void TallyDepth(ID3D12Resource* r, const D3D12_RESOURCE_DESC& d, unsigned draws);
void NoteDepthUsed(ID3D12Resource* r);                // the scene depth was bound this frame (it exists)

// ---- Present thread (compositor.cpp)
void OnPresent(ID3D12Device* d12, ID3D11Device5* d11, UINT bbW, UINT bbH, DXGI_FORMAT bbFmt);   // pick the depth, (re)create copies
UINT64 NeedBForNextFrame();                           // fence B value the game queue must wait for before the next frame
// reconstruct the undrawn eye: result (RGBA16F, same encoding as the back buffer) in *out. finalTex / finalSrv = this
// frame's back buffer copy (with UI). false: not this frame (the other eye keeps its last image).
float BlitSharpen(bool centre, float& cap);
void PresentDepthCopy(ID3D12GraphicsCommandList* l);   // 0.9.3: the staged depth -> this frame's shared texture, on the mod's list at Present   // the rebuilt eyes' sharpening in the headset blit (amount; cap = the step limit)
bool Reconstruct(ID3D11DeviceContext* c, const RenderedEye& re, ID3D11Texture2D* finalTex, ID3D11ShaderResourceView* finalSrv,
                 ID3D11ShaderResourceView** out);
void AfterSignal(UINT64 fenceB);                     // the D3D11 work of this frame ends at fence B value
void Report();
void Release();
void PrepareShaders();                                // 0.7.3: compile / load the shaders in the background (first Present, any mode)
}
