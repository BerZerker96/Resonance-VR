// Proxy exports. The same DLL is built as dxgi.dll (0.6.6 default: the game loads dxgi.dll for D3D12 and the copy in
// its folder comes first), winmm.dll (Resonance.exe imports winmm.dll statically) or ResonanceVR.asi (an ASI loader: no exports).
// The real DLL of the same name is loaded from the system folder and every export jumps to it. All dxgi users in
// the process (the game and d3d11.dll itself) bind to this copy, so every export is forwarded; an export the
// system DLL does not have returns E_NOTIMPL.
#include <windows.h>
#include <string>
#include <cstring>
#include <cwctype>
#include "proxy_names.inc"


std::wstring g_proxyName;    // lower-case file name we were loaded as
HMODULE g_realDll = nullptr;
std::wstring g_chainName;     // 0.6.36: the chained dxgi (another mod) this proxy forwards to, empty = the system's

static HRESULT WINAPI NotImplemented() { return E_NOTIMPL; }
// filled at link time: an export called before ProxyLoad (a dependency's DllMain) returns E_NOTIMPL, never jumps to 0
extern "C" { FARPROC g_px[PROXY_SLOTS] = { PROXY_INIT }; }

// dxgi.dll: the game's own factory calls come through here. The mod's swap-chain hooks must be in place BEFORE the
// game's first factory makes its swap chain - as winmm.dll the mod starts with the process, as dxgi.dll only when the
// game first loads dxgi - so the first factory call installs them (here: a normal call, outside the loader lock).
void ProxyBeforeFactory();   // main.cpp
typedef HRESULT(WINAPI* PFN_F0)(REFIID, void**);
typedef HRESULT(WINAPI* PFN_F2)(UINT, REFIID, void**);
static PFN_F0 r_F = nullptr, r_F1 = nullptr; static PFN_F2 r_F2 = nullptr;
static HRESULT WINAPI W_CreateDXGIFactory(REFIID i, void** o) { ProxyBeforeFactory(); return r_F ? r_F(i, o) : E_NOTIMPL; }
static HRESULT WINAPI W_CreateDXGIFactory1(REFIID i, void** o) { ProxyBeforeFactory(); return r_F1 ? r_F1(i, o) : E_NOTIMPL; }
static HRESULT WINAPI W_CreateDXGIFactory2(UINT f, REFIID i, void** o) { ProxyBeforeFactory(); return r_F2 ? r_F2(f, i, o) : E_NOTIMPL; }

void ProxyLoad(HMODULE self) {
    wchar_t me[MAX_PATH]; GetModuleFileNameW(self, me, MAX_PATH);
    std::wstring n = me; n = n.substr(n.find_last_of(L'\\') + 1);
    for (auto& c : n) c = (wchar_t)towlower(c);
    g_proxyName = n;
    const char* const* tab = n == L"winmm.dll" ? kNames_winmm : n == L"dxgi.dll" ? kNames_dxgi : nullptr;
    for (int i = 0; i < PROXY_SLOTS; i++) g_px[i] = (FARPROC)NotImplemented;
    if (!tab) return;   // .asi or another name: no forwarding
    // 0.6.36: chain-loading. Another mod that also has to be dxgi.dll (ReShade, an ASI loader ...) is renamed
    // dxgi_chain.dll - this proxy forwards to it, it forwards to the system's.
    // Only a DLL with the dxgi factory exports, and never this file itself.
    std::wstring dir = me; dir = dir.substr(0, dir.find_last_of(L'\\') + 1);
    if (tab == kNames_dxgi) {
        // 0.6.37: only the explicit rename. ReShade64.dll is ReShade installed for Vulkan / as a layer - loading it as a
        // dxgi chain could hook the game twice; a ReShade that was dxgi.dll is renamed dxgi_chain.dll like any other
        for (const wchar_t* cn : { L"dxgi_chain.dll" }) {
            std::wstring cp = dir + cn;
            if (GetFileAttributesW(cp.c_str()) == INVALID_FILE_ATTRIBUTES) continue;
            HMODULE c = LoadLibraryW(cp.c_str());
            if (!c || c == self) continue;
            if (GetProcAddress(c, "CreateDXGIFactory2") && GetProcAddress(c, "CreateDXGIFactory1")) { g_realDll = c; g_chainName = cn; break; }
            FreeLibrary(c);
        }
    }
    if (!g_realDll) {
        wchar_t sys[MAX_PATH]; GetSystemDirectoryW(sys, MAX_PATH);
        g_realDll = LoadLibraryW((std::wstring(sys) + L"\\" + n).c_str());
    }
    if (!g_realDll) return;
    for (int i = 0; i < PROXY_SLOTS && tab[i]; i++)
        if (FARPROC p = GetProcAddress(g_realDll, tab[i])) g_px[i] = p;
    if (tab == kNames_dxgi)
        for (int i = 0; i < PROXY_SLOTS && tab[i]; i++) {
            if (!strcmp(tab[i], "CreateDXGIFactory")) { r_F = (PFN_F0)g_px[i]; g_px[i] = (FARPROC)W_CreateDXGIFactory; }
            else if (!strcmp(tab[i], "CreateDXGIFactory1")) { r_F1 = (PFN_F0)g_px[i]; g_px[i] = (FARPROC)W_CreateDXGIFactory1; }
            else if (!strcmp(tab[i], "CreateDXGIFactory2")) { r_F2 = (PFN_F2)g_px[i]; g_px[i] = (FARPROC)W_CreateDXGIFactory2; }
        }
}

#ifdef _MSC_VER
#error "build with mingw-w64 (x86_64): the stubs are GNU assembler"
#endif
// Each stub sits alone in 16 bytes: tools that hook these exports in place (Cheat Engine's speed hack patches
// timeGetTime with a 14-byte jump) must not overwrite the next export's stub.
#define PX(i) asm(".text\n.p2align 4, 0xCC\n.globl Proxy_" #i "\nProxy_" #i ":\n\tjmp *g_px+" #i "*8(%rip)\n\tint3\n");
PX(0)
PX(1)
PX(2)
PX(3)
PX(4)
PX(5)
PX(6)
PX(7)
PX(8)
PX(9)
PX(10)
PX(11)
PX(12)
PX(13)
PX(14)
PX(15)
PX(16)
PX(17)
PX(18)
PX(19)
PX(20)
PX(21)
PX(22)
PX(23)
PX(24)
PX(25)
PX(26)
PX(27)
PX(28)
PX(29)
PX(30)
PX(31)
PX(32)
PX(33)
PX(34)
PX(35)
PX(36)
PX(37)
PX(38)
PX(39)
PX(40)
PX(41)
PX(42)
PX(43)
PX(44)
PX(45)
PX(46)
PX(47)
PX(48)
PX(49)
PX(50)
PX(51)
PX(52)
PX(53)
PX(54)
PX(55)
PX(56)
PX(57)
PX(58)
PX(59)
PX(60)
PX(61)
PX(62)
PX(63)
PX(64)
PX(65)
PX(66)
PX(67)
PX(68)
PX(69)
PX(70)
PX(71)
PX(72)
PX(73)
PX(74)
PX(75)
PX(76)
PX(77)
PX(78)
PX(79)
PX(80)
PX(81)
PX(82)
PX(83)
PX(84)
PX(85)
PX(86)
PX(87)
PX(88)
PX(89)
PX(90)
PX(91)
PX(92)
PX(93)
PX(94)
PX(95)
PX(96)
PX(97)
PX(98)
PX(99)
PX(100)
PX(101)
PX(102)
PX(103)
PX(104)
PX(105)
PX(106)
PX(107)
PX(108)
PX(109)
PX(110)
PX(111)
PX(112)
PX(113)
PX(114)
PX(115)
PX(116)
PX(117)
PX(118)
PX(119)
PX(120)
PX(121)
PX(122)
PX(123)
PX(124)
PX(125)
PX(126)
PX(127)
PX(128)
PX(129)
PX(130)
PX(131)
PX(132)
PX(133)
PX(134)
PX(135)
PX(136)
PX(137)
PX(138)
PX(139)
PX(140)
PX(141)
PX(142)
PX(143)
PX(144)
PX(145)
PX(146)
PX(147)
PX(148)
PX(149)
PX(150)
PX(151)
PX(152)
PX(153)
PX(154)
PX(155)
PX(156)
PX(157)
PX(158)
PX(159)
PX(160)
PX(161)
PX(162)
PX(163)
PX(164)
PX(165)
PX(166)
PX(167)
PX(168)
PX(169)
PX(170)
PX(171)
PX(172)
PX(173)
PX(174)
PX(175)
PX(176)
PX(177)
PX(178)
PX(179)
PX(180)
PX(181)
PX(182)
PX(183)
PX(184)
PX(185)
PX(186)
PX(187)
PX(188)
PX(189)
PX(190)
PX(191)
PX(192)
PX(193)
PX(194)
PX(195)
PX(196)
PX(197)
PX(198)
PX(199)
PX(200)
PX(201)
PX(202)
PX(203)
PX(204)
PX(205)
PX(206)
PX(207)
PX(208)
