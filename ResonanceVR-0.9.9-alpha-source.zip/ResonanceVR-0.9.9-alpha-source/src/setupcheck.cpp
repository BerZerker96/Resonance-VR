// 0.6.44: SETUP CHECK - the things in a player's setup that are known to cause problems which are NOT mod bugs, said
// loudly at the top of the log and on the VR panel's status line. The tester logs of 0.6.25 - 0.6.41 spent days on
// other mods patching the game (a TAA-off mod hooking the camera-jitter function), the mod loaded through an ASI loader
// next to other mods, Oculus ASW halving the rate, a cropped field of view from the Oculus Debug Tool, DLSS / the game's
// TAA in synchronized - every one of them visible in the log, none of them said plainly. This check says them.
// It only reports: nothing is changed (the player's settings stay the player's).
#include "d3d.h"
#include <string>
#include <vector>
#include <cmath>
#include <cstdio>
#include "log.h"
#include "game.h"
#include "camera.h"
#include "settings.h"
#include "upscale.h"
#include "modtime.h"

extern std::wstring g_gameDir;
extern std::wstring g_proxyName;
extern HMODULE g_self;
extern volatile int g_scenePct;
bool FpsRuntimeSmoothing();

namespace {
std::vector<std::string> g_issues;
std::string g_last;
ULONGLONG g_lastPrint = 0;
volatile LONG g_count = 0;

std::string U8(const std::wstring& w) {
    char b[600]; WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, b, sizeof b, nullptr, nullptr); return b;
}
std::wstring Lower(std::wstring s) { for (auto& c : s) c = (wchar_t)towlower(c); return s; }
std::wstring BaseName(const std::wstring& p) { size_t k = p.find_last_of(L"\\/"); return k == std::wstring::npos ? p : p.substr(k + 1); }

// other mod files in the game folder (DLL proxies an ASI loader / other mods use, .asi files, ReShade)
std::string FolderMods() {
    static std::string cached; static bool done = false;
    if (done) return cached;
    done = true;
    wchar_t selfPath[MAX_PATH] = L""; GetModuleFileNameW(g_self, selfPath, MAX_PATH);
    std::wstring self = Lower(BaseName(selfPath));
    static const wchar_t* proxies[] = { L"dinput8.dll", L"winmm.dll", L"version.dll", L"d3d11.dll", L"d3d12.dll", L"dxgi.dll",
                                        L"xinput1_3.dll", L"xinput1_4.dll", L"dsound.dll", L"d3d9.dll", L"winhttp.dll",
                                        L"wininet.dll", L"reshade64.dll", L"dxgi_chain.dll", L"reshade.ini" };
    std::string out;
    for (const wchar_t* p : proxies) {
        if (self == p) continue;
        std::wstring f = g_gameDir + L"\\" + p;
        if (GetFileAttributesW(f.c_str()) != INVALID_FILE_ATTRIBUTES) { if (!out.empty()) out += ", "; out += U8(p); }
    }
    for (const wchar_t* dir : { L"", L"\\scripts", L"\\plugins" }) {
        WIN32_FIND_DATAW fd; std::wstring pat = g_gameDir + dir + L"\\*.asi";
        HANDLE h = FindFirstFileW(pat.c_str(), &fd);
        if (h == INVALID_HANDLE_VALUE) continue;
        do {
            std::wstring n = Lower(fd.cFileName);
            if (n == self && !*dir) continue;
            if (!out.empty()) out += ", ";
            out += U8(std::wstring(dir) + (*dir ? L"\\" : L"") + fd.cFileName);
        } while (FindNextFileW(h, &fd));
        FindClose(h);
    }
    cached = out;
    return out;
}

// DLLs loaded into the game that belong to other mods / tools / OpenXR layers
std::string LoadedMods() {
    typedef BOOL(WINAPI * PFN_Enum)(HANDLE, HMODULE*, DWORD, LPDWORD);
    static PFN_Enum en = (PFN_Enum)GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "K32EnumProcessModules");
    if (!en) return "";
    HMODULE mods[1024]; DWORD need = 0;
    if (!en(GetCurrentProcess(), mods, sizeof mods, &need)) return "";
    static const wchar_t* tags[] = { L".asi", L"reshade", L"toolkit", L"vectorxr", L"xr_apilayer", L"api_layer", L"apilayer",
                                     L"freepie", L"igcs", L"unrealunlocker", L"specialk", L"dxvk", L"fovtuning", L"fsr3", L"framegen",
                                     L"lossless", L"uevr", L"vorpx", L"real_vr", L"realvr", L"advancedconfigurator", L"resonance32", L"ultrawide" };
    std::string out;
    for (DWORD i = 0; i < need / sizeof(HMODULE) && i < 1024; i++) {
        if (mods[i] == g_self) continue;
        wchar_t p[MAX_PATH]; if (!GetModuleFileNameW(mods[i], p, MAX_PATH)) continue;
        std::wstring b = Lower(BaseName(p));
        for (const wchar_t* t : tags) if (b.find(t) != std::wstring::npos) { if (!out.empty()) out += ", "; out += U8(BaseName(p)); break; }
    }
    return out;
}

// a second copy of ResonanceVR loaded into the game (main.cpp: the copy that lost the one-instance lock leaves its path)
std::string SecondCopy() {
    wchar_t nm[64]; wsprintfW(nm, L"Local\\ResonanceVR_dup_%lu", GetCurrentProcessId());
    HANDLE fm = OpenFileMappingW(FILE_MAP_READ, FALSE, nm);
    if (!fm) return "";
    std::string s;
    if (const wchar_t* v = (const wchar_t*)MapViewOfFile(fm, FILE_MAP_READ, 0, 0, 1024)) { s = U8(v); UnmapViewOfFile(v); }
    CloseHandle(fm);
    return s.empty() ? "another copy" : s;
}

// OpenXR API layers switched on in the registry (implicit layers load into every OpenXR app: they can crop the field of
// view, change the resolution, add smoothing or overlays). DWORD 0 = enabled. Virtual Desktop's own compatibility layer
// is part of that runtime and is not counted.
std::string XrLayers() {
    std::string out;
    for (HKEY root : { HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER }) {
        HKEY k;
        if (RegOpenKeyExW(root, L"SOFTWARE\\Khronos\\OpenXR\\1\\ApiLayers\\Implicit", 0, KEY_READ | KEY_WOW64_64KEY, &k) != ERROR_SUCCESS) continue;
        for (DWORD i = 0;; i++) {
            wchar_t name[600]; DWORD nl = 600, type = 0, val = 1, vl = sizeof val;
            if (RegEnumValueW(k, i, name, &nl, nullptr, &type, (BYTE*)&val, &vl) != ERROR_SUCCESS) break;
            if (type != REG_DWORD || val != 0) continue;   // disabled
            std::wstring b = Lower(BaseName(name));
            if (b.find(L"virtualdesktop") != std::wstring::npos || b.find(L"vdxr") != std::wstring::npos) continue;
            if (!out.empty()) out += ", ";
            out += U8(BaseName(name));
        }
        RegCloseKey(k);
    }
    return out;
}

double Deg(double t) { return atan(t) * 57.2957795; }
}

int SetupIssueCount() { return (int)g_count; }

// every 10 s (compositor report); the block is printed when it changes, and every 5 minutes while there is anything
void SetupCheckReport() {
    std::vector<std::string> v;
    char b[700];
    if (FpsRuntimeSmoothing())
        v.push_back("MOTION SMOOTHING IS HALVING THE FRAME RATE (Oculus ASW / SteamVR motion smoothing / Virtual Desktop SSW): the "
                    "runtime shows every other frame invented - warped motion, the world seems to change scale. Not supported: turn it "
                    "off (Oculus: Ctrl+Numpad1 in game or the Oculus Debug Tool; SteamVR: per-app Motion Smoothing off; Virtual "
                    "Desktop: SSW off).");
    { std::string x = XrLayers(); if (!x.empty()) { snprintf(b, sizeof b, "OPENXR LAYERS SWITCHED ON: %s - they change what the headset gets (field of view, resolution, "
                                                       "smoothing, overlays). Switch them off (OpenXR API Layers GUI / the tool's own settings) before reporting.", x.c_str()); v.push_back(b); } }
    if (game::g_otherModPatchedGame)
        v.push_back("ANOTHER MOD changed the game's code (a function the mod reads is patched or hooked, or the gameplay FOV load is patched - an FOV / ultrawide patcher or "
                    "similar). ResonanceVR sets the field of view and the picture shape itself: remove the other mod / close the patcher.");
    { std::string f = FolderMods(); if (!f.empty()) { snprintf(b, sizeof b, "OTHER MOD FILES in the game folder: %s - other mods / an ASI loader / ReShade next to ResonanceVR. Test with ResonanceVR alone (dxgi.dll) before reporting.", f.c_str()); v.push_back(b); } }
    { std::string l = LoadedMods(); if (!l.empty()) { snprintf(b, sizeof b, "OTHER MODS / TOOLS LOADED into the game: %s (OpenXR layers can crop the field of view or change the frame rate).", l.c_str()); v.push_back(b); } }
    {   // 0.6.47: overlays that hook the game's rendering - known to crash / stutter with VR mods (the Steam and NVIDIA overlays
        // are common and usually fine: they are listed in the system line only)
        static const char* ov[] = { "rtsshooks64.dll", "discordhook64.dll", "graphics-hook64.dll", "igo64.dll", "overlay64.dll" };
        std::string o;
        for (const char* n : ov) if (GetModuleHandleA(n)) { if (!o.empty()) o += ", "; o += n; }
        if (!o.empty()) { snprintf(b, sizeof b, "OVERLAYS HOOKING THE GAME'S RENDERING: %s (RTSS / Afterburner, Discord, OBS game capture, EA ...) - known to "
                                   "cause crashes and stutter with VR mods; close them before reporting.", o.c_str()); v.push_back(b); }
    }
    { std::string c = SecondCopy(); if (!c.empty()) { snprintf(b, sizeof b, "ResonanceVR IS INSTALLED TWICE - a second copy was loaded and kept off: %s. Keep one (dxgi.dll).", c.c_str()); v.push_back(b); } }
    if (g_proxyName != L"dxgi.dll") { snprintf(b, sizeof b, "ResonanceVR loaded as %s (through an ASI / DLL loader), not as dxgi.dll - the install guide uses dxgi.dll.", U8(g_proxyName).c_str()); v.push_back(b); }
    if (CameraFrameIsVR() || g_cam.eyeTan[0][1] != 0.f) {
        const float* t = g_cam.eyeTan[0];
        if (t[1] > 0.f && t[2] > 0.f) {
            double h = Deg(-t[0]) + Deg(t[1]), vv = Deg(t[2]) + Deg(-t[3]);
            if (h < 75.0 || vv < 75.0) { snprintf(b, sizeof b, "CROPPED FIELD OF VIEW from the headset runtime: %.0f x %.0f deg per eye - reduced in the Oculus Debug Tool "
                                                    "(FOV-Tangent Multiplier), OpenXR Toolkit, VectorXR or the headset software. The picture is cut to it.", h, vv); v.push_back(b); }
        }
    }
    {
        upscale::Settings us = game::RenderUpscale();
        if (upscale::Any(us)) { snprintf(b, sizeof b, "GAME UPSCALING / LOWER RESOLUTION: %s - softer picture%s.", upscale::Describe(us).c_str(),
                                            upscale::Temporal(us) && (g_cam.mode == VRMODE_SYNCED || g_cam.mode == VRMODE_STEREO) ? "; DLSS is temporal: it mixes the two eyes in synchronized / alternate eye" : ""); v.push_back(b); }
        else if (g_scenePct > 0 && g_scenePct < 95) { snprintf(b, sizeof b, "THE 3D SCENE IS DRAWN AT %d %% of the eye's size (upscaled by the game).", g_scenePct); v.push_back(b); }
    }
    if (g_set.renderScale < 0.95f) { snprintf(b, sizeof b, "RENDER SCALE %.2f (render_scale) - below the headset's resolution.", g_set.renderScale); v.push_back(b); }
    {   // the game's own render settings (read from its renderer)
        game::RenderSettings rs = game::RenderSettingsRead();
        if (rs.known && rs.fg)
            v.push_back(rs.fg == 1 ? "FRAME GENERATION IS ON (DLSS Frame Generation) - invented frames, never with VR. Game options: Frame Generation off."
                                   : "FRAME GENERATION IS ON (FSR Frame Generation) - invented frames, never with VR. Game options: Frame Generation off.");
        if (rs.known && game::AaTemporal(rs.aa) && (g_cam.mode == VRMODE_SYNCED || g_cam.mode == VRMODE_STEREO)) {
            snprintf(b, sizeof b, "THE GAME'S %s IS TEMPORAL in an eye-alternating method (synchronized / alternate eye) - it blends each eye with the "
                                  "other's frame (double image, smear). Game options: Anti-aliasing FXAA or Off, or use stereo reconstruction.", game::AaName(rs.aa));
            v.push_back(b);
        }
    }
    {
        std::string s;
        if (g_set.swapEyes) s += " swap_eyes on (depth inside out);";
        if (fabsf(g_set.ipdScale - 1.f) > 0.01f) { snprintf(b, sizeof b, " ipd_scale %.2f;", g_set.ipdScale); s += b; }
        if (fabsf(g_set.worldScale - 1.f) > 0.01f) { snprintf(b, sizeof b, " world_scale %.2f;", g_set.worldScale); s += b; }
        if (g_cam.mode == VRMODE_SYNCED && g_set.syncSubmit == "each") s += " sync_submit each (eyes sent as drawn, can be a frame apart);";
        if (!s.empty()) { snprintf(b, sizeof b, "SETTINGS CHANGED FROM THE DEFAULT that change the picture:%s", s.c_str()); v.push_back(b); }
    }
    std::string all; for (auto& s : v) { all += s; all += '\n'; }
    ULONGLONG now = ModTick64();   // 0.6.52: real time (a speed hack scales GetTickCount64)
    InterlockedExchange(&g_count, (LONG)v.size());
    if (all == g_last && (v.empty() || now - g_lastPrint < 300000)) return;
    g_last = all; g_lastPrint = now; g_issues = v;
    if (v.empty()) { LOGI("SETUP CHECK: clean - ResonanceVR alone, no other mods found, full field of view, no upscaling, no motion smoothing"); return; }
    LOGE("==================================================================================================");
    LOGE("SETUP CHECK: %d PROBLEM(S) IN THIS SETUP - known to break VR, NOT ResonanceVR bugs. Fix these before reporting:", (int)v.size());
    for (size_t i = 0; i < v.size(); i++) LOGE("SETUP [%zu] %s", i + 1, v[i].c_str());
    LOGE("==================================================================================================");
}
