#include "modtime.h"
// ResonanceVR - VR for Resonance: A Plague Tale Legacy (Asobo's Zouna engine, D3D12), built on mark-mon's VR framework
// (in-process XrBridge OpenXR host, vrkit VR panel, proxy loader). Loaded as dxgi.dll (the game imports it, so the copy
// next to Resonance.exe is loaded first), winmm.dll (also imported) or ResonanceVR.asi through an ASI loader.
#include <windows.h>
#include <psapi.h>
#include <string>
#include <vector>
#include "log.h"
#include "config.h"
#include "MinHook.h"
#include "game.h"
#include "settings.h"
#include "firstperson.h"
#include "version.h"
#include <algorithm>
#include <cstdio>

void ProxyLoad(HMODULE self);
extern std::wstring g_proxyName;

std::wstring g_gameDir;      // folder of Resonance.exe
std::wstring g_modDir;       // <game>\ResonanceVR (host, logs, triggers) - or %LOCALAPPDATA%\ResonanceVR if the game folder is read-only
std::wstring g_cfgPath;      // the config file in use
std::wstring g_shotDir;      // screenshots (the game folder, or g_modDir)
HMODULE g_self = nullptr;

static LONG WINAPI CrashFilter(EXCEPTION_POINTERS* ep) {
    auto* er = ep->ExceptionRecord; auto* c = ep->ContextRecord;
    HMODULE m = nullptr; char mod[MAX_PATH] = "?";
    if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           (LPCSTR)er->ExceptionAddress, &m)) GetModuleFileNameA(m, mod, MAX_PATH);
    LOGE("CRASH code %08lx at %p (%s+%llx)", er->ExceptionCode, er->ExceptionAddress, strrchr(mod, '\\') ? strrchr(mod, '\\') + 1 : mod,
         (unsigned long long)((char*)er->ExceptionAddress - (char*)m));
    LOGE("  rax %llx rbx %llx rcx %llx rdx %llx rsi %llx rdi %llx rbp %llx rsp %llx", c->Rax, c->Rbx, c->Rcx, c->Rdx, c->Rsi, c->Rdi, c->Rbp, c->Rsp);
    uintptr_t* sp = (uintptr_t*)c->Rsp; int n = 0;
    for (int i = 0; i < 1024 && n < 16; i++) {
        if (!game::Readable(sp + i, 8)) break;
        uintptr_t v = sp[i];
        if (game::g_base && v >= game::g_base + 0x1000 && v < game::g_base + game::g_size) { LOGE("  stack+%04x exe+%llx", i * 8, (unsigned long long)(v - game::g_base)); n++; }
        else {
            HMODULE mm = nullptr;
            if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCSTR)v, &mm) && mm == g_self) {
                LOGE("  stack+%04x resonancevr+%llx", i * 8, (unsigned long long)(v - (uintptr_t)g_self)); n++;
            }
        }
    }
    LogFlushDisk();
    return EXCEPTION_CONTINUE_SEARCH;
}

void D3DHooksInstall();
bool CameraInstall();
void ModTick();
void ResolutionStart();
void SettingsApplyGame();

static DWORD WINAPI FlushThread(LPVOID) {
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);
    for (;;) { Sleep(1000); LogFlushDisk(); }
}

static bool g_gamePending = false;
// the swap-chain hooks, once: from the first game factory call (dxgi.dll proxy) or the init thread, whichever is first
static SRWLOCK g_d3dHookLock = SRWLOCK_INIT; static bool g_d3dHooked = false, g_modReady = false;
static thread_local bool t_inHookInstall = false;
static void D3DHooksOnce() {
    // re-entrant on the installing thread: the install creates a D3D12 device, and d3d12 makes a DXGI factory of its
    // own - that call comes back here through the dxgi.dll proxy (it must not wait for the lock this thread holds)
    if (t_inHookInstall) return;
    t_inHookInstall = true;
    AcquireSRWLockExclusive(&g_d3dHookLock);
    if (!g_d3dHooked) { g_d3dHooked = true; D3DHooksInstall(); extern void MouseInputInstall(); MouseInputInstall(); extern void PadInputInstall(); PadInputInstall(); }
    ReleaseSRWLockExclusive(&g_d3dHookLock);
    t_inHookInstall = false;
}
void ProxyBeforeFactory() { if (g_modReady) D3DHooksOnce(); }
static DWORD WINAPI InitThread(LPVOID) {
    D3DHooksOnce();
    if (g_gamePending) {   // a protected build may decrypt its code after the loader ran us
        DWORD t0 = (DWORD)ModTick64(); bool ok = false;
        for (int i = 0; (DWORD)ModTick64() - t0 < 120000; i++) { Sleep(50); if (game::Init(true)) { ok = true; break; } if (i & 1) ModTick(); }
        if (ok) { LOGI("game: code readable after %lu ms", (DWORD)ModTick64() - t0); SettingsApplyGame(); }
        else LOGE("game: the code never became readable - VR camera and game patches off");
        g_gamePending = false;
        if (!ok) { for (;;) { Sleep(100); ModTick(); } }
    }
    CreateThread(nullptr, 0, [](LPVOID) -> DWORD {   // another camera mod moving the same camera fights the VR pose
        Sleep(15000);
        HMODULE mods[512]; DWORD need = 0;
        if (EnumProcessModules(GetCurrentProcess(), mods, sizeof mods, &need))
            for (DWORD i = 0; i < need / sizeof(HMODULE) && i < 512; i++) {
                wchar_t n[MAX_PATH]; if (!GetModuleBaseNameW(GetCurrentProcess(), mods[i], n, MAX_PATH)) continue;
                for (wchar_t* c = n; *c; c++) *c = towlower(*c);
                if (wcsstr(n, L"headtracking") || wcsstr(n, L"opentrack") || wcsstr(n, L"cameratools") || wcsstr(n, L"igcs") || wcsstr(n, L"uuu"))
                    LOGE("CONFLICT: %ls is loaded - another camera mod also moves the game camera. Remove it while using ResonanceVR.", n);
            }
        return 0;
    }, nullptr, 0, nullptr);
    // 0.9.3 (Framework Boost 7): safe mode - every optional game hook off (video, post effects, UI scaling, UI probe, first person), for
    // "it crashes at start" reports and for a game patch that moved code the signatures still match by accident. VR itself keeps running.
    const bool safe = ConfigBool("safe_mode", false);
    if (safe) LOGW("SAFE MODE (safe_mode = true): optional game hooks off - video, post effects, UI scaling, UI probe, first person");
    if (ConfigBool("camera_hooks", true)) CameraInstall(); else LOGI("camera: hooks off (camera_hooks = false)");
    { extern void VideoInstall(); if (!safe && ConfigBool("video_hooks", true)) VideoInstall(); }
    { extern void PostFxInstall(); if (!safe && ConfigBool("postfx_hooks", true)) PostFxInstall(); }
    { extern void UiEngineInstall(); if (!safe) UiEngineInstall(); }
    { extern void UiProbeInstall(); if (!safe && ConfigBool("ui_probe", true)) UiProbeInstall(); }   // 0.6.42: counts only
    if (!safe && ConfigBool("first_person_hooks", true)) fp::Install(); else LOGI("firstperson: off (%s)", safe ? "safe mode" : "first_person_hooks = false");
    game::CompatReport();
    for (;;) { Sleep(100); ModTick(); }
}

static const char* kDefaultConfig =
    "# Resonance VR (ResonanceVR) settings. Lines: key = value. Delete this file to get the defaults back.\n"
    "# Everything here is also in the VR panel (Insert, or hold L3 + R3 on a gamepad).\n"
    "\n"
    "# recon  = 3D, stereo reconstruction: the head-centre view is drawn every frame and both eyes are rebuilt from its\n"
    "#          picture and depth - both eyes new every frame, the same moment, full frame rate, works with the game's TAA\n"
    "# synced = 3D, both eyes drawn from the SAME game tick (the game clock is held for the second eye)\n"
    "# aer    = 3D, alternate-eye rendering: one eye per game frame, every frame a new game tick\n"
    "# head   = head-tracked single image, screen = flat virtual screen. F8 cycles them.\n"
    "vr_mode = aer\n"
    "# synced: pair = the headset gets both eyes of a tick together | each = every eye as soon as it is drawn\n"
    "sync_submit = pair\n"
    "# synced: render frames behind the game clock: -1 = automatic, 0..2 = fixed\n"
    "sync_lag = -1\n"
    "# synced: the part of a game step a held (second-eye) tick still advances (0.03..1). Lower = the world stands more still\n"
    "# between the eyes, but cloth / hair physics jitter from a tiny step followed by a double one. 1 = like alternate eye\n"
    "sync_hold = 0.35\n"
    "recon_gap_reach = 132\n"
    "# recon_preset: performance (matched tiles, the fastest) | balanced (PatchMatch, 1 pass) | quality (PatchMatch, 3 passes, 4 M remembered points)\n"
    "recon_preset = performance\n"
    "# history = real remembered pixels + PatchMatch infill | patch = PatchMatch only | classic | soft | clone | stretch | scatter = older two-pass infills\n"
    "recon_fill = history\n"
    "# the previous frame's fill carried into this one (no shimmer in motion)\n"
    "# eye = one eye-size drawn view (the fastest; the outer part of each eye repeats the rim) | wide = the drawn view at the headset's pixel\n"
    "# density (native detail) | headset = the headset's pixel count (faster, softer, sharpened)\n"
    "recon_view = eye\n"
    "# eye view only: 0 = exactly one eye wide, 1 = as wide as the wide view (no rim repeat)\n"
    "recon_eye_cover = 0.50\n"
    "# where an eye sees past the drawn view's side: the rim repeated outward (no black, no stretch)\n"
    "recon_edge_fill = true\n"
    "# true = the HUD / UI is cut out of the picture and placed at each eye's own HUD position (costs more); false = it is part of the picture\n"
    "recon_hud_split = false\n"
    "# the slower two-dispatch resolve, only to compare its GPU time in the log\n"
    "recon_resolve_split = false\n"
    "# outer = with foveated rendering on, full-screen passes without a depth target are shaded at a lower rate at the lens edge | off\n"
    "fov_effects = outer\n"
    "# Performance preset + fov_mode off: the centre view is shaded at a lower rate away from both eyes' axes (variable-rate shading tier 2)\n"
    "fov_recon_auto = true\n"
    "recon_fill_steady = true\n"
    "# edge pixels follow their colour, holes inside a surface move with it (no halo, no see-through dither)\n"
    "recon_edge_pixels = true\n"
    "# metres: nothing nearer is pushed further apart (0 = off)\n"
    "recon_near_limit = 0.35\n"
    "# 0..1 sharpening of the rebuilt eyes, 0..3 blend band beside the fill, 0..1 detail kept where the matches disagree\n"
    "recon_sharpen = 0.00\n"
    "recon_infill_blend = 2.0\n"
    "recon_infill_detail = 0.50\n"
    "recon_edge_guard = 1\n"
    "recon_fast_footprint = true\n"
    "# synchronized / alternate eye: frame releases locked to the headset's frames (no judder)\n"
    "pace_lock = true\n"
    "# recon: 1 = tint the hidden areas, 2 = picture grey and the UI in colour\n"
    "recon_debug = 0\n"
    "\n"
    "# flat virtual screen while the game is paused (pause menu, settings, codex ...; photo mode stays 3D once its\n"
    "# camera moves). F6 holds the flat screen. Title, loading screens and videos (no 3D view) are always flat.\n"
    "flat_pause_menus = true\n"
    "\n"
    "# borderless window, exclusive fullscreen refused (the mod's frame pacing needs a window)\n"
    "force_windowed = true\n"
    "\n"
    "# render size: auto = the headset's recommended per-eye size and shape x render_scale - the mod sets the game's\n"
    "# render surface together with the swap chain, so the 3D itself is drawn at that size (falls back to the game's\n"
    "# own resolution by itself if a game build does not follow). game = the resolution in the game's graphics menu.\n"
    "# WxH (e.g. 2400x2400)\n"
    "render_resolution = auto\n"
    "render_scale = 1.00\n"
    "render_max_side = 8192\n"
    "\n"
    "world_scale = 1.00\n"
    "units_per_metre = 1.0\n"
    "\n"
    "# stereo\n"
    "swap_eyes = false\n"
    "# Presents between a frame's camera setup and its Present: 0 = automatic. Try 1 if both eyes look the same.\n"
    "# Presents between a frame's camera and its picture: 1 = this engine (its render thread draws one frame behind)\n"
    "aer_frame_delay = 1\n"
    "ipd_scale = 1.00\n"
    "# in-mod camera extrapolation of the newest real frame (never invented frames)\n"
    "camera_reprojection = false\n"
    "cull_margin = 1.00\n"
    "\n"
    "# camera: decoupled_pitch keeps the horizon level (your head pitches the view); offsets in metres\n"
    "decoupled_pitch = true\n"
    "# head aim: the sling / crossbow aim where you look (the view is not turned): off | always | aiming (only while LT / L2\n"
    "# or the right mouse button is held)\n"
    "head_aim = always\n"
    "head_aim_origin = eyes\n"
    "head_aim_smoothing = 0.30\n"
    "# head aim also turns the camera's look-at point (what the sling / crossbow aim reads)\n"
    "head_aim_target = true\n"
    "# game camera shake / bob filter (0 off .. 1 strong); your head is never filtered\n"
    "camera_stabilize = 0.35\n"
    "camera_offset_x = 0.00\n"
    "camera_offset_y = 0.00\n"
    "camera_offset_z = 0.00\n"
    "# rows of the camera matrix that are right, up, back (only change if head movement goes the wrong way)\n"
    "camera_axes = +0+1+2\n"
    "# the game's camera object gets the game's camera back after each eye is set up (its logic never sees your head)\n"
    "keep_game_camera = true\n"
    "\n"
    "# first person (End): the eye at the character the game camera follows (its look-at point). fp_offset_* = metres\n"
    "# from that point (right, up, forward) - first person only; camera_offset_* above are third person only.\n"
    "# fp_smooth = head bob filter (0..1), fp_max_distance: a look-at point farther away = cutscene (waits)\n"
    "first_person = false\n"
    "fp_offset_x = -0.69\n"
    "fp_offset_y = 0.25\n"
    "fp_offset_z = 0.41\n"
    "fp_smooth = 0.60\n"
    "fp_max_distance = 6.0\n"
    "\n"
    "# UI: moved onto each eye's line of sight, scaled by ui_scale, at ui_depth metres\n"
    "ui_mode = flat\n"
    "# alternate eye / synchronized: the HUD's convergence is set for the next frame's eye (only if the HUD seems behind the scene)\n"
    "ui_eye_next = false\n"
    "# alternate eye / synchronized: false = the HUD the same in both eyes, at infinity (always fuses); true = shifted per eye to ui_depth\n"
    "ui_converge = false\n"
    "ui_scale = 0.49\n"
    "ui_depth = 2.2\n"
    "ui_offset_y = 0.00\n"
    "# draws = the D3D12 draw viewports place the UI; where none is found (this game) the game's own layout does, on each\n"
    "# eye's line of sight and converged at ui_depth | engine = the game's own layout only\n"
    "ui_placement = draws\n"
    "hide_hud = false\n"
    "# where the UI starts in the final image: auto | count (after hud_scene_draws draws) | all\n"
    "hud_split = auto\n"
    "hud_scene_draws = 1\n"
    "\n"
    "# the picture-shape clamp (1.6 .. 2.33) kept open in VR - else the eye is letterboxed\n"
    "no_black_bars = true\n"
    "# the game's out-of-focus frame limiter kept off (in VR the headset software has the focus)\n"
    "# the publisher / studio logos at start skipped (the game's own -FastLaunch switch)\n"
    "skip_intro = true\n"
    "# depth of field (the out-of-focus blur): game | cutscenes (off in cutscenes - blurred shots look flat and\n"
    "# smeared in a headset) | off (never)\n"
    "depth_of_field = cutscenes\n"
    "run_in_background = true\n"
    "# post effects: true = off\n"
    "lens_distortion_off = true\n"
    "chromatic_fringe_off = true\n"
    "vignette_off = true\n"
    "film_grain_off = false\n"
    "lens_dirt_off = false\n"
    "lens_flare_off = false\n"
    "\n"
    "# frame rate: fps_unlocked = no cap at all (logged as a warning in VR); fps_limit = headset caps at the headset's own\n"
    "# refresh rate - never the half rate motion smoothing / ASW runs the app at (kept per headset in ResonanceVR\\refresh.txt)\n"
    "fps_unlocked = false\n"
    "fps_limit = headset\n"
    "# the headset's refresh rate if it is reported wrongly (0 = automatic)\n"
    "headset_refresh_hz = 0\n"
    "# synchronized / alternate eye: twice the refresh rate when the GPU has room (both eyes new every refresh)\n"
    "pair_rate = true\n"
    "# headset_smoothing: full = a fresh image every headset frame, never late (the runtime's smoothing never starts) |\n"
    "# runtime = the headset's own smoothing fills in when the game is slower | repeat = newest frame\n"
    "headset_smoothing = full\n"
    "paced_timeout_ms = 100\n"
    "vsync_off = true\n"
    "sharpen = 0.00\n"
    "# HDR output of the game is converted to SDR for the headset: auto | off | pq | scrgb (HDR off in the game is better)\n"
    "hdr_input = auto\n"
    "hdr_paper_white = 200\n"
    "# monitor: left = the left eye only (no flicker) | game = what the game draws (alternates)\n"
    "mirror = left\n"
    "# frames the CPU may queue ahead of the GPU (1-2 = freshest head pose; 0 = the game's own)\n"
    "max_frame_latency = 2\n"
    "# fixed foveated rendering (D3D12 VRS tier 2): off | quality | balanced | performance | custom\n"
    "fov_mode = off\n"
    "\n"
    "# flat screen (screen mode, loading screens, videos) and the VR menu panel\n"
    "screen_distance = 2.7\n"
    "screen_width = 3.2\n"
    "menu_distance = 0.95\n"
    "menu_panel_width = 1.10\n"
    "menu_width = 0.80\n"
    "menu_opacity = 0.8\n"
    "# screenshot (hotkey_screenshot, Delete): the left eye as the headset shows it, PNG next to Resonance.exe (headset | full)\n"
    "screenshot_view = headset\n"
    "\n"
    "# hotkeys (VR panel tab \"Hotkeys\" - bind them there by pressing the key / pad buttons): <keyboard> | <gamepad>\n"
    "# keyboard: a key, Ctrl / Shift / Alt allowed (CTRL+F1); gamepad: 1-3 buttons held together (LB+DPAD UP, LT+RT,\n"
    "# BACK+Y; any connected pad); \"none\" = unbound\n"
    "hotkey_menu = INSERT | L3+R3\n"
    "hotkey_recenter = SPACE | none\n"
    "hotkey_recenter_2 = F9 | none\n"
    "hotkey_screenshot = DELETE | none\n"
    "hotkey_flat = F6 | none\n"
    "hotkey_hud = F7 | none\n"
    "hotkey_first_person = END | none\n"
    "hotkey_vr_mode = F8 | none\n"
    "\n"
    "# troubleshooting\n"
    "camera_hooks = true\n"
    "ui_hooks = true\n"
    "xr_output = true\n"
    "# true = every optional game hook off (video, post effects, UI scaling, first person) - for a crash at start or after a game patch\n"
    "safe_mode = false\n"
    "config_version = 16\n"
    "\n"
    "# --- more settings (all in the VR panel) ---\n"
    "fov_inner = 0.60\n"
    "fov_outer = 1.00\n"
    "fov_wide = 1.25\n"
    "fov_debug = false\n"
    "panel_layers = auto\n"
    "render_density = headset\n"
    "offset_step_cm = 3\n"
    "ui_pick = 0\n"
    "recon_depth = auto\n"
    "recon_parallax = 1.00\n"
    "recon_align_h = 0.0\n"
    "recon_align_v = 0.0\n"
    "aer_align_h = 0.0\n"
    "aer_align_v = 0.0\n"
    "view_width = 1.00\n"
    "view_height = 1.00\n"
    "edge_fill = true\n"
    "# each eye image sent this much wider on every side, edge-filled - no black when the runtime turns a late picture (0 = off)\n"
    "edge_fill_margin = 0.06\n"
    "symmetric_view = true\n"
    "wide_cull = true\n"
    "ui_layers = one\n"
    "camera_settle = 0.50\n";


static void SchedulingTweaks() {
    // VR: the game window does not have focus (the headset software has it) - no EcoQoS / power throttling for it
    typedef BOOL(WINAPI * PFN_SPI)(HANDLE, int, LPVOID, DWORD);
    PFN_SPI spi = (PFN_SPI)GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "SetProcessInformation");
    struct { ULONG Version, ControlMask, StateMask; } pt = { 1, 1, 0 };
    bool eco = spi && spi(GetCurrentProcess(), 4 /* ProcessPowerThrottling */, &pt, sizeof pt);
    LOGI("cpu: power throttling %s", eco ? "off" : "unchanged");
}

// can this folder be written to? (a test file is created and deleted)
static bool DirWritable(const std::wstring& dir) {
    std::wstring t = dir + L"\\resonancevr_write_test.tmp";
    HANDLE f = CreateFileW(t.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_TEMPORARY | FILE_FLAG_DELETE_ON_CLOSE, nullptr);
    if (f == INVALID_HANDLE_VALUE) return false;
    CloseHandle(f); return true;
}
static bool WriteNewFile(const std::wstring& path, const char* text, DWORD* err) {
    HANDLE f = CreateFileW(path.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_NEW, 0, nullptr);
    if (f == INVALID_HANDLE_VALUE) { *err = GetLastError(); return false; }
    DWORD w = 0, n = (DWORD)strlen(text); BOOL ok = WriteFile(f, text, n, &w, nullptr); CloseHandle(f);
    if (!ok || w != n) { *err = GetLastError(); DeleteFileW(path.c_str()); return false; }
    return true;
}

static void Init() {
    // 0.6.25: store-agnostic paths. The mod's files live next to the game's exe (Steam, Epic, GOG, Game Pass, any
    // folder). If that folder cannot be written (e.g. an install under "Program Files" without admin rights - a common
    // Epic location), everything goes to %LOCALAPPDATA%\ResonanceVR instead, and the log says so. Before, the config was
    // silently not created there (CreateFile failed, nothing logged) and the logs were lost too.
    std::vector<wchar_t> exe(32768); GetModuleFileNameW(nullptr, exe.data(), (DWORD)exe.size());
    g_gameDir = exe.data(); g_gameDir = g_gameDir.substr(0, g_gameDir.find_last_of(L'\\'));
    bool gameWritable = DirWritable(g_gameDir);
    std::wstring local;
    { wchar_t la[MAX_PATH] = {}; DWORD n = GetEnvironmentVariableW(L"LOCALAPPDATA", la, MAX_PATH); if (n && n < MAX_PATH) local = std::wstring(la) + L"\\ResonanceVR"; }
    g_modDir = g_gameDir + L"\\ResonanceVR";
    CreateDirectoryW(g_modDir.c_str(), nullptr);
    bool modLocal = false;
    if (!DirWritable(g_modDir) && !local.empty()) { CreateDirectoryW(local.c_str(), nullptr); g_modDir = local; modLocal = true; }
    { extern void DiagRotateLogs(const std::wstring&); DiagRotateLogs(g_modDir); }   // 0.6.47: the previous run kept as *.prev.log
    LogInit((g_modDir + L"\\resonancevr.log").c_str());
    g_shotDir = gameWritable ? g_gameDir : g_modDir;
    std::wstring cfg = g_gameDir + L"\\resonancevr_config.txt";
    std::string cfgNote;
    bool exists = GetFileAttributesW(cfg.c_str()) != INVALID_FILE_ATTRIBUTES;
    if (exists && !gameWritable && !local.empty()) {
        // the shipped / existing config is read-only here: work on a copy the panel can save to
        std::wstring lc = g_modDir + L"\\resonancevr_config.txt";
        if (GetFileAttributesW(lc.c_str()) == INVALID_FILE_ATTRIBUTES) CopyFileW(cfg.c_str(), lc.c_str(), TRUE);
        cfg = lc; cfgNote = "the game folder is read-only - using a copy in %LOCALAPPDATA%\\ResonanceVR";
    } else if (!exists) {
        DWORD err = 0;
        if (WriteNewFile(cfg, kDefaultConfig, &err)) cfgNote = "not found - created with the defaults";
        else {
            std::wstring lc = g_modDir + L"\\resonancevr_config.txt";
            DWORD err2 = 0;
            if (GetFileAttributesW(lc.c_str()) != INVALID_FILE_ATTRIBUTES || WriteNewFile(lc, kDefaultConfig, &err2)) {
                cfg = lc; char b[160]; snprintf(b, sizeof b, "could not be created in the game folder (error %lu) - %s", err,
                                                 modLocal ? "using %LOCALAPPDATA%\\ResonanceVR" : "using the ResonanceVR folder"); cfgNote = b;
            } else { char b[160]; snprintf(b, sizeof b, "could not be created (errors %lu / %lu) - built-in defaults, nothing saved", err, err2); cfgNote = b; }
        }
    } else cfgNote = "found";
    g_cfgPath = cfg;
    ConfigLoad(cfg.c_str());
    // config_version: migrations only for values a later version proves wrong.
    // 10 (0.3): render_resolution auto -> game (0.3 could not make the game draw at another size).
    // 11 (0.4): render_resolution -> auto (the game's render surface now follows the swap chain); aer_frame_delay 0 -> 1
    // (the render thread draws one frame behind: every eye was paired with the next frame's camera - eyes swapped in the
    // alternating methods, the wrong head pose on every picture); swap_eyes true -> false (it only hid that).
    if (ConfigInt("config_version", 9) < 11) {
        std::string all;
        if (FILE* f = _wfopen(cfg.c_str(), L"rb")) { char b[4096]; size_t k; while ((k = fread(b, 1, sizeof b, f)) > 0) all.append(b, k); fclose(f); }
        if (!all.empty()) {
            std::string out, what; size_t pos = 0;
            while (pos < all.size()) {
                size_t e = all.find('\n', pos); if (e == std::string::npos) e = all.size();
                std::string line = all.substr(pos, e - pos); bool cr = !line.empty() && line.back() == '\r'; if (cr) line.pop_back();
                std::string t = line; t.erase(std::remove_if(t.begin(), t.end(), [](char c) { return c == ' ' || c == '\t'; }), t.end());
                if (t == "render_resolution=game") { line = "render_resolution = auto"; what += " render_resolution game -> auto;"; }
                else if (t == "aer_frame_delay=0") { line = "aer_frame_delay = 1"; what += " aer_frame_delay 0 -> 1;"; }
                else if (t == "swap_eyes=true") { line = "swap_eyes = false"; what += " swap_eyes true -> false;"; }
                else if (t == "fps_unlocked=true") { line = "fps_unlocked = false"; what += " fps_unlocked true -> false (capped at the headset's refresh: no late frames);"; }
                else if (t.rfind("config_version=", 0) == 0) line = "config_version = 11";
                out += line; if (cr) out += "\r"; if (e < all.size()) out += "\n";
                pos = e + 1;
            }
            if (FILE* f = _wfopen(cfg.c_str(), L"wb")) { fwrite(out.data(), 1, out.size(), f); fclose(f); ConfigLoad(cfg.c_str()); }
            LOGI("config: updated to config_version 11%s", what.c_str());
        }
    }
    // 12 (0.9, framework 0.6.97): the performance path. Only the values that were the old defaults move: recon_view wide -> eye,
    // recon_preset balanced -> performance, recon_infill_blend 1.0 -> 2.0. A value the player changed to anything else stays.
    if (ConfigInt("config_version", 9) < 12) {
        std::string all;
        if (FILE* f = _wfopen(cfg.c_str(), L"rb")) { char b[4096]; size_t k; while ((k = fread(b, 1, sizeof b, f)) > 0) all.append(b, k); fclose(f); }
        if (!all.empty()) {
            std::string out, what; size_t pos = 0; bool haveVer = false;
            while (pos < all.size()) {
                size_t e = all.find('\n', pos); if (e == std::string::npos) e = all.size();
                std::string line = all.substr(pos, e - pos); bool cr = !line.empty() && line.back() == '\r'; if (cr) line.pop_back();
                std::string t = line; t.erase(std::remove_if(t.begin(), t.end(), [](char c) { return c == ' ' || c == '\t'; }), t.end());
                if (t == "recon_view=wide") { line = "recon_view = eye"; what += " recon_view wide -> eye;"; }
                else if (t == "recon_preset=balanced") { line = "recon_preset = performance"; what += " recon_preset balanced -> performance;"; }
                else if (t == "recon_infill_blend=1.0" || t == "recon_infill_blend=1.00" || t == "recon_infill_blend=1") { line = "recon_infill_blend = 2.0"; what += " recon_infill_blend 1 -> 2;"; }
                else if (t.rfind("config_version=", 0) == 0) { line = "config_version = 12"; haveVer = true; }
                out += line; if (cr) out += "\r"; if (e < all.size()) out += "\n";
                pos = e + 1;
            }
            if (!haveVer) out += "\nconfig_version = 12\n";
            if (FILE* f = _wfopen(cfg.c_str(), L"wb")) { fwrite(out.data(), 1, out.size(), f); fclose(f); ConfigLoad(cfg.c_str()); }
            LOGI("config: updated to config_version 12%s", what.c_str());
        }
    }
    // 13 (0.9.3, framework 0.6.93): the HUD left in the picture by default - recon_hud_split true (the 0.9.0 - 0.9.2 default) -> false.
    if (ConfigInt("config_version", 9) < 13) {
        std::string all;
        if (FILE* f = _wfopen(cfg.c_str(), L"rb")) { char b[4096]; size_t k; while ((k = fread(b, 1, sizeof b, f)) > 0) all.append(b, k); fclose(f); }
        if (!all.empty()) {
            std::string out, what; size_t pos = 0; bool haveVer = false;
            while (pos < all.size()) {
                size_t e = all.find('\n', pos); if (e == std::string::npos) e = all.size();
                std::string line = all.substr(pos, e - pos); bool cr = !line.empty() && line.back() == '\r'; if (cr) line.pop_back();
                std::string t = line; t.erase(std::remove_if(t.begin(), t.end(), [](char c) { return c == ' ' || c == '\t'; }), t.end());
                if (t == "recon_hud_split=true") { line = "recon_hud_split = false"; what += " recon_hud_split true -> false;"; }
                else if (t.rfind("config_version=", 0) == 0) { line = "config_version = 13"; haveVer = true; }
                out += line; if (cr) out += "\r"; if (e < all.size()) out += "\n";
                pos = e + 1;
            }
            if (!haveVer) out += "\nconfig_version = 13\n";
            if (FILE* f = _wfopen(cfg.c_str(), L"wb")) { fwrite(out.data(), 1, out.size(), f); fclose(f); ConfigLoad(cfg.c_str()); }
            LOGI("config: updated to config_version 13%s", what.c_str());
        }
    }
    // 14 (0.9.6): pair_rate on - the 0.9.5 log: alternate eye / synchronized waited 8 - 11 ms of every frame in the frame cap (the GPU had room
    // for twice the rate; each eye was new only every second refresh). It is adaptive: back to the refresh rate when the GPU cannot keep up.
    if (ConfigInt("config_version", 9) < 14) {
        std::string all;
        if (FILE* f = _wfopen(cfg.c_str(), L"rb")) { char b[4096]; size_t k; while ((k = fread(b, 1, sizeof b, f)) > 0) all.append(b, k); fclose(f); }
        if (!all.empty()) {
            std::string out, what; size_t pos = 0; bool haveVer = false;
            while (pos < all.size()) {
                size_t e = all.find('\n', pos); if (e == std::string::npos) e = all.size();
                std::string line = all.substr(pos, e - pos); bool cr = !line.empty() && line.back() == '\r'; if (cr) line.pop_back();
                std::string t = line; t.erase(std::remove_if(t.begin(), t.end(), [](char c) { return c == ' ' || c == '\t'; }), t.end());
                if (t == "pair_rate=false") { line = "pair_rate = true"; what += " pair_rate false -> true;"; }
                else if (t.rfind("config_version=", 0) == 0) { line = "config_version = 14"; haveVer = true; }
                out += line; if (cr) out += "\r"; if (e < all.size()) out += "\n";
                pos = e + 1;
            }
            if (!haveVer) out += "\nconfig_version = 14\n";
            if (FILE* f = _wfopen(cfg.c_str(), L"wb")) { fwrite(out.data(), 1, out.size(), f); fclose(f); ConfigLoad(cfg.c_str()); }
            LOGI("config: updated to config_version 14%s", what.c_str());
        }
    }
    // 15 (0.9.7): ui_eye_next back off - the HUD's per-eye place was the error, not its frame (the 0.9.6 default true moves to false)
    if (ConfigInt("config_version", 9) < 15) {
        std::string all;
        if (FILE* f = _wfopen(cfg.c_str(), L"rb")) { char b[4096]; size_t k; while ((k = fread(b, 1, sizeof b, f)) > 0) all.append(b, k); fclose(f); }
        if (!all.empty()) {
            std::string out, what; size_t pos = 0; bool haveVer = false;
            while (pos < all.size()) {
                size_t e = all.find('\n', pos); if (e == std::string::npos) e = all.size();
                std::string line = all.substr(pos, e - pos); bool cr = !line.empty() && line.back() == '\r'; if (cr) line.pop_back();
                std::string t = line; t.erase(std::remove_if(t.begin(), t.end(), [](char c) { return c == ' ' || c == '\t'; }), t.end());
                if (t == "ui_eye_next=true") { line = "ui_eye_next = false"; what += " ui_eye_next true -> false;"; }
                else if (t.rfind("config_version=", 0) == 0) { line = "config_version = 15"; haveVer = true; }
                out += line; if (cr) out += "\r"; if (e < all.size()) out += "\n";
                pos = e + 1;
            }
            if (!haveVer) out += "\nconfig_version = 15\n";
            if (FILE* f = _wfopen(cfg.c_str(), L"wb")) { fwrite(out.data(), 1, out.size(), f); fclose(f); ConfigLoad(cfg.c_str()); }
            LOGI("config: updated to config_version 15%s", what.c_str());
        }
    }
    // 16 (0.9.8): symmetric view on for the eye methods - the HUD is drawn in screen space and only fuses with each eye's picture centred
    // on its own line of sight (symmetric_view false -> true once)
    if (ConfigInt("config_version", 9) < 16) {
        std::string all;
        if (FILE* f = _wfopen(cfg.c_str(), L"rb")) { char b[4096]; size_t k; while ((k = fread(b, 1, sizeof b, f)) > 0) all.append(b, k); fclose(f); }
        if (!all.empty()) {
            std::string out, what; size_t pos = 0; bool haveVer = false;
            while (pos < all.size()) {
                size_t e = all.find('\n', pos); if (e == std::string::npos) e = all.size();
                std::string line = all.substr(pos, e - pos); bool cr = !line.empty() && line.back() == '\r'; if (cr) line.pop_back();
                std::string t = line; t.erase(std::remove_if(t.begin(), t.end(), [](char c) { return c == ' ' || c == '\t'; }), t.end());
                if (t == "symmetric_view=false") { line = "symmetric_view = true"; what += " symmetric_view false -> true;"; }
                else if (t.rfind("config_version=", 0) == 0) { line = "config_version = 16"; haveVer = true; }
                out += line; if (cr) out += "\r"; if (e < all.size()) out += "\n";
                pos = e + 1;
            }
            if (!haveVer) out += "\nconfig_version = 16\n";
            if (FILE* f = _wfopen(cfg.c_str(), L"wb")) { fwrite(out.data(), 1, out.size(), f); fclose(f); ConfigLoad(cfg.c_str()); }
            LOGI("config: updated to config_version 16%s", what.c_str());
        }
    }
    char pn[64]; WideCharToMultiByte(CP_UTF8, 0, g_proxyName.c_str(), -1, pn, 64, nullptr, nullptr);
    LOGI("ResonanceVR %s loaded as %s (pid %lu)", ResonanceVR_VERSION, pn, GetCurrentProcessId());
    {   extern std::wstring g_chainName; extern HMODULE g_realDll;
        if (!g_chainName.empty()) { char c[64]; WideCharToMultiByte(CP_UTF8, 0, g_chainName.c_str(), -1, c, 64, nullptr, nullptr);
                                    LOGI("proxy: chained - dxgi calls go on to %s (another mod), then to Windows' dxgi.dll", c); }
        else if (g_proxyName == L"dxgi.dll" && !g_realDll) LOGE("proxy: the system dxgi.dll could not be loaded");
        // another copy of a dxgi-named mod in the folder that is NOT chained: say how to chain it
        if (g_proxyName != L"dxgi.dll") {
            std::wstring d = g_gameDir + L"\\dxgi.dll";
            if (GetFileAttributesW(d.c_str()) != INVALID_FILE_ATTRIBUTES)
                LOGI("proxy: a dxgi.dll is in the game folder too (another mod?) - ResonanceVR itself can be dxgi.dll and chain it: rename that one to dxgi_chain.dll");
        }
    }
    {   char a[1024], b[1024];
        WideCharToMultiByte(CP_UTF8, 0, g_gameDir.c_str(), -1, a, sizeof a, nullptr, nullptr);
        WideCharToMultiByte(CP_UTF8, 0, g_cfgPath.c_str(), -1, b, sizeof b, nullptr, nullptr);
        LOGI("files: game folder %s (%s) | config %s - %s%s", a, gameWritable ? "writable" : "READ-ONLY", b, cfgNote.c_str(),
             modLocal ? " | logs in %LOCALAPPDATA%\\ResonanceVR" : ""); }
    { extern void DiagStartup(); DiagStartup(); }   // 0.6.47: run id, system, settings that differ, crash report (diag.cpp)
    (void)CrashFilter;
    if (MH_Initialize() != MH_OK) LOGE("MH_Initialize failed");
    SettingsLoad();
    { extern void SettingsApplyCamera(); extern void XrSetMode(int); SettingsApplyCamera();
      extern int ModeFromString(const std::string&); XrSetMode(ModeFromString(g_set.vrMode)); }
    { extern void StartupInstall(); StartupInstall(); }   // before the exe's CRT reads the command line / settings
    SchedulingTweaks();
    if (game::Init()) SettingsApplyGame(); else g_gamePending = true;
    ResolutionStart();
    CreateThread(nullptr, 0, FlushThread, nullptr, 0, nullptr);
    g_modReady = true;   // from here a game factory call installs the D3D hooks itself
    CreateThread(nullptr, 0, InitThread, nullptr, 0, nullptr);
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = h;
        DisableThreadLibraryCalls(h);
        ProxyLoad(h);
        wchar_t exe[MAX_PATH]; GetModuleFileNameW(nullptr, exe, MAX_PATH);
        const wchar_t* base = wcsrchr(exe, L'\\'); base = base ? base + 1 : exe;
        // every store's game exe (Resonance.exe; a store-specific name that starts the same is accepted too)
        if (_wcsnicmp(base, L"resonance", 9) != 0 || (!wcsstr(base, L".exe") && !wcsstr(base, L".EXE"))) return TRUE;   // other processes (launcher, the VR host): proxy only
        wchar_t mx[64]; wsprintfW(mx, L"Local\\ResonanceVR_%lu", GetCurrentProcessId());
        HANDLE m = CreateMutexW(nullptr, TRUE, mx);
        if (m && GetLastError() == ERROR_ALREADY_EXISTS) {
            // 0.6.44: a second copy of ResonanceVR (e.g. dxgi.dll + an .asi): stays off, and leaves its path for the setup check
            wchar_t nm[64]; wsprintfW(nm, L"Local\\ResonanceVR_dup_%lu", GetCurrentProcessId());
            if (HANDLE fm = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0, 1024, nm))
                if (wchar_t* v = (wchar_t*)MapViewOfFile(fm, FILE_MAP_WRITE, 0, 0, 1024)) { GetModuleFileNameW(h, v, 500); }   // kept mapped
            return TRUE;
        }
        Init();
    }
    return TRUE;
}

const char* DefaultConfigText() { return kDefaultConfig; }   // 0.6.47: diag (settings that differ from the defaults)
