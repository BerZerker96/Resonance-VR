#include "modtime.h"
#include "log.h"
#include <windows.h>
#include <io.h>
#include <string>
#include <cstdlib>

// 0.9.1: the log is written by its own thread. Before, every line was fflush'ed on the thread that logged it, and the once-a-second
// FlushFileBuffers held the same lock: a slow disk or a virus scanner made the render / Present thread wait inside a log call (a
// hitch on the 10 s report). Now a log call only formats the line and appends it to a buffer under a short lock; the writer thread
// writes and flushes the file. Errors are written at once (the crash and device-lost paths call LogFlushDisk, which drains the buffer
// on the calling thread first).
static FILE* g_log = nullptr;
static CRITICAL_SECTION g_cs;       // the pending buffer
static CRITICAL_SECTION g_fileCs;   // the file
static LARGE_INTEGER g_freq, g_t0;
static std::string g_pending;
static HANDLE g_wake = nullptr;

static void Drain() {   // with g_fileCs held
    std::string out;
    EnterCriticalSection(&g_cs); out.swap(g_pending); LeaveCriticalSection(&g_cs);
    if (!out.empty() && g_log) { fwrite(out.data(), 1, out.size(), g_log); fflush(g_log); }
}
static DWORD WINAPI WriterThread(LPVOID) {
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);
    for (;;) {
        WaitForSingleObject(g_wake, 250);
        EnterCriticalSection(&g_fileCs); Drain(); LeaveCriticalSection(&g_fileCs);
    }
}
static void AtExitDrain() { if (g_log) { EnterCriticalSection(&g_fileCs); Drain(); LeaveCriticalSection(&g_fileCs); } }

void LogInit(const wchar_t* path) {
    InitializeCriticalSection(&g_cs);
    InitializeCriticalSection(&g_fileCs);
    ModQpf(&g_freq);
    ModQpc(&g_t0);
    g_log = _wfopen(path, L"w");
    g_pending.reserve(64 * 1024);
    g_wake = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    HANDLE h = g_wake ? CreateThread(nullptr, 0, WriterThread, nullptr, 0, nullptr) : nullptr;
    if (h) CloseHandle(h); else if (g_wake) { CloseHandle(g_wake); g_wake = nullptr; }   // no thread: lines are written by the caller
    atexit(AtExitDrain);
}

void LogWrite(const char* level, const char* fmt, ...) {
    if (!g_log) return;
    LARGE_INTEGER t; ModQpc(&t);
    double s = double(t.QuadPart - g_t0.QuadPart) / double(g_freq.QuadPart);
    char buf[2048];
    va_list ap; va_start(ap, fmt);
    vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    char line[2200];
    int n = snprintf(line, sizeof line, "%9.3f [%s] [%5lu] %s\n", s, level, GetCurrentThreadId(), buf);
    if (n < 0) return;
    if (n >= (int)sizeof line) n = (int)sizeof line - 1;
    EnterCriticalSection(&g_cs);
    g_pending.append(line, (size_t)n);
    size_t big = g_pending.size();
    LeaveCriticalSection(&g_cs);
    if (!g_wake) { EnterCriticalSection(&g_fileCs); Drain(); LeaveCriticalSection(&g_fileCs); return; }
    if (level[0] == 'E' || big > 32 * 1024) SetEvent(g_wake);   // errors (and a full buffer) go out at once
}

// the crash / device-lost / report paths and the once-a-second commit: drain, then commit to disk - never under the buffer's lock
void LogFlushDisk() {
    if (!g_log) return;
    // a crash on the writer thread itself may hold the file lock: wait at most 200 ms, then write anyway
    bool locked = false;
    for (int i = 0; i < 200 && !(locked = TryEnterCriticalSection(&g_fileCs) != 0); i++) Sleep(1);
    Drain();
    FlushFileBuffers((HANDLE)_get_osfhandle(_fileno(g_log)));
    if (locked) LeaveCriticalSection(&g_fileCs);
}
