// Resonance (Zouna engine) specifics: signatures, struct offsets read from the code, patches. See game.h and NOTES.md.
#include "game.h"
#include <cstdio>
#include <cstring>
#include <climits>
#include <string>
#include <vector>
#include "log.h"
#include "modtime.h"

namespace game {

uintptr_t g_base = 0;
size_t g_size = 0;
void* g_viewSetup = nullptr;
void* g_getProj = nullptr;
void* g_fovTangents = nullptr;
void* g_camUpdate = nullptr;
void* g_frameTime = nullptr;
volatile unsigned char* g_taaFlag = nullptr;
bool g_otherModPatchedGame = false;
uintptr_t g_pauseGlobal = 0;
// defaults = the 1.2.0.0 exe; every one is replaced by the value read from the code (and logged)
uintptr_t kVpCam = 0x68, kVpCamId = 0x70, kVpW = 0x20, kVpH = 0x24, kVpTanX = 0xCC, kVpTanY = 0xD0, kVpProj = 0xE0, kVpJitter = 0x120,
          kVpBlock = 0x59E0, kBlockPos = 0x450;
uintptr_t kCamComp = 0x120, kCamWorld = 0x3F0, kCamView = 0x430, kObjWorld = 0x148, kCamPos = 0x470, kCamTarget = 0x488,
          kCamNear = 0x3A0, kCamFar = 0x3A8, kCamFov = 0x3D0;
void* g_guiBeginFrame = nullptr;
uintptr_t kGuiCtx = 8, kGuiTgtW = 0x20, kGuiTgtH = 0x24;
PFN_NvgXY g_nvgTranslate = nullptr, g_nvgScale = nullptr;
uintptr_t kDt = 0x25C0, kDtRaw = 0x25C4, kTimeScale = 0x2F0, kPauseFlag = 0x10;

struct Section { uintptr_t start = 0; size_t size = 0; bool exec = false; char name[9] = {}; };
static std::vector<Section> g_secs;
static bool g_quiet = false;

bool InCode(uintptr_t a) { for (auto& s : g_secs) if (s.exec && a >= s.start && a < s.start + s.size) return true; return false; }

// 0.6.14: VirtualQuery gets slow as the game's address space fills up (the camera / menu part of the mod's time at
// Present grew from 0.6 to 5.5 ms over a session in the 0.6.13 log). Regions checked readable in the last 50 ms are
// remembered per thread (16 of them) - the same few objects are checked many times a frame.
static volatile LONG64 g_vqCalls = 0, g_vqHits = 0, g_vqTime = 0;   // g_vqTime: QPC ticks spent in VirtualQuery
// 0.6.56: regions stay remembered for 1 s (was 50 ms): the camera node, its record and the tally objects were checked
// again every few frames - ~1.5 VirtualQuery a frame on the Present thread, and VirtualQuery slows as the game's
// address space fills. A committed heap region does not go away within a second; a freed object inside it stays
// readable either way (the check never protected against that). Timed on the real clock (a speed hack can't stretch it).
static const ULONGLONG kRdKeepMs = 2000;
void ReadableStats(long long& calls, long long& hits) { calls = g_vqCalls; hits = g_vqHits; g_vqCalls = g_vqHits = 0; }
double ReadableStatsMs() {
    LARGE_INTEGER f; QueryPerformanceFrequency(&f);
    LONG64 t = InterlockedExchange64(&g_vqTime, 0);
    return f.QuadPart ? (double)t * 1000.0 / (double)f.QuadPart : 0.0;
}
// 0.9.5: a per-thread hash of readable PAGES (1024 slots, 2 s) instead of 64 ranges scanned in turn - the GUI hook checks thousands of
// widgets a second on the render thread; the 0.9.4 log had 41 655 misses in 10 s (27 ms of probes) with the 64-range cache
struct RdPage { uintptr_t pg; ULONGLONG at; };
static thread_local RdPage t_pg[1024];
bool Readable(const void* p, size_t n) {
    if (!n) n = 1;
    const char* a = (const char*)p; const char* e = a + n;
    if (e < a) return false;
    uintptr_t lo = (uintptr_t)a & ~(uintptr_t)0xFFF, last = ((uintptr_t)e - 1) & ~(uintptr_t)0xFFF;
    if (last - lo > 0x4000000) return false;   // more than 64 MB at once: not a pointer check
    ULONGLONG now = ModTick64();
    HANDLE self = GetCurrentProcess();
    bool allHit = true;
    for (uintptr_t pg = lo; pg <= last; pg += 0x1000) {
        RdPage& c = t_pg[(pg >> 12) & 1023];
        if (c.pg == pg && now - c.at <= kRdKeepMs) continue;
        allHit = false;
        g_vqCalls++;
        LARGE_INTEGER q0, q1; QueryPerformanceCounter(&q0);
        unsigned char b; SIZE_T got = 0;
        BOOL ok = ReadProcessMemory(self, (const void*)(pg < (uintptr_t)a ? (uintptr_t)a : pg), &b, 1, &got);
        QueryPerformanceCounter(&q1); InterlockedAdd64(&g_vqTime, q1.QuadPart - q0.QuadPart);
        if (!ok || got != 1) return false;
        c.pg = pg; c.at = now;
    }
    if (allHit) g_vqHits++;
    return true;
}

static void FindSections() {
    g_secs.clear();
    auto* dos = (IMAGE_DOS_HEADER*)g_base;
    auto* nt = (IMAGE_NT_HEADERS64*)(g_base + dos->e_lfanew);
    g_size = nt->OptionalHeader.SizeOfImage;
    auto* s = IMAGE_FIRST_SECTION(nt);
    for (int i = 0; i < nt->FileHeader.NumberOfSections; i++, s++) {
        Section sec; sec.start = g_base + s->VirtualAddress; sec.size = s->Misc.VirtualSize;
        sec.exec = (s->Characteristics & IMAGE_SCN_MEM_EXECUTE) != 0;
        memcpy(sec.name, s->Name, 8);
        g_secs.push_back(sec);
    }
}

// "48 8B ?? 05" pattern, ?? = any byte
static std::vector<int> Parse(const char* pattern) {
    std::vector<int> pat;
    for (const char* p = pattern; *p;) {
        while (*p == ' ') p++;
        if (!*p) break;
        if (p[0] == '?') { pat.push_back(-1); p += (p[1] == '?') ? 2 : 1; }
        else { pat.push_back((int)strtoul(p, nullptr, 16)); p += 2; }
    }
    return pat;
}
// 0.9.3 (version agnostic): a section is scanned only in its committed, readable runs (VirtualQuery per region, at start-up only) - a
// patched or re-protected exe may leave pages of a code section reserved or no-access; reading one used to be a crash at start
static void ScanRange(uintptr_t start, size_t size, const std::vector<int>& pat, std::vector<uintptr_t>& out, size_t max) {
    if (size < pat.size()) return;
    const unsigned char* b = (const unsigned char*)start;
    size_t n = size - pat.size();
    int first = pat[0];
    for (size_t i = 0; i <= n; i++) {
        if (first >= 0 && b[i] != first) continue;
        size_t k = 1;
        for (; k < pat.size(); k++) if (pat[k] >= 0 && b[i + k] != pat[k]) break;
        if (k == pat.size()) { out.push_back(start + i); if (out.size() >= max) return; }
    }
}
static void ScanSec(const Section& sec, const std::vector<int>& pat, std::vector<uintptr_t>& out, size_t max) {
    if (pat.empty() || sec.size < pat.size()) return;
    uintptr_t a = sec.start, end = sec.start + sec.size, runStart = 0;
    while (a < end) {
        MEMORY_BASIC_INFORMATION mi = {};
        if (!VirtualQuery((void*)a, &mi, sizeof mi)) break;
        uintptr_t rEnd = (uintptr_t)mi.BaseAddress + mi.RegionSize; if (rEnd > end) rEnd = end;
        bool ok = mi.State == MEM_COMMIT && !(mi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) && mi.Protect != 0;
        if (ok && !runStart) runStart = a;
        if (!ok && runStart) { ScanRange(runStart, a - runStart, pat, out, max); runStart = 0; if (out.size() >= max) return; }
        a = rEnd;
    }
    if (runStart) ScanRange(runStart, a - runStart, pat, out, max);
}
// the sections a signature is looked for in: the main code section(s) first; when a pattern is in none of them (a patch that moved the
// code into another executable section), every executable section
static void ScanSecs(const std::vector<int>& pat, std::vector<uintptr_t>& r, size_t max) {
    for (auto& s : g_secs) if (s.exec && s.size > 0x100000 && s.size < 0x10000000) { ScanSec(s, pat, r, max); if (r.size() >= max) return; }
    if (!r.empty()) return;
    for (auto& s : g_secs) if (s.exec && !(s.size > 0x100000 && s.size < 0x10000000)) { ScanSec(s, pat, r, max); if (r.size() >= max) return; }
}
// only the main code section (.shared in this exe): the protector's sections hold copies / noise
static unsigned g_sigFound = 0; static std::string g_sigMissing;
static uintptr_t ScanOne(const char* name, const char* pattern) {
    std::vector<int> pat = Parse(pattern);
    std::vector<uintptr_t> r;
    ScanSecs(pat, r, 2);
    if (g_quiet && r.size() != 1) return 0;
    if (r.size() == 1) { LOGI("sig %-24s exe+%llx", name, (unsigned long long)(r[0] - g_base)); g_sigFound++; return r[0]; }
    LOGE("sig %-24s %s - feature off", name, r.empty() ? "NOT FOUND" : "AMBIGUOUS");
    // a name with "(patched)" / "(32:9 ...)" is a second pattern for the same feature: its miss is not a missing feature on its own
    if (!strchr(name, '(')) { g_sigMissing += g_sigMissing.empty() ? "" : ", "; g_sigMissing += name; }
    return 0;
}
static uintptr_t Rip(uintptr_t insn, int dispOffset, int insnLen) { return insn + insnLen + *(int32_t*)(insn + dispOffset); }
uintptr_t Scan(const char* name, const char* pattern) { if (g_secs.empty()) FindSections(); return ScanOne(name, pattern); }
static std::vector<uintptr_t> ScanAll(const char* pattern, size_t max) {
    std::vector<int> pat = Parse(pattern);
    std::vector<uintptr_t> r;
    ScanSecs(pat, r, max);
    return r;
}

static bool WriteCode(uintptr_t at, const void* bytes, size_t n) {
    DWORD old;
    if (!VirtualProtect((void*)at, n, PAGE_EXECUTE_READWRITE, &old)) return false;
    memcpy((void*)at, bytes, n);
    VirtualProtect((void*)at, n, old, &old);
    FlushInstructionCache(GetCurrentProcess(), (void*)at, n);
    return true;
}


static uint32_t U32(uintptr_t a) { return *(const uint32_t*)a; }
static bool Bytes(uintptr_t a, const char* pattern) {   // a short pattern at a known place (checks a found function)
    std::vector<int> p = Parse(pattern);
    if (!Readable((void*)a, p.size())) return false;
    for (size_t i = 0; i < p.size(); i++) if (p[i] >= 0 && ((const unsigned char*)a)[i] != p[i]) return false;
    return true;
}
static uintptr_t Within(uintptr_t from, size_t win, const char* pattern) {   // first match inside a found function
    std::vector<int> p = Parse(pattern);
    if (!from || !Readable((void*)from, win + p.size())) return 0;
    const unsigned char* b = (const unsigned char*)from;
    for (size_t i = 0; i < win; i++) {
        size_t k = 0;
        for (; k < p.size(); k++) if (p[k] >= 0 && b[i + k] != p[k]) break;
        if (k == p.size()) return from + i;
    }
    return 0;
}
static bool SaneOff(uintptr_t v, uintptr_t lo, uintptr_t hi) { return v >= lo && v <= hi && (v & 3) == 0; }

void* CamObjectOfViewport(void* vp) {
    if (!vp || !Readable((char*)vp + kVpCam, 16)) return nullptr;
    void** h = *(void***)((char*)vp + kVpCam);
    uint32_t id = *(uint32_t*)((char*)vp + kVpCamId);
    if (!h || !Readable(h, 0x20)) return nullptr;
    if (*(uint32_t*)((char*)h + 0x1C) != id) return nullptr;
    return *h;
}
// ---- the renderer's own main viewport -----------------------------------------------------------------------------
// The renderer walks its viewport list (renderer+0xB08, next +0xCF18) once a frame and calls SetupView for each
// (exe+18BCC60). Viewport+0x40 is its slot: 0 = the player's view - only that one gets the camera update and the FOV
// tangents in that loop; slots 1..8 copy blocks from renderer+0xB20[0] (the main viewport) before their own setup;
// 9 and above are render-to-texture / UI viewports. renderer+0xB20 is the table of viewports by slot.
uintptr_t kVpIndex = 0, kRendVpTable = 0;
static uintptr_t g_rendererPtr = 0;
static void FindViewportTable() {
    uintptr_t a = ScanOne("Renderer viewport loop", "48 8B CB E8 ?? ?? ?? ?? 45 33 C0 B2 01 48 8B CB E8 ?? ?? ?? ?? 4C 8D AB ?? ?? ?? ?? 49 8B 84 24 ?? ?? ?? ?? 48 8B 38");
    uintptr_t b = ScanOne("Viewport slot", "44 8B 73 ?? 44 89 75 ?? 41 83 FE 09");
    if (!a || !b) { LOGW("game: the renderer's viewport table was not found - the main viewport is picked by size and draw count"); return; }
    if ((void*)Rip(a + 16, 1, 5) != g_viewSetup) { LOGW("game: viewport loop calls exe+%llx, not the view setup - viewport table off", (unsigned long long)(Rip(a + 16, 1, 5) - g_base)); return; }
    kRendVpTable = U32(a + 32); kVpIndex = *(const unsigned char*)(b + 3);
    LOGI("game: renderer viewport table +%llx (slot 0 = the player's view), viewport slot +%llx", (unsigned long long)kRendVpTable, (unsigned long long)kVpIndex);
}
int ViewportSlot(void* vp) {
    if (!kVpIndex || !vp || !Readable((char*)vp + kVpIndex, 4)) return -1;
    return *(int*)((char*)vp + kVpIndex);
}
void* MainViewport() {
    if (!kRendVpTable || !g_rendererPtr) return nullptr;
    char* r = *(char**)g_rendererPtr;
    if (!r || !Readable(r + kRendVpTable, 8)) return nullptr;
    void** t = *(void***)(r + kRendVpTable);
    if (!t || !Readable(t, 8)) return nullptr;
    void* vp = t[0];
    if (!vp || ViewportSlot(vp) != 0 || !Readable((char*)vp + kVpW, 8)) return nullptr;
    return vp;
}
void* CameraOfViewport(void* vp) {
    void* o = CamObjectOfViewport(vp);
    if (!o || !Readable((char*)o + kCamComp, 8)) return nullptr;
    void* c = *(void**)((char*)o + kCamComp);
    return (c && Readable((char*)c + kCamWorld, 0xA0)) ? c : nullptr;
}

bool GameHalted() {
    if (!g_pauseGlobal) return false;
    char* p = *(char**)g_pauseGlobal;
    return p && Readable(p + kPauseFlag, 1) && p[kPauseFlag] != 0;
}

// ---- black bars: the aspect clamp ------------------------------------------------------------------------------
static volatile float* g_aspMin = nullptr; static volatile float* g_aspMax = nullptr;
static uintptr_t kRefresh = 0;
bool AspectCapFound() { return g_aspMin && g_aspMax; }
static void FindAspectCap() {
    uintptr_t h = ScanOne("CapAspectRatio", "48 83 EC 28 48 8B 0D ?? ?? ?? ?? C7 05 ?? ?? ?? ?? CD CC CC 3F C7 05 ?? ?? ?? ?? 55 55 15 40");
    if (!h) h = ScanOne("CapAspectRatio (32:9 patched)", "48 83 EC 28 48 8B 0D ?? ?? ?? ?? C7 05 ?? ?? ?? ?? CD CC CC 3F C7 05 ?? ?? ?? ?? 39 8E 63 40");
    if (!h) { LOGW("blackbars: the aspect clamp was not found - VR eyes may get black bars (top / bottom)"); return; }
    uintptr_t mn = Rip(h + 11, 2, 10), mx = Rip(h + 21, 2, 10);
    g_rendererPtr = Rip(h + 4, 3, 7);
    // the handler ends with a call that sets the renderer's "re-layout" byte: C6 81 <off32> 01 C3
    uintptr_t call = Within(h + 0x20, 0x60, "48 8B 0D ?? ?? ?? ?? E8");
    if (call) { uintptr_t t = Rip(call + 7, 1, 5); if (InCode(t) && Bytes(t, "C6 81 ?? ?? ?? ?? 01 C3")) kRefresh = U32(t + 2); }
    if (!Readable((void*)mn, 8)) { LOGW("blackbars: clamp values not readable - off"); return; }
    g_aspMin = (volatile float*)mn; g_aspMax = (volatile float*)mx;
    LOGI("blackbars: picture shape clamp at exe+%llx / exe+%llx (now %.3g .. %.3g), renderer exe+%llx, re-layout +%llx",
         (unsigned long long)(mn - g_base), (unsigned long long)(mx - g_base), *g_aspMin, *g_aspMax,
         (unsigned long long)(g_rendererPtr - g_base), (unsigned long long)kRefresh);
}
void AspectCapKeepOpen(bool on) {
    if (!g_aspMin) return;
    static bool saved = false; static float sMin = 0, sMax = 0; static unsigned asks = 0;
    const float kMin = 0.2f, kMax = 8.f;
    float a = *g_aspMin, b = *g_aspMax;
    if (on) {
        if (a == kMin && b == kMax) return;
        if (!saved || a != kMin || b != kMax) { sMin = a; sMax = b; saved = true; }
        *g_aspMin = kMin; *g_aspMax = kMax;
        if (asks++ < 8) LOGI("blackbars: the game set the picture shape clamp to %.3g .. %.3g - kept open (no_black_bars)", a, b);
    } else {
        if (!saved || (a != kMin && b != kMax)) return;
        *g_aspMin = sMin; *g_aspMax = sMax; saved = false;
        LOGI("blackbars: the game's picture shape clamp %.3g .. %.3g back", sMin, sMax);
    }
    if (kRefresh && g_rendererPtr) { char* r = *(char**)g_rendererPtr; if (r && Readable(r + kRefresh, 1)) r[kRefresh] = 1; }
}

// ---- out-of-focus frame limiter -----------------------------------------------------------------------------------
static uintptr_t kFocusFlags = 0;
bool FocusLimiterFound() { return g_rendererPtr && kFocusFlags; }
static void FindFocusLimiter(uintptr_t frameTime) {
    uintptr_t a = Within(frameTime, 0x400, "48 8B 05 ?? ?? ?? ?? 48 8D BB ?? ?? ?? ?? 48 83 B8 ?? ?? ?? ?? 00 7D");
    if (!a) { LOGW("focus: the out-of-focus frame limiter check was not found - the game may slow down while its window has no focus"); return; }
    uintptr_t rp = Rip(a, 3, 7);
    if (!g_rendererPtr) g_rendererPtr = rp;
    if (rp != g_rendererPtr) { LOGW("focus: renderer pointer differs (exe+%llx / exe+%llx) - off", (unsigned long long)(rp - g_base), (unsigned long long)(g_rendererPtr - g_base)); return; }
    kFocusFlags = U32(a + 17);
    LOGI("focus: out-of-focus frame limiter = [exe+%llx]+%llx bit 63", (unsigned long long)(rp - g_base), (unsigned long long)kFocusFlags);
}
void RunInBackground(bool on) {
    if (!FocusLimiterFound()) return;
    char* r = *(char**)g_rendererPtr;
    if (!r || !Readable(r + kFocusFlags, 8)) return;
    volatile LONG64* f = (volatile LONG64*)(r + kFocusFlags);
    static int orig = -1;   // the game's own bit (from its settings)
    bool bit = *f < 0;
    if (on) {
        if (bit) { if (orig < 0) { orig = 1; LOGI("focus: the game's out-of-focus frame limiter is on - kept off (run_in_background)"); } InterlockedAnd64(f, 0x7FFFFFFFFFFFFFFFll); }
        else if (orig < 0) orig = 0;
    } else if (orig == 1 && !bit) { InterlockedOr64(f, (LONG64)0x8000000000000000ull); orig = -1; LOGI("focus: the game's out-of-focus frame limiter back on"); }
}

// ---- post effects ------------------------------------------------------------------------------------------------
static uintptr_t g_cfgPtr = 0, kCfgIdx = 0, kCfgBlockSize = 0, kCfgBlocks = 0;
static uintptr_t g_pfxOff[PFX_COUNT] = {};
static const char* kPfxName[PFX_COUNT] = { "Fringe", "LensDistortion", "Dirt", "LensFlare", "FilmGrain", "Vignette" };
static const char* kPfxNice[PFX_COUNT] = { "chromatic fringe", "lens distortion", "lens dirt", "lens flare", "film grain", "vignette" };
const char* PostFxName(int fx) { return fx >= 0 && fx < PFX_COUNT ? kPfxNice[fx] : "?"; }
bool PostFxFound(int fx) { return g_cfgPtr && fx >= 0 && fx < PFX_COUNT && g_pfxOff[fx]; }
static uintptr_t StrInData(const char* s) {   // a NUL-terminated string in a data section (with the NUL before it)
    size_t n = strlen(s) + 1;
    for (auto& sec : g_secs) {
        if (sec.exec || !Readable((void*)sec.start, 1)) continue;
        const char* b = (const char*)sec.start; const char* e = b + sec.size - n;
        for (const char* p = b + 1; p <= e; p++) if (*p == s[0] && p[-1] == 0 && !memcmp(p, s, n)) return (uintptr_t)p;
    }
    return 0;
}
static void FindPostFx() {
    uintptr_t h = ScanOne("RenderConfig", "4C 8B 05 ?? ?? ?? ?? 41 8B 80 ?? ?? ?? ?? 48 69 D0 ?? ?? ?? ?? 49 81 C0 ?? ?? ?? ?? 49 03 D0");
    if (!h) { LOGW("postfx: render config not found - the post effect switches are off"); return; }
    g_cfgPtr = Rip(h, 3, 7); kCfgIdx = U32(h + 10); kCfgBlockSize = U32(h + 17); kCfgBlocks = U32(h + 24);
    if (!SaneOff(kCfgIdx, 0x10, 0x10000) || kCfgBlockSize < 0x20 || kCfgBlockSize > 0x2000) { g_cfgPtr = 0; LOGW("postfx: render config layout not as expected - off"); return; }
    // the game's settings dump: "movzx r8d, byte [r14 + off]" right before "lea rdx, <"\t\t<Name> %d\n">"
    int ok = 0;
    for (int fx = 0; fx < PFX_COUNT; fx++) {
        char s[64]; snprintf(s, sizeof s, "\t\t%s %%d\n", kPfxName[fx]);
        uintptr_t str = StrInData(s);
        if (!str) continue;
        for (auto& sec : g_secs) {
            if (!sec.exec || sec.size < 0x100000) continue;
            const unsigned char* b = (const unsigned char*)sec.start;
            for (size_t i = 8; i + 7 < sec.size && !g_pfxOff[fx]; i++)
                if (b[i] == 0x48 && b[i + 1] == 0x8D && b[i + 2] == 0x15 && sec.start + i + 7 + *(const int32_t*)(b + i + 3) == str &&
                    b[i - 8] == 0x45 && b[i - 7] == 0x0F && b[i - 6] == 0xB6 && b[i - 5] == 0x86) {
                    uintptr_t off = *(const uint32_t*)(b + i - 4);
                    if (off < kCfgBlockSize) g_pfxOff[fx] = off;
                }
            if (g_pfxOff[fx]) break;
        }
        if (g_pfxOff[fx]) ok++;
    }
    LOGI("postfx: render config exe+%llx (preset +%llx, blocks +%llx x %llx) - %d of %d post effect switches found (fringe +%llx, lens distortion +%llx, "
         "dirt +%llx, lens flare +%llx, film grain +%llx, vignette +%llx)", (unsigned long long)(g_cfgPtr - g_base), (unsigned long long)kCfgIdx,
         (unsigned long long)kCfgBlocks, (unsigned long long)kCfgBlockSize, ok, (int)PFX_COUNT, (unsigned long long)g_pfxOff[0], (unsigned long long)g_pfxOff[1],
         (unsigned long long)g_pfxOff[2], (unsigned long long)g_pfxOff[3], (unsigned long long)g_pfxOff[4], (unsigned long long)g_pfxOff[5]);
}
void PostFxSet(int fx, int want) {
    if (!PostFxFound(fx)) return;
    static int s_orig[PFX_COUNT] = { -1, -1, -1, -1, -1, -1 }; static int s_lastWant[PFX_COUNT] = { -2, -2, -2, -2, -2, -2 };
    char* cfg = *(char**)g_cfgPtr;
    if (!cfg || !Readable(cfg + kCfgIdx, 4)) return;
    uint32_t idx = *(uint32_t*)(cfg + kCfgIdx);
    if (idx > 64) return;
    volatile unsigned char* p = (volatile unsigned char*)(cfg + kCfgBlocks + (uintptr_t)idx * kCfgBlockSize + g_pfxOff[fx]);
    if (!Readable((const void*)p, 1)) return;
    unsigned char v = *p;
    if (v > 1) { if (s_lastWant[fx] != -3) { s_lastWant[fx] = -3; LOGW("postfx: %s switch holds %u (not 0 / 1) - left alone", kPfxNice[fx], v); } return; }
    if (want == 0) {
        if (v) { s_orig[fx] = v; *p = 0; }
    } else if (s_orig[fx] >= 0) { *p = (unsigned char)s_orig[fx]; s_orig[fx] = -1; }
    if (want != s_lastWant[fx]) { s_lastWant[fx] = want; LOGI("postfx: %s %s", kPfxNice[fx], want == 0 ? "OFF" : "as the game has it"); }
}

// ---- render settings (read only) -----------------------------------------------------------------------------------
static uintptr_t kRsAa = 0, kRsDlss = 0, kRsFsr = 0, kRsFg = 0, kRsScale = 0;
static void FindRenderSettings() {
    uintptr_t a = ScanOne("RenderSettings dump", "41 8B 85 ?? ?? ?? ?? 83 C0 FB 48 8D 1D");
    if (!a) return;
    kRsAa = U32(a + 3);
    if (uintptr_t b = Within(a, 0x100, "41 0F B6 85 ?? ?? ?? ?? 4C 8D 35")) kRsDlss = U32(b + 4);
    uintptr_t f = Within(a, 0x200, "41 8B 8D ?? ?? ?? ?? 85 C9 74 ?? 83 E9 01 74 ?? 83 E9 01 74 ?? 83 E9 01");
    if (f) {
        kRsFsr = U32(f + 3);
        if (uintptr_t g = Within(f, 0x100, "41 0F B6 8D ?? ?? ?? ?? 85 C9 74 ?? 83 E9 01 74 ?? 83 F9 01 75")) kRsFg = U32(g + 4);
        if (uintptr_t h = Within(f, 0x180, "F3 41 0F 10 95 ?? ?? ?? ?? 0F 5A D2")) kRsScale = U32(h + 5);
    }
    LOGI("render settings: anti-aliasing +%llx, DLSS mode +%llx, FSR mode +%llx, frame generation +%llx, scaling +%llx (read only)",
         (unsigned long long)kRsAa, (unsigned long long)kRsDlss, (unsigned long long)kRsFsr, (unsigned long long)kRsFg, (unsigned long long)kRsScale);
}
const char* AaName(int aa) {
    switch (aa) { case 5: return "FXAA"; case 6: return "DLAA"; case 7: return "TAA"; case 8: return "DLSS"; case 9: return "DLSS ray reconstruction";
                  case 10: return "FSR"; case 11: return "PSSR"; default: return "off"; }
}
RenderSettings RenderSettingsRead() {
    RenderSettings r;
    if (!g_cfgPtr || !kRsAa) return r;
    char* c = *(char**)g_cfgPtr;
    if (!c || !Readable(c + kRsAa, 4) || (kRsScale && !Readable(c + kRsScale, 4))) return r;
    r.known = true;
    r.aa = *(int*)(c + kRsAa);
    if (kRsDlss) r.dlss = *(unsigned char*)(c + kRsDlss);
    if (kRsFsr) r.fsr = *(int*)(c + kRsFsr);
    if (kRsFg) r.fg = *(unsigned char*)(c + kRsFg);
    if (kRsScale) { float v = *(float*)(c + kRsScale); if (v > 0.1f && v <= 4.f) r.scale = v; }
    return r;
}
// the shared upscaler view (setup check, status line): DLSS / FSR from the anti-aliasing mode
upscale::Settings RenderUpscale() {
    upscale::Settings u;
    RenderSettings r = RenderSettingsRead();
    if (!r.known) return u;
    u.known = true;
    u.dlss = (r.aa == 8 || r.aa == 9) ? r.dlss + 1 : 0;
    u.fsr = r.aa == 10 ? r.fsr + 1 : 0;
    u.scale = r.scale < 0.995f ? r.scale * 100.f : 100.f;
    return u;
}

// ---- the GUI renderer (NanoVG) ------------------------------------------------------------------------------------
static void FindGui() {
    uintptr_t bf = ScanOne("nvgBeginFrame", "48 89 5C 24 08 57 48 83 EC 50 0F 29 74 24 40 33 FF 0F 29 7C 24 30 0F 28 F3 44 0F 29 44 24 20 0F 28 FA 44 0F 28 C1 89 B9");
    uintptr_t tr = ScanOne("nvgTranslate", "40 53 48 83 EC 40 48 63 81 ?? ?? ?? ?? 0F 28 05 ?? ?? ?? ?? 48 69 D8 ?? ?? ?? ?? F3 0F 11 4C 24 30 F3 0F 11 54 24 34 0F 11 44 24 20");
    uintptr_t sc = ScanOne("nvgScale", "40 53 48 83 EC 40 48 63 81 ?? ?? ?? ?? 48 69 D8 ?? ?? ?? ?? F3 0F 11 4C 24 20 F3 0F 11 54 24 2C 48 C7 44 24 24 00 00 00 00");
    if (!bf || !tr || !sc) { LOGW("gui: NanoVG not found - the UI is placed by the D3D12 hooks instead"); return; }
    uint32_t nst = U32(bf + 40);
    if (U32(tr + 9) != nst || U32(sc + 9) != nst) { LOGW("gui: NanoVG state layout differs between its functions - off"); return; }
    uintptr_t vt = VtableByRtti(".?AVGuiRendererNanoVG@GUI@@");
    if (!vt) { LOGW("gui: the NanoVG renderer class was not found (RTTI) - the UI is placed by the D3D12 hooks"); return; }
    for (int i = 1; i < 24 && !g_guiBeginFrame; i++) {
        uintptr_t f = ((uintptr_t*)vt)[i];
        if (!InCode(f) || !Readable((void*)f, 0x200)) break;
        const unsigned char* b = (const unsigned char*)f;
        for (int k = 0; k + 5 < 0x200; k++)
            if (b[k] == 0xE8 && Rip(f + k, 1, 5) == bf) {
                uintptr_t sz = Within(f, k, "66 0F 6E 53 ?? 0F 5B D2 66 0F 6E 4B ?? 0F 5B C9");
                uintptr_t cx = Within(f + k - 8, 8, "48 8B 4F ??");
                if (sz && cx) { kGuiTgtH = *(const unsigned char*)(sz + 4); kGuiTgtW = *(const unsigned char*)(sz + 12); kGuiCtx = *(const unsigned char*)(cx + 3);
                                g_guiBeginFrame = (void*)f; LOGI("gui: NanoVG renderer vtable exe+%llx slot %d = BeginFrame exe+%llx (context +%llx, target size +%llx/+%llx), nvgTranslate exe+%llx, nvgScale exe+%llx",
                                    (unsigned long long)(vt - g_base), i, (unsigned long long)(f - g_base), (unsigned long long)kGuiCtx, (unsigned long long)kGuiTgtW,
                                    (unsigned long long)kGuiTgtH, (unsigned long long)(tr - g_base), (unsigned long long)(sc - g_base)); }
                break;
            }
    }
    if (!g_guiBeginFrame) { LOGW("gui: BeginFrame of the NanoVG renderer not recognised - the UI is placed by the D3D12 hooks"); return; }
    g_nvgTranslate = (PFN_NvgXY)tr; g_nvgScale = (PFN_NvgXY)sc;
}

// ---- the display's render surface (the size the 3D and every render target are made at) ---------------------------
// exe+19005A0 gives each viewport its size: `mov rax,[vp+5700] / mov r9,[exe+39B07D8] / test / cmovne r9,rax` then
// `mov eax,[r9+1D4] -> vp+20`, `mov eax,[r9+1D8] -> vp+24`. [exe+39B07D8] is the display object; +0x1D4/+0x1D8 its
// render surface, set from the game's own resolution setting - not from the swap chain (a forced swap chain size left
// the 3D at 16:9, 0.2's log). The game resizes like every D3D12 engine: release its targets, ResizeBuffers(w, h),
// make its targets again from the surface size. The mod changes the surface in the same ResizeBuffers call where it
// changes the swap chain, so everything the game makes next has the headset's size and shape.
static uintptr_t g_displayPtr = 0, kSurfW = 0, kSurfH = 0;
static void FindDisplay() {
    uintptr_t a = ScanOne("Display surface", "48 8B 81 ?? ?? ?? ?? 4C 8B 0D ?? ?? ?? ?? 48 85 C0 4C 0F 45 C8 83 79 ?? 09");
    if (!a) { LOGW("display: the render surface was not found - the game keeps its own resolution (render_resolution auto falls back to game)"); return; }
    uintptr_t w = Within(a, 0x80, "41 8B 81 ?? ?? ?? ?? 41 89 40 20"), h = Within(a, 0x80, "41 8B 81 ?? ?? ?? ?? 41 89 40 24");
    if (!w || !h || U32(h + 3) != U32(w + 3) + 4) { LOGW("display: surface size layout not as expected - off"); return; }
    g_displayPtr = Rip(a + 7, 3, 7); kSurfW = U32(w + 3); kSurfH = U32(h + 3);
    LOGI("display: [exe+%llx] render surface +%llx/+%llx", (unsigned long long)(g_displayPtr - g_base), (unsigned long long)kSurfW, (unsigned long long)kSurfH);
}
bool DisplaySurface(unsigned& w, unsigned& h) {
    if (!g_displayPtr) return false;
    char* d = *(char**)g_displayPtr;
    if (!d || !Readable(d + kSurfW, 8)) return false;
    w = *(unsigned*)(d + kSurfW); h = *(unsigned*)(d + kSurfH);
    return w >= 64 && h >= 64 && w <= 16384 && h <= 16384;
}
bool DisplaySetSurface(unsigned fromW, unsigned fromH, unsigned toW, unsigned toH) {
    if (!g_displayPtr || !toW || !toH) return false;
    char* d = *(char**)g_displayPtr;
    if (!d || !Readable(d + kSurfW, 8)) return false;
    unsigned* sw = (unsigned*)(d + kSurfW); unsigned* sh = (unsigned*)(d + kSurfH);
    if (*sw == toW && *sh == toH) return true;
    // only the size the game itself is resizing to (or already set from it): never a surface of another size
    if (!((*sw == fromW && *sh == fromH) || (*sw == 0 && *sh == 0))) {
        static int n = 0; if (n++ < 4) LOGW("display: surface is %u x %u while the game resizes to %u x %u - left alone", *sw, *sh, fromW, fromH);
        return false;
    }
    *sw = toW; *sh = toH;
    static int n = 0; if (n++ < 8) LOGI("display: render surface %u x %u -> %u x %u (with the swap chain)", fromW, fromH, toW, toH);
    return true;
}

// ---- the GUI's widget layout (HUD scale) -----------------------------------------------------------------------------
// exe+2283F30 Widget::CalcScreenQuad(widget, float out[8], bool storeCache, bool): the widget's 4 corners in canvas
// pixels, its parents through nested calls, the result copied to its cache (+0x40) before it returns. The canvas is
// widget+0x1B8; its width / height come from the viewport table (exe+2275DC0 / exe+2275D30: renderer+0xB20[canvas+0xD4]
// +0x20 / +0x24) - the HUD is laid out in screen pixels. exe+22CB670 is the text scale (from the canvas height).
// The mod scales the OUTERMOST result about the eye's UI centre (ui.cpp): every widget once, the cache untouched.
void* g_cullBuild = nullptr;
void* g_dofPass = nullptr;
// depth of field: the pass builder starts with "blur on = 0 < params+0xC" - with it 0 the game takes its own no-DOF
// path (frees the DOF targets and returns), as in play without DOF
static void FindDof() {
    uintptr_t a = ScanOne("DepthOfField", "4C 8B F9 0F 57 C0 41 0F 2F 40 0C 0F 92 85 ?? ?? ?? ?? 8B 81 ?? ?? ?? ?? 89 44 24 ?? 80 3D ?? ?? ?? ?? 00 0F 84");
    if (!a) { LOGW("dof: the depth of field passes were not found - depth_of_field stays the game's"); return; }
    for (uintptr_t f = a; f + 0x40 > a && f > g_base; f--)
        if (Bytes(f, "48 89 54 24 ?? 55 53 56 57")) { g_dofPass = (void*)f; break; }
    if (g_dofPass) LOGI("dof: depth of field passes exe+%llx (blur amount params+0xC)", (unsigned long long)((uintptr_t)g_dofPass - g_base));
    else LOGW("dof: the start of the depth of field passes was not found - depth_of_field stays the game's");
}
void* g_guiWidgetCalc = nullptr; void* g_guiTextScale = nullptr;
PFN_GuiDim g_guiCanvasW = nullptr, g_guiCanvasH = nullptr; PFN_GuiObj g_guiCanvasOf = nullptr;
uintptr_t kGuiCanvas = 0;
// the start of the function holding `a`, from the exe's own unwind table (.pdata) - no assumed distance
static uintptr_t FuncStart(uintptr_t a) {
    if (!a || !g_base) return 0;
    auto* dos = (const IMAGE_DOS_HEADER*)g_base;
    auto* nt = (const IMAGE_NT_HEADERS64*)(g_base + dos->e_lfanew);
    const IMAGE_DATA_DIRECTORY& dd = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXCEPTION];
    if (!dd.VirtualAddress || dd.Size < sizeof(RUNTIME_FUNCTION)) return 0;
    auto* rf = (const RUNTIME_FUNCTION*)(g_base + dd.VirtualAddress);
    size_t n = dd.Size / sizeof(RUNTIME_FUNCTION);
    if (!Readable(rf, n * sizeof *rf)) return 0;
    DWORD r = (DWORD)(a - g_base);
    size_t lo = 0, hi = n;   // sorted by BeginAddress
    while (lo < hi) { size_t m = (lo + hi) / 2; if (rf[m].BeginAddress <= r) lo = m + 1; else hi = m; }
    if (!lo) return 0;
    const RUNTIME_FUNCTION* e = &rf[lo - 1];
    if (r >= e->EndAddress) return 0;
    for (int k = 0; k < 8; k++) {   // a chained entry (a split-off part): the parent function's start
        const unsigned char* ui = (const unsigned char*)(g_base + (e->UnwindData & ~1u));
        if (e->UnwindData & 1) { e = (const RUNTIME_FUNCTION*)ui; continue; }
        if (!Readable(ui, 4)) break;
        if (!(ui[0] >> 3 & 4)) break;   // UNW_FLAG_CHAININFO not set
        size_t codes = (ui[2] + 1) & ~1u;
        e = (const RUNTIME_FUNCTION*)(ui + 4 + codes * 2);
        if (!Readable(e, sizeof *e)) return 0;
    }
    return g_base + e->BeginAddress;
}
static void FindGuiLayout() {
    // found by instructions inside each function (the widget's parent / visibility test, the text scale's canvas
    // height -> float and style lookup), the start taken from the unwind table
    uintptr_t c = FuncStart(ScanOne("GUI widget layout", "33 FF 84 C0 49 0F 44 FF 48 85 FF 41 0F 95 C6 48 85 FF 74 ?? 48 8B CF E8 ?? ?? ?? ?? 48 85 C0"));
    uintptr_t t = FuncStart(ScanOne("GUI text scale", "F3 48 0F 2A F0 E8 ?? ?? ?? ?? 48 8B D8 48 85 C0 74 ?? 48 8B C8 E8 ?? ?? ?? ?? 84 C0 74 ??"));
    if (!c) { LOGW("gui: the widget layout was not found - HUD size and position by the D3D12 hooks only"); return; }
    uintptr_t m = Within(c, 0x220, "4C 8B A3 ?? ?? ?? ?? 48 85 C0");   // mov r12,[rbx+canvas] (... the parent loop)
    if (!m) m = Within(c, 0x220, "4C 8B A3 ?? ?? ?? ??");
    // the first two calls after it whose targets are the canvas size getters (movsxd rax,[rcx+slot] / test / js)
    uintptr_t fw = 0, fh = 0;
    if (m) for (uintptr_t a = m + 7; a < m + 0x90 && !fh; a++) {
        if (*(const unsigned char*)a != 0xE8) continue;
        uintptr_t f = Rip(a, 1, 5);
        if (!InCode(f) || !Bytes(f, "48 63 81 ?? ?? ?? ?? 85 C0 78")) continue;
        if (!fw) fw = f; else if (f != fw) fh = f;
        a += 4;
    }
    if (!m || !fw || !fh) { LOGW("gui: widget layout found, its canvas not recognised - off"); return; }
    kGuiCanvas = U32(m + 3);
    g_guiCanvasW = (PFN_GuiDim)fw; g_guiCanvasH = (PFN_GuiDim)fh; g_guiWidgetCalc = (void*)c;
    if (uintptr_t k = Within(t, 0x30, "48 8B F9 E8")) { g_guiCanvasOf = (PFN_GuiObj)Rip(k + 3, 1, 5); g_guiTextScale = (void*)t; }
    LOGI("gui: widget layout exe+%llx (canvas +%llx, size exe+%llx / exe+%llx), text scale %s%llx", (unsigned long long)(c - g_base), (unsigned long long)kGuiCanvas,
         (unsigned long long)(fw - g_base), (unsigned long long)(fh - g_base), g_guiTextScale ? "exe+" : "not found ", (unsigned long long)(t ? t - g_base : 0));
}

// ---- skip the intro logos ------------------------------------------------------------------------------------------
// exe+136A2DC: `if (HasCommandLineArg("-FastLaunch")) SetScriptVar(globals, "SKIP_LOGOS")` - the game's own developer
// switch for skipping the publisher / studio logos at start. The mod forces the test: `test al,al / jz` (84 C0 74 xx)
// becomes `mov al,1 / nop / nop` (B0 01 90 90). Found by the code shape and checked by BOTH strings the two `lea rdx`
// point at, so any build without exactly this switch is left alone.
static uint8_t* g_skipIntroAt = nullptr; static uint8_t g_skipIntroOrig[4];
static bool StrAt(uintptr_t a, const char* s) { size_t n = strlen(s) + 1; return Readable((void*)a, n) && !memcmp((void*)a, s, n); }
static void FindSkipIntro() {
    uintptr_t a = ScanOne("Intro logos switch", "45 33 C0 48 8D 15 ?? ?? ?? ?? 48 8D 0D ?? ?? ?? ?? E8 ?? ?? ?? ?? 84 C0 74 ?? 48 8D 15");
    if (!a) { LOGW("intro: the logo switch was not found - skip_intro off (the intro plays)"); return; }
    if (!StrAt(Rip(a + 3, 3, 7), "-FastLaunch") || !StrAt(Rip(a + 26, 3, 7), "SKIP_LOGOS")) { LOGW("intro: the logo switch does not point at -FastLaunch / SKIP_LOGOS - skip_intro off"); return; }
    g_skipIntroAt = (uint8_t*)(a + 22);
    memcpy(g_skipIntroOrig, g_skipIntroAt, 4);
    if (g_skipIntroOrig[0] == 0xB0 && g_skipIntroOrig[1] == 0x01) { g_skipIntroOrig[0] = 0x84; g_skipIntroOrig[1] = 0xC0; g_skipIntroOrig[2] = 0x74; }   // already patched (another tool)
    LOGI("intro: logo switch exe+%llx (-FastLaunch -> SKIP_LOGOS)", (unsigned long long)(a + 22 - g_base));
}
bool SkipIntroFound() { return g_skipIntroAt != nullptr; }
void SkipIntro(bool on) {
    if (!g_skipIntroAt) return;
    static int state = -1;
    if (state == (int)on) return;
    const uint8_t patch[4] = { 0xB0, 0x01, 0x90, 0x90 };
    DWORD old;
    if (!VirtualProtect(g_skipIntroAt, 4, PAGE_EXECUTE_READWRITE, &old)) { LOGW("intro: the code could not be written - the intro plays"); return; }
    memcpy(g_skipIntroAt, on ? patch : g_skipIntroOrig, 4);
    VirtualProtect(g_skipIntroAt, 4, old, &old);
    FlushInstructionCache(GetCurrentProcess(), g_skipIntroAt, 4);
    if (state >= 0 || on) LOGI("intro: %s", on ? "logos skipped at start (skip_intro)" : "the game's own logos (skip_intro off)");
    state = on;
}

// ---- the main hooks ------------------------------------------------------------------------------------------------
bool InitAt(uintptr_t base, bool quiet);
bool Init(bool quiet) { return InitAt((uintptr_t)GetModuleHandleW(nullptr), quiet); }
// tools/game_scan_test.cpp maps the exe without running it and calls this (the same code path as the game)
bool InitAt(uintptr_t base, bool quiet) {
    g_base = base;
    FindSections();
    g_quiet = quiet;
    // found by the register saves and argument moves inside it, the start from the unwind table
    uintptr_t vs = FuncStart(ScanOne("Viewport::SetupView", "44 0F 29 A8 ?? ?? ?? ?? 44 0F 29 B0 ?? ?? ?? ?? 44 0F 29 B8 ?? ?? ?? ?? 45 0F B6 F8 44 0F B6 E2"));
    if (!vs) { if (!quiet) LOGW("game: view setup not found (code not readable yet?)"); g_quiet = false; return false; }
    g_quiet = false;
    LOGI("game: Resonance.exe base %p, image %zu bytes, %zu sections", (void*)g_base, g_size, g_secs.size());
    {   // the exe's own identity for reports (link date, size)
        auto* dos = (IMAGE_DOS_HEADER*)g_base; auto* nt = (IMAGE_NT_HEADERS64*)(g_base + dos->e_lfanew);
        LOGI("game: exe link date %08lx, code %s", (unsigned long)nt->FileHeader.TimeDateStamp, g_secs.empty() ? "?" : "found");
    }
    // ---- view setup: the view block, the camera component and its matrices, the camera object's world matrix
    bool viewOk = true;
    if (uintptr_t a = Within(vs, 0x100, "48 8B F9 48 8D B1 ?? ?? ?? ?? 44 0F 10")) kVpBlock = U32(a + 6); else viewOk = false;
    if (uintptr_t a = Within(vs, 0x800, "4D 8B BD ?? ?? ?? ?? 49 8B D5 49 8B CF E8")) {
        kCamComp = U32(a + 3);
        uintptr_t th = Rip(a + 13, 1, 5);
        if (InCode(th) && Bytes(th, "48 8D 91 ?? ?? ?? ?? 48 81 C1 ?? ?? ?? ?? E9")) { kCamView = U32(th + 3); kCamWorld = U32(th + 10); }
        else viewOk = false;
    } else viewOk = false;
    if (uintptr_t a = Within(vs, 0x800, "49 8B 85 ?? ?? ?? ?? 0F 10 40 30 0F 11 86")) { kObjWorld = U32(a + 3); kBlockPos = U32(a + 14); } else viewOk = false;
    if (!SaneOff(kCamWorld, 0x100, 0x2000) || kCamView != kCamWorld + 0x40 || !SaneOff(kVpBlock, 0x100, 0x20000)) viewOk = false;
    if (viewOk) {
        g_viewSetup = (void*)vs;
        LOGI("game: view setup exe+%llx - view block +%llx (camera position +%llx), camera component +%llx: camera world +%llx, view +%llx, object world +%llx",
             (unsigned long long)(vs - g_base), (unsigned long long)kVpBlock, (unsigned long long)kBlockPos, (unsigned long long)kCamComp,
             (unsigned long long)kCamWorld, (unsigned long long)kCamView, (unsigned long long)kObjWorld);
    } else LOGE("game: the view setup's layout is not as expected on this exe - head tracking off (report this with the log)");
    // ---- projection getter
    uintptr_t gp = ScanOne("Viewport::GetProjection", "48 89 5C 24 08 57 48 81 EC ?? ?? ?? ?? 4C 8B 41 ?? 45 33 D2 8B FA 4D 8D 48 1C 4D 85 C0");
    if (gp) {
        kVpCam = *(const unsigned char*)(gp + 16);
        if (uintptr_t a = Within(gp, 0x40, "44 3B 59 ??")) kVpCamId = *(const unsigned char*)(a + 3);
        uintptr_t o = Within(gp, 0x120, "48 8D 99 ?? ?? ?? ?? C7 44 24");
        uintptr_t j = Within(gp, 0x260, "F3 44 0F 10 91 ?? ?? ?? ?? F3 44 0F 10 99");
        if (o && j) {
            kVpProj = U32(o + 3); kVpJitter = U32(j + 5);
            g_getProj = (void*)gp;
            LOGI("game: projection getter exe+%llx - camera handle +%llx/+%llx, projection +%llx, jitter +%llx", (unsigned long long)(gp - g_base),
                 (unsigned long long)kVpCam, (unsigned long long)kVpCamId, (unsigned long long)kVpProj, (unsigned long long)kVpJitter);
        } else LOGE("game: projection getter layout not as expected - the headset FOV cannot be set");
    }
    // ---- FOV tangents (culling / LOD)
    uintptr_t ft = ScanOne("Viewport::UpdateFovTangents", "40 53 48 81 EC ?? ?? ?? ?? 48 8B D9 48 8B 49 ?? 48 85 C9 75 ?? C7 83 ?? ?? ?? ?? 00 00 80 3F C7 83 ?? ?? ?? ?? 00 00 80 3F");
    if (ft) {
        uintptr_t x = Within(ft, 0x260, "F3 0F 11 BB ?? ?? ?? ?? 0F 28 FE"), y = Within(ft, 0x260, "F3 0F 11 8B ?? ?? ?? ?? 48 8B 0D");
        uintptr_t w = Within(ft, 0x100, "66 44 0F 6E 53 ?? 66 44 0F 6E 5B ??");
        if (x && y && w) {
            kVpTanX = U32(x + 4); kVpTanY = U32(y + 4); kVpW = *(const unsigned char*)(w + 5); kVpH = *(const unsigned char*)(w + 11);
            g_fovTangents = (void*)ft;
            // 0.5: the camera's FOV / near / far from the same function (they were assumed): movss xmm6,[rdi+fov] and
            // movss xmm0,[rdi+far2] / xmm3,[rdi+far] / xmm2,[rdi+near] before the projection build
            if (uintptr_t fv = Within(ft, 0x100, "F3 0F 10 B7 ?? ?? ?? ??")) kCamFov = U32(fv + 4);
            if (uintptr_t nf = Within(ft, 0x300, "F3 0F 10 87 ?? ?? ?? ?? F3 0F 10 9F ?? ?? ?? ?? F3 0F 10 97 ?? ?? ?? ??")) {
                kCamFar = U32(nf + 12); kCamNear = U32(nf + 20);
                // 0.6: the call right after those loads builds the culling frustum (exe+18F9B40: from the viewport's
                // tangents +0xCC/+0xD0 and the camera matrix, into camera+0x140) - INSIDE this function, before any hook
                // after it could widen the tangents
                if (Bytes(nf + 24, "F3 0F 11 44 24 ?? E8")) {
                    uintptr_t cb = Rip(nf + 30, 1, 5);
                    if (InCode(cb) && Bytes(cb, "48 8B C4 48 89 70 ?? 48 89 78 ?? 55")) g_cullBuild = (void*)cb;
                }
            }
            else LOGW("game: camera near / far not found in the FOV tangents - the defaults +%llx / +%llx are used", (unsigned long long)kCamNear, (unsigned long long)kCamFar);
            LOGI("game: camera FOV +%llx, near +%llx, far +%llx (read from the FOV tangents), culling frustum builder %s%llx", (unsigned long long)kCamFov,
                 (unsigned long long)kCamNear, (unsigned long long)kCamFar, g_cullBuild ? "exe+" : "NOT FOUND ", (unsigned long long)(g_cullBuild ? (uintptr_t)g_cullBuild - g_base : 0));
            LOGI("game: FOV tangents exe+%llx - tan x +%llx, tan y +%llx, viewport size +%llx/+%llx", (unsigned long long)(ft - g_base),
                 (unsigned long long)kVpTanX, (unsigned long long)kVpTanY, (unsigned long long)kVpW, (unsigned long long)kVpH);
        } else LOGW("game: FOV tangent layout not as expected - wide culling off");
    }
    // ---- the game camera's update (Camera_Z vtable slot, found by its first instructions)
    if (uintptr_t vt = VtableByRtti(".?AVCamera_Z@@")) {
        for (int i = 8; i < 48 && !g_camUpdate; i++) {
            uintptr_t f = ((uintptr_t*)vt)[i];
            if (!InCode(f)) break;
            // node world matrix -> position, then the look-at object handle: "mov rax,[rdx+objWorld] / lea r8,[rcx+pos]"
            // and "lea r9,[rbx+target] / mov eax,[rax+38] / mov [r8+8],eax / mov rcx,[rcx+handle] / test / jz"
            uintptr_t pa = Within(f, 0x20, "48 8B 82 ?? ?? ?? ?? 4C 8D 81 ?? ?? ?? ??");
            uintptr_t ta = pa ? Within(pa, 0x40, "4C 8D 8B ?? ?? ?? ?? 8B 40 38 41 89 40 08 48 8B 89 ?? ?? ?? ?? 48 85 C9 74") : 0;
            if (pa && ta && U32(pa + 3) == kObjWorld) {
                kCamPos = U32(pa + 10);
                kCamTarget = U32(ta + 3);
                g_camUpdate = (void*)f;
                LOGI("rtti: Camera_Z vtable exe+%llx, slot %d = the camera update exe+%llx (position +%llx, target +%llx)", (unsigned long long)(vt - g_base), i,
                     (unsigned long long)(f - g_base), (unsigned long long)kCamPos, (unsigned long long)kCamTarget);
            }
        }
        if (!g_camUpdate) LOGW("rtti: Camera_Z found, its update slot not recognised - head aim and first person off");
    } else LOGW("rtti: Camera_Z not found - head aim and first person off");
    // ---- game clock
    uintptr_t tm = ScanOne("Engine::UpdateFrameTime", "48 89 5C 24 18 48 89 74 24 20 57 48 83 EC ?? F3 0F 10 81 ?? ?? ?? ?? 48 8D B9 ?? ?? ?? ?? 0F 5A C0 48 8B D9");
    if (tm) {
        kDt = U32(tm + 19); kDtRaw = U32(tm + 26);
        if (uintptr_t a = Within(tm, 0x140, "48 8B 05 ?? ?? ?? ?? 80 78 ?? 00 75")) { g_pauseGlobal = Rip(a, 3, 7); kPauseFlag = *(const unsigned char*)(a + 9); }
        if (uintptr_t a = Within(tm, 0x400, "F3 0F 59 93 ?? ?? ?? ?? F3 0F 11 93")) kTimeScale = U32(a + 4);
        if (kDtRaw == kDt + 4 && SaneOff(kDt, 0x100, 0x10000)) {
            g_frameTime = (void*)tm;
            LOGI("game: frame clock exe+%llx - frame time +%llx (unscaled +%llx, time scale +%llx), pause flag %s+%llx", (unsigned long long)(tm - g_base),
                 (unsigned long long)kDt, (unsigned long long)kDtRaw, (unsigned long long)kTimeScale,
                 g_pauseGlobal ? "[exe" : "(not found)", (unsigned long long)(g_pauseGlobal ? g_pauseGlobal - g_base : 0));
        } else LOGW("game: frame clock layout not as expected - synchronized stereo works as alternate eye");
    }
    FindAspectCap();
    if (tm) FindFocusLimiter(tm);
    FindPostFx();
    FindRenderSettings();
    FindGui();
    FindViewportTable();
    FindSkipIntro();
    FindDisplay();
    FindGuiLayout();
    FindDof();
    // another mod hooked what the mod reads (the first bytes are a jmp): reported by the setup check
    for (void* f : { g_viewSetup, g_getProj, g_fovTangents, g_frameTime })
        if (f && (((const unsigned char*)f)[0] == 0xE9 || ((const unsigned char*)f)[0] == 0xFF)) g_otherModPatchedGame = true;
    // the gameplay camera's FOV load (camera behaviour +0x35C -> Camera_Z::SetFov). An external FOV patcher replaces it
    // with a load from its own value: found patched = another tool is changing the game's FOV (setup check)
    {
        bool q = g_quiet; g_quiet = true;
        uintptr_t stock = ScanOne("GameplayFov", "F3 0F 10 8B ?? ?? ?? ?? 49 8B CF E8 ?? ?? ?? ?? F3 0F 10 8B ?? ?? ?? ?? 49 8B CF E8");
        uintptr_t patched = stock ? 0 : ScanOne("GameplayFov (patched)", "F3 0F 10 8B ?? ?? ?? ?? 49 8B CF E8 ?? ?? ?? ?? F3 0F 10 0D ?? ?? ?? ?? 49 8B CF E8");
        g_quiet = q;
        if (patched) { g_otherModPatchedGame = true; LOGE("game: the gameplay FOV load at exe+%llx is PATCHED - an FOV / ultrawide patcher is running (setup check)", (unsigned long long)(patched - g_base)); }
        else if (stock) LOGI("game: gameplay FOV load exe+%llx as in the exe (no FOV patcher)", (unsigned long long)(stock - g_base));
    }
    return true;
}

static bool SecReadable(const Section& s) {
    MEMORY_BASIC_INFORMATION mi = {};
    for (uintptr_t a = s.start; a < s.start + s.size; a = (uintptr_t)mi.BaseAddress + mi.RegionSize) {
        if (!VirtualQuery((void*)a, &mi, sizeof mi)) return false;
        if (mi.State != MEM_COMMIT || (mi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) || !(mi.Protect & (PAGE_READONLY | PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE)))
            return false;
    }
    return true;
}
uintptr_t VtableByRtti(const char* typeName) {
    if (g_secs.empty()) FindSections();
    size_t n = strlen(typeName) + 1;
    for (auto& s : g_secs) {
        if (s.exec || s.size < n || !SecReadable(s)) continue;
        const char* b = (const char*)s.start; const char* e = b + s.size - n;
        for (const char* p = b; p <= e; p++) {
            if (*p != typeName[0] || memcmp(p, typeName, n)) continue;
            uintptr_t td = (uintptr_t)p - 16;
            uint32_t tdRva = (uint32_t)(td - g_base);
            for (auto& s2 : g_secs) {
                if (s2.exec || !SecReadable(s2)) continue;
                for (uintptr_t q = s2.start; q + 24 <= s2.start + s2.size; q += 4) {
                    if (*(uint32_t*)q != tdRva) continue;
                    uintptr_t col = q - 12;
                    if (col < s2.start || *(uint32_t*)col != 1 || *(uint32_t*)(col + 20) != (uint32_t)(col - g_base) || *(uint32_t*)(col + 4) != 0) continue;
                    for (auto& s3 : g_secs) {
                        if (s3.exec || !SecReadable(s3)) continue;
                        for (uintptr_t v = s3.start; v + 16 <= s3.start + s3.size; v += 8)
                            if (*(uintptr_t*)v == col) {
                                uintptr_t vt = v + 8;
                                if (InCode(*(uintptr_t*)vt)) return vt;
                            }
                    }
                }
            }
        }
    }
    return 0;
}

} // namespace game

namespace game {
// 0.9.3 (version agnostic): one line after start-up - how many of the game's code signatures matched this exe and which features are off.
// Every game hook is found by a byte pattern (never a fixed address) and every offset is read from the code it patches; a game patch that
// changes one function only turns that feature off.
void CompatReport() {
    unsigned long link = 0;
    if (g_base) { auto* dos = (IMAGE_DOS_HEADER*)g_base; link = (unsigned long)((IMAGE_NT_HEADERS64*)(g_base + dos->e_lfanew))->FileHeader.TimeDateStamp; }
    if (g_sigMissing.empty()) LOGI("COMPAT: all %u game signatures found in this exe (link date %08lx) - every feature available", g_sigFound, link);
    else LOGW("COMPAT: %u game signatures found, missing: %s (exe link date %08lx - a game patch?) - those features are off, VR and the rest of the mod "
              "run. safe_mode = true turns every optional game hook off.", g_sigFound, g_sigMissing.c_str(), link);
}
}
