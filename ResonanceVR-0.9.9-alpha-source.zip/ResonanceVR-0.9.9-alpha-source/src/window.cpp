#include "modtime.h"
// Render size and the game window.
// The game renders at the size of its swap chain, which follows its window in windowed mode (IGCS's hotsampling resizes
// the window to take screenshots above the monitor's resolution). The mod:
//   * asks the VR runtime for the headset's recommended per-eye size as early as possible (the host starts while
//     the game is still loading; the size is cached in ResonanceVR\headset.txt for the next start),
//   * picks the eye size: render_resolution auto = recommended x render_scale, reshaped by eye_aspect
//     (headset | 1:1 | 5:4 | 4:3: same height, width from the shape; the FOV is widened to match in camera.cpp),
//   * creates the swap chain at that size, keeps the window borderless at that client size (it may be larger than
//     the monitor: the window's size limit is lifted) and forces ResizeBuffers to it.
#include "d3d.h"
#include <string>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include "log.h"
#include "config.h"
#include "settings.h"
#include "camera.h"
#include "xrbridge/client.h"

extern std::wstring g_modDir;
static volatile LONG g_targetW = 0, g_targetH = 0;
static volatile bool g_targetSet = false;

void ResolutionSaveHeadset(unsigned w, unsigned h) {
    unsigned ow = 0, oh = 0;
    if (FILE* f = _wfopen((g_modDir + L"\\headset.txt").c_str(), L"r")) { if (fscanf(f, "%u %u", &ow, &oh) != 2) ow = oh = 0; fclose(f); }
    if (ow == w && oh == h) return;
    if (FILE* f = _wfopen((g_modDir + L"\\headset.txt").c_str(), L"w")) { fprintf(f, "%u %u\n", w, h); fclose(f); }
    LOGI("resolution: headset size %ux%u saved", w, h);
}
static bool CachedHeadset(unsigned& w, unsigned& h) {
    w = h = 0;
    if (FILE* f = _wfopen((g_modDir + L"\\headset.txt").c_str(), L"r")) { if (fscanf(f, "%u %u", &w, &h) != 2) w = h = 0; fclose(f); }
    return w && h;
}

static unsigned g_baseRw = 0, g_baseRh = 0; static float g_growX = 1.f, g_growY = 1.f;
static unsigned g_eyeOutW = 0, g_eyeOutH = 0;
// 0.6.9: the size of the images that go to the headset - its recommended size x render_scale, its own shape. The game
// renders a wider view (symmetric, per-axis growth); each eye is cut out of it 1:1 at this size, so the runtime gets
// square pixels at exactly the headset's resolution and aspect. It does not change with the stereo method.
bool HeadsetEyeSize(unsigned& w, unsigned& h) { w = g_eyeOutW; h = g_eyeOutH; return w >= 256 && h >= 256; }
static bool g_followGame = false;   // 0.3: set when the game's 3D did not follow the forced swap chain size
// the eye image size for a scale, with every cap (8192 a side for the shared atlas, the runtime's largest) - the same for the start-up size,
// the live APPLY and the panel's preview (framework 0.6.63: the preview must use the same caps)
static void EyeFor(unsigned rw, unsigned rh, float s, unsigned& w, unsigned& h, bool log) {
    if (!(s > 0.1f && s < 3.f)) s = 1.f;
    w = ((unsigned)(rw * s + 0.5f) + 1) & ~1u; h = ((unsigned)(rh * s + 0.5f) + 1) & ~1u;
    if (w > 8192 || h > 8192) {   // 0.9.3: the height is capped too (it was only the width)
        double k = std::min(8192.0 / w, 8192.0 / h);
        unsigned ow = w, oh = h; w = ((unsigned)(w * k)) & ~1u; h = ((unsigned)(h * k)) & ~1u;
        if (log) LOGW("resolution: eye image limited to %ux%u (8192 per side, the shared atlas's limit) - was %ux%u", w, h, ow, oh);
    }
    // 0.6.22: never above the runtime's largest per-eye image (render_scale > 1 on a high-resolution headset
    // could ask for more - its swap chains would fail and the headset would stay black); same shape
    unsigned mw = 0, mh = 0;
    if (xrb::ClientMaxEyeSize(&mw, &mh) && mw >= 256 && mh >= 256 && (w > mw || h > mh)) {
        double k = std::min((double)mw / w, (double)mh / h);
        w = ((unsigned)(w * k)) & ~1u; h = ((unsigned)(h * k)) & ~1u;
        if (log) LOGW("resolution: limited to %ux%u per eye (the runtime's largest)", w, h);
    }
}
static void ComputeTarget(unsigned rw, unsigned rh) {
    g_baseRw = rw; g_baseRh = rh;
    EyeFor(rw, rh, g_set.renderScale, g_eyeOutW, g_eyeOutH, true);
    std::string rr = g_set.renderResolution;
    unsigned w = 0, h = 0;
    if (g_followGame && rr != "game") { g_targetSet = false; return; }   // 0.3: the game does not follow a forced size (this session)
    if (rr == "game") { LOGI("resolution: the game's own window size is kept"); g_targetSet = false; return; }
    if (rr == "auto") {
        float s = g_set.renderScale; if (!(s > 0.1f && s < 3.f)) s = 1.f;
        w = (unsigned)(rw * s + 0.5f); h = (unsigned)(rh * s + 0.5f);
        LOGI("resolution: headset recommends %ux%u per eye, x %.2f", rw, rh, s);
    } else if (sscanf(rr.c_str(), "%ux%u", &w, &h) != 2) { LOGW("resolution: bad render_resolution '%s'", rr.c_str()); w = rw; h = rh; }
    const char* a = "headset";
    if (rr == "auto" && (g_growX > 1.005f || g_growY > 1.005f)) {   // a wider / taller rendered view keeps the headset's pixel density
        w = (unsigned)(w * g_growX + 0.5f); h = (unsigned)(h * g_growY + 0.5f);
        // 0.6.12: the render size gets exactly the drawn view's shape (square pixels; the engine may take its
        // sideways field of view from the window's shape) - the height follows the width
        float da = CameraDrawAspect();
        if (da > 0.2f && da < 5.f) h = (unsigned)(w / da + 0.5f);
        LOGI("resolution: rendered view %.2f x %.2f the headset's (width x height) - render size grown to match, shape %.3f", g_growX, g_growY, da);
    }
    if (rr == "auto" && g_growX <= 1.005f && g_growY <= 1.005f) { w = g_eyeOutW; h = g_eyeOutH; }   // 0.6.22: exactly the eye images' size
    unsigned maxSide = (unsigned)(g_set.renderMaxSide > 512 ? g_set.renderMaxSide : 8192);
    if (maxSide > 16384) maxSide = 16384;
    if (w > maxSide) { h = h * maxSide / w; w = maxSide; }
    if (h > maxSide) { w = w * maxSide / h; h = maxSide; }
    w = (w + 1) & ~1u; h = (h + 1) & ~1u;
    if (w < 256 || h < 256) { w = 2048; h = 2048; }
    g_targetW = w; g_targetH = h; g_targetSet = true;
    LOGI("resolution: game render size %ux%u (%s, %.2f MP)", w, h, a, w * (double)h / 1e6);
}

// called every Present: when the rendered view gets wider or narrower than the headset's (mode change: stereo
// reconstruction's shared view, head mode, cull margin), the eye image size follows so the headset keeps its density
void ResolutionFollowView() {
    // 0.6.14: the game renders at the headset's own size and shape, always. Each eye now gets its own (asymmetric)
    // frustum in the node projection the whole renderer uses, so nothing wider is needed for alternate eye /
    // synchronized; head mode and reconstruction's centre view squeeze the both-eye view into the same size.
    // 0.6.16: with one symmetric view for both eyes (the culling fix) the render grows sideways so the pixel
    // density stays the headset's; Pixel density = fixed keeps the headset's exact size instead (cheaper, softer)
    // 0.6.27: back to the headset's exact size when symmetric view is turned off again (0.6.26 only reset the growth:
    // the render stayed at the grown, wider size - 4788x2994 for 3420x2668 - until the game was restarted)
    // 0.8: stereo reconstruction's "headset size" view (recon_view = headset, framework 0.6.84): the one drawn view is the headset's pixel
    // count (render growth 1.0, ~25 % fewer pixels than the wide view); the rebuilt eyes magnify and sharpen it
    // 0.9.1: from the selected method, not the current mode - a flat pause menu / loading screen must not resize the render (a hitch each time)
    const bool reconSel = g_set.vrMode == "recon" && g_cam.reconCentre;
    const bool headsetView = g_set.reconView == "headset" && reconSel;
    // 0.9.4 (framework 49.3: render width = density x 2 hx in every case): stereo reconstruction's centre view grows to the headset's pixel
    // density whether or not "symmetric view" is on. 0.9.0 - 0.9.3 drew the eye-size view (2.899 wide) into the headset's 3420 pixels when
    // symmetric view was off (the default): 1180 px per unit instead of 1355 - every rebuilt eye magnified 1.15 x, softer than the eye modes.
    const bool reconGrow = reconSel && !headsetView;
    if ((!g_set.symmetricView && !reconGrow) || !g_baseRw || g_set.renderResolution != "auto" || g_set.renderDensity != "headset" || headsetView) {
        if (g_growX != 1.f || g_growY != 1.f) {
            g_growX = g_growY = 1.f;
            if (g_baseRw) {
                LOGI(headsetView ? "resolution: the headset's own size for the reconstruction's drawn view (recon_view = headset)"
                                 : "resolution: back to the headset's own size and shape (eye methods, symmetric view off)");
                ComputeTarget(g_baseRw, g_baseRh);
                WindowApplyTarget();
            }
        }
        return;
    }
    float gx, gy; CameraStableGrowthXY(gx, gy);   // 0.6.9: one size for every stereo method
    if (g_set.reconView == "eye" && reconSel) CameraReconEyeGrowthXY(gx, gy);   // 0.9: the eye-size view's own, smaller size
    else if (reconSel && !g_set.symmetricView) CameraDrawGrowthXY(gx, gy);       // 0.9.4: the wide centre view at the headset's density
    // 0.6.11: exact (the 2 % steps made the render size's shape differ from the picture's by up to 1 %); it only
    // changes with the headset's field of view / the eyes' angle / cull margin, not with the stereo method
    static float s_wantX = 0.f, s_wantY = 0.f; static ULONGLONG s_since = 0;
    if (fabsf(gx - g_growX) < 0.002f && fabsf(gy - g_growY) < 0.002f) { s_since = 0; return; }
    ULONGLONG now = ModTick64();
    // 0.9.1 (framework 0.6.63 rule: apply once, never on every slider step): the new size is applied once it has held for 1 s - dragging
    // "drawn view reach" or the cull margin recreated every render target every 1.5 s while the slider moved
    if (!s_since || fabsf(gx - s_wantX) > 0.002f || fabsf(gy - s_wantY) > 0.002f) { s_wantX = gx; s_wantY = gy; s_since = now; return; }
    if (now - s_since < 1000) return;
    s_since = 0;
    LOGI("resolution: rendered view %.2f x %.2f the headset's - eye image follows (headset pixel density kept)", gx, gy);
    g_growX = gx; g_growY = gy;
    ComputeTarget(g_baseRw, g_baseRh);
    WindowApplyTarget();
}

bool ResolutionTarget(unsigned& w, unsigned& h) {
    if (!g_targetSet || g_cam.mode == VRMODE_SCREEN) return false;
    w = (unsigned)g_targetW; h = (unsigned)g_targetH;
    return w && h;
}

static DWORD WINAPI HostThread(LPVOID) {
    unsigned w = 0, h = 0, cw = 0, ch = 0;
    bool cached = CachedHeadset(cw, ch);
    if (cached && !g_targetSet) ComputeTarget(cw, ch);   // the swap chain may come before the runtime answers
    bool ok = XrStartHost() && xrb::ClientWaitRecommendedSize(&w, &h, cached ? 8000 : 20000) && w && h;
    if (ok) {
        ResolutionSaveHeadset(w, h);
        LONG ow = g_targetW, oh = g_targetH;
        ComputeTarget(w, h);   // again also with the same size: the runtime's limits are known now
        if (!cached || g_targetW != ow || g_targetH != oh) WindowApplyTarget();
    } else if (!cached) {
        LOGW("resolution: the VR runtime did not report the headset size - 2048x2048 for now (start the VR software first)");
        ComputeTarget(2048, 2048); WindowApplyTarget();
    }
    return 0;
}

// 0.6.28: OpenXR is started when the GAME creates its swap chain, not when the process starts. Started from the store
// without the skip-launcher .bat, Resonance.exe can show its launcher (Play / Options) first; the VR session used to start
// right then and run behind the launcher until Play was pressed. The headset size from the last session (cached) is
// still used at once, so the game's first swap chain already has the eye size.
static volatile LONG g_hostKicked = 0;
static bool ContainsNoCase(const wchar_t* s, const wchar_t* sub) {
    if (!s || !sub) return false;
    size_t n = wcslen(sub);
    for (; *s; s++) if (_wcsnicmp(s, sub, n) == 0) return true;
    return false;
}
static bool IsLauncherWindow(HWND h) {
    if (!h) return false;
    wchar_t t[256] = {}, c[256] = {};
    GetWindowTextW(h, t, 255); GetClassNameW(h, c, 255);
    return ContainsNoCase(t, L"launcher") || ContainsNoCase(c, L"launcher");
}
bool ResolutionHostAllowed() { return g_hostKicked != 0; }
void ResolutionKickHost(HWND hwnd, const char* why) {
    if (g_hostKicked) return;
    if (IsLauncherWindow(hwnd)) {
        static bool said = false;
        if (!said) { said = true; LOGI("xr: a swap chain for the game's launcher window - VR waits until the game itself starts (Play)"); }
        return;
    }
    if (InterlockedExchange(&g_hostKicked, 1)) return;
    LOGI("xr: the game created its swap chain (%s) - starting OpenXR now", why ? why : "");
    if (g_cam.mode == VRMODE_SCREEN) { XrStartHost(); return; }
    CreateThread(nullptr, 0, HostThread, nullptr, 0, nullptr);
}

void ResolutionStart() {
    if (g_cam.mode == VRMODE_SCREEN) { LOGI("resolution: screen mode - the window is left alone (OpenXR starts with the game's swap chain)"); return; }
    unsigned cw = 0, ch = 0;
    if (CachedHeadset(cw, ch)) ComputeTarget(cw, ch);   // right away: the swap chain may come before the runtime answers
    else LOGI("resolution: no headset size from an earlier session yet - the game starts at its own size and is resized once the VR runtime answers");
    LOGI("xr: OpenXR starts when the game creates its swap chain (not in the launcher)");
}

// ---------------------------------------------------------------- window
// The game renders at the size it asks ResizeBuffers for, which it takes from its window's client area. If that is
// not the eye size, the game draws its frame at its own size and copies it into back buffers of another size - the
// picture lands in the top part of the eye image (stretched FOV, black band at the bottom) and the mismatched copy can
// end in garbage and a GPU crash. Windows (and the game itself) keep a window inside the monitor, so a 3420x2668 eye
// on a 2160-line monitor came out 3420x2153. Now, while a VR eye size is set:
//   * WM_WINDOWPOSCHANGING is set to the eye size AFTER the game's own handler too, WM_GETMINMAXINFO allows it,
//   * WM_SIZE tells the game the eye size,
//   * GetClientRect on the game window answers the eye size (what IGCS-style hotsampling relies on),
// so the game asks for - and renders at - exactly the eye size, whatever fits on the monitor.
#include "MinHook.h"
static WNDPROC g_origProc = nullptr;
static bool g_applying = false;
static volatile LONG g_clampSeen = 0;
typedef BOOL(WINAPI* PFN_GetClientRect)(HWND, LPRECT);
static PFN_GetClientRect o_GetClientRect = nullptr;
static BOOL WINAPI H_GetClientRect(HWND h, LPRECT r) {
    BOOL ok = o_GetClientRect(h, r);
    unsigned tw, th;
    if (ok && r && h && h == g_hwnd && !IsIconic(h) && ResolutionTarget(tw, th)) {
        if ((unsigned)(r->right - r->left) != tw || (unsigned)(r->bottom - r->top) != th) {
            if (InterlockedIncrement(&g_clampSeen) <= 3)
                LOGI("window: client area %ld x %ld (kept inside the monitor) - the game is told %u x %u", r->right - r->left, r->bottom - r->top, tw, th);
            r->left = 0; r->top = 0; r->right = (LONG)tw; r->bottom = (LONG)th;
        }
    }
    return ok;
}

static void ForceSizeInPos(HWND h, WINDOWPOS* p, unsigned tw, unsigned th) {
    if (p->flags & SWP_NOSIZE) return;
    RECT r = { 0, 0, (LONG)tw, (LONG)th };
    AdjustWindowRectEx(&r, (DWORD)GetWindowLongW(h, GWL_STYLE), FALSE, (DWORD)GetWindowLongW(h, GWL_EXSTYLE));
    p->cx = r.right - r.left; p->cy = r.bottom - r.top;
}
static LRESULT CALLBACK SizeProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    unsigned tw, th;
    bool vr = ResolutionTarget(tw, th);
    if (msg == WM_WINDOWPOSCHANGING && vr) ForceSizeInPos(h, (WINDOWPOS*)lp, tw, th);   // keep the client area at the eye size
    if (msg == WM_SIZE && vr && wp != SIZE_MINIMIZED) lp = MAKELPARAM(tw, th);         // what the game sizes its frame by
    if (msg == WM_MOUSEWHEEL) { extern bool MouseInputWheel(int); if (MouseInputWheel(GET_WHEEL_DELTA_WPARAM(wp))) return 0; }   // the VR panel's
    LRESULT res = CallWindowProcW(g_origProc, h, msg, wp, lp);
    if (msg == WM_WINDOWPOSCHANGING && vr) ForceSizeInPos(h, (WINDOWPOS*)lp, tw, th);   // ... after the game's own handler too
    if (msg == WM_GETMINMAXINFO) {
        auto* mm = (MINMAXINFO*)lp;
        mm->ptMaxTrackSize.x = mm->ptMaxSize.x = 16384;
        mm->ptMaxTrackSize.y = mm->ptMaxSize.y = 16384;
    }
    return res;
}

void WindowHook(HWND h) {
    if (!h || g_hwnd == h) return;
    g_hwnd = h;
    g_origProc = (WNDPROC)SetWindowLongPtrW(h, GWLP_WNDPROC, (LONG_PTR)SizeProc);
    if (!o_GetClientRect) {
        void* f = (void*)GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetClientRect");
        if (f && MH_CreateHook(f, (void*)H_GetClientRect, (void**)&o_GetClientRect) == MH_OK && MH_EnableHook(f) == MH_OK) LOGI("window: GetClientRect hooked");
        else o_GetClientRect = (PFN_GetClientRect)f;
    }
    RECT rc; o_GetClientRect(h, &rc);
    LOGI("window %p: client %ld x %ld", (void*)h, rc.right, rc.bottom);
}

// borderless, client area = eye size. Asynchronous: the window's own thread may be the one waiting on us.
void WindowApplyTarget() {
    unsigned tw, th;
    if (!g_hwnd || !ResolutionTarget(tw, th)) return;
    RECT rc; (o_GetClientRect ? o_GetClientRect : GetClientRect)(g_hwnd, &rc);
    LONG st = GetWindowLongW(g_hwnd, GWL_STYLE);
    bool styled = (st & WS_POPUP) && !(st & (WS_CAPTION | WS_THICKFRAME));
    if (styled && rc.right == (LONG)tw && rc.bottom == (LONG)th) return;
    g_applying = true;
    st &= ~(WS_CAPTION | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU);
    st |= WS_POPUP;
    SetWindowLongW(g_hwnd, GWL_STYLE, st);
    SetWindowPos(g_hwnd, nullptr, 0, 0, (int)tw, (int)th, SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED | SWP_ASYNCWINDOWPOS);
    g_applying = false;
    LOGI("window: borderless %u x %u (was %ld x %ld)", tw, th, rc.right, rc.bottom);
}

// 0.3: the player's viewport is drawn at another size than the back buffer (camera.cpp, after 90 VR frames). Zouna
// draws its 3D at its own render surface's size - the game's resolution setting (the display object, exe+19005A0) -
// whatever size the swap chain is forced to. A forced size then only puts the picture in a corner of a bigger back
// buffer. The mod stops forcing the size for this session and gives the window back, so the game's next resize
// (its own size) goes through untouched; the eyes are cut from what the game really draws.
void ResolutionGameSizeMismatch(unsigned vw, unsigned vh, unsigned bw, unsigned bh) {
    static bool once = false;
    if (once) return;
    once = true;
    if (!g_targetSet) {
        LOGE("resolution: the game draws its 3D at %u x %u into a %u x %u back buffer - another tool resizes the swap chain? Eye images and stereo reconstruction need them equal.", vw, vh, bw, bh);
        return;
    }
    LOGE("resolution: the game draws its 3D at %u x %u (its own resolution setting), not at the forced %u x %u - the forced size is dropped for this session, "
         "the game renders at its own size. Set render_resolution = game, and pick the game's resolution in its graphics menu (higher = sharper in the headset).", vw, vh, bw, bh);
    g_followGame = true; g_targetSet = false;
    if (g_hwnd) SetWindowPos(g_hwnd, nullptr, 0, 0, (int)vw, (int)vh, SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED | SWP_ASYNCWINDOWPOS);
}

// 0.9.3 (Framework Boost 1): every 10 s - the runtime's recommended size rechecked (SteamVR's resolution slider, Pimax / Virtual Desktop
// quality changes mid-game), then the whole resolution chain in one line: RESOLUTION CHECK
void ResolutionReport() {
    if (!xrb::ClientHostConnected()) return;
    unsigned rw = 0, rh = 0;
    if (xrb::ClientRecommendedSize(&rw, &rh) && rw && rh && g_baseRw && (rw != g_baseRw || rh != g_baseRh) && !g_followGame) {
        LOGI("resolution: the runtime now recommends %ux%u per eye (was %ux%u) - followed", rw, rh, g_baseRw, g_baseRh);
        ResolutionSaveHeadset(rw, rh);
        ComputeTarget(rw, rh);
        WindowApplyTarget();
    }
    unsigned mw = 0, mh = 0; xrb::ClientMaxEyeSize(&mw, &mh);
    RECT rc = {}; if (g_hwnd) (o_GetClientRect ? o_GetClientRect : GetClientRect)(g_hwnd, &rc);
    HMONITOR mon = g_hwnd ? MonitorFromWindow(g_hwnd, MONITOR_DEFAULTTONEAREST) : nullptr;
    MONITORINFO mi = { sizeof mi }; if (mon) GetMonitorInfoW(mon, &mi);
    UINT dpi = 96; const char* aware = "unknown";
    {
        typedef UINT(WINAPI* PFN_Dpi)(HWND); typedef DPI_AWARENESS_CONTEXT(WINAPI* PFN_Ctx)(HWND); typedef DPI_AWARENESS(WINAPI* PFN_Aw)(DPI_AWARENESS_CONTEXT);
        HMODULE u = GetModuleHandleW(L"user32.dll");
        auto fd = u ? (PFN_Dpi)GetProcAddress(u, "GetDpiForWindow") : nullptr;
        auto fc = u ? (PFN_Ctx)GetProcAddress(u, "GetWindowDpiAwarenessContext") : nullptr;
        auto fa = u ? (PFN_Aw)GetProcAddress(u, "GetAwarenessFromDpiAwarenessContext") : nullptr;
        if (fd && g_hwnd) dpi = fd(g_hwnd);
        if (fc && fa && g_hwnd) { DPI_AWARENESS a = fa(fc(g_hwnd)); aware = a == DPI_AWARENESS_PER_MONITOR_AWARE ? "per-monitor" : a == DPI_AWARENESS_SYSTEM_AWARE ? "system" : a == DPI_AWARENESS_UNAWARE ? "unaware" : "unknown"; }
    }
    float sc = g_set.renderScale; if (!(sc > 0.1f && sc < 3.f)) sc = 1.f;
    LOGI("RESOLUTION CHECK: headset %ux%u (runtime largest %ux%u) x render scale %.2f -> eye images %ux%u | game renders %ux%u (target %ldx%ld) | "
         "window area %ldx%ld (told %ldx%ld) | monitor %ldx%ld, DPI %u (aware: %s)", g_baseRw, g_baseRh, mw, mh, sc, g_eyeOutW, g_eyeOutH, g_bbW, g_bbH,
         g_targetW, g_targetH, rc.right - rc.left, rc.bottom - rc.top, g_targetW, g_targetH, mi.rcMonitor.right - mi.rcMonitor.left,
         mi.rcMonitor.bottom - mi.rcMonitor.top, dpi, aware);
    if (!g_targetSet || g_cam.mode == VRMODE_SCREEN) return;   // flat screen / the game's own size: nothing forced
    if (g_bbW == (UINT)g_targetW && g_bbH == (UINT)g_targetH) {
        bool small = (LONG)(mi.rcMonitor.right - mi.rcMonitor.left) < g_targetW || (LONG)(mi.rcMonitor.bottom - mi.rcMonitor.top) < g_targetH;
        LOGI("RESOLUTION CHECK: OK - the game renders at the full VR size%s", small ? " (the monitor is smaller - only the desktop mirror is affected)" : "");
    } else LOGW("RESOLUTION CHECK: the swap chain is %ux%u, not the VR size %ldx%ld - something resized it outside the hooks (an overlay, a second proxy DLL)",
                g_bbW, g_bbH, g_targetW, g_targetH);
}

// 0.9.3 (framework rule 0.6.63): the live VR resolution. The panel's APPLY / HEADSET DEFAULT set render_scale and call this; every VR
// resource compares the size it was made at with the wanted one and re-creates itself (eye images, atlas, host swapchains, reconstruction)
bool ResolutionPreview(float scale, unsigned& w, unsigned& h) {
    if (!g_baseRw || !g_baseRh) { w = h = 0; return false; }
    EyeFor(g_baseRw, g_baseRh, scale, w, h, false);
    return true;
}
bool ResolutionCurrent(unsigned& w, unsigned& h) { w = g_eyeOutW; h = g_eyeOutH; return w && h; }
void ResolutionApplyLive() {
    if (!g_baseRw || !g_baseRh) { LOGI("resolution: VR resolution x %.2f saved - applied when the headset size is known", g_set.renderScale); return; }
    unsigned ow = g_eyeOutW, oh = g_eyeOutH;
    ComputeTarget(g_baseRw, g_baseRh);
    WindowApplyTarget();
    LOGI("resolution: VR resolution x %.2f applied in game - eye images %ux%u -> %ux%u (headset %ux%u)", g_set.renderScale, ow, oh, g_eyeOutW, g_eyeOutH, g_baseRw, g_baseRh);
}
