// Stereo reconstruction 0.8 shaders: the infill pipeline of the framework's stereo-reconstruction reference (0.6.84),
// written for ResonanceVR from its specification. One HLSL source, compiled for cs_5_0 in the background at game start
// and cached on disk (see recon.cpp). It is a SECOND source, separate from the older two-pass shaders in recon.cpp: if any
// entry point here fails to compile on a machine, the older pipeline keeps running and the log carries the compiler's message.
//
// Entry points
//   fwd2      forward projection of the drawn depth into the other eye (edge pixels follow their colour, holes inside a
//             surface move with it, close-object limit) -> key map (nearest distance per cell, atomic min)
//   memory    once per drawn frame: real background pixels remembered from earlier frames (point memory)
//   tiles     per 32 x 32 key tile: the offset whose copy best predicts the real background around the gaps (matched patches)
//   tilefix   tiles with a gap and no offset take the nearest valid tile's
//   pminit    half-size map: seen colours / distances, gap and ring cells start from their tile's offset
//   pmiter    PatchMatch on the half map (propagation, random search, proximity prior, EM colours)
//   ppseed    membrane seed: the colour mismatch at every gap edge
//   ppdown    membrane pyramid down, ppup membrane pyramid up
//   res2      the eye: sharp seen pixels, gaps from memory / PatchMatch vote / tiles, ring, steady infill, UI
//   finish    blend band beside the fill, optional sharpening
static const char* kHlsl2 = R"HLSL(
#pragma pack_matrix(row_major)
static const uint NONE = 0xFFFFFFFF;
Texture2D<float4> DepthIn   : register(t0);
Texture2D<uint>   NearestIn : register(t1);
Texture2D<float4> Scene     : register(t2);
Texture2D<float4> Final     : register(t3);
Texture2D<float4> PmColIn   : register(t4);
Texture2D<float4> PmStIn    : register(t5);
Texture2D<float4> Tiles     : register(t6);
Texture2D<float4> TileCorr  : register(t7);
Texture2D<float4> Memb      : register(t8);
Texture2D<float4> FillPrev  : register(t9);
Texture2D<float4> MemColIn  : register(t10);
Texture2D<float>  MemDistIn : register(t11);
Texture2D<float4> MemOffIn  : register(t12);
Texture2D<float4> BigIn     : register(t13);
Texture2D<float4> SrcA      : register(t14);
Texture2D<float4> SrcB      : register(t15);
Texture2D<float4> FillCurIn : register(t16);
SamplerState Bilinear : register(s0);
RWTexture2D<uint>   NearestU   : register(u0);
RWTexture2D<uint>   NearestU2  : register(u3);   // the other eye's key map (shared forward pass)
RWTexture2D<float4> OutA       : register(u1);
RWTexture2D<float4> OutB       : register(u2);
RWByteAddressBuffer Counters   : register(u4);
RWTexture2D<float>  MemDistOut : register(u5);
RWTexture2D<float4> MemOffOut  : register(u6);
cbuffer C : register(b0) {
    float4x4 ClipToWorld;    // drawn clip (with the game's jitter) -> world (origin = the drawn eye)
    float4x4 WorldToOther;   // world -> the rebuilt eye's clip
    float4x4 OtherToDrawn;   // rebuilt eye's clip -> drawn clip (no jitter)
    float4x4 DrawnToOther;   // its inverse
    float4x4 OtherToPrev;    // rebuilt eye's clip -> that eye's clip at its last rebuild (steady infill)
    float4x4 CurToPrev;      // drawn clip -> the previous frame's drawn clip (memory)
    float4x4 PrevToCur;      // the previous frame's drawn clip -> this frame's
    float4 DSize;            // depth size, 1 / size
    float4 KSize;            // key map size, 1 / size
    float4 OSize;            // rebuilt eye size, 1 / size
    float4 HSize;            // half map w, h; tiles x, y
    float4 Fmt;              // depth: format, flip, count, near limit (world units)
    float4 Foot;             // forward footprint x, y, adaptive, edge pixels + holes on
    float4 Z;                // rebuilt eye: ndc depth = x + y / distance; z = gap reach (key px); w = steady usable
    float4 ZD;               // drawn view: ndc depth = x + y / distance
    float4 Opt;              // debug, UI split on, UI threshold, UI scale
    float4 UiC;              // UI centre of the drawn picture (px), of this eye (px)
    float4 Pre;              // x vote radius, y tile offsets (21 / 63), z passes, w fill mode (0 none, 1 tiles, 2 PatchMatch + ring)
    float4 Mix;              // x edge guard, y steady infill, z infill blend, w infill detail
    float4 Mem;              // x memory on (history valid), y memory w, z memory h, w seconds since the last frame
    float4 Misc;             // x sharpen, y PatchMatch jump, z pass seed, w memory lookup on
    float4x4 WorldToOther2;  // shared forward pass: world -> the second rebuilt eye's clip
    float4 Foot2;            // its forward footprint x, y, adaptive, w = the second map is written too
    float4 Edge;             // x edge fill on (rays at infinity that leave the drawn view repeat its rim), y held tiles valid, z performance path (35 offsets, membrane), w steady edges (depth smaller than the picture)
    float4 Edge2;            // x band-only writes (the blend input only near gap tiles, the blend pass only on band pixels); y resolve split: 1 groups without a gap tile, 2 groups with one (0 = one dispatch)
};

// ------------------------------------------------------------------------------------------------ shared helpers
float Depth01(float4 v) {
    uint4 b = (uint4)round(saturate(v) * 255.0);
    uint raw = (b.x & 0xFFu) | ((b.y & 0xFFu) << 8);
    if (Fmt.x < 1.5) raw |= ((b.z & 0xFFu) << 16) | ((b.w & 0xFFu) << 24);
    if (Fmt.x < 0.5) return asfloat(raw);
    if (Fmt.x < 1.5) return float(raw & 0xFFFFFF) * (1.0 / 16777215.0);
    return float(raw & 0xFFFF) * (1.0 / 65535.0);
}
float DepthFixed(float4 v) { float d = Depth01(v); return Fmt.y > 0.5 ? 1.0 - d : d; }
uint NearAt(int2 q) { return (q.x < 0 || q.y < 0 || q.x >= (int)KSize.x || q.y >= (int)KSize.y) ? NONE : NearestIn.Load(int3(q, 0)); }
float2 KeyUv(int2 k) { return (float2(k) + 0.5) * KSize.zw; }
uint Hash(uint x) { x ^= x >> 16; x *= 0x7feb352du; x ^= x >> 15; x *= 0x846ca68bu; x ^= x >> 16; return x; }
float2 ClipUv(float4 c) { return c.xy / c.w * float2(0.5, -0.5) + 0.5; }

// the rebuilt eye's point (uv, distance) in the drawn picture; false when it is outside
bool DrawnUv(float2 uv, float dist, out float2 su) {
    float4 p = float4(uv * float2(2, -2) + float2(-1, 1), dist >= 1e29 ? Z.x : Z.x + Z.y / max(dist, 1e-6), 1.0);
    float4 dc = mul(p, OtherToDrawn);
    su = dc.w > 1e-9 ? ClipUv(dc) : float2(-1, -1);
    return su.x >= 0.0 && su.y >= 0.0 && su.x <= 1.0 && su.y <= 1.0;
}
// RunColour: the drawn picture at key cell k at its own distance (bilinear)
float4 RunCol(int2 k, out bool ok) {
    uint kk = NearAt(k); ok = false;
    if (kk == NONE) return float4(0, 0, 0, 0);
    float2 su; ok = DrawnUv(KeyUv(k), asfloat(kk), su);
    return ok ? Scene.SampleLevel(Bilinear, su, 0) : float4(0, 0, 0, 0);
}
// SampleSharp: clamped Catmull-Rom with 5 bilinear taps (the 4 corner taps dropped, weights renormalised), then the 2 x 2 min / max clamp
float4 SharpScene(float2 uv) {
    uint sw, sh; Scene.GetDimensions(sw, sh);
    float2 sz = float2(sw, sh);
    float2 pos = uv * sz;
    float2 t1 = floor(pos - 0.5) + 0.5;
    float2 f = pos - t1;
    float2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
    float2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
    float2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
    float2 w3 = f * f * (-0.5 + 0.5 * f);
    float2 w12 = w1 + w2;
    float2 o12 = w2 / max(w12, 1e-5);
    float2 tA = (t1 - 1.0) / sz, tB = (t1 + 2.0) / sz, tC = (t1 + o12) / sz;
    float4 r = Scene.SampleLevel(Bilinear, float2(tC.x, tC.y), 0) * (w12.x * w12.y)
             + Scene.SampleLevel(Bilinear, float2(tA.x, tC.y), 0) * (w0.x * w12.y)
             + Scene.SampleLevel(Bilinear, float2(tB.x, tC.y), 0) * (w3.x * w12.y)
             + Scene.SampleLevel(Bilinear, float2(tC.x, tA.y), 0) * (w12.x * w0.y)
             + Scene.SampleLevel(Bilinear, float2(tC.x, tB.y), 0) * (w12.x * w3.y);
    float ws = w12.x * w12.y + w0.x * w12.y + w3.x * w12.y + w12.x * w0.y + w12.x * w3.y;
    r /= max(ws, 1e-5);
    int2 i0 = int2(floor(pos - 0.5));
    int2 mx = int2(sw, sh) - 1;
    float4 a = Scene.Load(int3(clamp(i0, int2(0, 0), mx), 0));
    float4 b = Scene.Load(int3(clamp(i0 + int2(1, 0), int2(0, 0), mx), 0));
    float4 c = Scene.Load(int3(clamp(i0 + int2(0, 1), int2(0, 0), mx), 0));
    float4 d = Scene.Load(int3(clamp(i0 + int2(1, 1), int2(0, 0), mx), 0));
    return clamp(r, min(min(a, b), min(c, d)), max(max(a, b), max(c, d)));
}

// FindGap2: what an empty key cell is. 0 not empty, 1 crack (one surface; ckey = its nearer side), 2 gap with the background on one side
// and an object on the other, 3 gap with only one side found, 4 nothing found
int FindGap2(int2 kp, out int bgDir, out int bgDist, out int fgDist, out float zb, out float zf, out uint ckey) {
    bgDir = 0; bgDist = 0; fgDist = 0; zb = 0; zf = 0; ckey = NONE;
    if (NearAt(kp) != NONE) return 0;
    uint kl = NONE, kr = NONE; int reach = (int)Z.z, stride = max(1, reach / 24), i = 1, fl = 0, fr = 0;
    [loop] for (; i <= reach && (kl == NONE || kr == NONE); i += (i < 4 ? 1 : stride)) {
        if (kl == NONE) { kl = NearAt(kp - int2(i, 0)); fl = i; }
        if (kr == NONE) { kr = NearAt(kp + int2(i, 0)); fr = i; }
    }
    if (kl != NONE && kr != NONE) {
        float dl = asfloat(kl), dr = asfloat(kr);
        bool crack = fl + fr <= 6 && abs(dl - dr) <= 0.03 * min(dl, dr);
        if (crack) { ckey = min(kl, kr); return 1; }
        bgDir = kl >= kr ? -1 : 1; bgDist = kl >= kr ? fl : fr; fgDist = kl >= kr ? fr : fl;
        zb = asfloat(max(kl, kr)); zf = asfloat(min(kl, kr));
        ckey = max(kl, kr);
        return 2;
    }
    if (kl != NONE || kr != NONE) {
        bgDir = kl != NONE ? -1 : 1; bgDist = kl != NONE ? fl : fr; zb = asfloat(kl != NONE ? kl : kr); zf = zb;
        ckey = kl != NONE ? kl : kr;
        return 3;
    }
    return 4;
}
bool FindGap(int2 kp, out int bgDir, out int bgDist, out int fgDist, out float zb, out float zf) {
    uint ck;
    int r = FindGap2(kp, bgDir, bgDist, fgDist, zb, zf, ck);
    return r == 2 || r == 3;
}
// RingZ: the seen cell k is the 1-pixel background ring of a gap beside it -> that gap's background distance, else 0
float RingZ(int2 k, uint kk, out int side) {
    side = 0;
    for (int j = 0; j < 2; j++) {   // (no [unroll]: the early return inside would make FXC refuse a forced unroll)
        int s = j * 2 - 1;
        int2 q = k + int2(s, 0);
        if (NearAt(q) == NONE) {
            int bd, bs, fd; float zb, zf;
            if (FindGap(q, bd, bs, fd, zb, zf) && bd == -s && bs == 1 && asfloat(kk) >= 0.9 * zb) { side = s; return zb; }
        }
    }
    return 0;
}
// the distance (view depth of the drawn view) of a depth texel
float DistAt(int2 q) {
    q = clamp(q, int2(0, 0), int2(DSize.xy) - 1);
    float2 nd = (float2(q) + 0.5) * DSize.zw * float2(2, -2) + float2(-1, 1);
    float4 v = float4(nd, DepthFixed(DepthIn.Load(int3(q, 0))), 1.0);
    float4 wc = float4(ClipToWorld._m03, ClipToWorld._m13, ClipToWorld._m23, ClipToWorld._m33);
    float w = abs(dot(v, wc));
    return w > 1e-20 ? 1.0 / w : 1e30;
}

// ------------------------------------------------------------------------------------------------ pass 1: forward
float WAt(int2 q, float4 wc) {
    q = clamp(q, int2(0, 0), int2(DSize.xy) - 1);
    float2 nd = (float2(q) + 0.5) * DSize.zw * float2(2, -2) + float2(-1, 1);
    float4 v = float4(nd, DepthFixed(DepthIn.Load(int3(q, 0))), 1.0);
    return abs(dot(v, wc));
}
float3 PicAt(int2 q) { return Scene.SampleLevel(Bilinear, (float2(q) + 0.5) * DSize.zw, 0).rgb; }
// writes one world point into one eye's key map (nearest distance per cell, atomic min)
void Splat(RWTexture2D<uint> map, float4 wp, float4x4 M, float4 ft) {
    float4 oc = mul(wp, M);
    if (oc.w <= 1e-9) return;
    float dist = wp.w > 1e-20 ? oc.w / wp.w : 1e30;
    float2 px = (oc.xy / oc.w * float2(0.5, -0.5) + 0.5) * KSize.xy;
    uint key = asuint(min(dist, 1e30)); uint was;
    if (ft.z > 0.5) {
        int2 c0 = int2(floor(px));
        float2 fr = px - floor(px);
        int dx = fr.x < ft.x ? -1 : fr.x > 1.0 - ft.x ? 1 : 0;
        int dy = fr.y < ft.y ? -1 : fr.y > 1.0 - ft.y ? 1 : 0;
        [unroll] for (int j = 0; j < 4; j++) {
            int ox = (j & 1) ? dx : 0, oy = (j >> 1) ? dy : 0;
            if (j > 0 && (((j & 1) != 0 && dx == 0) || ((j >> 1) != 0 && dy == 0))) continue;
            int2 q = c0 + int2(ox, oy);
            if (q.x >= 0 && q.y >= 0 && q.x < (int)KSize.x && q.y < (int)KSize.y) InterlockedMin(map[q], key, was);
        }
        return;
    }
    int2 q0 = int2(floor(px - 0.5));
    [unroll] for (int j = 0; j < 4; j++) {
        int2 q = q0 + int2(j & 1, j >> 1);
        if (q.x >= 0 && q.y >= 0 && q.x < (int)KSize.x && q.y < (int)KSize.y) InterlockedMin(map[q], key, was);
    }
}
// 49.6: the group's w values (1 / distance) and a 2-texel border read into shared memory once; the edge / hole tests take their 8
// neighbours from there (was 9 depth reads per pixel)
groupshared float gsW[12][20];
float WS(uint2 gt, int dx, int dy) { return gsW[(int)gt.y + 2 + dy][(int)gt.x + 2 + dx]; }
[numthreads(16, 8, 1)] void fwd2(uint3 t : SV_DispatchThreadID, uint3 gt : SV_GroupThreadID, uint3 gid : SV_GroupID, uint gi : SV_GroupIndex) {
    {
        float4 wcs = float4(ClipToWorld._m03, ClipToWorld._m13, ClipToWorld._m23, ClipToWorld._m33);
        int2 org = int2(gid.xy) * int2(16, 8) - int2(2, 2);
        for (uint i = gi; i < 240u; i += 128u) { int2 q = org + int2((int)(i % 20u), (int)(i / 20u)); gsW[i / 20u][i % 20u] = WAt(q, wcs); }
    }
    GroupMemoryBarrierWithGroupSync();
    if (t.x >= (uint)DSize.x || t.y >= (uint)DSize.y) return;
    int2 p = int2(t.xy);
    float2 ndc = (float2(p) + 0.5) * DSize.zw * float2(2, -2) + float2(-1, 1);
    float4 raw4 = DepthIn.Load(int3(p, 0));
    if (Fmt.z > 0.5 && (t.x & 15u) == 0 && (t.y & 15u) == 0) {   // which way the depth runs: far half / near half
        float d0 = Depth01(raw4); uint o;
        if (d0 > 0.0 && d0 < 1.0) { Counters.InterlockedAdd(16, 1u, o); if (d0 > 0.5) Counters.InterlockedAdd(20, 1u, o); } else if (d0 <= 0.0) Counters.InterlockedAdd(28, 1u, o); else Counters.InterlockedAdd(32, 1u, o);   /* exact 0 / 1: cleared or sky pixels hold only the far value */
    }
    float4 v = float4(ndc, DepthFixed(raw4), 1.0);
    float4 wp = mul(v, ClipToWorld);
    wp *= sign(wp.w + 1e-30);
    if (Foot.w > 0.5 && wp.w > 1e-20) {
        // 0.6.71 / 0.6.78: edge pixels follow their colour, holes inside a surface move with it. w = 1 / distance (one dot product)
        float4 wc = float4(ClipToWorld._m03, ClipToWorld._m13, ClipToWorld._m23, ClipToWorld._m33);
        float w0 = abs(dot(v, wc));
        static const int2 TapO[4] = { int2(-1, 0), int2(-2, 0), int2(1, 0), int2(2, 0) };
        float tw[4];
        [unroll] for (int i = 0; i < 4; i++) tw[i] = WS(gt.xy, TapO[i].x, TapO[i].y);
        float nl = max(tw[0], tw[1]), nr = max(tw[2], tw[3]);
        float wmax = max(nl, nr), wmin = min(min(tw[0], tw[1]), min(tw[2], tw[3]));
        float wn = 0.0;
        bool holeH = min(nl, nr) > 1.08 * w0 && abs(nl - nr) <= 0.05 * max(nl, nr);
        float cu = WS(gt.xy, 0, -1), cu2 = WS(gt.xy, 0, -2), cd = WS(gt.xy, 0, 1), cd2 = WS(gt.xy, 0, 2);
        float nu = max(cu, cu2), ndn = max(cd, cd2);
        bool holeV = min(nu, ndn) > 1.08 * w0 && abs(nu - ndn) <= 0.05 * max(nu, ndn);
        if (holeH || holeV) {
            if (holeH) wn = max(wn, max(nl, nr));
            if (holeV) wn = max(wn, max(nu, ndn));
        } else if (wmax > 1.08 * wmin && wmax > 1.08 * w0) {
            float3 c = PicAt(p);
            float3 nearSum = 0, farSum = 0; float nn = 0, nf = 0;
            [unroll] for (int j = 0; j < 4; j++) {
                float3 cj = PicAt(p + TapO[j]);
                if (tw[j] >= wmax / 1.03) { nearSum += cj; nn += 1; }
                if (tw[j] <= wmin * 1.03) { farSum += cj; nf += 1; }
            }
            farSum += c; nf += 1;
            float3 nm = nn > 0 ? nearSum / nn : c, fm = farSum / nf;
            if (dot(abs(c - nm), float3(1, 1, 1)) < dot(abs(c - fm), float3(1, 1, 1))) wn = wmax;   // this pixel is the near surface's
        }
        if (wn > 0.0) wp = float4(wp.xyz / wp.w * (w0 / wn), 1.0);
    }
    if (Fmt.w > 0.0 && wp.w > 1e-20) {   // close-object limit: nothing nearer than this is pushed further apart
        float3 pos = wp.xyz / wp.w; float r = length(pos);
        if (r > 1e-6 && r < Fmt.w) { pos = pos / r * (Fmt.w / (1.0 + log(Fmt.w / r))); wp = float4(pos, 1.0); }
    }
    Splat(NearestU, wp, WorldToOther, Foot);
    if (Foot2.w > 0.5) Splat(NearestU2, wp, WorldToOther2, Foot2);   // 0.8: one projection per rebuilt eye of the same drawn pixel
}

// ------------------------------------------------------------------------------------------------ pass 0: memory (real pixels)
// A remembered point: texel centre + offset at its own distance. A texel of the memory is either what the drawn view shows now
// (age 0), or a real pixel remembered from earlier frames that lies BEHIND what is visible now (the background an object hid).
bool MemPoint(float2 muv, float guess, float wc, bool behind, out float3 col, out float age, out float dist, out float2 off) {
    col = 0; age = 0; dist = 0; off = 0;
    float4 p = float4(muv * float2(2, -2) + float2(-1, 1), ZD.x + ZD.y / max(guess, 1e-6), 1.0);
    float4 pc = mul(p, CurToPrev);
    if (pc.w <= 1e-9) return false;
    float2 puv = ClipUv(pc);
    float2 msz = float2(Mem.y, Mem.z);
    float2 pm = puv * msz - 0.5;
    int2 p0 = int2(floor(pm));
    float bestErr = 0.75; bool got = false;
    [unroll] for (int j = 0; j < 4; j++) {
        int2 q = p0 + int2(j & 1, j >> 1);
        if (q.x < 0 || q.y < 0 || q.x >= (int)msz.x || q.y >= (int)msz.y) continue;
        float4 mc = MemColIn.Load(int3(q, 0));
        if (mc.a < 0.0) continue;
        float qd = MemDistIn.Load(int3(q, 0));
        if (behind ? (qd <= 1.04 * wc) : (abs(qd - wc) > 0.03 * wc)) continue;
        float2 qo = MemOffIn.Load(int3(q, 0)).xy;
        float2 pu = (float2(q) + 0.5 + qo) / msz;
        float4 pp = float4(pu * float2(2, -2) + float2(-1, 1), ZD.x + ZD.y / max(qd, 1e-6), 1.0);
        float4 nc = mul(pp, PrevToCur);
        if (nc.w <= 1e-9) continue;
        float2 nu = ClipUv(nc);
        float err = length((nu - muv) * msz);
        if (err < bestErr) { bestErr = err; got = true; col = mc.rgb; age = mc.a + Mem.w; dist = nc.w; off = (nu - muv) * msz; }
    }
    return got;
}
[numthreads(16, 8, 1)] void memory(uint3 t : SV_DispatchThreadID) {
    if (t.x >= (uint)Mem.y || t.y >= (uint)Mem.z) return;
    float2 msz = float2(Mem.y, Mem.z);
    float2 muv = (float2(t.xy) + 0.5) / msz;
    int2 dp = min(int2(muv * DSize.xy), int2(DSize.xy) - 1);
    float wc = DistAt(dp);
    float3 pic = Scene.SampleLevel(Bilinear, muv, 0).rgb;
    int stp = max(1, (int)(DSize.x / msz.x));
    float wl = DistAt(dp - int2(stp, 0)), wr = DistAt(dp + int2(stp, 0)), wu = DistAt(dp - int2(0, stp)), wd = DistAt(dp + int2(0, stp));
    float lim = 0.0488;   // ln 1.05
    bool edge = abs(log(wl / wc)) > lim || abs(log(wr / wc)) > lim || abs(log(wu / wc)) > lim || abs(log(wd / wc)) > lim;
    float4 outc = float4(pic, edge ? -1.0 : 0.0); float outd = wc; float2 outo = float2(0, 0);
    if (Mem.x > 0.5 && wc < 1e29) {
        float3 c; float a, d; float2 o;
        if (edge && MemPoint(muv, wc, wc, false, c, a, d, o)) { outc = float4(c, 0.0); outd = d; outo = o; }   // keep this surface's clean remembered sample
        float gd[5]; gd[0] = wc;
        [unroll] for (int k = 1; k < 5; k++) {   // what may hide behind: the farthest depth within 8, 16, 32, 64 px (of 1920) to either side
            int r = max(1, (int)((8 << (k - 1)) * DSize.x / 1920.0));
            gd[k] = max(DistAt(dp - int2(r, 0)), DistAt(dp + int2(r, 0)));
        }
        for (int g = 0; g < 5; g++) {   // (no [unroll]: the break below)
            if (gd[g] < wc * 1.04 || gd[g] > 1e29) continue;
            if (MemPoint(muv, gd[g], wc, true, c, a, d, o)) { outc = float4(c, a); outd = d; outo = o; break; }
        }
    }
    OutA[t.xy] = outc; MemDistOut[t.xy] = outd; MemOffOut[t.xy] = float4(outo, 0, 0);
}

// ------------------------------------------------------------------------------------------------ pass 1b: matched patches per 32 x 32 tile
groupshared float4 gsGapInfo[128];   // side, width, background threshold, background distance (side 0: none)
groupshared int2   gsGapPos[128];
groupshared float4 gsBrd[128];       // a border cell's colour, w = valid
groupshared int2   gsBrdPos[128];
groupshared float  gsCost[64];
groupshared float4 gsTile;           // side, widest gap, threshold, sample count
groupshared float4 gsMean, gsSig;
groupshared uint   gsAnyGap;
static const int kDX[9] = { 0, 3, 6, 10, 15, 22, 32, 46, 64 };
static const int kDY[7] = { -18, -12, -6, 0, 6, 12, 18 };
static const int kDXP[5] = { 0, 8, 22, 46, 90 };
static const int kDYP[7] = { -24, -12, -6, 0, 6, 12, 24 };
int2 CandOff(int c, float side, float widest) {
    if (Edge.z > 0.5) {   // 0.9 performance path: 5 x 7 = 35 offsets
        int dp = c / 7, yp = c - dp * 7;
        return int2((int)side * ((int)widest + (int)Mix.x + 1 + kDXP[dp]), kDYP[yp]);
    }
    int nd = Pre.y > 30.0 ? 9 : 3;
    int di = c / 7, yi = c - di * 7;
    int dxi = nd == 9 ? di : (di == 0 ? 0 : di == 1 ? 2 : 5);
    int D = (int)side * ((int)widest + (int)Mix.x + 1 + kDX[dxi]);
    return int2(D, kDY[yi]);
}
[numthreads(128, 1, 1)] void tiles(uint3 gid : SV_GroupID, uint gi : SV_GroupIndex) {
    int2 tile = int2(gid.xy);
    int2 org = tile * 32;
    if (gi == 0) gsAnyGap = 0;
    gsGapInfo[gi] = float4(0, 0, 0, 0); gsGapPos[gi] = int2(0, 0); gsBrd[gi] = float4(0, 0, 0, 0); gsBrdPos[gi] = int2(0, 0);
    GroupMemoryBarrierWithGroupSync();
    uint h0 = Hash((uint)tile.x * 73856093u ^ (uint)tile.y * 19349663u ^ gi * 83492791u);
    int start = (int)(h0 & 7u);
    [loop] for (int jj = 0; jj < 8; jj++) {
        int j = (jj + start) & 7;
        int idx = (int)gi + 128 * j;
        int2 k = org + int2(idx & 31, idx >> 5);
        if (k.x >= (int)KSize.x || k.y >= (int)KSize.y) continue;
        if (NearAt(k) != NONE) continue;
        int bd, bs, fd; float zb, zf;
        if (!FindGap(k, bd, bs, fd, zb, zf) || bd == 0) continue;
        float thr = fd == 0 ? 0.85 * zb : (zf < 0.7 * zb ? sqrt(zb * zf) : 0.85 * min(zb, zf));
        gsGapInfo[gi] = float4((float)bd, (float)max(bs + fd - 1, 1), thr, zb);
        gsGapPos[gi] = k;
        int2 b = k + int2(bd * (bs + 1 + (int)Mix.x), 0);   // a border cell one past the edge guard, on the background
        bool ok; float4 c = RunCol(b, ok);
        if (ok) { gsBrd[gi] = float4(c.rgb, 1.0); gsBrdPos[gi] = b; }
        uint o; InterlockedOr(gsAnyGap, 1u, o);
        break;
    }
    GroupMemoryBarrierWithGroupSync();
    // (no early return: every barrier below stays in uniform flow control, which the FXC compiler insists on)
    if (gi == 0 && gsAnyGap != 0u) {
        float side = 0, widest = 0, thr = 0, n = 0;
        float3 m1 = 0, m2 = 0; float nb = 0;
        for (int i = 0; i < 128; i++) {
            if (gsGapInfo[i].x != 0.0) { side += gsGapInfo[i].x; widest = max(widest, gsGapInfo[i].y); thr += gsGapInfo[i].z; n += 1.0; }
            if (gsBrd[i].w > 0.5) { m1 += gsBrd[i].rgb; m2 += gsBrd[i].rgb * gsBrd[i].rgb; nb += 1.0; }
        }
        gsTile = float4(side >= 0.0 ? 1.0 : -1.0, widest, thr / max(n, 1.0), n);
        float3 mean = nb > 0 ? m1 / nb : float3(0, 0, 0);
        gsMean = float4(mean, nb);
        gsSig = float4(sqrt(max(nb > 0 ? m2 / nb - mean * mean : float3(1, 1, 1), 1e-4)), 0);
    }
    GroupMemoryBarrierWithGroupSync();
    int ncand = (int)Pre.y;
    int ntot = ncand + (Edge.y > 0.5 ? 1 : 0);          // + the offset this tile held last frame
    float4 heldTile = Edge.y > 0.5 ? Tiles.Load(int3(tile, 0)) : float4(0, 0, 0, 0);
    if ((int)gi < 64) gsCost[gi] = 1e9;
    if (gsAnyGap != 0u && (int)gi < ntot) {
        bool valid = true;
        int2 off = int2(0, 0);
        if ((int)gi < ncand) off = CandOff((int)gi, gsTile.x, gsTile.y);
        else { valid = heldTile.z > 0.5; off = int2(round(heldTile.xy)); }
        float thr = gsTile.z;
        int ng = 0, nok = 0, nout = 0; float plaus = 0.0;
        int gstep = Edge.z > 0.5 ? 4 : 2, bstep = Edge.z > 0.5 ? 4 : 3;   // performance path: 32 gap + 32 border samples
        if (valid) {
            [loop] for (int n = 0; n < 128; n += gstep) {
                if (gsGapInfo[n].x == 0.0) continue;
                ng++;
                int2 s = gsGapPos[n] + off;
                uint ks = NearAt(s);
                if (ks == NONE || asfloat(ks) < thr) continue;
                bool ok; float4 c = RunCol(s, ok);
                if (!ok) continue;
                nok++;
                float3 z = (c.rgb - gsMean.rgb) / gsSig.rgb;
                if (gsMean.w > 3.5) { float zz = dot(z, z); if (zz > 27.0) nout++; plaus += min(zz / 27.0, 1.0); }
            }
        }
        float cost = 1e9;
        if (valid && ng > 0 && nok >= 0.85 * ng && nout <= 0.15 * max(nok, 1)) {
            int nb = 0, nseen = 0; float ssd = 0;
            [loop] for (int m = 0; m < 128; m += bstep) {
                if (gsBrd[m].w < 0.5) continue;
                nb++;
                bool ok; float4 c = RunCol(gsBrdPos[m] + off, ok);
                if (!ok) continue;
                nseen++;
                float3 d = c.rgb - gsBrd[m].rgb; ssd += dot(d, d);
            }
            float reg = 1e-4 * (abs(off.y) + abs(off.x)) + 0.01 * plaus / max((float)nok, 1.0);   // + 0.01 x mean plausibility (colour outlier score)
            if (nb >= 4) { if (nseen >= 0.7 * nb) cost = ssd / max(nseen, 1) + reg; }
            else cost = 10.0 * reg;
        }
        gsCost[gi] = cost;
    }
    GroupMemoryBarrierWithGroupSync();
    if (gi == 0) {
        float best = 1e8; int bi = -1;
        for (int c = 0; c < ncand; c++) if (gsCost[c] < best) { best = gsCost[c]; bi = c; }
        bool useHeld = false;
        if (ntot > ncand && gsCost[ncand] < 1e8 && (bi < 0 || gsCost[ncand] <= 1.3 * best + 1e-5)) { useHeld = true; bi = ncand; }   // the held offset stays unless a new one is clearly better
        if (gsAnyGap == 0u) { OutA[tile] = float4(0, 0, 0, 0); OutB[tile] = float4(0, 0, 0, 0); }
        else if (bi < 0) { OutA[tile] = float4(0, 0, 0, 1); OutB[tile] = float4(0, 0, 0, 0); }
        else {
            int2 off = useHeld ? int2(round(heldTile.xy)) : CandOff(bi, gsTile.x, gsTile.y);
            float3 acc = 0; float na = 0;
            for (int m = 0; m < 128; m += 3) {
                if (gsBrd[m].w < 0.5) continue;
                bool ok; float4 c = RunCol(gsBrdPos[m] + off, ok);
                if (!ok) continue;
                acc += gsBrd[m].rgb - c.rgb; na += 1.0;
            }
            float3 corr = na > 0 ? acc / na : float3(0, 0, 0);
            if (useHeld) corr = lerp(TileCorr.Load(int3(tile, 0)).rgb, corr, 0.2);   // the colour correction follows 20 % a frame
            OutA[tile] = float4((float)off.x, (float)off.y, 1, 1);
            OutB[tile] = float4(corr, 0);
        }
    }
}
[numthreads(8, 8, 1)] void tilefix(uint3 t : SV_DispatchThreadID) {
    if (t.x >= (uint)HSize.z || t.y >= (uint)HSize.w) return;
    int2 tl = int2(t.xy);
    float4 a = Tiles.Load(int3(tl, 0)), c = TileCorr.Load(int3(tl, 0));
    if (a.w > 0.5 && a.z < 0.5) {
        float best = 1e9; int2 bt = tl;
        [loop] for (int dy = -3; dy <= 3; dy++) for (int dx = -3; dx <= 3; dx++) {
            int2 q = tl + int2(dx, dy);
            if (q.x < 0 || q.y < 0 || q.x >= (int)HSize.z || q.y >= (int)HSize.w) continue;
            float4 b = Tiles.Load(int3(q, 0));
            if (b.z > 0.5) { float d = (float)(dx * dx + dy * dy); if (d < best) { best = d; bt = q; } }
        }
        if (best < 1e8) { a = float4(Tiles.Load(int3(bt, 0)).xy, 1, 1); c = TileCorr.Load(int3(bt, 0)); }
    }
    OutA[t.xy] = a; OutB[t.xy] = c;
}

// ------------------------------------------------------------------------------------------------ PatchMatch on the half map
// PmCol: rgb, a = log2 distance (seen cells). PmSt: x, y = offset (half cells), z = kind (0 seen, 1 gap, 2 not used, 3 ring), w = log2 background distance
bool IsFilled(float k) { return (k > 0.5 && k < 1.5) || k > 2.5; }
float4 TileAt(int2 k) { return Tiles.Load(int3(k >> 5, 0)); }
float4 TileCorrAt(int2 k) { return TileCorr.Load(int3(k >> 5, 0)); }
[numthreads(16, 8, 1)] void pminit(uint3 t : SV_DispatchThreadID) {
    if (t.x >= (uint)HSize.x || t.y >= (uint)HSize.y) return;
    int2 k = int2(t.xy) * 2;
    uint kk = NearAt(k);
    float4 col = float4(0, 0, 0, 0), st = float4(0, 0, 2, 0);
    if (kk != NONE) {
        int side = 0; float rz = 0.0;
        if (Pre.w > 1.5) rz = RingZ(k, kk, side);
        if (rz > 0.0) {   // the background pixel right beside a gap is filled too (no outline)
            float4 tp = TileAt(k);
            float2 o = tp.z > 0.5 ? round(tp.xy * 0.5) : float2(-3.0 * side, 0);
            bool ok; float4 c = RunCol(k, ok);
            col = float4(c.rgb, 0); st = float4(o, 3, log2(rz));
        } else {
            // the 2 x 2 key cells: one bilinear read when they are one surface, else their mean
            uint k1 = NearAt(k + int2(1, 0)), k2 = NearAt(k + int2(0, 1)), k3 = NearAt(k + int2(1, 1));
            float d0 = asfloat(kk);
            bool one = k1 != NONE && k2 != NONE && k3 != NONE;
            if (one) { float d1 = asfloat(k1), d2 = asfloat(k2), d3 = asfloat(k3); float lo = min(min(d0, d1), min(d2, d3)), hi = max(max(d0, d1), max(d2, d3)); one = hi < 1.04 * lo; }
            float3 acc = 0;
            if (one) {
                float2 su;
                float md = 0.25 * (d0 + asfloat(k1) + asfloat(k2) + asfloat(k3));
                if (DrawnUv((float2(k) + 1.0) * KSize.zw, md, su)) acc = Scene.SampleLevel(Bilinear, su, 0).rgb;
                else { bool ok; acc = RunCol(k, ok).rgb; }
            } else {
                float n = 0;
                [unroll] for (int j = 0; j < 4; j++) { bool ok; float4 c = RunCol(k + int2(j & 1, j >> 1), ok); if (ok) { acc += c.rgb; n += 1.0; } }
                acc = n > 0 ? acc / n : float3(0, 0, 0);
            }
            col = float4(acc, log2(max(d0, 1e-4))); st = float4(0, 0, 0, 0);
        }
    } else {
        int bd, bs, fd; float zb, zf;
        if (FindGap(k, bd, bs, fd, zb, zf) && bd != 0) {
            float4 tp = TileAt(k);
            float2 o = tp.z > 0.5 ? tp.xy : float2((float)(bd * (bs + fd + 3)), 0);
            bool ok; float4 c = RunCol(k + int2(o), ok);
            float3 corr = tp.z > 0.5 ? TileCorrAt(k).rgb : float3(0, 0, 0);
            col = float4(c.rgb + corr, 0); st = float4(round(o * 0.5), 1, log2(max(zb, 1e-4)));
        }
    }
    OutA[t.xy] = col; OutB[t.xy] = st;
}
float PmCost(int2 c, int2 o, float lo, float hi, int2 hs) {
    float sum = 0, wsum = 0; int n = 0;
    [loop] for (int dy = -2; dy <= 2; dy++) for (int dx = -2; dx <= 2; dx++) {
        int2 tc = c + int2(dx, dy), sc = tc + o;
        if (tc.x < 0 || tc.y < 0 || tc.x >= hs.x || tc.y >= hs.y || sc.x < 0 || sc.y < 0 || sc.x >= hs.x || sc.y >= hs.y) continue;
        float4 tcol = PmColIn.Load(int3(tc, 0)), tst = PmStIn.Load(int3(tc, 0));
        float wt = 0;
        if (IsFilled(tst.z)) wt = 1.0;
        else if (tst.z < 0.5 && tcol.a >= lo) wt = 2.0;
        if (wt == 0.0) continue;
        float4 scol = PmColIn.Load(int3(sc, 0)), sst = PmStIn.Load(int3(sc, 0));
        if (sst.z > 0.5 || scol.a < lo - 0.152 || scol.a > hi + 0.138) continue;   // the source: a seen cell of the background's distance range
        float3 d = tcol.rgb - scol.rgb;
        sum += wt * dot(d, d); wsum += wt; n++;
    }
    return n < 8 ? 1e9 : sum / wsum;
}
float CandCost(int2 c, int2 o, float lo, float hi, int2 hs) {
    int2 sc = c + o;
    if (sc.x < 0 || sc.y < 0 || sc.x >= hs.x || sc.y >= hs.y) return 1e9;
    float4 scol = PmColIn.Load(int3(sc, 0)), sst = PmStIn.Load(int3(sc, 0));
    if (sst.z > 0.5 || scol.a < lo || scol.a > hi) return 1e9;   // the source's centre lies on the background
    float cost = PmCost(c, o, lo, hi, hs);
    if (cost >= 1e9) return cost;
    return cost * (1.0 + 0.75 * (abs(o.x) + abs(o.y)));      // 0.6.77: of two similar patches the nearer wins
}
[numthreads(16, 8, 1)] void pmiter(uint3 t : SV_DispatchThreadID) {
    if (t.x >= (uint)HSize.x || t.y >= (uint)HSize.y) return;
    int2 c = int2(t.xy); int2 hs = int2(HSize.xy);
    float4 st = PmStIn.Load(int3(c, 0));
    if (!IsFilled(st.z)) return;
    float lo = st.w + log2(0.85), hi = st.w + log2(1.35);
    int2 own = int2(round(st.xy));
    int2 best = own; float bestC = CandCost(c, own, lo, hi, hs);
    int jump = (int)Misc.y;
    [unroll] for (int d = 0; d < 4; d++) {
        int2 dir = d == 0 ? int2(1, 0) : d == 1 ? int2(-1, 0) : d == 2 ? int2(0, 1) : int2(0, -1);
        int2 nc = c + dir * jump;
        if (nc.x < 0 || nc.y < 0 || nc.x >= hs.x || nc.y >= hs.y) continue;
        float4 nst = PmStIn.Load(int3(nc, 0));
        if (!IsFilled(nst.z)) continue;
        int2 cand = int2(round(nst.xy));
        float cc = CandCost(c, cand, lo, hi, hs) * 0.9;   // coherence
        if (cc < bestC) { bestC = cc; best = cand; }
    }
    uint seed = Hash((uint)c.x * 1973u + (uint)c.y * 9277u + (uint)Misc.z * 26699u);
    [unroll] for (int r = 0; r < 5; r++) {
        int R = 48 >> r; if (r == 0) R = 48; if (r == 1) R = 24; if (r == 2) R = 12; if (r == 3) R = 6; if (r == 4) R = 3;
        seed = Hash(seed + 911u * (uint)(r + 1));
        int2 cand = own + int2((int)((seed >> 16) % (uint)(2 * R + 1)) - R, (int)((seed & 0xFFFFu) % (uint)(R + 1)) - R / 2);
        float cc = CandCost(c, cand, lo, hi, hs);
        if (cc < bestC) { bestC = cc; best = cand; }
    }
    int2 sc = c + best;
    bool valid = bestC < 1e8 && sc.x >= 0 && sc.y >= 0 && sc.x < hs.x && sc.y < hs.y;
    float3 colour = valid ? PmColIn.Load(int3(sc, 0)).rgb : PmColIn.Load(int3(c, 0)).rgb;   // EM: the cell takes its match's colour
    OutA[t.xy] = float4(colour, 0);
    OutB[t.xy] = float4((float)(valid ? best.x : own.x), (float)(valid ? best.y : own.y), st.z, st.w);
}

// ------------------------------------------------------------------------------------------------ membrane (seam colour correction)
[numthreads(16, 8, 1)] void ppseed(uint3 t : SV_DispatchThreadID) {
    if (t.x >= (uint)HSize.x || t.y >= (uint)HSize.y) return;
    int2 c = int2(t.xy);
    float3 m = 0; float n = 0;
    [loop] for (int qi = 0; qi < 4; qi++) {
        int2 q = c * 2 + int2(qi & 1, qi >> 1);
        uint kq = NearAt(q);
        if (kq == NONE) continue;
        int rs = 0;
        if (Pre.w > 1.5) { if (RingZ(q, kq, rs) > 0.0) continue; }   // seeds come from clean background only
        [unroll] for (int ni = 0; ni < 4; ni++) {
            int2 g = q + (ni == 0 ? int2(1, 0) : ni == 1 ? int2(-1, 0) : ni == 2 ? int2(0, 1) : int2(0, -1));
            if (NearAt(g) != NONE) continue;
            float4 st = PmStIn.Load(int3(g >> 1, 0));
            if (!IsFilled(st.z) || log2(max(asfloat(kq), 1e-4)) < st.w + log2(0.85)) continue;
            int2 o = int2(round(st.xy));
            bool ok1, ok2;
            float4 c1 = RunCol(q, ok1), c2 = RunCol(q + 2 * o, ok2);
            if (ok1 && ok2) { m += c1.rgb - c2.rgb; n += 1.0; }
        }
    }
    OutA[t.xy] = n > 0 ? float4(clamp(m / n, -0.15, 0.15), 1.0) : float4(0, 0, 0, 0);
}
[numthreads(16, 8, 1)] void ppdown(uint3 t : SV_DispatchThreadID) {
    uint w, h; SrcA.GetDimensions(w, h);
    uint ow = (w + 1) / 2, oh = (h + 1) / 2;
    if (t.x >= ow || t.y >= oh) return;
    float3 acc = 0; float asum = 0;
    [unroll] for (int j = 0; j < 4; j++) {
        int2 q = int2(t.xy) * 2 + int2(j & 1, j >> 1);
        if (q.x >= (int)w || q.y >= (int)h) continue;
        float4 v = SrcA.Load(int3(q, 0));
        acc += v.rgb * v.a; asum += v.a;
    }
    OutA[t.xy] = asum > 0.0 ? float4(acc / asum, min(asum, 1.0)) : float4(0, 0, 0, 0);
}
[numthreads(16, 8, 1)] void ppup(uint3 t : SV_DispatchThreadID) {
    uint w, h; SrcA.GetDimensions(w, h);
    if (t.x >= w || t.y >= h) return;
    float4 v = SrcA.Load(int3(t.xy, 0));
    float2 uv = (float2(t.xy) + 0.5) / float2(w, h);
    float4 up = SrcB.SampleLevel(Bilinear, uv, 0);
    OutA[t.xy] = float4(v.rgb * v.a + up.rgb * (1.0 - v.a), saturate(v.a + up.a * (1.0 - v.a)));
}

// ------------------------------------------------------------------------------------------------ pass 2: the eye
// the vote of the matches around key cell kp: mean colour m, spread v, the cell's own match cen, colour range
bool Vote(int2 kp, float dist, out float3 m, out float v, out float3 cen, out float3 cmin, out float3 cmax) {
    int R = (int)Pre.x;
    float3 acc = 0, acc2 = 0; float ws = 0;
    m = 0; v = 0; cen = 0; cmin = float3(1e9, 1e9, 1e9); cmax = float3(-1e9, -1e9, -1e9);
    bool haveCen = false;
    [loop] for (int dy = -R; dy <= R; dy++) for (int dx = -R; dx <= R; dx++) {
        int2 n = kp + int2(dx, dy);
        float4 st = PmStIn.Load(int3(max(n >> 1, int2(0, 0)), 0));
        if (!IsFilled(st.z)) continue;
        if (st.z < 1.5 && NearAt(n) != NONE) continue;          // a gap half cell, but this key cell is seen
        int2 s = n + 2 * int2(round(st.xy));
        uint ks = NearAt(s);
        if (ks == NONE) continue;
        float ds = asfloat(ks);
        if (ds < dist * 0.85 * 0.9 || ds > dist * 1.35 * 1.1) continue;
        float2 su; if (!DrawnUv(KeyUv(s), ds, su)) continue;
        float3 c = Scene.SampleLevel(Bilinear, su, 0).rgb;
        float w = exp(-(float)(dx * dx + dy * dy) / 8.0);
        acc += c * w; acc2 += c * c * w; ws += w;
        cmin = min(cmin, c); cmax = max(cmax, c);
        if (dx == 0 && dy == 0) { cen = c; haveCen = true; }
    }
    if (ws <= 0.0) return false;
    m = acc / ws;
    v = dot(acc2 / ws - m * m, float3(1, 1, 1)) / 3.0;
    if (!haveCen) cen = m;
    return true;
}
// matched tiles only (the Performance preset): the four nearest tiles' offsets, bilinear weights. A tile's copy counts only when its
// source is seen and at least zthr deep. The gap pixel's own copy is read with the sharp resampler; the border copies the membrane
// uses may be bilinear (low frequency only).
bool TileFill(int2 kp, float zthr, bool sharp, out float3 colour, out float3 cmin, out float3 cmax) {
    float2 tf = (float2(kp) + 0.5) / 32.0 - 0.5;
    int2 t0 = int2(floor(tf)); float2 fr = tf - floor(tf);
    float3 acc = 0; float ws = 0;
    colour = 0; cmin = float3(1e9, 1e9, 1e9); cmax = float3(-1e9, -1e9, -1e9);
    [unroll] for (int j = 0; j < 4; j++) {
        int2 tl = t0 + int2(j & 1, j >> 1);
        if (tl.x < 0 || tl.y < 0 || tl.x >= (int)HSize.z || tl.y >= (int)HSize.w) continue;
        float4 tp = Tiles.Load(int3(tl, 0));
        if (tp.z < 0.5) continue;
        int2 s = kp + int2(round(tp.xy));
        uint ks = NearAt(s);
        if (ks == NONE || asfloat(ks) < zthr) continue;
        float2 su; if (!DrawnUv(KeyUv(s), asfloat(ks), su)) continue;
        float3 c = (sharp ? SharpScene(su).rgb : Scene.SampleLevel(Bilinear, su, 0).rgb) + TileCorr.Load(int3(tl, 0)).rgb;
        float w = ((j & 1) ? fr.x : 1.0 - fr.x) * ((j >> 1) ? fr.y : 1.0 - fr.y) + 1e-3;
        acc += c * w; ws += w; cmin = min(cmin, c); cmax = max(cmax, c);
    }
    if (ws <= 0.0) return false;
    colour = acc / ws;
    return true;
}
// a soft fill from the background beside the gap (when nothing else is valid)
bool SoftFill(float2 uv, int2 kp, int bgDir, int bgDist, float dBg, out float3 colour) {
    float stride = max(1.5, (float)bgDist * 0.35);
    float3 acc = 0; float wsum = 0;
    colour = 0;
    [unroll] for (int j = 0; j < 6; j++) {
        float2 uvT = uv + float2(bgDir * ((float)(bgDist + (int)Mix.x) + j * stride) * KSize.z, 0);
        uint kT = NearAt(int2(uvT * KSize.xy));
        if (kT == NONE) continue;
        float dT = asfloat(kT);
        if (j > 0 && dT < dBg * 0.85) continue;
        float2 s2; if (!DrawnUv(uvT, dT, s2)) continue;
        float w = exp(-0.45 * j);
        acc += w * Scene.SampleLevel(Bilinear, s2, 0).rgb; wsum += w;
    }
    if (wsum <= 0.0) return false;
    colour = acc / wsum;
    return true;
}
// real pixels remembered from earlier frames, projected into this eye
bool MemLookup(float2 uv, float zb, out float3 colour, out float conf) {
    colour = 0; conf = 0;
    float2 msz = float2(Mem.y, Mem.z);
    float tol = 1.0 + OSize.x / msz.x;
    static const float mul8[8] = { 1.0, 1.06, 1.15, 1.3, 1.5, 1.85, 2.5, 4.0 };
    float bestErr = 1e9; float3 bestCol = 0; float bestAge = 0;
    [loop] for (int i = 0; i < 8; i++) {
        float2 su;
        if (!DrawnUv(uv, zb * mul8[i], su)) continue;
        float2 pm = su * msz - 0.5; int2 p0 = int2(floor(pm));
        float3 acc = 0; float ws = 0; float minErr = 1e9; float age = 0;
        [unroll] for (int j = 0; j < 4; j++) {
            int2 q = p0 + int2(j & 1, j >> 1);
            if (q.x < 0 || q.y < 0 || q.x >= (int)msz.x || q.y >= (int)msz.y) continue;
            float4 mc = MemColIn.Load(int3(q, 0));
            if (mc.a < 0.0) continue;
            float qd = MemDistIn.Load(int3(q, 0));
            float2 qo = MemOffIn.Load(int3(q, 0)).xy;
            float2 pu = (float2(q) + 0.5 + qo) / msz;
            float4 pp = float4(pu * float2(2, -2) + float2(-1, 1), ZD.x + ZD.y / max(qd, 1e-6), 1.0);
            float4 oc = mul(pp, DrawnToOther);
            if (oc.w <= 1e-9 || oc.w < 0.85 * zb) continue;     // the point must lie at or behind the gap's background
            float err = length((ClipUv(oc) - uv) * OSize.xy);
            if (err >= tol) continue;
            float w = 1.0 - err / tol;
            acc += mc.rgb * w; ws += w; age = max(age, mc.a); minErr = min(minErr, err);
        }
        if (ws > 0.0 && minErr < bestErr) { bestErr = minErr; bestCol = acc / ws; bestAge = age; if (minErr < 0.3) break; }
    }
    if (bestErr >= 1e8) return false;
    colour = bestCol;
    conf = saturate((1.0 - bestErr / tol) * saturate(1.0 - bestAge / 20.0) * 1.6);
    return conf > 0.0;
}
// YCoCg of a colour, and back (the memory clip works in it: luma and chroma are separate ranges)
float3 ToYCoCg(float3 c) { return float3(0.25 * c.r + 0.5 * c.g + 0.25 * c.b, 0.5 * c.r - 0.5 * c.b, -0.25 * c.r + 0.5 * c.g - 0.25 * c.b); }
float3 FromYCoCg(float3 y) { return float3(y.x + y.y - y.z, y.x + y.z, y.x - y.y - y.z); }
// the colour range of the background strip beside a gap (the six cells past the background's edge, at the background's distance), in YCoCg
bool StripRange(int2 kp, int bgDir, int bgDist, float zb, out float3 lo, out float3 hi) {
    float3 m1 = 0, m2 = 0; float n = 0;
    lo = 0; hi = 0;
    for (int i = 0; i < 6; i++) {
        int2 kq = kp + int2(bgDir * (bgDist + 1 + i), 0);
        uint kk = NearAt(kq);
        if (kk == NONE || asfloat(kk) < 0.85 * zb) continue;
        bool ok; float4 c = RunCol(kq, ok);
        if (!ok) continue;
        float3 y = ToYCoCg(c.rgb);
        m1 += y; m2 += y * y; n += 1.0;
    }
    if (n < 3.0) return false;
    float3 mean = m1 / n, sig = sqrt(max(m2 / n - mean * mean, 1e-6));
    float3 w = max(3.0 * sig, float3(0.06, 0.06, 0.06));
    lo = mean - w; hi = mean + w;
    return true;
}
// the membrane of a tile fill (0.6.94, the Performance preset): the copy meets the real background at every background border.
// Row border: the median of the picture at the background cells 2, 3, 4 past its edge against the copy at the gap's cell next to it,
// weight 1 / bgDist. Up and down: steps 1, 2, 3, 4, 6, 8, 12, 16, 24, 32 until a seen cell (skipped when nearer than zthr - the object -
// or when the cell before it is not a gap); the real colour 2 cells further in against the copy at the cell before it, weight 1 / step.
// A border counts only with a valid copy and a summed difference under 0.3. fill = copy + (sum w d / sum w) * min(1, 3 * sum w).
bool BorderDiff(float3 real, int2 kc, float zthr, out float3 d) {
    float3 e, cmn, cmx;
    d = float3(0, 0, 0);
    if (!TileFill(kc, zthr, false, e, cmn, cmx)) return false;
    d = real - e;
    return (abs(d.r) + abs(d.g) + abs(d.b)) < 0.3;
}
float3 Membrane(int2 kp, int bgDir, int bgDist, float zthr, inout float3 lo, inout float3 hi) {
    float3 sumd = 0; float sumw = 0;
    // row border
    {
        float3 a = 0, b = 0, c = 0; int n = 0;
        for (int i = 0; i < 3; i++) {
            int2 kq = kp + int2(bgDir * (bgDist + 2 + i), 0);
            uint kk = NearAt(kq);
            if (kk == NONE || asfloat(kk) < zthr) continue;
            bool ok; float4 col = RunCol(kq, ok);
            if (!ok) continue;
            if (n == 0) a = col.rgb; else if (n == 1) b = col.rgb; else c = col.rgb;
            n++;
        }
        if (n > 0) {
            float3 tgt = n == 1 ? a : (n == 2 ? 0.5 * (a + b) : max(min(a, b), min(max(a, b), c)));   // the median of the three
            lo = min(lo, tgt); hi = max(hi, tgt);        // the history's clip range: the copy's colours here + tgt
            float3 d;
            if (BorderDiff(tgt, kp + int2(bgDir * (bgDist - 1), 0), zthr, d)) { float w = 1.0 / max((float)bgDist, 1.0); sumd += w * d; sumw += w; }
        }
    }
    // up and down
    static const int kStep[10] = { 1, 2, 3, 4, 6, 8, 12, 16, 24, 32 };
    for (int dir = -1; dir <= 1; dir += 2) {
        bool found = false;
        for (int i = 0; i < 10 && !found; i++) {
            int2 q = kp + int2(0, dir * kStep[i]);
            if (q.y < 0 || q.y >= (int)KSize.y) { found = true; continue; }
            uint kk = NearAt(q);
            if (kk == NONE) continue;
            found = true;
            if (asfloat(kk) < zthr) continue;                           // the object
            int2 before = kp + int2(0, dir * (kStep[i] - 1));           // the cell before it must be a gap
            if (i > 0 && NearAt(before) != NONE) continue;
            bool ok; float4 col = RunCol(q + int2(0, dir * 2), ok);
            if (!ok) continue;
            float3 d;
            if (BorderDiff(col.rgb, before, zthr, d)) { float w = 1.0 / (float)kStep[i]; sumd += w * d; sumw += w; }
        }
    }
    if (sumw <= 0.0) return float3(0, 0, 0);
    return (sumd / sumw) * min(1.0, 3.0 * sumw);
}
// 0.9 edge fill (framework 0.6.97, 49.10): a rebuilt eye's pixel whose ray at infinity leaves the drawn view's side. The band just
// inside the side is repeated outward in the same direction (no mirror), softened with the distance, its low frequency shifted to the
// rim's and cross-faded from the rim over the first 12 px. Above / below the view the rim row.
bool InfUv(float2 uv, out float2 s) {
    float4 p = float4(uv * float2(2, -2) + float2(-1, 1), Z.x, 1.0);
    float4 dc = mul(p, OtherToDrawn);
    s = float2(0, 0);
    if (dc.w <= 1e-9) return false;
    s = ClipUv(dc);
    return true;
}
float3 LowPass(float2 uv, float2 px) {
    float2 u = float2(saturate(uv.x), saturate(uv.y));
    float3 c = Scene.SampleLevel(Bilinear, u, 0).rgb;
    c += Scene.SampleLevel(Bilinear, saturate(u + float2(px.x, 0)), 0).rgb;
    c += Scene.SampleLevel(Bilinear, saturate(u - float2(px.x, 0)), 0).rgb;
    c += Scene.SampleLevel(Bilinear, saturate(u + float2(0, px.y)), 0).rgb;
    c += Scene.SampleLevel(Bilinear, saturate(u - float2(0, px.y)), 0).rgb;
    return c * 0.2;
}
bool EdgeFill(float2 uv, out float3 col) {
    col = float3(0, 0, 0);
    float2 s;
    if (!InfUv(uv, s)) return false;
    if (s.x >= 0.0 && s.x <= 1.0 && s.y >= 0.0 && s.y <= 1.0) return false;
    uint sw, sh; Scene.GetDimensions(sw, sh);
    float2 px = float2(16.0 / sw, 16.0 / sh);
    float sy = saturate(s.y);
    float over = s.x < 0.0 ? -s.x : (s.x > 1.0 ? s.x - 1.0 : 0.0);
    float side = s.x < 0.0 ? 0.0 : 1.0;
    float2 rimUv = float2(side, sy);
    float3 rim = Scene.SampleLevel(Bilinear, rimUv, 0).rgb;
    if (over <= 0.0) { col = rim; return true; }
    // the strip's width: how far the outermost column of this row goes past the side
    float2 s0, s1; float o0 = 0.0, o1 = 0.0;
    if (InfUv(float2(0.0, uv.y), s0)) o0 = max(-s0.x, s0.x - 1.0);
    if (InfUv(float2(1.0, uv.y), s1)) o1 = max(-s1.x, s1.x - 1.0);
    float P = max(max(o0, o1) * 1.03, 0.02);
    float f = over - floor(over / P) * P;
    float xs = side > 0.5 ? 1.0 - P + f : P - f;
    float radius = 0.1 * over;
    float3 c = float3(0, 0, 0);
    [unroll] for (int i = 0; i < 7; i++) c += Scene.SampleLevel(Bilinear, float2(saturate(xs + (i - 3) * radius / 3.0), sy), 0).rgb;
    c *= 1.0 / 7.0;
    float3 lpRim = LowPass(rimUv, px), lpBand = LowPass(float2(side > 0.5 ? 1.0 - P : P, sy), px);
    float q = 1.0 - f / P;
    c += (lpRim - lpBand) * (q * q);
    float t = saturate(f * (float)sw / 12.0);
    col = lerp(rim, c, t * t * (3.0 - 2.0 * t));
    return true;
}
// the previous frame's fill, resampled sharply (clamped Catmull-Rom, 5 bilinear taps) - the history is read at a sub-pixel offset every frame
float3 SharpFill(float2 uv) {
    uint sw, sh; FillPrev.GetDimensions(sw, sh);
    float2 sz = float2(sw, sh);
    float2 pos = uv * sz;
    float2 t1 = floor(pos - 0.5) + 0.5;
    float2 f = pos - t1;
    float2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
    float2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
    float2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
    float2 w3 = f * f * (-0.5 + 0.5 * f);
    float2 w12 = w1 + w2;
    float2 o12 = w2 / max(w12, 1e-5);
    float2 tA = (t1 - 1.0) / sz, tB = (t1 + 2.0) / sz, tC = (t1 + o12) / sz;
    float3 r = FillPrev.SampleLevel(Bilinear, float2(tC.x, tC.y), 0).rgb * (w12.x * w12.y)
             + FillPrev.SampleLevel(Bilinear, float2(tA.x, tC.y), 0).rgb * (w0.x * w12.y)
             + FillPrev.SampleLevel(Bilinear, float2(tB.x, tC.y), 0).rgb * (w3.x * w12.y)
             + FillPrev.SampleLevel(Bilinear, float2(tC.x, tA.y), 0).rgb * (w12.x * w0.y)
             + FillPrev.SampleLevel(Bilinear, float2(tC.x, tB.y), 0).rgb * (w12.x * w3.y);
    float ws = w12.x * w12.y + w0.x * w12.y + w3.x * w12.y + w12.x * w0.y + w12.x * w3.y;
    return r / max(ws, 1e-5);
}
groupshared uint gsCnt[5];
groupshared uint gsNear;
[numthreads(16, 8, 1)] void res2(uint3 t : SV_DispatchThreadID, uint gi : SV_GroupIndex, uint3 gid : SV_GroupID) {
    if (gi < 5) gsCnt[gi] = 0;
    if (gi == 0) {   // 49.9: is a gap tile within reach R + 17 key cells of this group? (only then the blend input is written here)
        uint nr = 1u;
        if (Edge2.x > 0.5 || Edge2.y > 0.5) {
            nr = 0u;
            int R = min((int)round(6.0 * max(1.0, Mix.z)), 18) + 40;   // + the blend pass's apron and its reach (FinishNear)
            float2 u0 = float2(gid.xy * uint2(16, 8)) * OSize.zw, u1 = float2(gid.xy * uint2(16, 8) + uint2(16, 8)) * OSize.zw;
            int2 k0 = int2(u0 * KSize.xy) - R, k1 = int2(u1 * KSize.xy) + R;
            int2 t0 = max(k0 >> 5, int2(0, 0)), t1 = min(k1 >> 5, int2((int)HSize.z, (int)HSize.w) - 1);
            for (int ty = t0.y; ty <= t1.y && nr == 0u; ty++)
                for (int tx = t0.x; tx <= t1.x && nr == 0u; tx++)
                    if (Tiles.Load(int3(tx, ty, 0)).w > 0.5) nr = 1u;
        }
        gsNear = nr;
    }
    GroupMemoryBarrierWithGroupSync();
    bool live = t.x < (uint)OSize.x && t.y < (uint)OSize.y;
    if ((Edge2.y > 0.5 && Edge2.y < 1.5 && gsNear != 0u) || (Edge2.y > 1.5 && gsNear == 0u)) live = false;   // recon_resolve_split: the other dispatch's group
    int kind = 0;   // 0 seen, 1 gap from the vote / tiles / soft, 2 gap from remembered real pixels, 3 nothing
    bool isUi = false;
    if (live) {
        float2 uv = (float2(t.xy) + 0.5) * OSize.zw;
        int2 kp = min(int2(uv * KSize.xy), int2(KSize.xy) - 1);
        uint key = NearAt(kp);
        int bgDir = 0, bgDist = 0, fgDist = 0; float zb = 0, zf = 0;
        bool gap = false;
        bool edgeFill = false; float3 edgeCol = float3(0, 0, 0);
        if (key == NONE) {
            if (Edge.x > 0.5 && EdgeFill(uv, edgeCol)) { edgeFill = true; key = asuint(1e30); }   // the ray at infinity leaves the drawn view: not a gap
            else {
                uint ck;
                int code = FindGap2(kp, bgDir, bgDist, fgDist, zb, zf, ck);
                if (code == 1) key = ck;
                else if (code == 2 || code == 3) { key = ck; gap = true; }
                else { key = asuint(1e30); gap = true; kind = 3; }
            }
        }
        float dist = asfloat(key);
        float2 su;
        bool seen = DrawnUv(uv, dist >= 1e29 ? 1e30 : dist, su);
        float3 col;
        float fillDist = 0;                         // > 0: this pixel is fill, at that distance
        float3 cmin = float3(1e9, 1e9, 1e9), cmax = float3(-1e9, -1e9, -1e9);
        bool haveRange = false;
        float bgZ = 0.0; int bgD = 0; bool keptHist = false;
        if (!gap) {
            col = seen ? SharpScene(su).rgb : Scene.SampleLevel(Bilinear, saturate(su), 0).rgb;
            if (edgeFill) col = edgeCol;
            // steady edges (0.6.64, only when the depth is smaller than the picture - an upscaler / render scale): at a depth step in the key map
            // last frame's pixel, reprojected, is blended in (0.7) when its distance is one of those around, clipped to the colours the picture
            // has at those distances - only colours this pixel could have, no ghost
            if (seen && !edgeFill && Edge.w > 0.5 && Mix.y > 0.5 && Z.w > 0.5) {
                uint kl = NearAt(kp - int2(1, 0)), kr = NearAt(kp + int2(1, 0));
                float dl = kl != NONE ? asfloat(kl) : dist, dr = kr != NONE ? asfloat(kr) : dist;
                if (abs(dl - dist) > 0.04 * dist || abs(dr - dist) > 0.04 * dist) {
                    float4 pp = float4(uv * float2(2, -2) + float2(-1, 1), Z.x + Z.y / max(dist, 1e-6), 1.0);
                    float4 pc = mul(pp, OtherToPrev);
                    if (pc.w > 1e-9) {
                        float2 pu = ClipUv(pc);
                        if (pu.x >= 0.0 && pu.y >= 0.0 && pu.x < 1.0 && pu.y < 1.0) {
                            float4 fp = FillPrev.Load(int3(int2(pu * OSize.xy), 0));
                            float dp = -fp.a, r = pc.w;
                            bool match = fp.a < 0.0 && (abs(dp - r * dist) <= 0.04 * r * dist || abs(dp - r * dl) <= 0.04 * r * dl || abs(dp - r * dr) <= 0.04 * r * dr);
                            if (match) {
                                float3 lo = col, hi = col; bool o1, o2;
                                float4 c1 = RunCol(kp - int2(1, 0), o1), c2 = RunCol(kp + int2(1, 0), o2);
                                if (o1) { lo = min(lo, c1.rgb); hi = max(hi, c1.rgb); }
                                if (o2) { lo = min(lo, c2.rgb); hi = max(hi, c2.rgb); }
                                col = lerp(col, clamp(fp.rgb, lo, hi), 0.7);
                            }
                        }
                    }
                }
            }
            int side = 0; float rz = 0.0;
            if (seen) rz = RingZ(kp, key, side);
            if (rz > 0.0 && Pre.w < 1.5) {   // boundary cleaning (0.6.65): the background pixel beside a gap takes the colour 2 cells further out (same surface)
                int2 k2 = kp - int2(2 * side, 0);
                uint kk2 = NearAt(k2);
                if (kk2 != NONE && abs(asfloat(kk2) - dist) <= 0.03 * dist) {
                    bool ok2; float4 c2 = RunCol(k2, ok2);
                    if (ok2) col = c2.rgb;
                }
            } else if (rz > 0.0) {   // the 1-pixel ring beside a gap takes the fill too (an outline otherwise)
                float3 m, cen, c0, c1; float v;
                if (Vote(kp, rz, m, v, cen, c0, c1)) {
                    float3 f = m + saturate(Mix.w * v / (v + 0.0064)) * (cen - m);
                    f += Memb.SampleLevel(Bilinear, uv, 0).rgb;
                    col = f; fillDist = rz; kind = 1; cmin = c0; cmax = c1; haveRange = true; bgZ = rz; bgD = 1;
                }
            }
        } else if (kind != 3) {
            bool done = false;
            float3 f = float3(0, 0, 0);
            bgZ = zb; bgD = bgDist;
            float3 memCol; float memConf = 0;
            if (Misc.w > 0.5 && MemLookup(uv, zb, memCol, memConf)) { /* blended below */ }
            if (Pre.w > 1.5) {
                float3 m, cen, c0, c1; float v;
                if (Vote(kp, dist, m, v, cen, c0, c1)) {
                    f = m + saturate(Mix.w * v / (v + 0.0064)) * (cen - m);
                    f += Memb.SampleLevel(Bilinear, uv, 0).rgb;
                    cmin = c0; cmax = c1; haveRange = true; done = true;
                }
            } else if (Pre.w > 0.5) {
                float3 c0, c1;
                // the copy's source must be at least zthr deep: no object distance -> 0.85 of the background; otherwise the geometric mean when
                // the object is much nearer, else 0.85 of the nearer of the two
                float zthr = (zb <= 0.0) ? 0.85 * dist : (fgDist == 0 ? 0.85 * zb : (zf < 0.7 * zb ? sqrt(zb * zf) : 0.85 * min(zb, zf)));
                if (TileFill(kp, zthr, true, f, c0, c1)) {
                    f += Membrane(kp, bgDir, bgDist, zthr, c0, c1);
                    cmin = c0; cmax = c1; haveRange = true; done = true;
                }
            }
            if (!done) done = SoftFill(uv, kp, bgDir, bgDist, dist, f);
            col = done ? f : (seen ? Scene.SampleLevel(Bilinear, saturate(su), 0).rgb : float3(0, 0, 0));
            fillDist = dist; kind = 1;
            if (memConf > 0.0) {
                float3 slo, shi;   // the remembered colour is clipped into the background strip's YCoCg range (3 sigma, at least 0.06)
                if (StripRange(kp, bgDir, bgDist, zb, slo, shi)) memCol = FromYCoCg(clamp(ToYCoCg(memCol), slo, shi));
                col = lerp(col, memCol, memConf); kind = 2;
            }
        } else {
            col = Scene.SampleLevel(Bilinear, saturate(su), 0).rgb;
        }
        // steady infill: last frame's fill, reprojected, clipped to the colours the fill has now
        if (fillDist > 0.0 && Mix.y > 0.5 && Z.w > 0.5 && haveRange && kind == 1) {
            float4 pp = float4(uv * float2(2, -2) + float2(-1, 1), Z.x + Z.y / max(fillDist, 1e-6), 1.0);
            float4 pc = mul(pp, OtherToPrev);
            if (pc.w > 1e-9) {
                float2 pu = ClipUv(pc);
                if (pu.x >= 0.0 && pu.y >= 0.0 && pu.x < 1.0 && pu.y < 1.0) {
                    float4 fp = FillPrev.Load(int3(int2(pu * OSize.xy), 0));
                    float dPrev = pc.w * fillDist;   // the point's distance along last frame's eye axis (pc.w is the ratio: never compare with fillDist itself)
                    if (fp.a > 0.0 && abs(fp.a - dPrev) <= 0.04 * dPrev) {
                        float wgt = 0.9 * saturate(((float)bgD + 1.0) / 3.0);
                        float3 hc = SharpFill(pu);
                        col = lerp(col, clamp(hc, cmin - 0.12, cmax + 0.12), wgt);   // clipped to the copy's colours here, widened by 0.12 (0.6.94)
                        keptHist = true;
                    }
                }
            }
        }
        // the UI: what the UI changed in the drawn picture, at this eye's UI place (copied, never moved by depth)
        float4 outc = float4(col, 1.0);
        if (Opt.y > 0.5) {
            float2 dp = UiC.xy + (t.xy + 0.5 - UiC.zw) * Opt.w;
            uint fw, fh; Final.GetDimensions(fw, fh);
            if (dp.x >= 0 && dp.y >= 0 && dp.x < (float)fw && dp.y < (float)fh) {
                int3 q = int3(dp, 0);
                float4 f = Final.Load(q), d4 = abs(f - Scene.Load(q));
                if (max(max(d4.r, d4.g), max(d4.b, d4.a)) > Opt.z) { outc = f; isUi = true; }
            }
        }
        if (Opt.x > 0.5 && Opt.x < 1.5 && !isUi) {   // debug 1: gaps tinted - orange filled, blue real pixels, red nothing
            float3 tint = kind == 1 ? float3(1, 0.45, 0) : kind == 2 ? float3(0.1, 0.4, 1) : kind == 3 ? float3(1, 0, 0) : outc.rgb;
            outc.rgb = lerp(outc.rgb, tint, 0.6);
        } else if (Opt.x > 1.5 && !isUi) {
            float g = dot(outc.rgb, float3(0.299, 0.587, 0.114)); outc.rgb = float3(g, g, g);
        }
        MemOffOut[t.xy] = outc;                         // the eye image (u6), every group
        if (gsNear != 0u) OutA[t.xy] = outc;            // the blend input, only near gaps
        float sd = isUi ? 0.0 : (kind == 3 ? 0.0 : (fillDist > 0.0 ? fillDist : -min(dist, 1e29)));
        if (gsNear != 0u || Edge.w > 0.5) OutB[t.xy] = float4(outc.rgb, sd);   // 49.9: the fill / history only near gaps (steady edges need it everywhere)
        uint o;
        InterlockedAdd(gsCnt[0], 1u, o);
        if (kind == 1 || kind == 3) InterlockedAdd(gsCnt[1], 1u, o);
        if (kind == 2) InterlockedAdd(gsCnt[2], 1u, o);
        if (isUi) InterlockedAdd(gsCnt[3], 1u, o);
        if (keptHist) InterlockedAdd(gsCnt[4], 1u, o);
    }
    GroupMemoryBarrierWithGroupSync();
    if (gi < 4 && gsCnt[gi] != 0u) { uint o; Counters.InterlockedAdd(gi * 4, gsCnt[gi], o); }
    if (gi == 4 && gsCnt[4] != 0u) { uint o; Counters.InterlockedAdd(24, gsCnt[4], o); }   // fill pixels that kept last frame's fill
}

// ------------------------------------------------------------------------------------------------ pass 3: finish
groupshared uint gsF[8][72];   // 20 cells of apron on each side: the widest blend band (blend 3) reaches 18 cells
uint FillFlag(int2 q) {
    if (q.x < 0 || q.y < 0 || q.x >= (int)OSize.x || q.y >= (int)OSize.y) return 0u;
    float a = FillCurIn.Load(int3(q, 0)).a;
    return a > 0.0 ? 1u : (a == 0.0 ? 2u : 0u);   // 1 fill, 0 real, 2 UI / nothing
}
groupshared uint gsFNear;
// 0.9.4: is a gap tile within the band's reach of this group? (49.9: the blend pass skips groups with no gap tile within R + 1 cells -
// here R + 21, the apron included). The test is one thread's; the loads below are skipped without it.
uint FinishNear(uint3 gid) {
    if (Edge2.x < 0.5) return 1u;
    int R = min((int)round(6.0 * max(1.0, Mix.z)), 18) + 21;
    float2 u0 = float2(gid.xy * uint2(32, 8)) * OSize.zw, u1 = float2(gid.xy * uint2(32, 8) + uint2(32, 8)) * OSize.zw;
    int2 k0 = int2(u0 * KSize.xy) - R, k1 = int2(u1 * KSize.xy) + R;
    int2 t0 = max(k0 >> 5, int2(0, 0)), t1 = min(k1 >> 5, int2((int)HSize.z, (int)HSize.w) - 1);
    uint nr = 0u;
    for (int ty = t0.y; ty <= t1.y && nr == 0u; ty++)
        for (int tx = t0.x; tx <= t1.x && nr == 0u; tx++)
            if (Tiles.Load(int3(tx, ty, 0)).w > 0.5) nr = 1u;
    return nr;
}
[numthreads(32, 8, 1)] void finish(uint3 t : SV_DispatchThreadID, uint3 gt : SV_GroupThreadID, uint3 gid : SV_GroupID, uint gi : SV_GroupIndex) {
    if (gi == 0) gsFNear = FinishNear(gid);
    GroupMemoryBarrierWithGroupSync();
    int2 p = int2(t.xy);
    bool nearGap = gsFNear != 0u;
    bool live = p.x < (int)OSize.x && p.y < (int)OSize.y;
    gsF[gt.y][gt.x + 20] = (live && nearGap) ? FillFlag(p) : 2u;
    if (gt.x < 20) gsF[gt.y][gt.x] = nearGap ? FillFlag(p + int2(-20, 0)) : 2u;
    if (gt.x >= 12) gsF[gt.y][gt.x + 40] = nearGap ? FillFlag(p + int2(20, 0)) : 2u;
    GroupMemoryBarrierWithGroupSync();
    if (!live) return;
    if (!nearGap && Edge2.x > 0.5) return;            // no gap tile in reach: the resolve already wrote the eye image here
    uint own = gsF[gt.y][gt.x + 20];
    if (own == 2u && Edge2.x > 0.5) return;      // UI / nothing: the resolve's value stands
    float3 c0 = BigIn.Load(int3(p, 0)).rgb;
    float3 col = c0;
    if (own != 2u) {
        // blend band (framework 0.6.97, 49.8): across the fill's edge, strongest at the edge. Blend slider b, infill detail:
        //   R = round(6 * max(1, b)) cells into the background, Rin = 3 into the fill, s = min(0.3 b, 0.9)
        //   fill: the nearest real pixel i cells away (i <= 3): w = s (1 - detail) (1 - (i - 1) / 3)
        //   background: the nearest gap i cells away (i <= R):  w = s (1 - (i - 0.5) / (R + 0.5))
        float b = Mix.z;
        float s = min(0.3 * b, 0.9);
        int R = min((int)round(6.0 * max(1.0, b)), 18);
        float dmin = 99.0;
        [unroll] for (int d = 1; d <= 18; d++) {
            uint l = gsF[gt.y][gt.x + 20 - d], r = gsF[gt.y][gt.x + 20 + d];
            if ((l != own && l != 2u) || (r != own && r != 2u)) { dmin = min(dmin, (float)d); }
        }
        float strength = 0.0;
        if (own == 1u) { if (dmin <= 3.0) strength = s * (1.0 - Mix.w) * (1.0 - (dmin - 1.0) / 3.0); }
        else if (dmin <= (float)R) strength = s * (1.0 - (dmin - 0.5) / ((float)R + 0.5));
        if (strength > 0.001) {
            float d0 = abs(FillCurIn.Load(int3(p, 0)).a);
            float3 acc = c0; float ws = 1.0;
            [unroll] for (int k = 1; k <= 4; k++) {
                [unroll] for (int sd = 0; sd < 2; sd++) {
                    int2 q = p + int2(sd == 0 ? -k : k, 0);
                    if (q.x < 0 || q.x >= (int)OSize.x) continue;
                    float4 fc = FillCurIn.Load(int3(q, 0));
                    if (fc.a == 0.0) continue;                       // UI / nothing
                    if (d0 > 0.0 && abs(fc.a) < d0 * 0.97) continue; // a nearer surface: not blended in
                    float3 c = BigIn.Load(int3(q, 0)).rgb;
                    float3 dc = c - c0;
                    float w = exp(-dot(dc, dc) * 30.0) * (1.0 - 0.2 * (float)k);
                    acc += c * w; ws += w;
                }
            }
            col = lerp(c0, acc / ws, strength);
        } else if (Edge2.x > 0.5) return;   // not a band pixel: the resolve already wrote the eye image here
        if (Misc.x > 0.001) {   // contrast-adaptive sharpening, clamped to the neighbours' range (no halos)
            float3 n1 = BigIn.Load(int3(min(p + int2(1, 0), int2(OSize.xy) - 1), 0)).rgb;
            float3 n2 = BigIn.Load(int3(max(p - int2(1, 0), int2(0, 0)), 0)).rgb;
            float3 n3 = BigIn.Load(int3(min(p + int2(0, 1), int2(OSize.xy) - 1), 0)).rgb;
            float3 n4 = BigIn.Load(int3(max(p - int2(0, 1), int2(0, 0)), 0)).rgb;
            float3 avg = 0.25 * (n1 + n2 + n3 + n4);
            float3 mn = min(min(min(n1, n2), min(n3, n4)), col), mx = max(max(max(n1, n2), max(n3, n4)), col);
            col = clamp(col + Misc.x * 0.8 * (col - avg), mn, mx);
        }
    }
    OutA[t.xy] = float4(col, 1.0);
}
)HLSL";
