#include <algorithm>
// Settings (resonancevr_config.txt) and the in-headset VR menu (vrkit: Dear ImGui into an off-screen texture, the same
// panel as DXMDVR). Insert or hold L3 + R3 opens it. Options edit g_set; the config file is rewritten on close.
#include <windows.h>
#include <d3d11.h>
#include <cmath>
#include <cstdio>
#include <string>
#include "log.h"
#include "config.h"
#include "settings.h"
#include "camera.h"
#include "game.h"
#include "version.h"
#include "vrkit_options.h"
#include "vrkit_menu.h"
#include "xrbridge/client.h"

extern std::wstring g_gameDir;
extern ID3D11Device* g_dev11;
extern ID3D11DeviceContext* g_ctx11;
void XrSetMode(int mode);
void XrRequestRecenter();
void SmoothingSet(const std::string& m);
void FpsLimitSet(const std::string& v);
void UiSplitSet();

VrSettings g_set;
static bool g_menuInit = false;
static float g_fps = 0;

int ModeFromString(const std::string& m) { return m == "head" ? VRMODE_HEAD : m == "screen" ? VRMODE_SCREEN : (m == "aer" || m == "stereo") ? VRMODE_STEREO : (m == "recon" || m == "afw") ? VRMODE_RECON : VRMODE_SYNCED; }
static const char* ModeKey(int m) { return m == VRMODE_HEAD ? "head" : m == VRMODE_SCREEN ? "screen" : m == VRMODE_STEREO ? "aer" : m == VRMODE_RECON ? "recon" : "synced"; }

void SettingsLoad() {
    VrSettings d;
    g_set.vrMode = ConfigStr("vr_mode", d.vrMode.c_str());
    if (g_set.vrMode == "stereo") g_set.vrMode = "aer";
    g_set.syncSubmit = ConfigStr("sync_submit", d.syncSubmit.c_str());
    g_set.syncLag = ConfigInt("sync_lag", d.syncLag);
    g_set.syncHold = ConfigFloat("sync_hold", d.syncHold);
    g_set.ui2d = ConfigBool("ui_2d", d.ui2d);
    g_set.symmetricView = ConfigBool("symmetric_view", d.symmetricView);
    g_set.wideCull = ConfigBool("wide_cull", d.wideCull);
    g_set.submitView = ConfigStr("submit_view", d.submitView.c_str()); if (g_set.submitView != "rendered") g_set.submitView = "headset";
    g_set.flatPauseMenus = ConfigBool("flat_pause_menus", d.flatPauseMenus);
    // 0.6.11: stereo reconstruction always draws the head-centre view and rebuilds both eyes (the left / alternate
    // drawn views were removed: misaligned on canted headsets, flashing history fill)
    g_set.reconEye = "centre"; g_set.reconHistory = false; g_set.reconShared = false;
    g_set.reconGapReach = ConfigInt("recon_gap_reach", d.reconGapReach);
    g_set.reconDepth = ConfigStr("recon_depth", d.reconDepth.c_str());
    if (g_set.reconDepth != "game" && g_set.reconDepth != "flip") g_set.reconDepth = "auto";
    g_set.reconDebug = ConfigInt("recon_debug", d.reconDebug);
    g_set.reconFill = ConfigStr("recon_fill", d.reconFill.c_str());
    if (g_set.reconFill == "seamless") g_set.reconFill = "history";   // the older default value: the new infill takes its place ("classic" is the old method)
    if (g_set.reconFill != "history" && g_set.reconFill != "patch" && g_set.reconFill != "classic" && g_set.reconFill != "soft" &&
        g_set.reconFill != "clone" && g_set.reconFill != "stretch" && g_set.reconFill != "scatter") g_set.reconFill = "history";
    g_set.reconPreset = ConfigStr("recon_preset", ConfigStr("recon_infill_preset", d.reconPreset.c_str()).c_str());   // recon_infill_preset: the framework's name for it
    if (g_set.reconPreset != "performance" && g_set.reconPreset != "quality") g_set.reconPreset = "balanced";
    g_set.reconView = ConfigStr("recon_view", d.reconView.c_str());
    if (g_set.reconView != "headset" && g_set.reconView != "wide") g_set.reconView = "eye";
    g_set.reconEyeCover = ConfigFloat("recon_eye_cover", d.reconEyeCover);
    if (g_set.reconEyeCover < 0.f) g_set.reconEyeCover = 0.f; if (g_set.reconEyeCover > 1.f) g_set.reconEyeCover = 1.f;
    g_set.reconHudSplit = ConfigBool("recon_hud_split", d.reconHudSplit);
    g_set.reconResolveSplit = ConfigBool("recon_resolve_split", d.reconResolveSplit);
    g_set.reconEdgeFill = ConfigBool("recon_edge_fill", d.reconEdgeFill);
    g_set.fovEffects = ConfigStr("fov_effects", d.fovEffects.c_str());
    if (g_set.fovEffects != "off") g_set.fovEffects = "outer";
    g_set.fovReconAuto = ConfigBool("fov_recon_auto", d.fovReconAuto);
    g_set.reconSteady = ConfigBool("recon_fill_steady", d.reconSteady);
    g_set.reconEdgePixels = ConfigBool("recon_edge_pixels", d.reconEdgePixels);
    g_set.reconNearLimit = ConfigFloat("recon_near_limit", d.reconNearLimit);
    if (g_set.reconNearLimit < 0.f) g_set.reconNearLimit = 0.f; if (g_set.reconNearLimit > 3.f) g_set.reconNearLimit = 3.f;
    g_set.reconSharpen = ConfigFloat("recon_sharpen", d.reconSharpen);
    if (g_set.reconSharpen < 0.f) g_set.reconSharpen = 0.f; if (g_set.reconSharpen > 1.f) g_set.reconSharpen = 1.f;
    g_set.reconBlend = ConfigFloat("recon_infill_blend", d.reconBlend);
    if (g_set.reconBlend < 0.f) g_set.reconBlend = 0.f; if (g_set.reconBlend > 3.f) g_set.reconBlend = 3.f;
    g_set.reconDetail = ConfigFloat("recon_infill_detail", d.reconDetail);
    if (g_set.reconDetail < 0.f) g_set.reconDetail = 0.f; if (g_set.reconDetail > 1.f) g_set.reconDetail = 1.f;
    g_set.reconEdgeGuard = ConfigInt("recon_edge_guard", d.reconEdgeGuard);
    g_set.reconFootprint = ConfigBool("recon_fast_footprint", d.reconFootprint);
    g_set.paceLock = ConfigBool("pace_lock", d.paceLock);
    g_set.uiEyeNext = ConfigBool("ui_eye_next", d.uiEyeNext);
    g_set.uiConverge = ConfigBool("ui_converge", d.uiConverge);
    g_set.renderResolution = ConfigStr("render_resolution", d.renderResolution.c_str());
    g_set.renderScale = ConfigFloat("render_scale", d.renderScale);
    g_set.uiTarget = ConfigStr("ui_target", d.uiTarget.c_str());
    g_set.renderDensity = ConfigStr("render_density", d.renderDensity.c_str());
    g_set.eyeAspect = ConfigStr("eye_aspect", d.eyeAspect.c_str());
    g_set.renderMaxSide = ConfigInt("render_max_side", d.renderMaxSide);
    g_set.worldScale = ConfigFloat("world_scale", d.worldScale);
    g_set.unitsPerMetre = ConfigFloat("units_per_metre", d.unitsPerMetre);
    g_set.swapEyes = ConfigBool("swap_eyes", d.swapEyes);
    g_set.frameDelay = ConfigInt("aer_frame_delay", d.frameDelay);
    g_set.ipdScale = ConfigFloat("ipd_scale", d.ipdScale);
    g_set.cameraReprojection = ConfigBool("camera_reprojection", d.cameraReprojection);
    g_set.cullMargin = ConfigFloat("cull_margin", d.cullMargin);
    g_set.reconShiftH = ConfigFloat("recon_align_h", d.reconShiftH); g_set.reconShiftV = ConfigFloat("recon_align_v", d.reconShiftV);
    g_set.aerShiftH = ConfigFloat("aer_align_h", d.aerShiftH); g_set.aerShiftV = ConfigFloat("aer_align_v", d.aerShiftV);
    g_set.reconParallax = ConfigFloat("recon_parallax", d.reconParallax);
    g_set.edgeFill = ConfigBool("edge_fill", d.edgeFill);
    g_set.edgeFillMargin = ConfigFloat("edge_fill_margin", d.edgeFillMargin);
    if (!(g_set.edgeFillMargin >= 0.f)) g_set.edgeFillMargin = 0.f; if (g_set.edgeFillMargin > 0.2f) g_set.edgeFillMargin = 0.2f;
    g_set.viewWidth = ConfigFloat("view_width", d.viewWidth); g_set.viewHeight = ConfigFloat("view_height", d.viewHeight);
    g_set.decoupledPitch = ConfigBool("decoupled_pitch", d.decoupledPitch);
    g_set.headAim = ConfigStr("head_aim", d.headAim.c_str());
    g_set.headAimSmooth = ConfigFloat("head_aim_smoothing", d.headAimSmooth);
    g_set.headAimTarget = ConfigBool("head_aim_target", d.headAimTarget);
    g_set.headAimOrigin = ConfigStr("head_aim_origin", d.headAimOrigin.c_str());
    g_set.offsetStepCm = ConfigFloat("offset_step_cm", d.offsetStepCm);
    if (!(g_set.offsetStepCm >= 1.f && g_set.offsetStepCm <= 30.f)) g_set.offsetStepCm = 3.f;
    g_set.camOffsetX = ConfigFloat("camera_offset_x", 0.f);
    g_set.camOffsetY = ConfigFloat("camera_offset_y", 0.f);
    g_set.camOffsetZ = ConfigFloat("camera_offset_z", 0.f);
    g_set.cameraAxes = ConfigStr("camera_axes", d.cameraAxes.c_str());
    g_set.panelLayers = ConfigStr("panel_layers", d.panelLayers.c_str());
    g_set.forceWindowed = ConfigBool("force_windowed", d.forceWindowed);
    g_set.firstPerson = ConfigBool("first_person", d.firstPerson);
    g_set.fpOffsetX = ConfigFloat("fp_offset_x", d.fpOffsetX);
    g_set.fpOffsetY = ConfigFloat("fp_offset_y", d.fpOffsetY);
    g_set.fpOffsetZ = ConfigFloat("fp_offset_z", d.fpOffsetZ);
    g_set.fpSmooth = ConfigFloat("fp_smooth", d.fpSmooth);
    g_set.fpMaxDistance = ConfigFloat("fp_max_distance", d.fpMaxDistance);
    g_cam.firstPerson = g_set.firstPerson;
    g_set.stabilize = ConfigFloat("camera_stabilize", d.stabilize);
    g_set.settle = ConfigFloat("camera_settle", d.settle);
    g_set.maxFrameLatency = ConfigInt("max_frame_latency", d.maxFrameLatency);
    g_set.fovMode = ConfigStr("fov_mode", d.fovMode.c_str());
    g_set.fovInner = ConfigFloat("fov_inner", d.fovInner);
    g_set.fovOuter = ConfigFloat("fov_outer", d.fovOuter);
    g_set.fovWide = ConfigFloat("fov_wide", d.fovWide);
    g_set.fovDebug = ConfigBool("fov_debug", d.fovDebug);
    g_set.uiMode = ConfigStr("ui_mode", d.uiMode.c_str());
    g_set.uiScale = ConfigFloat("ui_scale", d.uiScale);
    g_set.uiPick = ConfigInt("ui_pick", 0); if (g_set.uiPick < 0 || g_set.uiPick > 16) g_set.uiPick = 0;
    g_set.uiPickSig = ConfigStr("ui_pick_sig", "");
    g_set.uiLayers = ConfigStr("ui_layers", d.uiLayers.c_str()); if (g_set.uiLayers != "one") g_set.uiLayers = "all";
    g_set.uiDepth = ConfigFloat("ui_depth", d.uiDepth);
    g_set.uiPlacement = ConfigStr("ui_placement", d.uiPlacement.c_str()); if (g_set.uiPlacement != "draws") g_set.uiPlacement = "engine";
    g_set.hideHud = ConfigBool("hide_hud", d.hideHud);
    g_set.keepGameCamera = ConfigBool("keep_game_camera", d.keepGameCamera);
    g_set.uiOffsetY = ConfigFloat("ui_offset_y", d.uiOffsetY);
    g_set.hudSplit = ConfigStr("hud_split", d.hudSplit.c_str());
    g_set.hudSceneDraws = ConfigInt("hud_scene_draws", d.hudSceneDraws);
    g_set.lensDistortionOff = ConfigBool("lens_distortion_off", d.lensDistortionOff);
    g_set.fringeOff = ConfigBool("chromatic_fringe_off", d.fringeOff);
    g_set.vignetteOff = ConfigBool("vignette_off", d.vignetteOff);
    g_set.filmGrainOff = ConfigBool("film_grain_off", d.filmGrainOff);
    g_set.lensDirtOff = ConfigBool("lens_dirt_off", d.lensDirtOff);
    g_set.lensFlareOff = ConfigBool("lens_flare_off", d.lensFlareOff);
    g_set.noBlackBars = ConfigBool("no_black_bars", d.noBlackBars);
    g_set.runInBackground = ConfigBool("run_in_background", d.runInBackground);
    g_set.skipIntro = ConfigBool("skip_intro", d.skipIntro);
    g_set.depthOfField = ConfigStr("depth_of_field", d.depthOfField.c_str());
    if (g_set.depthOfField != "game" && g_set.depthOfField != "off") g_set.depthOfField = "cutscenes";
    g_set.fpsLimit = ConfigStr("fps_limit", d.fpsLimit.c_str());
    if (g_set.fpsLimit != "headset") g_set.fpsLimit = "0";
    g_set.fpsUnlocked = ConfigBool("fps_unlocked", d.fpsUnlocked);
    g_set.pairRate = ConfigBool("pair_rate", d.pairRate);
    g_set.headsetHz = ConfigFloat("headset_refresh_hz", d.headsetHz);
    g_set.smoothing = ConfigStr("headset_smoothing", d.smoothing.c_str());
    g_set.pacedTimeoutMs = ConfigInt("paced_timeout_ms", d.pacedTimeoutMs);
    g_set.vsyncOff = ConfigBool("vsync_off", d.vsyncOff);
    g_set.sharpen = ConfigFloat("sharpen", d.sharpen);
    g_set.hdrInput = ConfigStr("hdr_input", d.hdrInput.c_str());
    g_set.hdrNits = ConfigFloat("hdr_paper_white", d.hdrNits);
    g_set.mirror = ConfigStr("mirror", d.mirror.c_str());
    g_set.screenDistance = ConfigFloat("screen_distance", d.screenDistance);
    g_set.screenWidth = ConfigFloat("screen_width", d.screenWidth);
    g_set.menuWidth = ConfigFloat("menu_width", d.menuWidth);
    g_set.menuDistance = ConfigFloat("menu_distance", d.menuDistance);
    g_set.menuPanelWidth = ConfigFloat("menu_panel_width", d.menuPanelWidth);
    g_set.recenterKey = ConfigStr("recenter_key", d.recenterKey.c_str());
    g_set.screenshotKey = ConfigStr("screenshot_key", d.screenshotKey.c_str());
    g_set.fpKey = ConfigStr("fp_key", d.fpKey.c_str());
    g_set.screenshotView = ConfigStr("screenshot_view", d.screenshotView.c_str());
}

// "+0+1+2": for right, up, back: sign and row of the node matrix
static void ParseAxes(const std::string& s) {
    int row[3]; float sg[3]; size_t i = 0; int k = 0;
    while (k < 3 && i + 1 < s.size()) {
        char c = s[i], r = s[i + 1];
        if ((c != '+' && c != '-') || r < '0' || r > '2') break;
        sg[k] = c == '-' ? -1.f : 1.f; row[k] = r - '0'; k++; i += 2;
    }
    if (k == 3 && row[0] != row[1] && row[1] != row[2] && row[0] != row[2]) {
        for (int j = 0; j < 3; j++) { g_cam.axisRow[j] = row[j]; g_cam.axisSign[j] = sg[j]; }
    } else LOGW("camera_axes '%s' invalid - using +0+1+2", s.c_str());
}

void SettingsApplyCamera() {
    g_cam.worldScale = g_set.worldScale < 0.05f ? 0.05f : g_set.worldScale;
    g_cam.unitsPerMetre = g_set.unitsPerMetre > 0.f ? g_set.unitsPerMetre : 1.f;
    g_cam.ipdScale = g_set.ipdScale < 0.f ? 0.f : g_set.ipdScale > 3.f ? 3.f : g_set.ipdScale;
    g_cam.decoupledPitch = g_set.decoupledPitch;
    g_cam.headAim = g_set.headAim == "always" ? 1 : g_set.headAim == "aiming" ? 2 : 0;
    g_cam.headAimTarget = g_set.headAimTarget;
    g_cam.headAimSmooth = g_set.headAimSmooth < 0.f ? 0.f : g_set.headAimSmooth > 1.f ? 1.f : g_set.headAimSmooth;
    g_cam.headAimFromEyes = g_set.headAimOrigin != "camera";
    g_cam.stabilize = g_set.stabilize < 0.f ? 0.f : g_set.stabilize > 1.f ? 1.f : g_set.stabilize;
    g_cam.settle = g_set.settle < 0.f ? 0.f : g_set.settle > 1.f ? 1.f : g_set.settle;
    g_cam.camOffset[0] = g_set.camOffsetX; g_cam.camOffset[1] = g_set.camOffsetY; g_cam.camOffset[2] = g_set.camOffsetZ;
    {
        auto cl = [](float v, float a, float b) { return v < a ? a : v > b ? b : v; };
        g_cam.fpOffset[0] = cl(g_set.fpOffsetX, -1.f, 1.f); g_cam.fpOffset[1] = cl(g_set.fpOffsetY, -1.f, 1.f); g_cam.fpOffset[2] = cl(g_set.fpOffsetZ, -1.f, 1.f);
        g_cam.fpSmooth = cl(g_set.fpSmooth, 0.f, 1.f);
        g_cam.fpMaxDist = cl(g_set.fpMaxDistance, 1.f, 50.f);
    }
    ParseAxes(g_set.cameraAxes);
    g_cam.cullMargin = g_set.cullMargin < 1.f ? 1.f : g_set.cullMargin > 2.f ? 2.f : g_set.cullMargin;
    g_cam.swapEyes = g_set.swapEyes;
    g_cam.frameDelay = g_set.frameDelay < 0 ? 0 : g_set.frameDelay > 2 ? 2 : g_set.frameDelay;
    g_cam.cameraReprojection = g_set.cameraReprojection;
    g_cam.syncPairSubmit = g_set.syncSubmit != "each";
    g_cam.keepGameCamera = g_set.keepGameCamera;
    { extern void UiEngineSet(); UiEngineSet(); }
    g_cam.syncHold = g_set.syncHold < 0.03f ? 0.03f : g_set.syncHold > 1.f ? 1.f : g_set.syncHold;
    g_cam.syncLag = g_set.syncLag < -1 ? -1 : g_set.syncLag > 2 ? 2 : g_set.syncLag;
    g_cam.reconCentre = g_set.reconEye == "centre";
    g_cam.reconAlternate = g_set.reconEye == "alternate";
    g_cam.reconShared = g_set.reconShared;
    g_cam.symmetricView = g_set.symmetricView;
    g_cam.wideCull = g_set.wideCull;
    g_cam.flatMenus = g_set.flatPauseMenus;
    g_cam.flatVideos = false;   // no video hooks in this engine (video.cpp): videos without a 3D view are flat anyway
    CameraUpdateFrustum();
    UiSplitSet();
}

void SettingsApplyGame() {
    { extern void PostFxApply(); PostFxApply(); }
    game::AspectCapKeepOpen(g_set.noBlackBars && g_cam.mode != VRMODE_SCREEN);
    game::RunInBackground(g_set.runInBackground);
    game::SkipIntro(g_set.skipIntro);
    CameraSetDof(g_set.depthOfField);
}

void SettingsApply() {
    SettingsApplyCamera();
    XrSetMode(ModeFromString(g_set.vrMode));
    xrb::ClientSetHud(g_set.menuDistance, g_set.menuPanelWidth, -0.05f, true);
    xrb::ClientSetMenu(g_set.screenDistance, g_set.screenWidth);
    xrb::ClientSetPanelMode(g_set.panelLayers == "quad" ? 1 : g_set.panelLayers == "composite" ? 2 : 0);
    SmoothingSet(g_set.smoothing);   // only acts on a change
}

void MenuNoteFps(float fps) { g_fps = fps; }
float MenuFps() { return g_fps; }

// every offset slider moves by offset_step_cm per press
static void OffsetStepApply(vrkit::Options& o) {
    float st = g_set.offsetStepCm * 0.01f;
    for (auto& op : o.All())
        if (op.key == "camera_offset_x" || op.key == "camera_offset_y" || op.key == "camera_offset_z" ||
            op.key == "fp_offset_x" || op.key == "fp_offset_y" || op.key == "fp_offset_z") op.step = st;
}
// 0.6.9: five tabs, each in a fixed order - the most used first; settings that belong to one stereo method are only
// shown while that method is selected (the View tab held 30 rows of every method's settings mixed together)
static float g_scalePending = 1.f;   // the VR resolution slider's value until APPLY
static void MenuSaveNow() { extern std::wstring g_cfgPath; if (!g_cfgPath.empty() && vrkit::Options::Get().Save(g_cfgPath)) LOGI("config: saved"); }
// the APPLY button shows the current per-eye size, and the new one while the slider differs (same caps as the real size)
static void ResolutionLabels() {
    extern bool ResolutionCurrent(unsigned&, unsigned&); extern bool ResolutionPreview(float, unsigned&, unsigned&);
    unsigned cw = 0, ch = 0, nw = 0, nh = 0; char b[128];
    bool cur = ResolutionCurrent(cw, ch), pre = ResolutionPreview(g_scalePending, nw, nh);
    if (!cur) snprintf(b, sizeof b, "Apply VR resolution (headset size not known yet)");
    else if (pre && (nw != cw || nh != ch)) snprintf(b, sizeof b, "Apply VR resolution: %u x %u > %u x %u per eye", cw, ch, nw, nh);
    else snprintf(b, sizeof b, "Apply VR resolution: %u x %u per eye (x %.2f)", cw, ch, g_set.renderScale);
    for (auto& op : vrkit::Options::Get().All()) if (op.type == vrkit::OptType::Action && op.label.rfind("Apply VR resolution", 0) == 0) { if (op.label != b) op.label = b; break; }
}
static void OrganisePages(vrkit::Options& o) {
    struct M { const char* key; const char* tab; const char* only; const char* group; };   // only: shown with this vr_mode only ("" = always)
    static const M map[] = {
        // View
        { "vr_mode", "View", "", "Stereo" }, { "world_scale", "View", "", "Stereo" }, { "ipd_scale", "View", "", "Stereo" }, { "swap_eyes", "View", "", "Stereo" },
        // 0.9.3 (framework rule 0.6.63): the VR resolution right under the 3D modes - slider, APPLY, HEADSET DEFAULT
        { "vr_resolution", "View", "", "VR resolution" }, { "Apply VR resolution", "View", "", "VR resolution" }, { "Headset default resolution", "View", "", "VR resolution" },
        { "render_scale", "View", "never", "VR resolution" },
        // 0.6.50: the frame-rate settings on the first tab, under the stereo method (their fine settings stay in Advanced)
        // 0.6.57: every stereo-reconstruction setting on the main tab, right under the stereo method, shown only with it
        // 0.9 (framework 0.6.90 / 0.6.97): the fast path's settings on the first tab - each costs nothing or very little
        { "recon_view", "View", "recon", "Reconstruction" }, { "recon_eye_cover", "View", "recon", "Reconstruction" }, { "recon_edge_fill", "View", "recon", "Reconstruction" },
        { "recon_parallax", "View", "recon", "Reconstruction" }, { "recon_near_limit", "View", "recon", "Reconstruction" },
        { "recon_infill_blend", "View", "recon", "Reconstruction" }, { "recon_infill_detail", "View", "recon", "Reconstruction" },
        { "recon_sharpen", "View", "recon", "Reconstruction" }, { "recon_hud_split", "View", "recon", "Reconstruction" },
        { "fps_limit", "View", "", "Performance" }, { "fps_unlocked", "View", "", "Performance" }, { "headset_refresh_hz", "View", "", "Performance" },
        { "camera_reprojection", "View", "", "Performance" }, { "pair_rate", "View", "", "Performance" }, { "fov_mode", "View", "", "Performance" }, 
        { "sync_submit", "View", "synced", "Synchronized" }, { "pace_lock", "View", "aer|synced", "Alternate eye / synchronized" },
        { "aer_frame_delay", "View", "aer", "Alternate eye / synchronized" },
        { "Recenter view", "View", "", "Quick actions" }, { "First person on / off (End)", "View", "", "Quick actions" }, { "Flat screen now (F6)", "View", "", "Quick actions" },
        // Camera
        { "head_aim", "Camera", "", "Aiming" }, { "head_aim_origin", "Camera", "", "Aiming" }, { "head_aim_smoothing", "Camera", "", "Aiming" }, { "head_aim_target", "Camera", "", "Aiming" }, { "decoupled_pitch", "Camera", "", "Camera" }, { "camera_stabilize", "Camera", "", "Camera" }, { "camera_settle", "Camera", "", "Camera" }, { "keep_game_camera", "Camera", "", "Camera" },
        { "camera_offset_x", "Camera", "", "Camera offset" }, { "camera_offset_y", "Camera", "", "Camera offset" }, { "camera_offset_z", "Camera", "", "Camera offset" },
        { "Reset camera", "Camera", "", "Camera offset" },
        { "first_person", "Camera", "", "First person" }, { "fp_offset_x", "Camera", "", "First person" }, { "fp_offset_y", "Camera", "", "First person" },
        { "fp_offset_z", "Camera", "", "First person" }, { "fp_smooth", "Camera", "", "First person" },
        { "fp_max_distance", "Camera", "", "First person" }, { "Reset first person", "Camera", "", "First person" },
        // HUD
        { "ui_mode", "HUD", "", "HUD" }, { "ui_converge", "HUD", "aer|synced", "HUD" }, { "ui_eye_next", "HUD", "aer|synced", "HUD" }, { "ui_scale", "HUD", "", "HUD" }, { "ui_depth", "HUD", "", "HUD" }, { "ui_offset_y", "HUD", "", "HUD" }, { "hide_hud", "HUD", "", "HUD" }, { "ui_placement", "HUD", "", "Which UI is scaled" },
        { "ui_pick", "HUD", "", "Which UI is scaled" }, { "ui_pick_sig", "HUD", "", "Which UI is scaled" },
        // Graphics
        { "lens_distortion_off", "Graphics", "", "Game effects" }, { "chromatic_fringe_off", "Graphics", "", "Game effects" }, { "vignette_off", "Graphics", "", "Game effects" },
        { "film_grain_off", "Graphics", "", "Game effects" }, { "lens_dirt_off", "Graphics", "", "Game effects" }, { "lens_flare_off", "Graphics", "", "Game effects" },
        { "sharpen", "Graphics", "", "Game effects" },
        { "no_black_bars", "Graphics", "", "Resolution and speed" },
        // Screen
        { "edge_fill", "View", "", "Edge fill" }, { "edge_fill_margin", "View", "", "Edge fill" }, { "flat_pause_menus", "Screen", "", "Flat screen" },
        { "screen_distance", "Screen", "", "Flat screen" }, { "screen_width", "Screen", "", "Flat screen" },
        { "menu_distance", "Screen", "", "Panels" }, { "menu_panel_width", "Screen", "", "Panels" }, { "menu_width", "Screen", "", "Panels" },
        { "mirror", "Screen", "", "Desktop window" }, { "vsync_off", "Screen", "", "Desktop window" }, { "hdr_input", "Screen", "", "Desktop window" },
        { "screenshot_view", "Screen", "", "Desktop window" },
        { "force_windowed", "Screen", "", "Start-up" }, { "run_in_background", "Screen", "", "Start-up" },
        // 0.6.16 Advanced: set once / rarely touched - foveated rendering first
        { "fov_inner", "Advanced", "", "Foveated rendering" }, { "fov_outer", "Advanced", "", "Foveated rendering" },
        { "fov_wide", "Advanced", "", "Foveated rendering" }, { "fov_debug", "Advanced", "", "Foveated rendering" },
        { "fov_effects", "Advanced", "", "Foveated rendering" },
        // costs GPU time: Advanced, with the cost in each description
        { "recon_preset", "Advanced", "recon", "Stereo reconstruction (costs more)" }, { "recon_fill", "Advanced", "recon", "Stereo reconstruction (costs more)" },
        { "fov_recon_auto", "Advanced", "recon", "Stereo reconstruction (costs more)" },
        // fine tuning and diagnostics
        { "recon_fill_steady", "Advanced", "recon", "Stereo reconstruction" }, { "recon_edge_guard", "Advanced", "recon", "Stereo reconstruction" },
        { "recon_gap_reach", "Advanced", "recon", "Stereo reconstruction" }, { "recon_depth", "Advanced", "recon", "Stereo reconstruction" },
        { "recon_fast_footprint", "Advanced", "recon", "Stereo reconstruction" }, { "recon_edge_pixels", "Advanced", "recon", "Stereo reconstruction" },
        { "recon_align_h", "Advanced", "recon", "Stereo reconstruction" }, { "recon_align_v", "Advanced", "recon", "Stereo reconstruction" },
        { "recon_debug", "Advanced", "recon", "Stereo reconstruction" },
        { "view_width", "Advanced", "", "Picture and frustum" }, { "view_height", "Advanced", "", "Picture and frustum" }, { "wide_cull", "Advanced", "", "Picture and frustum" }, { "symmetric_view", "Advanced", "", "Picture and frustum" },
        { "cull_margin", "Advanced", "", "Picture and frustum" }, { "units_per_metre", "Advanced", "", "Picture and frustum" },
        { "aer_align_h", "Advanced", "aer|synced", "Eye alignment" }, { "aer_align_v", "Advanced", "aer|synced", "Eye alignment" },
        { "sync_lag", "Advanced", "synced", "Eye alignment" }, { "sync_hold", "Advanced", "synced", "Eye alignment" },
        { "render_resolution", "Advanced", "", "Render size and timing" }, { "render_density", "Advanced", "", "Render size and timing" },
        { "headset_smoothing", "Advanced", "", "Render size and timing" }, { "max_frame_latency", "Advanced", "", "Render size and timing" },
        { "ui_layers", "Advanced", "never", "Fine tuning" }, { "hud_split", "Advanced", "", "Fine tuning" }, { "hud_scene_draws", "Advanced", "", "Fine tuning" },
        { "offset_step_cm", "Advanced", "", "Fine tuning" }, { "panel_layers", "Advanced", "", "Fine tuning" },
        { "hdr_paper_white", "Advanced", "", "Fine tuning" },
    };
    static const char* order[] = { "View", "Camera", "HUD", "Graphics", "Screen", "Advanced" };
    auto& v = o.All();
    std::vector<int> idx(v.size(), 1000);
    for (size_t k = 0; k < v.size(); k++) {
        auto& op = v[k];
        if (op.page == "First person") op.page = "Camera";
        else if (op.page == "Stereo" || op.page == "Recon") op.page = "View";
        else if (op.page == "Speed") op.page = "Graphics";
        else if (op.page == "Start") op.page = "Screen";
        for (int i = 0; i < (int)(sizeof map / sizeof *map); i++) {
            const M& m = map[i];
            if (!(op.key == m.key || (op.key.empty() && op.label == m.key))) continue;
            op.page = m.tab; op.group = m.group; idx[k] = i;
            std::string only = m.only;
            if (!only.empty()) op.visible = [only] {
                size_t p = 0;
                while (p <= only.size()) { size_t q = only.find('|', p); if (q == std::string::npos) q = only.size();
                    if (only.compare(p, q - p, g_set.vrMode) == 0 && q - p == g_set.vrMode.size()) return true; p = q + 1; }
                return false;
            };
            break;
        }
    }
    for (auto& op : v) if (op.key == "recon_eye_cover") op.visible = [] { return g_set.vrMode == "recon" && g_set.reconView == "eye"; };   // only with Eye size
    // 0.9: every option must have an entry in the tab table - an option without one lands at the end of its own page; say so in the log
    { int missing = 0;
      for (size_t k = 0; k < v.size(); k++) if (idx[k] == 1000 && !v[k].key.empty() && v[k].type != vrkit::OptType::Hotkey) { LOGW("panel: option %s has no entry in the tab table", v[k].key.c_str()); missing++; }   // hotkeys have their own page
      if (!missing) LOGI("panel: every option has a tab-table entry (%d options)", (int)v.size()); }
    auto rank = [&](const std::string& pg) { for (int i = 0; i < (int)(sizeof order / sizeof *order); i++) if (pg == order[i]) return i; return 99; };
    std::vector<int> perm(v.size()); for (size_t k = 0; k < v.size(); k++) perm[k] = (int)k;
    std::stable_sort(perm.begin(), perm.end(), [&](int a, int b) {
        int ra = rank(v[a].page), rb = rank(v[b].page);
        return ra != rb ? ra < rb : idx[a] < idx[b];
    });
    std::vector<vrkit::Option> sorted; sorted.reserve(v.size());
    for (int k : perm) sorted.push_back(std::move(v[k]));
    v = std::move(sorted);
}
static void MenuInit() {
    g_menuInit = true;
    vrkit::SetLog([](const char* m) { LOGI("vrkit: %s", m); });
    auto& o = vrkit::Options::Get();
    auto apply = [] { SettingsApply(); };
    auto cam = [] { SettingsApplyCamera(); };
    auto gameP = [] { extern void SettingsApplyGame(); SettingsApplyGame(); };

    // ---- View
    auto& m = o.AddChoice("View", "vr_mode", "Stereo method", &g_set.vrMode, { "synced", "recon", "aer", "head", "screen" },
                          "Synchronized: both eyes from the SAME game tick (UEVR's synchronized sequential) - the game clock "
                          "waits for the second eye, both eyes always match; world motion updates every second frame. "
                          "Stereo reconstruction: one eye drawn per frame, the other reconstructed from its picture and depth - "
                          "both eyes new every frame, same moment, full frame rate (small fringes around close objects). "
                          "Alternate eye: every frame is a new tick for one eye - the eyes are one tick apart. "
                          "Head: one head-tracked image. Screen: flat virtual screen. (F8 cycles them.)", apply);
    m.choiceLabels = { "Synchronized (same tick)", "Stereo reconstruction (full rate)", "Alternate eye (AER)", "Head-tracked mono", "Flat screen" };
    o.AddFloat("View", "world_scale", "World scale", &g_set.worldScale, 0.25f, 4.f, 0.05f, 2,
               "1.0 = real size. Larger values make the world look smaller (head movement moves you more).", cam);
    o.AddFloat("View", "units_per_metre", "Engine units per metre", &g_set.unitsPerMetre, 0.1f, 200.f, 0.1f, 1,
               "Calibration: how many game units are one metre. Leaning 10 cm should move the view 10 cm.", cam);
    o.AddBool("View", "flat_pause_menus", "Flat screen in pause menus", &g_set.flatPauseMenus,
              "When the game is paused (pause menu, settings, map, gear, codex ...) the game is shown on the flat virtual "
              "screen instead of in 3D. Photo mode stays 3D once you move its camera. Screens without any 3D view "
              "(title, loading) are always flat.", cam);
    o.AddAction("View", "Flat screen now (F6)", [] { g_cam.flatHold = !g_cam.flatHold; }, "Shows the flat virtual screen until pressed again (also F6).");
    o.AddBool("View", "force_windowed", "Always windowed (next start)", &g_set.forceWindowed,
              "The game runs windowed (exclusive fullscreen refused), so its window - and the picture - can be the "
              "headset's full per-eye resolution and shape, larger than your monitor. Nothing is changed in the game's "
              "own settings. Takes effect the next time the game starts.", [] {});
    o.AddAction("View", "Recenter view", [] { XrRequestRecenter(); }, "Puts the view and the panels in front of you (also Space / F9).");
    // 0.6.47: for reports
    o.AddAction("View", "Mark an issue in the log", [] { extern void DiagMarkIssue(); DiagMarkIssue(); },
                "Writes \"USER MARK\" with the mod's state into resonancevr.log right now - press it when something goes wrong, then say which mark in the report.");
    o.AddAction("View", "Make a report folder", [] { extern void DiagMakeReport(); DiagMakeReport(); },
                "Copies both logs, the previous run's logs and your config into ResonanceVR\\report_<date> - zip that folder and send it with what you did.");
    auto& sv = o.AddChoice("View", "screenshot_view", "Screenshot (Delete)", &g_set.screenshotView, { "headset", "full" },
                           "Delete saves the left eye as a PNG next to Resonance.exe. Headset: exactly the part of the image your "
                           "headset shows, pixel for pixel. Full: the whole rendered eye image (with its margin).", [] {});
    sv.choiceLabels = { "As the headset shows it (1:1)", "Whole eye image" };
    o.AddAction("View", "First person on / off (End)", [] { extern void FpToggleFromMenu(); FpToggleFromMenu(); },
                "Your eye at the character instead of behind her shoulder. Settings: the First person page.");

    // ---- Stereo
    auto& ss = o.AddChoice("Stereo", "sync_submit", "Synchronized: send eyes", &g_set.syncSubmit, { "pair", "each" },
                           "Pair: the headset gets both eyes of a tick together (never mismatched). Each: every eye as soon "
                           "as it is drawn (one frame less latency for the first eye).", cam);
    ss.choiceLabels = { "As a pair", "As drawn" };
    o.AddFloat("Stereo", "sync_hold", "Synchronized: step kept", &g_set.syncHold, 0.03f, 1.0f, 0.01f, 2,
               "The second eye of a pair is drawn on a game tick that still advances this part of a step (the rest goes to the next "
               "tick, so game speed is unchanged). Low = the world stands more still between the eyes (most exact 3D, but a "
               "tiny step followed by a double step makes cloth and hair physics jitter). Higher = smoother physics, a little "
               "more difference between the eyes on moving objects. 1 = like alternate eye.", cam);
    o.AddInt("Stereo", "sync_lag", "Synchronized: clock lag", &g_set.syncLag, -1, 2, 1,
             "-1 = automatic (found from when the game camera stands still). Which game tick a picture belongs to. "
             "If the two eyes of moving characters do not match, try 0, 1 or 2.", cam);
    auto& rd = o.AddChoice("Stereo", "recon_depth", "Reconstruction: depth direction", &g_set.reconDepth, { "auto", "game", "flip" },
                           "Which way the game's depth buffer runs. Auto: measured on the depth itself (the log says what it "
                           "found). If both eyes look crossed or everything looks very close, try the other fixed value.", [] {});
    rd.choiceLabels = { "Auto (measured)", "As the game says", "Turned round" };
    o.AddInt("Stereo", "recon_gap_reach", "Reconstruction: gap reach", &g_set.reconGapReach, 8, 192, 4,
             "How far (pixels at 1920 wide) a hidden area looks sideways for the surface behind it.", [] {});
    { auto& rp = o.AddChoice("Stereo", "recon_preset", "Reconstruction: infill quality", &g_set.reconPreset, { "performance", "balanced", "quality" },
                             "Which infill passes run - the cost of reconstruction. Performance (default, the fastest): matched tiles of the real "
                             "background held over frames (35 offsets), a membrane seam, the steady-infill history and the blend band; no "
                             "remembered pixels, no PatchMatch. Balanced: + remembered real pixels and PatchMatch with one pass (about +2 ms a "
                             "frame). Quality: PatchMatch with three passes, a 5 x 5 vote, 4 M remembered points (about +4 ms a frame). The GPU "
                             "time of every pass is in resonancevr.log (\"GPU per frame, both eyes\").", [] {});
      rp.choiceLabels = { "Performance (matched tiles)", "Balanced (PatchMatch, 1 pass)", "Quality (PatchMatch, 3 passes)" }; }
    { auto& rf = o.AddChoice("Stereo", "recon_fill", "Reconstruction: infill", &g_set.reconFill, { "history", "patch", "classic", "soft", "clone", "stretch", "scatter" },
                             "How the areas the drawn view could not see (beside close objects) are filled (Balanced / Quality; the Performance preset "
                             "uses matched tiles in place of PatchMatch and no remembered pixels). Real pixels + PatchMatch (default): background that earlier frames saw is shown as it really was; the rest is copied from the "
                             "real background beside the gap by matching patches, with a colour-matched seam and no outline. Patches "
                             "only: the same without the remembered pixels (saves VRAM and one pass). The others are the older "
                             "two-pass infills: Classic (the 0.7 default - 8-direction background search), Soft background, Clone, "
                             "Stretch, Scatter. Turn on \"show hidden areas\" to see where it acts.", [] {});
      rf.choiceLabels = { "Real pixels + PatchMatch", "PatchMatch only", "Classic (older)", "Soft background", "Clone", "Stretch", "Scatter" }; }
    { auto& rv = o.AddChoice("Stereo", "recon_view", "Reconstruction: drawn view size", &g_set.reconView, { "eye", "wide", "headset" },
                             "Eye size (default, 0.9): the game draws one view about as wide as a single eye plus part of the way to the full "
                             "width (see \"drawn view reach\") - the fastest frame. The outer part of each rebuilt eye, which that view cannot "
                             "see, repeats the picture's rim. Wide: the game draws the one view that covers both eyes at the headset's pixel "
                             "density (~1.3 x an eye's width) - native detail everywhere, more pixels. Headset size: the headset's pixel count "
                             "(~25 % fewer pixels, softer, sharpened at least 0.35). Changing it resizes the game's render targets once.", [] {});
      rv.choiceLabels = { "Eye size (fastest)", "Wide (native detail)", "Headset size (softer)" }; }
    o.AddFloat("Stereo", "recon_eye_cover", "Reconstruction: drawn view reach", &g_set.reconEyeCover, 0.f, 1.f, 0.05f, 2,
               "Eye-size view only. 0 = the drawn view is exactly one eye wide (the most rim repeat, the fastest); 1 = as wide as the wide "
               "view (no rim repeat). 0.5 = default: halfway - the rim repeat only touches the outer part of each eye.", [] {});
    o.AddBool("Stereo", "recon_edge_fill", "Reconstruction: edge fill", &g_set.reconEdgeFill,
              "On (default): the part of each eye that lies past the drawn view's side (the outer edge with the eye-size view) repeats the "
              "picture's rim outward - its own texture, colour-matched at the seam, softer further out, never darkened. Off: that part is "
              "the drawn view's nearest edge pixel.", [] {});
    o.AddBool("Stereo", "recon_hud_split", "Reconstruction: place the HUD separately", &g_set.reconHudSplit,
              "Off (default, the performance path): the HUD is part of the picture and sits at the depth of the scene behind it - "
              "nothing extra runs. On: what the HUD / UI draws on top of the picture is cut out and placed at each eye's own HUD "
              "position (its own depth) - costs a picture copy at the first UI draw and a compare per pixel.", [] {});
    { auto& fe = o.AddChoice("Stereo", "fov_effects", "Foveation: full-screen passes", &g_set.fovEffects, { "outer", "off" },
                             "Outer (default): with foveated rendering on, full-screen passes that have no depth target (bloom, blur, "
                             "post effects) are shaded at a lower rate at the lens edge, away from both eyes. Off: only the passes with a "
                             "depth target are foveated. Needs variable-rate shading (tier 2).", [] {});
      fe.choiceLabels = { "Lens edge lower rate", "Off" }; }
    o.AddBool("Stereo", "fov_recon_auto", "Reconstruction: shade the centre view's far sides less (Performance)", &g_set.fovReconAuto,
              "With the Performance preset and foveated rendering off, the game shades the centre view at half rate in a ring and quarter rate "
              "at the far sides - away from both eyes' lens axes, where the headset shows little. Needs variable-rate shading (tier 2). "
              "Foveated rendering set by you is never changed.", [] {});
    o.AddBool("Stereo", "recon_fill_steady", "Reconstruction: steady infill", &g_set.reconSteady,
              "On (default): the previous frame's fill is carried into this one (clipped to the colours the new fill has), so "
              "filled areas stop shimmering while you move. Costs one texture per eye.", [] {});
    o.AddBool("Stereo", "recon_edge_pixels", "Reconstruction: edge pixels follow their colour", &g_set.reconEdgePixels,
              "On (default): a pixel on an object's edge that has the object's colour moves with the object, and holes inside a "
              "surface (hair, foliage) move with it - no halo of object colour beside the fill, no see-through dither. Off: "
              "every pixel moves by its depth alone (cheaper in the forward pass).", [] {});
    o.AddFloat("Stereo", "recon_near_limit", "Reconstruction: close-object limit (m)", &g_set.reconNearLimit, 0.f, 3.f, 0.05f, 2,
               "Things nearer than this are pushed apart less than their distance says, so a hand or weapon right in front of the "
               "camera does not tear a huge hole. 0 = off.", [] {});
    o.AddFloat("Stereo", "recon_sharpen", "Reconstruction: sharpening", &g_set.reconSharpen, 0.f, 1.f, 0.05f, 2,
               "Luma sharpening of the rebuilt eyes in the headset blit (no extra pass), clamped to the neighbouring pixels (no halos). 0 = off; the headset-size view uses at least 0.35.", [] {});
    o.AddFloat("Stereo", "recon_infill_blend", "Reconstruction: infill blend", &g_set.reconBlend, 0.f, 3.f, 0.1f, 1,
               "How wide the soft band between a filled area and the real picture beside it is. 0 = none, 1 = default, 3 = widest.", [] {});
    o.AddFloat("Stereo", "recon_infill_detail", "Reconstruction: infill detail", &g_set.reconDetail, 0.f, 1.f, 0.05f, 2,
               "Where the matches disagree (grain, rain, small lights) a filled pixel keeps up to this share of its own match "
               "instead of the average haze. 0.5 = default.", [] {});
    o.AddInt("Stereo", "recon_edge_guard", "Reconstruction: infill edge guard", &g_set.reconEdgeGuard, 0, 4, 1,
             "Pixels the infill keeps away from the background's edge. The edge pixel is often blended with the object in "
             "front (anti-aliasing) and shows as a halo outline in the filled area. 1 (default) removes most of it; 0 = "
             "as before 0.6.53.", [] {});
    o.AddBool("Stereo", "recon_fast_footprint", "Reconstruction: fast forward pass", &g_set.reconFootprint,
              "On (default): the reconstruction writes each drawn pixel into the other eye's map only where a hole could "
              "open (about 40 % fewer writes, the same picture). Off: the full 2 x 2 footprint as before 0.6.53 - turn it "
              "off if thin lines or dots of missing picture appear. Headsets with canted displays always use the full one.", [] {});
    o.AddInt("Stereo", "recon_debug", "Reconstruction: show hidden areas", &g_set.reconDebug, 0, 2, 1,
             "1 = hidden areas tinted (orange stretched, blue from the last image, red nothing), 2 = picture grey and "
             "the UI in colour (checks the UI split). 0 = off.", [] {});
    o.AddBool("Stereo", "swap_eyes", "Swap eyes", &g_set.swapEyes, "Off on this game. If depth looks inside out, check Frame delay first (1 on this engine).", cam);
    o.AddInt("Stereo", "aer_frame_delay", "Frame delay", &g_set.frameDelay, 0, 2, 1,
             "1 (default): this engine's render thread draws a frame one Present after its camera was set - each picture is "
             "matched with the head pose it was drawn with. 0 pairs every picture with the next frame's camera (eyes swapped "
             "in alternate eye / synchronized, a hitch in every head turn).", cam);
    o.AddFloat("Stereo", "ipd_scale", "Eye distance x", &g_set.ipdScale, 0.f, 2.f, 0.02f, 2,
               "1.0 = your headset's IPD. Lower = less depth (world looks bigger), higher = more depth.", cam);
    o.AddBool("Stereo", "camera_reprojection", "Motion smoothing: in-mod camera extrapolation", &g_set.cameraReprojection,
              "Every 3D mode. When the game is slower than the headset, a game frame is shown for more than one headset "
              "frame, and while you turn the camera with the stick / mouse the picture stands still, then jumps. On: each "
              "headset frame turns the newest picture on by the camera's own (smoothed) turning speed, so turning looks "
              "smooth and sharp at the headset's full rate; in alternate eye the older eye is turned too, so both eyes "
              "agree. Your head's own movement is always corrected by the headset. Only turning is extrapolated - walking "
              "and animations stay at the game's rate; the character the camera orbits can wobble a little. Never "
              "extrapolates more than 50 ms. Logged as \"reproject\" in xrhost.log.", cam);
    o.AddFloat("Stereo", "recon_parallax", "Reconstruction: depth strength", &g_set.reconParallax, 0.f, 2.f, 0.05f, 2,
               "How far apart the two rebuilt eyes are (x the real eye distance). Lower it if close things look doubled, "
               "raise it for more depth. 1 = your own eye distance.", cam);
    o.AddFloat("Stereo", "recon_align_h", "Reconstruction: eye align sideways", &g_set.reconShiftH, -10.f, 10.f, 0.1f, 1,
               "Degrees each eye's picture is moved sideways (+ apart, - together). Use it if the two eyes do not line up "
               "on far away things.", cam);
    o.AddFloat("Stereo", "recon_align_v", "Reconstruction: eye align up / down", &g_set.reconShiftV, -5.f, 5.f, 0.1f, 1,
               "Degrees the left eye's picture is moved up and the right eye's down (- the other way).", cam);
    o.AddFloat("Stereo", "aer_align_h", "Eye align sideways", &g_set.aerShiftH, -10.f, 10.f, 0.1f, 1,
               "Alternate eye / synchronized: degrees each eye's picture is moved sideways (+ apart, - together).", cam);
    o.AddFloat("Stereo", "aer_align_v", "Eye align up / down", &g_set.aerShiftV, -5.f, 5.f, 0.1f, 1,
               "Alternate eye / synchronized: degrees the left eye's picture is moved up and the right eye's down.", cam);
    o.AddFloat("Stereo", "view_width", "Picture width", &g_set.viewWidth, 0.7f, 1.3f, 0.01f, 2,
               "How wide the world looks in the headset. Above 1 = narrower (more of the picture squeezed in), below 1 = "
               "wider. 1 = exactly the headset's field of view. All 3D methods.", cam);
    o.AddFloat("Stereo", "view_height", "Picture height", &g_set.viewHeight, 0.7f, 1.3f, 0.01f, 2,
               "How tall the world looks in the headset. Above 1 = flatter, below 1 = taller. 1 = the headset's own.", cam);
    o.AddBool("Screen", "edge_fill", "Edge fill", &g_set.edgeFill,
              "On (default): every eye image goes to the headset with a border around the game's picture (see \"edge fill border\"), "
              "and wherever the headset shows past the picture - that border, the runtime turning the picture with your head between "
              "frames, picture size / eye align - the picture's rim and all four corners are stretched outward, softer further out, "
              "instead of black. Every 3D method.", [] {});
    o.AddFloat("Screen", "edge_fill_margin", "Edge fill border", &g_set.edgeFillMargin, 0.f, 0.2f, 0.01f, 2,
               "How much wider than the headset's view each eye image is sent, on every side (0.06 = 6 % of the width). The runtime turns "
               "the last picture with your head when a new one is late (alternate eye shows each eye every second refresh): with a border "
               "it turns in stretched picture, not black. The eye images grow by the same amount (their pixel density stays). 0 = no border.", [] {});
    o.AddBool("Stereo", "wide_cull", "Wide culling (no pop-in at the sides)", &g_set.wideCull,
              "On (default): the game decides what to draw (and which shadows to cast) from one symmetric view that "
              "covers the eye, while the picture is drawn with the eye's own view at the headset's size - nothing pops "
              "in at the outer sides and nothing extra is rendered. Off: culling uses the eye's view (side pop-in).", [] { SettingsApplyCamera(); });
    o.AddBool("Stereo", "symmetric_view", "One symmetric view for both eyes", &g_set.symmetricView,
              "On (default since 0.9.8): alternate eye, synchronized and head draw each eye with a view symmetric about its own line "
              "of sight and cut the eye out of it - the HUD (drawn by the game in screen space) is then the same in both eyes and "
              "fuses, and every effect the game builds from its field of view agrees with the picture. The render is wider than the "
              "eye (headsets with off-centre eyes: ~1.27x). Off: each eye drawn with its own off-centre view at the headset's exact "
              "size (fewer pixels) - the HUD then has to be moved per eye and can show double. Reconstruction never uses it.", [] { SettingsApplyCamera(); extern void ResolutionFollowView(); ResolutionFollowView(); });
    o.AddFloat("Stereo", "cull_margin", "FOV / culling margin", &g_set.cullMargin, 1.f, 1.6f, 0.01f, 2,
               "Renders (and culls) this much more than the headset shows. Raise it if objects pop at the edges.", cam);

    // ---- Camera
    { auto& ha = o.AddChoice("Camera", "head_aim", "Head aim", &g_set.headAim, { "off", "always", "aiming" },
          "The sling / crossbow aim where you look, the camera does not turn. Always: every shot goes where your head points. While aiming: "
          "only while L2 / LT (or the right mouse button) is held - then the shot follows your head; let go and it follows the "
          "camera again. Off: the game's own aim (centre of the camera). Changes only the aim, never the view.", [] { SettingsApplyCamera(); });
      ha.choiceLabels = { "Off", "Always", "While aiming (L2 / right mouse)" };
      auto& ho = o.AddChoice("Camera", "head_aim_origin", "Head aim: shots start at", &g_set.headAimOrigin, { "eyes", "camera" },
          "Eyes (default): the shot starts where your eyes are drawn (first person: at the character) - it hits exactly what "
          "you look at. Camera: from the game camera (third person: behind the character).", [] { SettingsApplyCamera(); });
      ho.choiceLabels = { "Your eyes", "Game camera" };
      o.AddBool("Camera", "head_aim_target", "Head aim: turn the aim target", &g_set.headAimTarget,
                "On (default): head aim also turns the game camera's look-at point, which the sling / crossbow aim reads. "
                "The game's own point is given back every frame. Turn the game's aim assist off for the aim to follow your head exactly.", cam);
      o.AddFloat("Camera", "head_aim_smoothing", "Head aim: smoothing", &g_set.headAimSmooth, 0.f, 1.f, 0.05f, 2,
          "Filters head tremor out of the aim (0 = raw head, 1 = steadiest, ~0.15 s). Only the head's own motion is filtered: "
          "turning with the stick is never delayed. Default 0.30.", [] { SettingsApplyCamera(); }); }
    o.AddBool("Camera", "decoupled_pitch", "Decoupled pitch", &g_set.decoupledPitch,
              "Removes the game camera's up / down tilt (and roll): the horizon stays level and only your head pitches "
              "the view. Stick / mouse turning (yaw) still applies.", cam);
    o.AddBool("Camera", "keep_game_camera", "Give the game its camera back", &g_set.keepGameCamera,
              "On (default): after the eye is set up for drawing, the game's camera object gets the game's own camera back - the "
              "game's logic (camera behaviours that start from the last camera, movement, audio) never sees your head, so nothing "
              "can drift or spin. Off: the head pose stays in the camera until the game's next camera update.", cam);
    o.AddFloat("Camera", "camera_settle", "Idle sway lock", &g_set.settle, 0.f, 1.f, 0.05f, 2,
               "Removes the game camera's small automatic movement while you stand still (third person idle drift, first "
               "person breathing / head bob): the camera only moves once the game's moves more than a little "
               "(1.0 = 2.5 degrees / 6 cm), then follows exactly. 0 = off.", [] { SettingsApplyCamera(); });
    o.AddFloat("Camera", "camera_stabilize", "Camera shake filter", &g_set.stabilize, 0.f, 1.f, 0.05f, 2,
               "Smooths the game camera's shake and bob (jumps, landings, hits) - only the fast part; walking and turning "
               "stay. 0 = off. Your own head movement is never filtered.", cam);
    // the step of every offset slider (third and first person), cm per press; the vector holds the options by value,
    // so they are looked up by key when the step changes (and once after the menu is built: OffsetStepApply)
    o.AddFloat("Camera", "offset_step_cm", "Offset step (cm per press)", &g_set.offsetStepCm, 1.f, 30.f, 1.f, 0,
               "How far one press moves the camera / first-person eye offsets below. Default 3 cm.", [] { OffsetStepApply(vrkit::Options::Get()); });
    o.AddFloat("Camera", "camera_offset_x", "Camera X (right)", &g_set.camOffsetX, -9.f, 9.f, 0.03f, 2, "Metres.", cam);
    o.AddFloat("Camera", "camera_offset_y", "Camera Y (up)", &g_set.camOffsetY, -9.f, 9.f, 0.03f, 2, "Metres.", cam);
    o.AddFloat("Camera", "camera_offset_z", "Camera Z (forward)", &g_set.camOffsetZ, -15.f, 15.f, 0.03f, 2,
               "Metres. The game camera is behind the character's shoulder: forward brings you closer to her.", cam);
    o.AddAction("Camera", "Reset camera", [] {
        g_set.decoupledPitch = true; g_set.camOffsetX = g_set.camOffsetY = g_set.camOffsetZ = 0.f; SettingsApplyCamera();
    }, "Decoupled pitch on, offsets 0.");

    // ---- First person (End): the eye at the character the camera follows. Offsets of its own - the Camera page's are third person.
    auto fpc = [] { g_cam.firstPerson = g_set.firstPerson; SettingsApplyCamera(); };
    o.AddBool("First person", "first_person", "First person (End)", &g_set.firstPerson,
              "Your eye is at the character the game camera follows (the point it looks at) instead of behind her "
              "shoulder, turned with the game camera and your head. Cutscenes and scripted cameras keep the game's camera. "
              "Her body is not hidden: Eye Z (forward) puts your eye in front of her head. End toggles it.", fpc);
    o.AddFloat("First person", "fp_offset_x", "Eye X (right)", &g_set.fpOffsetX, -1.5f, 1.5f, 0.03f, 2,
               "Metres to the side of the camera's look-at point. First person only.", cam);
    o.AddFloat("First person", "fp_offset_y", "Eye Y (up)", &g_set.fpOffsetY, -1.5f, 1.5f, 0.03f, 2,
               "Metres above the camera's look-at point (eye height). First person only.", cam);
    o.AddFloat("First person", "fp_offset_z", "Eye Z (forward)", &g_set.fpOffsetZ, -1.5f, 1.5f, 0.03f, 2,
               "Metres in front of the look-at point, along where the camera faces. Raise it if you see her hair or the inside of her head. First person only.", cam);
    o.AddFloat("First person", "fp_smooth", "Head bob filter", &g_set.fpSmooth, 0.f, 1.f, 0.05f, 2,
               "Smooths the walk / run animation's head bob. Only the bob: walking and running speed are never delayed. 0 = off.", cam);
    o.AddFloat("First person", "fp_max_distance", "Cutscene distance (m)", &g_set.fpMaxDistance, 2.f, 20.f, 0.5f, 1,
               "If the camera's look-at point is farther than this from the camera (or behind it), it is a cutscene or "
               "scripted camera: first person waits and the game's camera is used.", cam);
    o.AddAction("First person", "Reset first person", [] {
        VrSettings d; g_set.fpOffsetX = d.fpOffsetX; g_set.fpOffsetY = d.fpOffsetY; g_set.fpOffsetZ = d.fpOffsetZ;
        g_set.fpSmooth = d.fpSmooth; g_set.fpMaxDistance = d.fpMaxDistance; SettingsApplyCamera();
    }, "Eye offsets, bob filter and cutscene distance to their defaults.");

    // ---- HUD / UI
    auto& um = o.AddChoice("HUD", "ui_mode", "UI placement", &g_set.uiMode, { "eyes", "flat" },
                           "eyes: the game's UI is moved onto each eye's centre of view, scaled and set at a fixed depth "
                           "(one sharp image). flat: kept in the middle of each eye's picture, scaled by UI scale.", cam);
    um.choiceLabels = { "In the eyes (scaled, fixed depth)", "Picture centre (scaled)" };
    um.visible = [] { return false; };   // 0.6.20: one placement (both values place the UI the same way)
    o.AddBool("HUD", "ui_converge", "HUD at the HUD depth (alternate eye / synchronized)", &g_set.uiConverge,
              "Off (default): the HUD is the same in both eyes and sits at infinity - it always fuses, whatever the frame order (needs "
              "\"One symmetric view for both eyes\", on by default). On: each eye's HUD is shifted a little so it sits at the HUD depth; "
              "if it then shows double, switch \"HUD depth set for the next frame\" or turn this off.", [] {});
    o.AddBool("HUD", "ui_eye_next", "HUD depth set for the next frame (alternate eye / synchronized)", &g_set.uiEyeNext,
              "Alternate eye and synchronized draw the eyes in turn; the HUD gets a small sideways shift per eye so both eyes see it at "
              "the HUD depth. Off (default): the shift is set for the frame being drawn. If the HUD seems to sit behind the scene or "
              "pulls your eyes apart slightly, turn it on (hotkey F10 switches it while playing).", [] {});
    o.AddFloat("HUD", "ui_scale", "UI scale", &g_set.uiScale, 0.2f, 1.f, 0.01f, 2,
               "Size of the HUD and menus in your view: 1 = edge to edge, 0.6 = comfortable.", cam);
    { auto& ps = o.AddChoice("HUD", "ui_pick_sig", "UI element kind", &g_set.uiPickSig, {}, "", [] {}); ps.visible = [] { return false; }; }
    { auto& ul = o.AddChoice("HUD", "ui_layers", "UI layers (automatic)", &g_set.uiLayers, { "all", "one" },
                             "With the picker at 0: All = every full-screen UI layer the game draws (menus AND the gameplay HUD) is scaled; "
                             "One = only the busiest one.", [] {});
      ul.choiceLabels = { "All UI layers", "Busiest only" }; }
    o.AddInt("HUD", "ui_pick", "UI element (picker)", &g_set.uiPick, 0, 16, 1,
             "0 = automatic. 1, 2, 3 ... = each target the game draws 2D / UI into this session (the panel's status line "
             "shows how many were found). Step through them with the HUD in view until it shrinks to the UI scale - that one "
             "is the HUD. It is kept for this session and saved.", [] {});
    { auto& up = o.AddChoice("HUD", "ui_placement", "UI placed by", &g_set.uiPlacement, { "draws", "engine" },
          "Draws (default): the D3D12 draw viewports of the UI are moved to your line of sight, at the UI scale. This game draws "
          "its UI where those hooks cannot see it, so when no UI draw is found the game's own layout (Engine) does it, still on "
          "your line of sight, converged at the UI depth, text sharp. Engine: always the game's own layout.", cam);
      up.choiceLabels = { "D3D12 draws (+ engine layout)", "Engine layout only" }; }
    o.AddBool("HUD", "hide_hud", "Hide the HUD", &g_set.hideHud,
              "The gameplay HUD off in VR (also F7). Menus, pause screens and the flat screen keep their UI.", cam);
    o.AddFloat("HUD", "ui_depth", "UI depth (m)", &g_set.uiDepth, 0.5f, 10.f, 0.1f, 1, "How far away the UI appears.", cam);
    o.AddFloat("HUD", "ui_offset_y", "UI height", &g_set.uiOffsetY, -0.3f, 0.3f, 0.01f, 2, "Moves the UI up (+) or down (-).", cam);
    auto& hs = o.AddChoice("HUD", "hud_split", "Where the UI starts", &g_set.hudSplit, { "auto", "count", "all" },
                           "auto: after the full-screen pass that puts the 3D image on screen. count: after the given number "
                           "of draws. all: every draw into the final image is UI.", cam);
    hs.choiceLabels = { "Auto", "Draw count", "Everything" };
    o.AddInt("HUD", "hud_scene_draws", "3D draws before the UI", &g_set.hudSceneDraws, 0, 8, 1, "Only for 'Draw count'.", cam);

    // ---- Display
    auto& rr = o.AddChoice("Display", "render_resolution", "Render resolution", &g_set.renderResolution, { "auto", "game" },
                           "auto: the game renders at the headset's per-eye size and shape x render scale (the mod sets the game's render "
                           "surface with the swap chain; falls back to the game's own resolution if the game does not follow). "
                           "game: the resolution in the game's graphics menu.");
    rr.choiceLabels = { "Headset (auto)", "Game setting" }; rr.needsRestart = true;
    { auto& rdn = o.AddChoice("Display", "render_density", "Pixel density", &g_set.renderDensity, { "headset", "fixed" },
                              "Headset: when the rendered view is wider than the headset's own (stereo reconstruction draws one "
                              "eye wide enough for both, a cull margin, head mode), the eye image grows with it so the part you "
                              "see keeps the headset's full resolution. Fixed: the headset's size whatever is rendered (faster, "
                              "softer).", [] {});
      rdn.choiceLabels = { "Headset's full density", "Fixed size" }; }
    // 0.9.3 (framework rule 0.6.63): the VR resolution live - a slider for the new value, APPLY and HEADSET DEFAULT; applied in game, no
    // restart, saved at once. render_scale (the applied value) is a hidden saved option; the slider is only the pending value.
    { auto& rs = o.AddFloat("Display", "render_scale", "VR resolution (applied)", &g_set.renderScale, 0.3f, 2.f, 0.05f, 2, "",
                            [] { g_scalePending = g_set.renderScale; extern void ResolutionApplyLive(); ResolutionApplyLive(); MenuSaveNow(); });   // hotkeys step it: applied at once
      rs.visible = [] { return false; }; }
    g_scalePending = g_set.renderScale;
    o.AddFloat("Display", "vr_resolution", "VR resolution (per eye x)", &g_scalePending, 0.3f, 2.f, 0.05f, 2,
               "The headset's recommended size per eye x this. Move it, then APPLY: the game, the eye images and the headset's swap chains "
               "change size in game, with no restart, and the value is saved at once. Above 1 the GPU cost grows with the square (1.25 = 1.56 x "
               "the pixels). HEADSET DEFAULT goes back to the headset's own size.", [] {});
    o.AddAction("Display", "Apply VR resolution", [] {
        g_set.renderScale = g_scalePending; extern void ResolutionApplyLive(); ResolutionApplyLive(); MenuSaveNow();
        LOGI("resolution: VR resolution x %.2f saved", g_set.renderScale);
    }, "Use the slider's VR resolution now (in game, no restart); saved at once.");
    o.AddAction("Display", "Headset default resolution", [] {
        g_scalePending = 1.f; g_set.renderScale = 1.f; extern void ResolutionApplyLive(); ResolutionApplyLive(); MenuSaveNow();
        LOGI("resolution: VR resolution x %.2f saved", g_set.renderScale);
    }, "Back to the headset's own recommended size per eye (x 1.00), in game; saved at once.");
    o.AddBool("Display", "pace_lock", "Lock frames to the headset (synchronized / alternate)", &g_set.paceLock,
              "On (default): each frame release is nudged so the frame is handed over a little before the headset takes its picture - "
              "a synchronized pair then shows for exactly two refreshes (no judder from hand-overs drifting through the headset's "
              "frame). Needs the frame cap at the headset's rate. Logged every 10 s (\"pacing: lock error\").", [] {});
    o.AddBool("Display", "pair_rate", "Synchronized / alternate: both eyes every refresh", &g_set.pairRate,
              "Synchronized and alternate eye draw one eye per game frame, so at the headset's refresh rate each eye gets a "
              "new image every second refresh. On: when the GPU has room, the game runs at twice the refresh rate (evenly "
              "paced), so both eyes are new every refresh - smoother turning and motion, twice the GPU load. Adaptive: if "
              "the GPU can't keep it up it drops back to the refresh rate by itself and tries again later (logged). "
              "Other modes are not affected.", [] { FpsLimitSet(g_set.fpsLimit); });
    o.AddBool("Display", "fps_unlocked", "Uncapped frame rate", &g_set.fpsUnlocked,
              "On (default): no cap at all - the game runs as fast as it can, beyond the headset's refresh rate; the headset "
              "shows the newest frame each refresh. Off: the game runs at the headset's own refresh rate. Uncapped in VR "
              "takes GPU / CPU time from the headset's own frame thread: frames go late and the headset can drop to a "
              "lower rate (seen: 72 -> 48 Hz). For more fps use \"both eyes every refresh\" instead.",
              [] { FpsLimitSet(g_set.fpsLimit); });
    auto& fl = o.AddChoice("Display", "fps_limit", "FPS limiter", &g_set.fpsLimit, { "headset", "0" },
                           "Headset: never more frames than the headset's own refresh rate - never the half rate a headset's "
                           "motion smoothing / ASW runs at (a reported 45 Hz on a 90 Hz headset is taken as 90). Off: no cap "
                           "in flat mode (in VR it stays at the headset's rate - use Uncapped frame rate to go beyond it).",
                           [] { FpsLimitSet(g_set.fpsLimit); });
    fl.choiceLabels = { "Headset refresh rate", "Off" };
    o.AddFloat("Display", "headset_refresh_hz", "Headset refresh rate (Hz)", &g_set.headsetHz, 0.f, 240.f, 1.f, 0,
               "0 = automatic: the headset's own refresh rate, never the half rate its motion smoothing / ASW runs at "
               "(remembered per headset). Set it only if the log shows a wrong rate.", [] {});
    auto& sm = o.AddChoice("Display", "headset_smoothing", "Headset smoothing", &g_set.smoothing, { "full", "runtime", "repeat" },
                           "None of these ever slows the game: it keeps running at the headset's full refresh rate. Full rate "
                           "(default): every headset frame gets a fresh image on time, so Smart Smoothing / Motion Smoothing / "
                           "ASW / SSW never switch on. Headset smoothing: when the game is slower than the headset, the "
                           "headset's own smoothing fills in the missing frames. Repeat: the newest frame every headset frame.", apply);
    sm.choiceLabels = { "Full rate (default)", "Headset smoothing fills in", "Repeat newest" };
    auto gameS = [] { extern void SettingsApplyGame(); SettingsApplyGame(); };
    o.AddBool("Display", "lens_distortion_off", "Lens distortion off", &g_set.lensDistortionOff,
              "The game's camera-lens bending of the picture off. In VR it bends the world differently in each eye.", gameS);
    o.AddBool("Display", "chromatic_fringe_off", "Chromatic fringe off", &g_set.fringeOff,
              "The colour fringes at the picture's edges off (they split the colours apart in each eye).", gameS);
    o.AddBool("Display", "vignette_off", "Vignette off", &g_set.vignetteOff,
              "The dark ring around the picture off - in a headset it sits in your lenses like a tunnel.", gameS);
    o.AddBool("Display", "film_grain_off", "Film grain off", &g_set.filmGrainOff, "The film grain overlay off.", gameS);
    o.AddBool("Display", "lens_dirt_off", "Lens dirt off", &g_set.lensDirtOff, "The dirt-on-the-lens overlay of bright lights off.", gameS);
    o.AddBool("Display", "lens_flare_off", "Lens flare off", &g_set.lensFlareOff, "Screen-space lens flares off (they have no depth in VR).", gameS);
    o.AddFloat("Display", "sharpen", "Sharpening", &g_set.sharpen, 0.f, 2.f, 0.05f, 2, "Sharpens the 3D image. 0 = off.");
    auto& hd = o.AddChoice("Display", "hdr_input", "HDR input", &g_set.hdrInput, { "auto", "off", "pq", "scrgb" },
                           "The game's HDR output is converted for the headset (8-bit SDR). Better: HDR off in the game.");
    hd.choiceLabels = { "Auto", "SDR", "HDR10 (PQ)", "scRGB" };
    o.AddFloat("Display", "hdr_paper_white", "HDR paper white (nits)", &g_set.hdrNits, 80.f, 500.f, 10.f, 0, "HDR input only.");
    auto& mi = o.AddChoice("Display", "mirror", "Monitor shows", &g_set.mirror, { "left", "game" },
                           "left: the left eye (no flicker). game: what the game draws (alternates between the eyes).");
    mi.choiceLabels = { "Left eye", "Both (alternating)" };
    o.AddInt("Display", "max_frame_latency", "Frames queued ahead", &g_set.maxFrameLatency, 0, 4, 1,
             "Frames the CPU may prepare before the GPU shows them: 1-2 = the freshest head pose in each frame. 0 = the "
             "game's own. Only if the game's swap chain allows it (the log says).").needsRestart = true;
    o.AddBool("Display", "vsync_off", "No vsync on the monitor", &g_set.vsyncOff, "The monitor's refresh rate does not cap VR frames.");
    o.AddBool("Display", "no_black_bars", "No black bars", &g_set.noBlackBars,
              "The game keeps its picture between 1.6 and 2.33 wide per 1 high and fills the rest with black bars. A headset "
              "eye is about 0.9 wide per 1 high, so without this the eye would be letterboxed (bars top and bottom). On "
              "(default): the clamp stays open in VR - the picture always fills the eye. Flat screen mode keeps the game's own.", gameP);
    { auto& si = o.AddBool("Display", "skip_intro", "Skip intro logos", &g_set.skipIntro,
              "On (default): the publisher and studio logos at start are skipped - the game's own -FastLaunch switch, no "
              "separate no-intro mod needed. Takes effect at the next start.", gameP); si.needsRestart = true; }
    o.AddChoice("Display", "depth_of_field", "Depth of field", &g_set.depthOfField, { "cutscenes", "off", "game" },
              "The game's out-of-focus blur. In a headset a blurred background looks smeared and flat - your eyes focus "
              "themselves. cutscenes (default): off while a cutscene or scripted camera is shown, the game's own in play. "
              "off: never. game: as the game does it.", gameP);
    o.AddBool("Display", "run_in_background", "Keep full speed without focus", &g_set.runInBackground,
              "The game slows itself down while its window has no focus (its \"out of focus frame limiter\") - and in VR the "
              "headset software always has the focus. On (default): the limiter stays off.", gameP);

    // ---- Foveated (D3D12 variable rate shading)
    {
        auto toCustom = [] { if (g_set.fovMode != "off") g_set.fovMode = "custom"; };
        auto& fm = o.AddChoice("Foveated", "fov_mode", "Foveated rendering", &g_set.fovMode, { "off", "quality", "balanced", "performance", "custom" },
                               "Fixed foveated rendering: full detail around each eye's lens centre, fewer pixel-shader runs "
                               "towards the edges the lenses blur anyway. Any GPU with variable rate shading tier 2 (RTX 20+, "
                               "RX 6000+, Arc). The HUD / UI is never affected. Inner / outer zones: Advanced - Foveated rendering.");
        fm.choiceLabels = { "Off", "Quality", "Balanced", "Performance", "Custom" };
        o.AddFloat("Foveated", "fov_inner", "Full-detail zone", &g_set.fovInner, 0.1f, 1.5f, 0.05f, 2, "Radius in half image heights from the lens centre.", toCustom);
        o.AddFloat("Foveated", "fov_outer", "Reduced zone ends at", &g_set.fovOuter, 0.2f, 2.f, 0.05f, 2, "Beyond this: the lowest rate.", toCustom);
        o.AddFloat("Foveated", "fov_wide", "Zone width", &g_set.fovWide, 0.8f, 2.f, 0.05f, 2, "Above 1 = wider than tall (wide lenses).", toCustom);
        o.AddBool("Foveated", "fov_debug", "Show the zones", &g_set.fovDebug, "The outer ring at the coarsest rate, to see where it starts.");
    }

    // ---- Screen / menu
    o.AddFloat("Screen", "screen_distance", "Screen distance", &g_set.screenDistance, 1.f, 10.f, 0.1f, 1,
               "Flat screen mode, loading screens and videos.", apply);
    o.AddFloat("Screen", "screen_width", "Screen width", &g_set.screenWidth, 1.f, 10.f, 0.1f, 1, "Metres.", apply);
    { auto& pl = o.AddChoice("Screen", "panel_layers", "Panels shown as", &g_set.panelLayers, { "auto", "composite", "quad" },
                             "How this menu, the HUD and the flat screen reach the headset. Drawn into the picture works on every "
                             "headset; separate layers are a little sharper but some runtimes (Pimax) show them black or not at "
                             "all. Auto: drawn in on Pimax, layers elsewhere.", [] { SettingsApply(); });
      pl.choiceLabels = { "Auto", "Drawn into the picture", "Separate layers" }; }
    o.AddFloat("Screen", "menu_distance", "This menu's distance", &g_set.menuDistance, 0.5f, 4.f, 0.05f, 2, "Metres (in 3D).", apply);
    o.AddFloat("Screen", "menu_panel_width", "This menu's panel width", &g_set.menuPanelWidth, 0.4f, 3.f, 0.05f, 2, "Metres (in 3D).", apply);
    o.AddFloat("Screen", "menu_width", "Menu size on the panel", &g_set.menuWidth, 0.3f, 1.f, 0.05f, 2, "Fraction of the panel.");

    vrkit::menu::Settings s;
    s.title = "Resonance VR";
    s.fontPx = 26.f; s.texH = 860;   // 0.6.7: smaller text, a shorter panel, more rows per page
    { extern std::wstring g_cfgPath; s.configPath = g_cfgPath.empty() ? g_gameDir + L"\\resonancevr_config.txt" : g_cfgPath; }
    s.statusLine = [] {
        extern UINT g_bbW, g_bbH;
        char b[300];
        extern int UiPickCount();
        int pn = UiPickCount();
        char pk[40] = ""; if (g_set.uiPick > 0) snprintf(pk, sizeof pk, "  |  UI %d/%d", g_set.uiPick, pn); else if (pn) snprintf(pk, sizeof pk, "  |  UI auto (%d found)", pn);
        extern volatile int g_scenePct;
        char up[56] = "";   // 0.6.35: DLSS (temporal: mixes the eyes in synchronized / AER) / FSR / scale, and the measured size
        { std::string u = upscale::Status(game::RenderUpscale(), g_scenePct, g_cam.mode == VRMODE_SYNCED || g_cam.mode == VRMODE_STEREO);
          if (!u.empty()) snprintf(up, sizeof up, "  |  %s", u.c_str()); }
        char sc[48] = ""; { extern int SetupIssueCount(); int n = SetupIssueCount(); if (n) snprintf(sc, sizeof sc, "  |  SETUP: %d problem%s (log)", n, n > 1 ? "s" : ""); }
        snprintf(b, sizeof b, "%.0f FPS  |  %s  |  %ux%u per eye%s%s%s", g_fps,
                 g_cam.flatNow ? (g_cam.flatReason == 2 ? "FLAT (paused)" : "FLAT (F6)") : g_cam.mode == VRMODE_SYNCED ? "SYNCED 3D" : g_cam.mode == VRMODE_RECON ? "RECON 3D" : g_cam.mode == VRMODE_STEREO ? "AER 3D" : g_cam.mode == VRMODE_HEAD ? "HEAD" : "SCREEN", g_bbW, g_bbH, pk, up, sc);
        return std::string(b);
    };
    s.input.keyboardToggleVk = VK_INSERT;
    { float a = ConfigFloat("menu_opacity", 0.8f); s.backgroundAlpha = a < 0.3f ? 0.3f : a > 1.f ? 1.f : a; }
    { extern void HotkeysRegister(vrkit::Options&); HotkeysRegister(o); }   // 0.6.28: tab "Hotkeys"
    OffsetStepApply(o);
    OrganisePages(o);
    bool ok = vrkit::menu::Init(g_dev11, g_ctx11, s);
    // 0.6.47: every change in the panel goes into the log ("option swap_eyes: false -> true")
    vrkit::SetChangeHook([](const char* k, const char* a, const char* b) { LOGI("option %s: %s -> %s", k, a, b); });
    vrkit::Options::Get().Snapshot();
    if (ok) { extern void HotkeysStart(); HotkeysStart(); }
    LOGI("menu: %s (%ux%u)", ok ? "ready - Insert or L3+R3" : "init FAILED", vrkit::menu::Width(), vrkit::menu::Height());
}

// Present thread, before the frame goes to the headset. Returns the menu texture while open.
ID3D11Texture2D* MenuUpdate() {
    if (!g_dev11 || !g_ctx11) return nullptr;
    if (!g_menuInit) MenuInit();
    if (!vrkit::menu::IsOpen()) g_set.vrMode = ModeKey(g_cam.mode);
    bool wasOpen = vrkit::menu::IsOpen();
    { extern void MouseInputFrame(bool); MouseInputFrame(wasOpen); }
    if (wasOpen) ResolutionLabels();
    bool open = vrkit::menu::Update();
    { extern void HotkeysRun(); HotkeysRun(); }
    if (open != wasOpen) LOGI("menu: %s", open ? "opened" : "closed");
    return open ? vrkit::menu::Texture() : nullptr;
}

void MenuSetOpen(bool open) { if (g_menuInit) vrkit::menu::SetOpen(open); }

// 0.9.3 (Framework Boost 4): config validation - the file's keys that the code never asked for and that are neither on the panel nor in the
// default config: typos and old keys (logged once, up to 12 names)
const char* DefaultConfigText();
void ConfigValidateReport() {
    std::vector<std::string> known;
    for (auto& op : vrkit::Options::Get().All()) if (!op.key.empty()) known.push_back(op.key);
    const char* d = DefaultConfigText();
    for (const char* p = d; p && *p;) {
        const char* e = strchr(p, '\n'); size_t n = e ? (size_t)(e - p) : strlen(p);
        std::string line(p, n);
        size_t h = line.find('#'); if (h != std::string::npos) line = line.substr(0, h);
        size_t q = line.find('=');
        if (q != std::string::npos) {
            std::string k = line.substr(0, q);
            size_t a = k.find_first_not_of(" \t"), b = k.find_last_not_of(" \t");
            if (a != std::string::npos) known.push_back(k.substr(a, b - a + 1));
        }
        p = e ? e + 1 : p + n;
    }
    known.push_back("config_version");
    auto u = ConfigUnknownKeys(known);
    if (u.empty()) { LOGI("config: every setting in the file is known to this version"); return; }
    std::string list;
    for (size_t i = 0; i < u.size() && i < 12; i++) { if (i) list += ", "; list += u[i]; }
    LOGW("config: %d setting(s) this version does not know: %s%s - a typo or an old key; ignored", (int)u.size(), list.c_str(), u.size() > 12 ? ", ..." : "");
}
