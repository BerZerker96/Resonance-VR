// 0.6.47: diagnostics that make reports quick to read - all of it once at start, on events, or with the 10 s report;
// nothing runs per frame.
//   * system summary at start (Windows, CPU, RAM, GPU / driver / VRAM, HAGS, Game Mode, monitor, store build, OpenXR
//     runtime, VR tools running, overlays loaded)
//   * the settings that differ from the defaults (one line) and every option change in the panel ("option x: a -> b")
//   * crash report (unhandled exception: code, module + offset, code addresses on the stack, the mod's state)
//   * events: GPU device lost (with Windows' reason), VRAM over the budget Windows gives the game
//   * HEALTH line every 60 s (fps, VRAM, smoothing, time in VR / flat, setup problems)
//   * panel actions: "Mark an issue in the log", "Make a report folder"
#include "d3d.h"
#include <d3d11.h>
#include <dxgi1_4.h>
#include <tlhelp32.h>
#include <string>
#include <vector>
#include <map>
#include <cstdio>
#include <cmath>
#include "log.h"
#include "game.h"
#include "camera.h"
#include "settings.h"
#include "config.h"
#include "version.h"
#include "modtime.h"

extern std::wstring g_modDir, g_gameDir, g_cfgPath;
extern ID3D11Device* g_dev11;
extern ID3D12Device* g_dev12;
bool FpsRuntimeSmoothing();
int SetupIssueCount();
float MenuFps();
const char* DefaultConfigText();

namespace {
std::string U8(const std::wstring& w) { char b[1024]; WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, b, sizeof b, nullptr, nullptr); return b; }
std::string Low(std::string s) { for (auto& c : s) c = (char)tolower((unsigned char)c); return s; }
std::string Trim(std::string s) { size_t a = s.find_first_not_of(" \t\r\n"), b = s.find_last_not_of(" \t\r\n"); return a == std::string::npos ? "" : s.substr(a, b - a + 1); }

std::string RegStr(HKEY root, const wchar_t* key, const wchar_t* val) {
    wchar_t b[512]; DWORD n = sizeof b, t = 0;
    if (RegGetValueW(root, key, val, RRF_RT_REG_SZ | RRF_SUBKEY_WOW6464KEY, &t, b, &n) != ERROR_SUCCESS) return "";
    return U8(b);
}
int RegDw(HKEY root, const wchar_t* key, const wchar_t* val, int def) {
    DWORD v = 0, n = sizeof v;
    if (RegGetValueW(root, key, val, RRF_RT_REG_DWORD | RRF_SUBKEY_WOW6464KEY, nullptr, &v, &n) != ERROR_SUCCESS) return def;
    return (int)v;
}

IDXGIAdapter3* g_ad3 = nullptr;
bool g_vramOver = false;
unsigned g_samples = 0, g_vrSamples = 0, g_flatSamples = 0;
ULONGLONG g_t0 = 0, g_lastHealth = 0;
volatile LONG g_mark = 0;
LPTOP_LEVEL_EXCEPTION_FILTER g_prevFilter = nullptr;
volatile LONG g_crashed = 0;

std::string StateLine() {
    char b[400];
    snprintf(b, sizeof b, "mode %d, %s, VR frame %d, fps %.0f, smoothing %s, setup problems %d, flat reason %d, swap eyes %d",
             g_cam.mode, g_cam.flatNow ? "FLAT" : "VR", (int)CameraFrameIsVR(), MenuFps(), FpsRuntimeSmoothing() ? "ON" : "off",
             SetupIssueCount(), g_cam.flatReason, (int)g_set.swapEyes);
    return b;
}

std::string ModAt(uintptr_t a) {
    HMODULE m = nullptr; char b[300];
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)a, &m) || !m) {
        snprintf(b, sizeof b, "%llx (no module)", (unsigned long long)a); return b;
    }
    wchar_t p[MAX_PATH]; GetModuleFileNameW(m, p, MAX_PATH);
    const wchar_t* n = wcsrchr(p, L'\\'); n = n ? n + 1 : p;
    snprintf(b, sizeof b, "%s+%llx", U8(n).c_str(), (unsigned long long)(a - (uintptr_t)m));
    return b;
}

LONG WINAPI CrashFilter(EXCEPTION_POINTERS* ep) {
    if (InterlockedExchange(&g_crashed, 1) == 0 && ep && ep->ExceptionRecord) {
        const EXCEPTION_RECORD* r = ep->ExceptionRecord;
        uintptr_t at = (uintptr_t)r->ExceptionAddress;
        LOGE("==================================================================================================");
        LOGE("CRASH: exception %08lx at %s%s", (unsigned long)r->ExceptionCode, ModAt(at).c_str(),
             r->ExceptionCode == EXCEPTION_ACCESS_VIOLATION && r->NumberParameters >= 2
                 ? (r->ExceptionInformation[0] == 1 ? " (writing an invalid address)" : r->ExceptionInformation[0] == 8 ? " (executing an invalid address)" : " (reading an invalid address)") : "");
        if (r->ExceptionCode == EXCEPTION_ACCESS_VIOLATION && r->NumberParameters >= 2)
            LOGE("CRASH: invalid address %llx", (unsigned long long)r->ExceptionInformation[1]);
        if (ep->ContextRecord) {
            const CONTEXT* c = ep->ContextRecord;
            LOGE("CRASH: rax %llx rbx %llx rcx %llx rdx %llx rsi %llx rdi %llx rbp %llx rsp %llx", c->Rax, c->Rbx, c->Rcx, c->Rdx, c->Rsi, c->Rdi, c->Rbp, c->Rsp);
            // code addresses found on the stack (the calls that led here, roughly, newest first)
            const uintptr_t* sp = (const uintptr_t*)ep->ContextRecord->Rsp;
            std::string st; int found = 0;
            for (int i = 0; i < 512 && found < 14; i++) {
                MEMORY_BASIC_INFORMATION mi;
                if ((i & 63) == 0 && (!VirtualQuery(sp + i, &mi, sizeof mi) || !(mi.State & MEM_COMMIT))) break;
                uintptr_t v = sp[i];
                if (v < 0x10000) continue;
                if (!VirtualQuery((void*)v, &mi, sizeof mi) || !(mi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY))) continue;
                HMODULE m = nullptr;
                if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCWSTR)v, &m) || !m) continue;
                st += " "; st += ModAt(v); found++;
            }
            LOGE("CRASH: stack:%s", st.c_str());
        }
        LOGE("CRASH: mod state - %s", StateLine().c_str());
        LOGE("==================================================================================================");
        LogFlushDisk();
    }
    return g_prevFilter ? g_prevFilter(ep) : EXCEPTION_CONTINUE_SEARCH;
}

void Processes(std::string& vr, std::string& tools) {
    HANDLE h = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (h == INVALID_HANDLE_VALUE) return;
    static const char* vrNames[] = { "ovrserver_x64.exe", "oculusclient.exe", "vrserver.exe", "vrcompositor.exe", "virtualdesktop.streamer.exe",
                                     "piservice.exe", "piservicelauncher.exe", "pimaxclient.exe", "pimax play.exe", "wmr", "mixedrealityportal.exe" };
    static const char* toolNames[] = { "oculustraytool.exe", "processlasso.exe", "processgovernor.exe", "rtss.exe", "msiafterburner.exe",
                                       "fpsvr", "openkneeboard", "openxr-toolkit", "obs64.exe", "lossless scaling", "losslessscaling.exe",
                                       "specialk", "reshade" };
    PROCESSENTRY32W pe = { sizeof pe };
    for (BOOL ok = Process32FirstW(h, &pe); ok; ok = Process32NextW(h, &pe)) {
        std::string n = Low(U8(pe.szExeFile));
        for (const char* v : vrNames) if (n.find(v) != std::string::npos) { if (vr.find(n) == std::string::npos) { if (!vr.empty()) vr += ", "; vr += n; } break; }
        for (const char* t : toolNames) if (n.find(t) != std::string::npos) { if (tools.find(n) == std::string::npos) { if (!tools.empty()) tools += ", "; tools += n; } break; }
    }
    CloseHandle(h);
}

std::string Overlays() {
    static const char* names[] = { "gameoverlayrenderer64.dll", "rtsshooks64.dll", "discordhook64.dll", "nvspcap64.dll", "igo64.dll",
                                   "graphics-hook64.dll", "overlay64.dll", "uplay_overlay", "upc_r2_loader64.dll" };
    std::string out;
    for (const char* n : names) if (GetModuleHandleA(n)) { if (!out.empty()) out += ", "; out += n; }
    return out;
}
}

// main.cpp, before the log is opened: the previous run's logs are kept as *.prev.log
void DiagRotateLogs(const std::wstring& dir) {
    for (const wchar_t* n : { L"resonancevr", L"xrhost" }) {
        std::wstring a = dir + L"\\" + n + L".log", b = dir + L"\\" + n + L".prev.log";
        if (GetFileAttributesW(a.c_str()) != INVALID_FILE_ATTRIBUTES) MoveFileExW(a.c_str(), b.c_str(), MOVEFILE_REPLACE_EXISTING);
    }
}

void DiagInstallCrashHandler() {
    LPTOP_LEVEL_EXCEPTION_FILTER p = SetUnhandledExceptionFilter(CrashFilter);
    if (p != CrashFilter) g_prevFilter = p;
}

// once, after the config is loaded
void DiagStartup() {
    g_t0 = ModTick64();
    SYSTEMTIME t; GetLocalTime(&t);
    LOGI("run: %04d-%02d-%02d %02d:%02d:%02d, id %08lx - ResonanceVR %s (the previous run's logs: resonancevr.prev.log / xrhost.prev.log)",
         t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond, (unsigned long)(GetTickCount() ^ GetCurrentProcessId() * 2654435761u), ResonanceVR_VERSION);
    DiagInstallCrashHandler();
    // Windows, CPU, RAM, HAGS, Game Mode, monitor
    {
        typedef LONG(WINAPI * PFN)(OSVERSIONINFOW*);
        OSVERSIONINFOW v = { sizeof v };
        if (PFN f = (PFN)GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "RtlGetVersion")) f(&v);
        MEMORYSTATUSEX ms = { sizeof ms }; GlobalMemoryStatusEx(&ms);
        std::string cpu = Trim(RegStr(HKEY_LOCAL_MACHINE, L"HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", L"ProcessorNameString"));
        int hags = RegDw(HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers", L"HwSchMode", 0);
        int gm = RegDw(HKEY_CURRENT_USER, L"Software\\Microsoft\\GameBar", L"AutoGameModeEnabled", -1);
        DEVMODEW dm = {}; dm.dmSize = sizeof dm; EnumDisplaySettingsW(nullptr, ENUM_CURRENT_SETTINGS, &dm);
        LOGI("system: Windows %lu.%lu build %lu | CPU %s, %u logical | RAM %.0f GB | HAGS %s | Game Mode %s | monitor %lux%lu @ %lu Hz",
             v.dwMajorVersion, v.dwMinorVersion, v.dwBuildNumber, cpu.c_str(), (unsigned)GetActiveProcessorCount(ALL_PROCESSOR_GROUPS),
             ms.ullTotalPhys / 1073741824.0, hags == 2 ? "on" : hags == 1 ? "off" : "default", gm == 0 ? "off" : gm == 1 ? "on" : "default",
             dm.dmPelsWidth, dm.dmPelsHeight, dm.dmDisplayFrequency);
    }
    // OpenXR runtime, VR software, tools
    {
        std::string rt = RegStr(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Khronos\\OpenXR\\1", L"ActiveRuntime");
        std::string vr, tools; Processes(vr, tools);
        LOGI("system: active OpenXR runtime %s | VR software running: %s | tools running: %s", rt.empty() ? "(none set)" : rt.c_str(),
             vr.empty() ? "none found" : vr.c_str(), tools.empty() ? "none" : tools.c_str());
    }
    // settings that differ from the defaults
    {
        std::string diff; int n = 0;
        const char* p = DefaultConfigText();
        while (p && *p) {
            const char* e = strchr(p, '\n'); std::string line(p, e ? (size_t)(e - p) : strlen(p)); p = e ? e + 1 : nullptr;
            line = Trim(line);
            if (line.empty() || line[0] == '#' || line[0] == ';') continue;
            size_t eq = line.find('='); if (eq == std::string::npos) continue;
            std::string k = Trim(line.substr(0, eq)), dv = Trim(line.substr(eq + 1));
            size_t hc = dv.find(" #"); if (hc != std::string::npos) dv = Trim(dv.substr(0, hc));
            std::string uv = Trim(ConfigStr(k.c_str(), dv.c_str()));
            if (Low(uv) != Low(dv)) { char b[200]; snprintf(b, sizeof b, "%s%s = %s (default %s)", n ? "; " : "", k.c_str(), uv.c_str(), dv.c_str()); diff += b; n++; }
        }
        if (n) LOGI("config: %d setting(s) differ from the defaults: %s", n, diff.c_str());
        else LOGI("config: all settings at their defaults");
    }
}

// the D3D11 device is there (compositor init): GPU, driver, VRAM, overlays
void DiagGpu() {
    static bool done = false; if (done || !g_dev11) return; done = true;
    IDXGIDevice* dd = nullptr; IDXGIAdapter* ad = nullptr;
    if (SUCCEEDED(g_dev11->QueryInterface(__uuidof(IDXGIDevice), (void**)&dd)) && dd && SUCCEEDED(dd->GetAdapter(&ad)) && ad) {
        DXGI_ADAPTER_DESC d = {}; ad->GetDesc(&d);
        LARGE_INTEGER umd = {}; ad->CheckInterfaceSupport(__uuidof(IDXGIDevice), &umd);
        LOGI("system: GPU %s, %.1f GB VRAM, driver %u.%u.%u.%u", U8(d.Description).c_str(), d.DedicatedVideoMemory / 1073741824.0,
             HIWORD(umd.HighPart), LOWORD(umd.HighPart), HIWORD(umd.LowPart), LOWORD(umd.LowPart));
        ad->QueryInterface(__uuidof(IDXGIAdapter3), (void**)&g_ad3);
    }
    if (ad) ad->Release();
    if (dd) dd->Release();
    // the game build (game::Init has run by now)
    {
        wchar_t ep[MAX_PATH] = L""; GetModuleFileNameW(nullptr, ep, MAX_PATH);
        bool xbox = wcsstr(ep, L"WindowsApps") || wcsstr(ep, L"XboxGames") || wcsstr(ep, L"ModifiableWindowsApps");
        const char* store = xbox ? "Xbox / Microsoft Store" : GetModuleHandleW(L"EOSSDK-Win64-Shipping.dll") ? "Epic" : GetModuleHandleW(L"steam_api64.dll") ? "Steam" : "unknown store";
        auto* dos = (IMAGE_DOS_HEADER*)game::g_base;
        unsigned long link = game::g_base ? (unsigned long)((IMAGE_NT_HEADERS64*)(game::g_base + dos->e_lfanew))->FileHeader.TimeDateStamp : 0;
        LOGI("system: game %s build, image %llu bytes, link date %08lx%s", store, (unsigned long long)game::g_size, link,
             game::g_otherModPatchedGame ? ", game code patched / hooked by another mod" : "");
    }
    std::string ov = Overlays();
    LOGI("system: overlays loaded into the game: %s", ov.empty() ? "none" : ov.c_str());
}

// Present returned a device-lost error
void DiagDeviceLost(HRESULT hr) {
    static bool said = false; if (said) return; said = true;
    HRESULT why = g_dev12 ? g_dev12->GetDeviceRemovedReason() : S_OK;
    LOGE("==================================================================================================");
    LOGE("GPU DEVICE LOST: Present returned %08lx, reason %08lx (%s) - the driver reset the GPU (driver crash / timeout / overclock / "
         "out of VRAM). State: %s", (unsigned long)hr, (unsigned long)why,
         why == DXGI_ERROR_DEVICE_HUNG ? "device hung" : why == DXGI_ERROR_DEVICE_RESET ? "device reset" : why == DXGI_ERROR_DRIVER_INTERNAL_ERROR ? "driver internal error" :
         why == DXGI_ERROR_INVALID_CALL ? "invalid call" : why == DXGI_ERROR_DEVICE_REMOVED ? "device removed" : "see code", StateLine().c_str());
    LOGE("==================================================================================================");
    LogFlushDisk();
}

// with the 10 s report
void DiagReport() {
    g_samples++;
    if (CameraFrameIsVR() && !g_cam.flatNow) g_vrSamples++; else g_flatSamples++;
    char vram[120] = "VRAM n/a";
    if (g_ad3) {
        DXGI_QUERY_VIDEO_MEMORY_INFO mi = {};
        if (SUCCEEDED(g_ad3->QueryVideoMemoryInfo(0, DXGI_MEMORY_SEGMENT_GROUP_LOCAL, &mi)) && mi.Budget) {
            double u = mi.CurrentUsage / 1073741824.0, b = mi.Budget / 1073741824.0;
            snprintf(vram, sizeof vram, "VRAM %.1f of %.1f GB", u, b);
            bool over = mi.CurrentUsage > mi.Budget;
            if (over != g_vramOver) {
                g_vramOver = over;
                if (over) LOGE("VRAM OVER BUDGET: the game uses %.1f GB of the %.1f GB Windows gives it - expect stutter and hitches. Lower the render "
                               "scale / the game's texture quality, close other GPU programs", u, b);
                else LOGI("VRAM back within the budget (%.1f of %.1f GB)", u, b);
            }
        }
    }
    ULONGLONG now = ModTick64();   // 0.6.52: real time - a speed hack scales GetTickCount64
    {   // 0.6.52 clock check (from the ACUnity VR mod): the game's clock against real time - a speed hack (Cheat Engine ...)
        // shows as a ratio other than 1. The mod's pacing uses the real clock, so VR keeps working; this only says so.
        static ULONGLONG g0 = 0, r0 = 0; static int said = 0;
        ULONGLONG g = GetTickCount64();
        if (!g0) { g0 = g; r0 = now; }
        else if (now - r0 >= 10000) {
            double ratio = (double)(g - g0) / (double)(now - r0);
            int state = ratio > 1.05 ? 1 : ratio < 0.95 ? -1 : 0;
            if (state != said) {
                said = state;
                if (state) LOGW("CLOCK CHECK: the game's clock runs at %.2fx real time - a speed hack / time-scaling tool is active. VR timing "
                                "uses the real clock and keeps working; game speed, physics and animations follow the tool.", ratio);
                else LOGI("CLOCK CHECK: the game's clock runs at real time again (%.2fx)", ratio);
            }
            g0 = g; r0 = now;
        }
    }
    if (now - g_lastHealth >= 60000) {
        g_lastHealth = now;
        unsigned mins = (unsigned)((now - g_t0) / 60000);
        LOGI("HEALTH: %u min running | %.0f fps | %s | smoothing %s | VR %u%% / flat %u%% of the time | setup problems %d | %s", mins, MenuFps(), vram,
             FpsRuntimeSmoothing() ? "ON (problem)" : "off", g_samples ? g_vrSamples * 100 / g_samples : 0, g_samples ? g_flatSamples * 100 / g_samples : 0,
             SetupIssueCount(), StateLine().c_str());
    }
    // 0.6.47: synchronized / alternating stereo draws one eye per game frame - below ~60 game fps each eye gets under 30
    // new images a second (judder, "motion vectors look off" when turning). Said once per stretch of 30 s.
    {
        static int lowRuns = 0; static bool said = false;
        float f = MenuFps();
        bool alt = (g_cam.mode == VRMODE_SYNCED || g_cam.mode == VRMODE_STEREO) && CameraFrameIsVR() && !g_cam.flatNow;
        if (alt && f > 1 && f < 60) { if (++lowRuns == 3 && !said) { said = true;
            LOGW("LOW FPS FOR THIS MODE: %s stereo at %.0f game fps - each eye gets only %.0f new images a second (judder / smearing when "
                 "turning). The GPU can't keep up: lower the render scale or the game's settings, or use stereo reconstruction (both eyes every frame).",
                 g_cam.mode == VRMODE_SYNCED ? "synchronized" : "alternating", f, f / 2); } }
        else { lowRuns = 0; if (!alt) said = false; }
    }
    static int s_reassert = 0;
    if (++s_reassert == 3) DiagInstallCrashHandler();   // the game may install its own crash handler after start: ours goes in front, then calls it
}

// panel actions
void DiagMarkIssue() {
    LONG n = InterlockedIncrement(&g_mark);
    LOGW("==================================================================================================");
    LOGW("USER MARK #%ld - the player marked a problem here. State: %s", n, StateLine().c_str());
    LOGW("==================================================================================================");
    LogFlushDisk();
}
void DiagMakeReport() {
    LogFlushDisk();
    SYSTEMTIME t; GetLocalTime(&t);
    wchar_t sub[64]; wsprintfW(sub, L"\\report_%04d%02d%02d_%02d%02d%02d", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond);
    std::wstring dir = g_modDir + sub;
    if (!CreateDirectoryW(dir.c_str(), nullptr)) { LOGW("report: folder could not be made (%lu)", GetLastError()); return; }
    int ok = 0;
    for (const wchar_t* n : { L"resonancevr.log", L"xrhost.log", L"resonancevr.prev.log", L"xrhost.prev.log", L"headset.txt", L"refresh.txt" }) {
        std::wstring a = g_modDir + L"\\" + n, b = dir + L"\\" + n;
        if (CopyFileW(a.c_str(), b.c_str(), FALSE)) ok++;
    }
    std::wstring cfg = g_cfgPath.empty() ? g_gameDir + L"\\resonancevr_config.txt" : g_cfgPath;
    if (CopyFileW(cfg.c_str(), (dir + L"\\resonancevr_config.txt").c_str(), FALSE)) ok++;
    LOGI("report: %d files copied to %s - send that folder (zip it) with what you did", ok, U8(dir).c_str());
}
