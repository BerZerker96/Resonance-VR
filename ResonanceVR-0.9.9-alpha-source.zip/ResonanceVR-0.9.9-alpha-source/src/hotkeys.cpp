// Hotkeys (VR panel tab "Hotkeys"): every mod function that is worth a button, each with one keyboard key (Ctrl /
// Shift / Alt allowed) and one gamepad combination (1-3 buttons, triggers count as buttons). Bindings are options of
// their own ("hotkey_<name> = <key> | <pad>" in resonancevr_config.txt), set in the panel by pressing the new key / buttons.
//   * keyboard: only while the game window is in front (typing elsewhere does not trigger anything),
//   * gamepad: every connected XInput pad (Xbox pads, and PlayStation / other pads through Steam Input or DS4Windows),
//     also without focus (the game keeps playing behind the headset software); a combination of 2+ buttons is hidden
//     from the game while it is held,
//   * while the panel is open: keyboard hotkeys work, gamepad hotkeys do not (the pad drives the panel); while a
//     binding is being captured, nothing fires.
// Polled every 5 ms on a thread of its own; the functions run on the Present thread (MenuUpdate -> HotkeysRun).
#include <windows.h>
#include <string>
#include <vector>
#include <cstring>
#include "log.h"
#include "camera.h"
#include "config.h"
#include "settings.h"
#include "firstperson.h"
#include "vrkit_options.h"
#include "vrkit_input.h"
#include "vrkit_menu.h"

void XrRequestRecenter();
void XrSetMode(int mode);
void ScreenshotRequest();
void SettingsApplyGame();

namespace {
enum Kind { Fn, Toggle, StepUp, StepDown, RunAction };
struct Hk {
    const char* key;       // config key
    const char* label;     // panel text
    const char* group;     // section in the tab
    const char* def;       // default binding ("none | none" = unbound)
    Kind kind; const char* target;   // Toggle / Step*: option key; RunAction: action label
    void (*fn)();
    const char* help;
    std::string value;     // current binding text
    vrkit::input::Binding b;
};

void CycleMode() {
    int m = g_cam.mode;
    XrSetMode(m == VRMODE_SYNCED ? VRMODE_RECON : m == VRMODE_RECON ? VRMODE_STEREO : m == VRMODE_STEREO ? VRMODE_HEAD : m == VRMODE_HEAD ? VRMODE_SCREEN : VRMODE_SYNCED);
}
void Flat() { g_cam.flatHold = !g_cam.flatHold; LOGI("hotkeys: flat screen %s", g_cam.flatHold ? "held" : "released"); }

Hk g_hk[] = {
    // menu: handled by vrkit (its open / close key and pad combination are set from this binding)
    { "hotkey_menu", "VR panel open / close", "Mod", "INSERT | L3+R3", Fn, nullptr, nullptr,
      "Opens and closes this panel. The pad combination is held for a moment. If both are cleared, Insert stays." },
    { "hotkey_recenter", "Recenter view", "Mod", "SPACE | none", Fn, nullptr, [] { XrRequestRecenter(); }, "Puts the view and the panels in front of you." },
    { "hotkey_recenter_2", "Recenter view (second binding)", "Mod", "F9 | none", Fn, nullptr, [] { XrRequestRecenter(); }, "A second binding for recentering." },
    { "hotkey_screenshot", "Screenshot", "Mod", "DELETE | none", Fn, nullptr, [] { ScreenshotRequest(); }, "Saves the left eye as a PNG (Screenshot setting on the Screen tab)." },
    { "hotkey_flat", "Flat screen on / off", "Mod", "F6 | none", Fn, nullptr, Flat, "Shows the flat virtual screen until pressed again." },
    { "hotkey_hud", "HUD on / off", "Mod", "F7 | none", Fn, nullptr, [] { g_set.hideHud = !g_set.hideHud; LOGI("hotkeys: HUD %s", g_set.hideHud ? "hidden" : "shown"); }, "Hides / shows the gameplay HUD in VR." },
    { "hotkey_first_person", "First person on / off", "Mod", "END | none", Fn, nullptr, [] { fp::Toggle(); }, "Your eye at the character the camera follows." },
    // stereo
    { "hotkey_vr_mode", "Cycle stereo method", "Stereo", "F8 | none", Fn, nullptr, CycleMode, "Synchronized -> reconstruction -> alternate eye -> head -> screen." },
    { "hotkey_mode_synced", "Stereo method: synchronized", "Stereo", "none | none", Fn, nullptr, [] { XrSetMode(VRMODE_SYNCED); }, "" },
    { "hotkey_mode_aer", "Stereo method: alternate eye", "Stereo", "none | none", Fn, nullptr, [] { XrSetMode(VRMODE_STEREO); }, "" },
    { "hotkey_mode_recon", "Stereo method: reconstruction", "Stereo", "none | none", Fn, nullptr, [] { XrSetMode(VRMODE_RECON); }, "" },
    { "hotkey_mode_head", "Stereo method: head (2D)", "Stereo", "none | none", Fn, nullptr, [] { XrSetMode(VRMODE_HEAD); }, "" },
    { "hotkey_mode_screen", "Stereo method: screen", "Stereo", "none | none", Fn, nullptr, [] { XrSetMode(VRMODE_SCREEN); }, "" },
    { "hotkey_swap_eyes", "Swap eyes on / off", "Stereo", "none | none", Toggle, "swap_eyes", nullptr, "" },
    { "hotkey_world_scale_up", "World scale +", "Stereo", "none | none", StepUp, "world_scale", nullptr, "One step of the World scale setting." },
    { "hotkey_world_scale_down", "World scale -", "Stereo", "none | none", StepDown, "world_scale", nullptr, "" },
    { "hotkey_ipd_up", "Eye distance +", "Stereo", "none | none", StepUp, "ipd_scale", nullptr, "" },
    { "hotkey_ipd_down", "Eye distance -", "Stereo", "none | none", StepDown, "ipd_scale", nullptr, "" },
    // camera
    { "hotkey_head_aim", "Cycle head aim (off / always / while aiming)", "Camera", "none | none", Toggle, "head_aim", nullptr, "" },
    { "hotkey_decoupled_pitch", "Decoupled pitch on / off", "Camera", "none | none", Toggle, "decoupled_pitch", nullptr, "" },
    { "hotkey_reset_camera", "Reset camera offset", "Camera", "none | none", RunAction, "Reset camera", nullptr, "" },
    { "hotkey_fp_body", "First person: hide body on / off", "Camera", "none | none", Toggle, "fp_hide_body", nullptr, "" },
    // HUD / graphics
    { "hotkey_ui_mode", "Cycle UI placement", "HUD and graphics", "none | none", Toggle, "ui_mode", nullptr, "" },
    { "hotkey_ui_eye", "HUD eye: this frame / next frame", "HUD and graphics", "F10 | none", Toggle, "ui_eye_next", nullptr, "Alternate eye / synchronized: if the HUD shows as two images, press it once." },
    { "hotkey_ui_scale_up", "UI scale +", "HUD and graphics", "none | none", StepUp, "ui_scale", nullptr, "" },
    { "hotkey_ui_scale_down", "UI scale -", "HUD and graphics", "none | none", StepDown, "ui_scale", nullptr, "" },
    { "hotkey_game_aa", "Cycle game anti-aliasing", "HUD and graphics", "none | none", Toggle, "game_aa", nullptr, "" },
    { "hotkey_sharpen_up", "Sharpening +", "HUD and graphics", "none | none", StepUp, "sharpen", nullptr, "" },
    { "hotkey_sharpen_down", "Sharpening -", "HUD and graphics", "none | none", StepDown, "sharpen", nullptr, "" },
    { "hotkey_mirror", "Cycle what the monitor shows", "HUD and graphics", "none | none", Toggle, "mirror", nullptr, "" },
    // performance
    { "hotkey_fps_unlocked", "Uncapped frame rate on / off", "Performance", "none | none", Toggle, "fps_unlocked", nullptr, "" },
    { "hotkey_foveated", "Cycle foveated rendering", "Performance", "none | none", Toggle, "fov_mode", nullptr, "" },
    { "hotkey_wide_cull", "Wide culling on / off", "Performance", "none | none", Toggle, "wide_cull", nullptr, "" },
    { "hotkey_render_scale_up", "Render scale +", "Performance", "none | none", StepUp, "render_scale", nullptr, "" },
    { "hotkey_render_scale_down", "Render scale -", "Performance", "none | none", StepDown, "render_scale", nullptr, "" },
};
const int kN = (int)(sizeof g_hk / sizeof *g_hk);

volatile LONG g_queue[64]; volatile LONG g_qHead = 0, g_qTail = 0;   // single producer (key thread), single consumer (Present)
void Push(int i) { LONG h = g_qHead; if (h - g_qTail >= 64) return; g_queue[h & 63] = i; InterlockedExchange(&g_qHead, h + 1); }
volatile LONG g_dirty = 1;   // bindings changed: the key thread re-reads them

// the old single-key settings (recenter_key, screenshot_key, fp_key) seed the defaults of configs from before 0.6.28
std::string OldKey(const char* old, const char* def) { std::string v = ConfigStr(old, ""); return v.empty() ? def : v + " | none"; }

void ApplyMenuBinding() {
    vrkit::input::Binding b = g_hk[0].b;
    vrkit::input::Settings s = vrkit::menu::core::Get().input;
    if (!b.vk && !b.pad) { b.vk = VK_INSERT; LOGW("hotkeys: the VR panel had no key and no pad binding - Insert kept"); }
    s.keyboardToggleVk = b.vk; s.keyboardToggleMods = b.mods;
    s.chordMask = b.pad; s.chordButtons = 0; s.chordTriggers = false;
    vrkit::input::Configure(s);
}

void Refresh() {
    std::vector<unsigned> combos;
    for (int i = 0; i < kN; i++) {
        g_hk[i].b = vrkit::input::ParseBinding(g_hk[i].value);
        if (i > 0 && g_hk[i].b.pad) combos.push_back(g_hk[i].b.pad);
    }
    vrkit::input::SetHiddenCombos(combos.data(), (int)combos.size());
    InterlockedExchange(&g_dirty, 1);
}

DWORD WINAPI Thread(LPVOID) {
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);
    struct Cur { int vk, mods; unsigned pad; } cur[64] = {};
    bool keyWas[64] = {}, padWas[64] = {};
    for (;;) {
        Sleep(5);
        if (InterlockedExchange(&g_dirty, 0)) {
            for (int i = 0; i < kN && i < 64; i++) { cur[i] = { g_hk[i].b.vk, g_hk[i].b.mods, g_hk[i].b.pad }; keyWas[i] = padWas[i] = true; }   // new bindings: wait for a release first
        }
        bool capturing = vrkit::menu::core::IsCapturing(), open = vrkit::menu::IsOpen();
        DWORD pid = 0; GetWindowThreadProcessId(GetForegroundWindow(), &pid);
        bool fg = pid == GetCurrentProcessId();
        int mods = ((GetAsyncKeyState(VK_CONTROL) & 0x8000) ? vrkit::input::ModCtrl : 0) | ((GetAsyncKeyState(VK_SHIFT) & 0x8000) ? vrkit::input::ModShift : 0) |
                   ((GetAsyncKeyState(VK_MENU) & 0x8000) ? vrkit::input::ModAlt : 0);
        bool anyPad = false; for (int i = 1; i < kN; i++) if (cur[i].pad) { anyPad = true; break; }
        unsigned pads = anyPad ? vrkit::input::ReadPadsAll() : 0;
        for (int i = 1; i < kN && i < 64; i++) {   // [0] = the panel's own binding (vrkit)
            bool kd = cur[i].vk && fg && (GetAsyncKeyState(cur[i].vk) & 0x8000) && mods == cur[i].mods;
            bool pd = cur[i].pad && (pads & cur[i].pad) == cur[i].pad;
            // the panel's own keys (Enter, Backspace, Delete, Page Up / Down, Home, arrows) belong to the panel while
            // it is open: Delete there is "undo", not a screenshot
            bool panelKey = open && !cur[i].mods && (cur[i].vk == VK_RETURN || cur[i].vk == VK_BACK || cur[i].vk == VK_DELETE || cur[i].vk == VK_PRIOR ||
                            cur[i].vk == VK_NEXT || cur[i].vk == VK_HOME || (cur[i].vk >= VK_LEFT && cur[i].vk <= VK_DOWN));
            // a pad combination that is part of a larger one being held (LB bound, LB+Y held): only the larger fires
            bool covered = false;
            if (pd && !padWas[i])
                for (int j = 1; j < kN && j < 64; j++)
                    if (j != i && cur[j].pad && (cur[j].pad & cur[i].pad) == cur[i].pad && cur[j].pad != cur[i].pad && (pads & cur[j].pad) == cur[j].pad) { covered = true; break; }
            if (kd && !keyWas[i] && !capturing && !panelKey) Push(i);
            if (pd && !padWas[i] && !capturing && !open && !covered) Push(i);
            keyWas[i] = kd; padWas[i] = pd;
        }
    }
}
} // namespace

// menu.cpp, while the options are registered: one row per function on the "Hotkeys" tab
void HotkeysRegister(vrkit::Options& o) {
    for (int i = 0; i < kN; i++) {
        Hk& h = g_hk[i];
        std::string def = h.def;
        if (!strcmp(h.key, "hotkey_recenter")) def = OldKey("recenter_key", h.def);
        else if (!strcmp(h.key, "hotkey_screenshot")) def = OldKey("screenshot_key", h.def);
        else if (!strcmp(h.key, "hotkey_first_person")) def = OldKey("fp_key", h.def);
        h.value = ConfigStr(h.key, def.c_str());
        h.value = vrkit::input::BindingText(vrkit::input::ParseBinding(h.value));   // tidy ("f8" -> "F8 | none")
        std::string help = std::string(h.help) + (h.help[0] ? " " : "") + (i == 0
            ? "A / Enter / click: press the new key or pad buttons. The VR panel key is always bound (it cannot be unbound)."
            : "A / Enter / click: press the new key or pad buttons. X in front of the keys (Left then A / Enter, or click it): unbind keyboard and pad.");
        auto& op = o.AddHotkey("Hotkeys", h.key, h.label, &h.value, "", [i] { Refresh(); if (i == 0) ApplyMenuBinding(); });
        op.help = help; op.group = h.group;
        if (i == 0) op.noUnbind = true;   // 0.6.39: the VR panel's own key can never be unbound (no X, no clear)
        op.defaultText = vrkit::input::BindingText(vrkit::input::ParseBinding(h.def));
    }
    o.AddAction("Hotkeys", "Restore the default hotkeys", [] {
        auto& all = vrkit::Options::Get().All();
        for (auto& op : all) if (op.type == vrkit::OptType::Hotkey) vrkit::Options::Get().SetValueText(op, op.defaultText);
        LOGI("hotkeys: defaults restored");
    }, "Every binding back to the mod's defaults (Insert / L3+R3 panel, Space + F9 recenter, Delete screenshot, F6 flat, F7 HUD, End first person, F8 stereo method).").group = "Mod";
    Refresh();
}
// after vrkit::menu::Init (its input settings exist then)
void HotkeysStart() {
    ApplyMenuBinding();
    std::string s;
    for (int i = 0; i < kN; i++) if (g_hk[i].b.vk || g_hk[i].b.pad) { if (!s.empty()) s += ", "; s += std::string(g_hk[i].label) + " = " + g_hk[i].value; }
    LOGI("hotkeys: %s", s.c_str());
    CreateThread(nullptr, 0, Thread, nullptr, 0, nullptr);
}
// Present thread
void HotkeysRun() {
    bool saved = false;
    while (g_qTail != g_qHead) {
        int i = g_queue[g_qTail & 63]; InterlockedIncrement(&g_qTail);
        if (i <= 0 || i >= kN) continue;
        Hk& h = g_hk[i];
        auto& opts = vrkit::Options::Get();
        if (h.kind == Fn) { if (h.fn) h.fn(); LOGI("hotkeys: %s", h.label); continue; }
        for (auto& op : opts.All()) {
            bool match = h.kind == RunAction ? (op.key.empty() && op.label == h.target) : op.key == h.target;
            if (!match) continue;
            if (h.kind == Toggle || h.kind == RunAction) opts.Activate(op);
            else opts.Step(op, h.kind == StepUp ? +1 : -1);
            LOGI("hotkeys: %s -> %s", h.label, op.key.empty() ? "done" : opts.ValueText(op).c_str());
            if (!op.key.empty() && !saved && !vrkit::menu::IsOpen()) {   // kept for the next start (the panel saves when it closes)
                extern std::wstring g_cfgPath, g_gameDir;
                saved = opts.Save(g_cfgPath.empty() ? g_gameDir + L"\\resonancevr_config.txt" : g_cfgPath);
            }
            break;
        }
    }
}
