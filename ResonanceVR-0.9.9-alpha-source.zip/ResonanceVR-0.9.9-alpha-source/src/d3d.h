#pragma once
// Shared D3D12 / DXGI state of the game (filled by d3d12hooks.cpp).
#ifndef WIDL_EXPLICIT_AGGREGATE_RETURNS
#define WIDL_EXPLICIT_AGGREGATE_RETURNS   // MSVC ABI for methods that return structs (GetDesc, GetCPUDescriptorHandle...)
#endif
#include <windows.h>
#include <d3d12.h>
#include <dxgi1_6.h>

extern ID3D12Device* g_dev12;            // the game's device (from its swap chain's queue)
extern ID3D12CommandQueue* g_queue;      // the game's direct queue its swap chain presents on
extern IDXGISwapChain3* g_swap;          // the game's swap chain
extern HWND g_hwnd;
extern ID3D12Resource* g_bb[8];
extern UINT g_bbCount, g_bbW, g_bbH;
extern DXGI_FORMAT g_bbFmt;
extern volatile int g_colorSpace;        // 0 sRGB, 1 HDR10 (PQ), 2 scRGB (linear FP16)
extern volatile LONG g_presents;
extern DWORD g_presentThread;

void XrOnPresent(UINT bbIndex);          // compositor.cpp: before the game's Present (game's Present thread)
void XrReleaseForResize();               // compositor.cpp: before ResizeBuffers
void XrReport();
bool XrStartHost();
bool ResolutionTarget(unsigned& w, unsigned& h);   // window.cpp: the per-eye render size wanted (VR modes)
void WindowHook(HWND h);                           // window.cpp
void WindowApplyTarget();                          // window.cpp
