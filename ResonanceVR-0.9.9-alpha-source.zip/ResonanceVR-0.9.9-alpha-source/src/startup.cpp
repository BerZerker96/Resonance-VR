// Start-up. Resonance.exe has no launcher of its own (the stores start the game exe directly), so nothing is skipped.
// Windowed: the swap chain side (exclusive fullscreen refused, Alt+Enter off) is in d3d12hooks.cpp and the window side
// (the window, and the rendering, at the headset's per-eye size - beyond the monitor if needed) in window.cpp. Nothing
// of the game's own settings is read or written here.
#include <windows.h>
#include "log.h"
#include "settings.h"
#include "camera.h"

bool StartupForceWindowed() { return g_set.forceWindowed && g_cam.mode != VRMODE_SCREEN; }

void StartupInstall() {
    LOGI("startup: %s", StartupForceWindowed() ? "windowed at the headset's eye size (exclusive fullscreen refused)"
                                                : g_set.forceWindowed ? "screen mode - the game's own display mode" : "force_windowed = false - the game's own display mode");
}
