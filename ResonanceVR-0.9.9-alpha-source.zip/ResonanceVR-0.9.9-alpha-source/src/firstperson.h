#pragma once
#include "vrmath.h"

// First person (End key): the VR camera sits at the character the game camera follows instead of behind her
// shoulder. See firstperson.cpp.
namespace fp {
void Install();                          // after game::Init
bool Available();                        // the game camera's target point was found
void GameTick();                         // game thread, once per frame (the game clock hook)
void NoteCamera(void* cam);              // render thread: the main Camera_Z of this frame (its look-at target)
// render thread: `cam` (the game camera after decoupled pitch) -> the eye base at the character. false = not now
// (first person off, no target, a cutscene / scripted camera): use `cam`. game: the game camera itself.
bool EyeBase(const Frame& cam, const Frame& game, Frame& out);
void Toggle();
const char* Status();                    // one line for the menu / log
void Report();
} // namespace fp
