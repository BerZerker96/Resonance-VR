#pragma once
#include <string>

// User settings edited by the in-headset menu (keys = resonancevr_config.txt keys). Only features that exist in this
// engine are here (NOTES.md lists what was left out and why).
struct VrSettings {
    std::string panelLayers = "auto";        // panel_layers: auto | quad | composite (HUD, VR menu, flat screen drawn into the eye images)
    bool forceWindowed = true;                // force_windowed: windowed at the eye size (exclusive fullscreen refused)
    std::string vrMode = "aer";               // vr_mode: recon (stereo reconstruction, default) | synced (same-tick 3D) | aer (alternate-eye 3D) | head | screen
    std::string syncSubmit = "pair";          // sync_submit: pair | each
    int syncLag = -1;                         // sync_lag: -1 auto | 0..2
    float syncHold = 0.35f;                   // sync_hold: the part of a game step a held (second-eye) tick still advances
    // stereo reconstruction (vr_mode = recon): one eye drawn per frame, the other reconstructed from its picture + depth
    std::string reconEye = "centre";     // recon_eye: centre (head-centre view drawn, both eyes rebuilt) | left | alternate
    bool reconHistory = true;                 // recon_history: gaps behind close objects from that eye's last real image
    bool reconShared = true;                  // recon_shared_frustum: the drawn eye also covers the other eye's view
    std::string reconDepth = "auto";          // recon_depth: auto | game | flip (which way the depth buffer runs)
    int reconGapReach = 64;                   // recon_gap_reach: how far a gap looks sideways for a surface (px at 1920)
    std::string reconFill = "history";        // recon_fill: history (real pixels + PatchMatch infill) | patch (no memory) | classic | soft | clone | stretch | scatter (older two-pass infills)
    std::string reconView = "eye";           // recon_view: eye (0.9: one eye-size drawn view, the outer part of each eye repeats the rim) | wide (the drawn view at the headset's pixel density, ~1.3 x an eye) | headset (the headset's pixel count: ~25 % fewer pixels drawn, softer)
    float reconEyeCover = 0.5f;               // recon_eye_cover: 0..1 how far the eye-size view reaches toward the full width (0 = exactly one eye, 1 = the wide view)
    float edgeFillMargin = 0.06f;            // edge_fill_margin: each eye image is sent this much wider on every side (edge-filled), so the runtime's reprojection never shows black
    bool reconEdgeFill = true;                // recon_edge_fill: where an eye sees past the drawn view, its rim is repeated outward (framework 49.10)
    bool reconResolveSplit = false;           // recon_resolve_split (config only): the slower two-dispatch resolve, for comparison
    bool reconHudSplit = false;               // recon_hud_split: the HUD / UI is split from the picture and placed per eye (off, default since 0.9.3 as in framework 0.6.93: it is part of the picture)
    std::string fovEffects = "outer";         // fov_effects: outer (full-screen passes without a depth target are shaded at a lower rate at the lens edge) | off
    bool fovReconAuto = true;                 // fov_recon_auto: stereo reconstruction's Performance preset shades the centre view at a lower rate away from both eyes' axes while fov_mode is off
    std::string reconPreset = "performance";     // recon_preset: performance | balanced | quality - which infill passes run (cost)
    bool reconSteady = true;                  // recon_fill_steady: last frame's fill reprojected - no shimmer in motion
    bool reconEdgePixels = true;              // recon_edge_pixels: edge pixels follow their colour, holes inside a surface move with it
    float reconNearLimit = 0.35f;             // recon_near_limit: metres - nothing nearer is pushed further apart (0 = off)
    float reconSharpen = 0.f;                 // recon_sharpen: 0..1 contrast-adaptive sharpening of the rebuilt eyes
    float reconBlend = 2.f;                   // recon_infill_blend: 0..3 blend band between fill and real pixels
    float reconDetail = 0.5f;                 // recon_infill_detail: 0..1 how much of its own match a filled pixel keeps
    bool uiConverge = false;                  // ui_converge: alternate eye / synchronized - the HUD shifted per eye to sit at ui_depth (off: at infinity, the same in both eyes)
    bool uiEyeNext = false;                   // ui_eye_next: alternate eye / synchronized - the HUD laid out on a frame is placed for the NEXT frame's eye
    bool paceLock = true;                     // pace_lock: synchronized / alternate eye - frame releases locked to the headset's frames
    bool reconFootprint = true;               // recon_fast_footprint: fewer writes in the forward pass (parallel eyes)
    int reconEdgeGuard = 1;                   // recon_edge_guard: px the fill keeps away from the background edge (halo)
    int reconDebug = 0;                       // recon_debug: 1 gaps tinted, 2 picture grey / UI in colour
    // flat screen for game states without a usable 3D view (title / loading screens with no camera are always flat)
    bool flatPauseMenus = true;               // flat_pause_menus: pause menu and its screens (settings, map, gear ...)
    // render size
    std::string renderResolution = "auto";    // render_resolution: auto (headset size and shape) | game (the game's resolution setting) | WxH
    std::string uiTarget = "auto";            // ui_target: auto (find the game's separate UI layer) | off
    std::string renderDensity = "headset";   // render_density: headset (the eye image grows with a wider rendered view: cull margin, reconstruction) | fixed
    float renderScale = 1.0f;                 // render_scale (x the headset's recommended per-eye size)
    std::string eyeAspect = "headset";        // eye_aspect: headset | 1:1 | 5:4 | 4:3 (per-eye width : height)
    int renderMaxSide = 8192;                 // render_max_side
    // world
    float worldScale = 1.f;                   // world_scale (1 = real size; larger = world looks smaller)
    float unitsPerMetre = 1.f;                // units_per_metre: engine world units per metre
    // stereo (alternate-eye rendering)
    bool swapEyes = false;                    // swap_eyes: depth inside out
    int frameDelay = 1;                       // aer_frame_delay: Presents between a frame's view setup and its Present. Zouna: 1 (render thread one frame behind)
    float ipdScale = 1.f;                     // ipd_scale: 1 = the headset's IPD
    bool cameraReprojection = false;          // camera_reprojection: host rotates the older eye with the game camera
    // 0.6.13: picture fixes (View tab). Eye align: degrees each eye's picture is moved (horizontal: + = apart,
    // vertical: + = left eye up / right eye down) - for reconstruction and for alternate / synchronized separately.
    float reconShiftH = 0.f, reconShiftV = 0.f, aerShiftH = 0.f, aerShiftV = 0.f;
    float reconParallax = 1.f;                // recon_parallax: the rebuilt eyes' distance from the centre view x this
    float viewWidth = 1.f, viewHeight = 1.f;
    bool edgeFill = true;
    float cullMargin = 1.0f;                  // cull_margin: rendered frustum = headset FOV x this
    // camera
    std::string headAim = "always";              // head_aim: off | always | aiming (only while LT / L2 or the right mouse button is held)
    bool headAimTarget = true;                // head_aim_target: also turn the camera's look-at target (what the aiming reads)
    float headAimSmooth = 0.3f;               // head_aim_smoothing 0..1
    std::string headAimOrigin = "eyes";      // head_aim_origin: eyes | camera
    bool decoupledPitch = true;               // decoupled_pitch: horizon stays level (third-person camera tilt removed)
    float camOffsetX = 0.f, camOffsetY = 0.f, camOffsetZ = 0.f;   // camera_offset_x / _y / _z (metres: right, up, forward)
    std::string cameraAxes = "+0+1+2";
    // first person (End): the eye at the character the camera follows; offsets of its own (camera_offset_* = third person)
    bool firstPerson = false;                 // first_person: start in first person
    float fpOffsetX = -0.69f, fpOffsetY = 0.25f, fpOffsetZ = 0.41f;  // fp_offset_x / _y / _z (metres from the camera's look-at point: right, up, forward)
    float fpSmooth = 0.6f;                    // fp_smooth: head bob filter (0 off .. 1 strong)
    float fpMaxDistance = 6.f;                // fp_max_distance: look-at point farther from the camera = cutscene (first person waits)
    float settle = 0.5f;                      // camera_settle: idle-sway lock (0 off .. 1 strong)
    float stabilize = 0.35f;                  // camera_stabilize: game camera shake filter (0 off .. 1 strong)
    // UI
    std::string uiMode = "eyes";              // ui_mode: eyes (UI in each eye, scaled, at a fixed depth) | flat (untouched)
    float uiScale = 0.49f;                    // ui_scale: size of the game's UI in each eye (1 = edge to edge)
    float uiDepth = 2.2f;                     // ui_depth: metres the UI appears at (eyes mode)
    float uiOffsetY = 0.f;                    // ui_offset_y: + = UI higher (fraction of the eye height)
    std::string submitView = "headset";       // submit_view: headset (eye images cut to the headset view) | rendered
    float offsetStepCm = 3.f;                 // offset_step_cm: camera / first-person offset sliders, cm per press
    // symmetric_view: the engine draws one symmetric view covering the eye, the eye is cut out of it (every engine
    // consumer that builds a projection from the FOV tangents agrees with the picture). Off: each eye's own frustum
    // (fewer pixels), the culling still gets a covering frustum (wide_cull).
    bool symmetricView = true; 
    bool wideCull = true;         // wide_cull: culling / LOD get a symmetric frustum covering both eyes
    std::string uiPlacement = "draws";      // ui_placement: engine (the game's GUI transform, sharp text) | draws (D3D12 viewports)
    bool hideHud = false;                     // hide_hud: the gameplay HUD off (VR frames only; menus on the flat screen stay)
    bool keepGameCamera = true;               // keep_game_camera: the game's logic never sees the head pose
    std::string uiLayers = "one";            // ui_layers: all = every full-screen UI layer is scaled | one = the busiest only
    std::string uiPickSig;                    // ui_pick_sig: what the picked UI element is (size / format / order), kept over restarts
    int uiPick = 0;                           // ui_pick: 0 = automatic UI layer, 1..16 = that UI picker candidate is the UI
    bool ui2d = true;                         // ui_2d: draws with 2D pipelines (UI / HUD) are scaled / placed as UI
    std::string hudSplit = "auto";            // hud_split: auto | count | all
    int hudSceneDraws = 1;                    // hud_scene_draws (hud_split = count)
    // post effects (postfx.cpp): the screen-space lens effects that do not fit a stereo picture
    bool lensDistortionOff = true;            // lens_distortion_off
    bool fringeOff = true;                    // chromatic_fringe_off
    bool vignetteOff = true;                  // vignette_off
    bool filmGrainOff = false;                // film_grain_off
    bool lensDirtOff = false;                 // lens_dirt_off
    bool lensFlareOff = false;                // lens_flare_off
    bool noBlackBars = true;                  // no_black_bars: the picture-shape clamp kept open (else a VR eye is letterboxed)
    std::string depthOfField = "cutscenes";  // depth_of_field: game | cutscenes (off in cutscenes) | off
    bool skipIntro = true;                    // skip_intro: the publisher / studio logos skipped at start
    bool runInBackground = true;              // run_in_background: the game's out-of-focus frame limiter kept off
    // display / timing
    float headsetHz = 0.f;                    // headset_refresh_hz: 0 = automatic (the headset's own refresh, never a smoothing rate)
    bool pairRate = true;                    // pair_rate: synchronized / alternate eye - up to two frames per headset refresh when the GPU has room
    bool fpsUnlocked = false;                 // fps_unlocked: no frame cap at all, also in VR (beyond the headset's refresh)
    std::string fpsLimit = "0";               // fps_limit: headset | <fps> | 0
    std::string smoothing = "full";           // headset_smoothing: full (never halves) | runtime (may halve) | repeat
    int pacedTimeoutMs = 100;                 // paced_timeout_ms
    bool vsyncOff = true;                     // vsync_off: no vsync while VR frames are produced
    float sharpen = 0.f;                      // sharpen (LumaSharpen-style, 0 = off)
    std::string hdrInput = "auto";            // hdr_input: auto | off | pq | scrgb
    float hdrNits = 200.f;                    // hdr_paper_white (HDR input only)
    std::string mirror = "left";
    int maxFrameLatency = 2;                  // max_frame_latency (frames the CPU may queue; 0 = the game's)
    // fixed foveated rendering (D3D12 variable rate shading, tier 2: RTX 20+, RX 6000+, Arc)
    std::string fovMode = "off";              // fov_mode: off | quality | balanced | performance | custom
    float fovInner = 0.6f, fovOuter = 1.0f;   // fov_inner / fov_outer (half image heights from the lens centre)
    float fovWide = 1.25f;                    // fov_wide
    bool fovDebug = false;                    // fov_debug: outer zone shown at the lowest rate (to see it)              // mirror: left (monitor shows the left eye) | game (alternating)
    // screen / menu
    float screenDistance = 2.7f, screenWidth = 3.2f;
    float menuWidth = 0.8f;                   // menu_width (fraction of the panel)
    float menuDistance = 0.95f, menuPanelWidth = 1.1f;   // menu_distance / menu_panel_width (in VR frames)
    std::string recenterKey = "SPACE";
    std::string screenshotKey = "DELETE";
    std::string fpKey = "END";               // first person on / off
    std::string screenshotView = "headset";  // screenshot_view: headset (exactly the headset's field of view, 1:1 pixels) | full (the whole rendered eye)
};
extern VrSettings g_set;
void SettingsLoad();
void SettingsApply();
void SettingsApplyCamera();
