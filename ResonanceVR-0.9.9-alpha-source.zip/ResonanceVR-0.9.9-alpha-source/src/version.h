#pragma once
#define ResonanceVR_VERSION "0.9.9-alpha"
