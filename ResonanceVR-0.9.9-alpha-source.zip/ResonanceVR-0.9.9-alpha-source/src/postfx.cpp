// Post effects off for VR: lens distortion and chromatic fringe (they bend / split the picture - both eyes then
// disagree with the geometry), vignette (a dark ring that sits in the headset's lenses), film grain, lens dirt and lens
// flare (screen-space overlays that do not belong to any depth).
// The switches are the bytes of the renderer's post-process config the game itself reads every frame
// (game.cpp: found from the game's own settings dump, so every build has them). "Off" writes 0 into the active
// preset's switch; "game" puts the game's own value back. Depth of field and motion blur are in the game's own options
// (Accessibility: Motion Blur None .. Ultra).
#include <windows.h>
#include "log.h"
#include "game.h"
#include "settings.h"

static int Want(bool off) { return off ? 0 : -1; }

void PostFxApply() {
    game::PostFxSet(game::PFX_LENSDIST, Want(g_set.lensDistortionOff));
    game::PostFxSet(game::PFX_FRINGE, Want(g_set.fringeOff));
    game::PostFxSet(game::PFX_VIGNETTE, Want(g_set.vignetteOff));
    game::PostFxSet(game::PFX_GRAIN, Want(g_set.filmGrainOff));
    game::PostFxSet(game::PFX_DIRT, Want(g_set.lensDirtOff));
    game::PostFxSet(game::PFX_LENSFLARE, Want(g_set.lensFlareOff));
}

void PostFxInstall() {
    int n = 0;
    for (int i = 0; i < game::PFX_COUNT; i++) if (game::PostFxFound(i)) n++;
    LOGI("postfx: %d of %d post effect switches available", n, (int)game::PFX_COUNT);
    PostFxApply();
}

void PostFxReport() {}
