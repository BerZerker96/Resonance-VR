#include "modtime.h"
// The game's UI placed inside the engine. Resonance draws its HUD, menus and subtitles with NanoVG
// (GUI::GuiRendererNanoVG). Each GUI frame starts in the renderer's BeginFrame (game.h), which calls nvgBeginFrame and
// leaves NanoVG's 2D transform at identity; nothing in the GUI resets it afterwards (only nvgSave / nvgRestore pairs
// and relative transforms). Right after BeginFrame the mod premultiplies one translate + scale with the game's own
// nvgTranslate / nvgScale: every widget, every glyph and every scissor of that GUI frame is placed on the eye's line
// of sight, converged at ui_depth, at ui_scale - exactly where the D3D12 placement (d3d12hooks.cpp UiPlacement) puts
// it, so the reconstruction's UI split finds it in the same place. Text is rasterised at the scaled size (sharp).
// Only the full-screen GUI (target = the back-buffer size) is placed; render-to-texture GUI (in-world screens) is not.
// While the engine places the UI, the D3D12 viewport placement stands aside (no double scaling).
#include <windows.h>
#include <cmath>
#include "MinHook.h"
#include "log.h"
#include "game.h"
#include "camera.h"
#include "settings.h"
#include "zouna_math.h"

extern UINT g_bbW, g_bbH;
extern volatile LONG g_presents;
bool UiPlacementFor(UINT W, UINT H, float& cx, float& cy, float& s);   // d3d12hooks.cpp
volatile LONG g_uiEnginePresent = -100;   // the Present count when the engine placed the UI last

typedef bool(__fastcall* PFN_GuiBegin)(void* self, void* target);
static PFN_GuiBegin o_GuiBegin = nullptr;
static volatile LONG g_placed = 0, g_hidden = 0, g_other = 0, g_flat = 0, g_calls = 0, g_everCalled = 0;
static bool g_engine = true;

bool UiEngineActive() { return g_presents - g_uiEnginePresent <= 2; }   // 0.5: NanoVG or the widget layout placed it

static bool __fastcall H_GuiBegin(void* self, void* target) {
    bool ok = o_GuiBegin(self, target);
    InterlockedIncrement(&g_calls); g_everCalled = 1;
    if (!ok || !g_engine || !target || !game::Readable((char*)target + game::kGuiTgtW, 8) || !game::Readable((char*)self + game::kGuiCtx, 8)) return ok;
    int W = *(int*)((char*)target + game::kGuiTgtW), H = *(int*)((char*)target + game::kGuiTgtH);
    void* ctx = *(void**)((char*)self + game::kGuiCtx);
    if (!ctx) return ok;
    if ((UINT)W != g_bbW || (UINT)H != g_bbH) { InterlockedIncrement(&g_other); return ok; }   // render-to-texture GUI
    float cx, cy, s;
    if (!UiPlacementFor((UINT)W, (UINT)H, cx, cy, s)) { InterlockedIncrement(&g_flat); return ok; }   // not a VR frame (flat screen)
    g_uiEnginePresent = g_presents;
    if (g_set.hideHud && !g_cam.flatNow) {   // the gameplay HUD off: the GUI frame drawn far outside the picture
        game::g_nvgTranslate(ctx, -1e6f, -1e6f); InterlockedIncrement(&g_hidden); return ok;
    }
    float tx, ty; zm::NvgPlace((float)W, (float)H, cx, cy, s, tx, ty);
    game::g_nvgTranslate(ctx, tx, ty);
    game::g_nvgScale(ctx, s, s);
    InterlockedIncrement(&g_placed);
    return ok;
}

// ---- 0.5: the HUD scaled in the game's own widget layout (game.cpp FindGuiLayout) ------------------------------------
// The game's HUD is not drawn through NanoVG and not into a layer the D3D12 hooks can separate (0.4's log: "UI layer not
// found" all session) - ui_scale did nothing. Every widget's screen quad comes from one layout function; its outermost
// result is moved about the eye's UI centre and scaled (parents are nested calls, so each widget is scaled once; the
// widget's cache stays the game's). Text sizes follow through the text scale. Only full-screen canvases (the canvas the
// size of the main viewport); render-to-texture GUI and the flat screen are left alone.
bool UiPlacementForSetup(UINT W, UINT H, float& cx, float& cy, float& s);   // d3d12hooks.cpp
typedef void(__fastcall* PFN_WidgetCalc)(void* w, float* out, char store, char b);
typedef float(__fastcall* PFN_TextScale)(void* w);
static PFN_WidgetCalc o_WidgetCalc = nullptr; static PFN_TextScale o_TextScale = nullptr;
static thread_local int tl_calcDepth = 0;
static volatile LONG g_quadsScaled = 0, g_quadsOther = 0, g_textScaled = 0;
static bool CanvasPlacement(void* canvas, float& cx, float& cy, float& s, float& W, float& H) {
    if (!canvas || !game::Readable(canvas, 0x100)) return false;
    unsigned w = game::g_guiCanvasW(canvas), h = game::g_guiCanvasH(canvas);
    unsigned mw = g_cam.mainW, mh = g_cam.mainH;
    if (w < 256 || h < 256) return false;
    if (mw && mh && (w != mw || h != mh)) return false;   // a render-to-texture canvas
    W = (float)w; H = (float)h;
    return UiPlacementForSetup(w, h, cx, cy, s);
}
// 0.7: the log of 0.6 showed the two mistakes of the widget hook (all HUD invisible, then "left alone"):
//  1. the layout is NOT in canvas pixels. A quad is (x y) x 4 corners, top-left first, in units of the canvas HEIGHT, origin
//     top-left: a full-width bar at the top read (0.0 0.0) (1.28 0.0) (0.0 0.1) (1.28 0.1) on a 3420 x 2668 canvas
//     (3420 / 2668 = 1.28). 0.5 moved them about a centre given in pixels (1222, 1334): every widget went thousands of
//     canvas heights away - the HUD was gone, in 0.6 only "left alone".
//  2. in play the game asks for the quad into the widget's own cache (w+0x40, "store"), and a valid cache is returned as is
//     (the early-out at exe+2283FFA). Scaling the cache in place and scaling again what comes back from it compounds.
// Now: every widget that has been placed keeps its unscaled quad and what the mod made of it (a small table keyed by the
// widget). A quad that comes back equal to what the mod made of it is the cache returning our own result: the unscaled one
// is put back first. Only an outermost call places a quad (a parent asked for by a child stays as the game laid it out; the
// child is then placed once, as a whole). Every call places from the unscaled quad with the placement of THIS frame, so the
// eye (alternate eye / synchronized: the UI centre differs per eye), ui_scale and ui_depth follow at once.
struct QuadEnt { void* w; float un[8]; float sc[8]; };
static QuadEnt g_quads[2048];
static QuadEnt* QuadFor(void* w, bool create) {
    unsigned h = (unsigned)(((uintptr_t)w >> 4) * 0x9E3779B1u) >> 21;   // 11 bits
    for (int k = 0; k < 8; k++, h = (h + 1) & 2047) {
        QuadEnt* e = &g_quads[h];
        if (e->w == w) return e;
        if (!e->w && create) { e->w = w; return e; }
    }
    if (!create) return nullptr;
    QuadEnt* e = &g_quads[((unsigned)(((uintptr_t)w >> 4) * 0x9E3779B1u) >> 21) & 2047];   // full: overwrite
    memset(e, 0, sizeof *e); e->w = w; return e;
}
static volatile LONG g_quadsPersistent = 0, g_rawLogged = 0, g_quadsRestored = 0, g_quadsPixels = 0;
static bool OnThisStack(const void* p) {
    NT_TIB* tib = (NT_TIB*)NtCurrentTeb();
    return (uintptr_t)p >= (uintptr_t)tib->StackLimit && (uintptr_t)p < (uintptr_t)tib->StackBase;
}
// when the D3D12 hooks (ui_placement = draws) found and moved no UI draw for a while, the game's own layout places the UI -
// in this game the D3D12 hooks see no UI draw (0.6 log: "UI layer not found", 0 UI draws), so draws keeps working
extern volatile LONG g_d3dUiMovedPresent;
static bool EngineOn() { return g_engine || g_presents - g_d3dUiMovedPresent > 60; }
static void __fastcall H_WidgetCalc(void* w, float* out, char store, char b) {
    int depth = tl_calcDepth++;
    o_WidgetCalc(w, out, store, b);
    tl_calcDepth--;
    if (!out) return;
    QuadEnt* e = QuadFor(w, false);
    if (e && !memcmp(out, e->sc, 32)) {   // the cache gave back what the mod made of it: the game's own quad again
        memcpy(out, e->un, 32); InterlockedIncrement(&g_quadsRestored);
    } else if (!OnThisStack(out)) {       // freshly laid out into the widget's own memory: remember it unscaled
        e = QuadFor(w, true); memcpy(e->un, out, 32); memset(e->sc, 0xFF, 32);
        InterlockedIncrement(&g_quadsPersistent);
    }
    if (depth || !EngineOn() || g_cam.flatNow || g_cam.mode == VRMODE_SCREEN) return;
    if (!game::Readable((char*)w + game::kGuiCanvas, 8)) return;
    float cx, cy, s, W, H;
    if (!CanvasPlacement(*(void**)((char*)w + game::kGuiCanvas), cx, cy, s, W, H)) { InterlockedIncrement(&g_quadsOther); return; }
    float mx = 0.f;
    for (int i = 0; i < 8; i++) { float v = fabsf(out[i]); if (!(v == v)) return; if (v > mx) mx = v; }
    // units of the canvas height (what the game does); pixels only if the numbers say so
    bool pixels = mx > 12.f;
    if (pixels) InterlockedIncrement(&g_quadsPixels);
    if (mx > 8.f * (W + H)) return;
    float u = pixels ? 1.f : H;                         // canvas units -> pixels
    if (InterlockedIncrement(&g_rawLogged) <= 8)
        LOGI("ui: widget quad - canvas %.0f x %.0f (%s), corners (%.3f %.3f) (%.3f %.3f) (%.3f %.3f) (%.3f %.3f), UI centre %.1f %.1f px, scale %.2f, %s",
             W, H, pixels ? "pixels" : "canvas-height units", out[0], out[1], out[2], out[3], out[4], out[5], out[6], out[7], cx, cy, s,
             OnThisStack(out) ? "temporary" : "the widget's cache");
    float qx[8];
    if (g_set.hideHud) { for (int i = 0; i < 8; i++) qx[i] = -100.f * (pixels ? H : 1.f); }
    else for (int i = 0; i < 4; i++) {
        qx[2 * i]     = (cx + (out[2 * i] * u - 0.5f * W) * s) / u;
        qx[2 * i + 1] = (cy + (out[2 * i + 1] * u - 0.5f * H) * s) / u;
    }
    memcpy(out, qx, 32);
    if ((e = QuadFor(w, false)) != nullptr) memcpy(e->sc, qx, 32);
    InterlockedIncrement(&g_quadsScaled);
    g_uiEnginePresent = g_presents;
}
static float __fastcall H_TextScale(void* w) {
    float f = o_TextScale(w);
    if (!EngineOn() || g_cam.flatNow || g_cam.mode == VRMODE_SCREEN || !game::g_guiCanvasOf) return f;
    float cx, cy, s, W, H;
    if (!CanvasPlacement(game::g_guiCanvasOf(w), cx, cy, s, W, H)) return f;
    InterlockedIncrement(&g_textScaled);
    return f * s;
}

void UiEngineInstall() {
    if (game::g_guiWidgetCalc && MH_CreateHook(game::g_guiWidgetCalc, (void*)H_WidgetCalc, (void**)&o_WidgetCalc) == MH_OK && MH_EnableHook(game::g_guiWidgetCalc) == MH_OK)
        LOGI("ui: the HUD is scaled in the game's own widget layout (ui_scale, ui_depth, hide HUD)");
    if (game::g_guiTextScale && MH_CreateHook(game::g_guiTextScale, (void*)H_TextScale, (void**)&o_TextScale) == MH_OK && MH_EnableHook(game::g_guiTextScale) == MH_OK)
        LOGI("ui: text sizes follow the HUD scale");
    g_engine = g_set.uiPlacement != "draws";
    if (!game::g_guiBeginFrame) { LOGI("ui: the UI is placed by the D3D12 hooks (the engine's GUI renderer was not found)"); return; }
    if (MH_CreateHook(game::g_guiBeginFrame, (void*)H_GuiBegin, (void**)&o_GuiBegin) == MH_OK && MH_EnableHook(game::g_guiBeginFrame) == MH_OK)
        LOGI("ui: the game's GUI is placed in the engine (NanoVG transform)%s", g_engine ? "" : " - off (ui_placement = draws): the D3D12 hooks place it");
    else LOGE("ui: GUI hook FAILED - the D3D12 hooks place the UI");
}
void UiEngineSet() { g_engine = g_set.uiPlacement != "draws"; }
void UiEngineReport() {
    LONG p = InterlockedExchange(&g_placed, 0), h = InterlockedExchange(&g_hidden, 0), o = InterlockedExchange(&g_other, 0), f = InterlockedExchange(&g_flat, 0);
    if (o_WidgetCalc) LOGI("ui: HUD widgets placed in the game's layout %ld, laid out into the widgets' own memory %ld (given back unscaled from the cache %ld, in pixels %ld), other canvases %ld, text scaled %ld",
                           InterlockedExchange(&g_quadsScaled, 0), InterlockedExchange(&g_quadsPersistent, 0), InterlockedExchange(&g_quadsRestored, 0),
                           InterlockedExchange(&g_quadsPixels, 0), InterlockedExchange(&g_quadsOther, 0), InterlockedExchange(&g_textScaled, 0));
    if (o_WidgetCalc) { extern void CameraLayoutEyeCounts(long[3]); long le[3]; CameraLayoutEyeCounts(le);
                        LOGI("ui: HUD layouts placed for the left eye %ld, the right eye %ld, the head-centre view %ld (alternate eye / synchronized: about equal)", le[0], le[1], le[2]); }
    if (o_WidgetCalc) { long hh[4]; CameraLayoutEyeStats(hh); LOGI("ui: HUD eye - layouts by the renderer %ld, 0 / 1 / 2 / 3+ frames ahead of the renderer: %ld %ld %ld (alternate eye / synchronized place the HUD for the eye of the frame it is laid out for)", hh[0], hh[1], hh[2], hh[3]); }
    LONG c = InterlockedExchange(&g_calls, 0);
    static int reports = 0; reports++;
    if (!o_GuiBegin) return;
    // 0.3: the 0.2 log - not one call. The exe has GUI::GuiRendererNanoVG but never creates one (its factory has no
    // caller), so the HUD is drawn another way and the D3D12 hooks place it.
    if (!g_everCalled) { if (reports == 2) LOGI("ui: the game does not draw its GUI through NanoVG (built in, never used) - the UI is placed by the D3D12 hooks"); return; }
    LOGI("ui: GUI frames %ld - placed in the engine %ld, hidden (HUD off) %ld, flat / not VR %ld, other targets (render-to-texture) %ld", c, p, h, f, o);
}
