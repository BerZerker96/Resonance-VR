#pragma once
// ResonanceVR log (resonancevr.log): lines are buffered and written by a writer thread (0.9.1), committed to disk once a second.
#include <cstdio>
#include <cstdarg>

void LogInit(const wchar_t* path);
void LogWrite(const char* level, const char* fmt, ...);
void LogFlushDisk();

#define LOGI(...) LogWrite("I", __VA_ARGS__)
#define LOGW(...) LogWrite("W", __VA_ARGS__)
#define LOGE(...) LogWrite("E", __VA_ARGS__)
