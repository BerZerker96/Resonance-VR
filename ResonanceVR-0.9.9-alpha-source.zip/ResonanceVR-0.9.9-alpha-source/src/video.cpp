// Pre-rendered videos. Resonance plays its few videos (logos, a handful of cutscenes) through its own Movie_Z /
// WinMovie_Z player on Media Foundation, not Bink. While such a video fills the screen the game draws no 3D view: no
// main viewport is set up, no VR frame is made, and the compositor shows the picture on the flat screen by itself.
// So nothing is hooked here; VideoActive() stays false (kept for the shared flat-screen code).
#include <windows.h>
#include "log.h"

void VideoInstall() { LOGI("video: the game's videos show on the flat screen when no 3D view is drawn (no video hooks needed)"); }
bool VideoActive(unsigned) { return false; }
