#!/bin/bash
# Tests that need no game:
#   build/zouna_math_test        native (Linux / any C++17 compiler): the camera / projection maths of this engine
#   build/game_scan_test.exe     Windows: maps Resonance.exe as an image and runs the mod's own exe analysis on it
#                                (wine build/game_scan_test.exe <Resonance.exe>, or on Windows)
#   tools/verify_signatures.py   Python: every signature and every value the mod reads from the code, for any exe
set -e
cd "$(dirname "$0")/.."
mkdir -p build
${HOSTCXX:-g++} -std=c++17 -O1 -Isrc tools/zouna_math_test.cpp -o build/zouna_math_test && echo "built build/zouna_math_test"
CXX=${CXX:-x86_64-w64-mingw32-g++}
$CXX -std=c++17 -O1 -municode -DWIN32_LEAN_AND_MEAN -DNOMINMAX -Isrc tools/game_scan_test.cpp src/game.cpp src/log.cpp -static -o build/game_scan_test.exe && echo "built build/game_scan_test.exe"
