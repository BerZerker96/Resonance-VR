#!/bin/sh
# XrBridgeHost.exe with mingw-w64. Needs the OpenXR SDK built for mingw (static loader), e.g.:
#   git clone --depth 1 --branch release-1.1.43 https://github.com/KhronosGroup/OpenXR-SDK.git $OXR
#   cmake -S $OXR -B $OXR/build -G Ninja -DCMAKE_TOOLCHAIN_FILE=<mingw toolchain> -DDYNAMIC_LOADER=OFF -DBUILD_TESTS=OFF -DBUILD_API_LAYERS=OFF
#   ninja -C $OXR/build openxr_loader
set -e
OXR=${OXR:-$HOME/oxr}
cd "$(dirname "$0")/../third_party/xrbridge"
x86_64-w64-mingw32-g++ -std=c++17 -O2 -municode -DXR_USE_PLATFORM_WIN32 -DXR_USE_GRAPHICS_API_D3D11 -DNOMINMAX -D_WIN32_WINNT=0x0A00 \
  -Iinclude -I"$OXR/include" src/host/main.cpp src/common/log.cpp src/common/config.cpp -o ../../build/XrBridgeHost.exe -mwindows -static \
  "$OXR/build/src/loader/libopenxr_loader.a" -ld3d11 -ldxgi -ldxguid -ladvapi32 -lshlwapi -lpathcch -lole32 -lshell32 -ld3dcompiler \
  -luser32 -lgdi32 -lcfgmgr32
echo "build/XrBridgeHost.exe"
