#include "vrkit_input.h"
#include "vrkit_options.h"
#include <windows.h>
#include <xinput.h>
#include "MinHook.h"
#include <string>
#include <cctype>
#include <cstring>
#include <cstdlib>

namespace vrkit { namespace input {

namespace {
Settings g_set;
using GetStateFn = DWORD(WINAPI*)(DWORD, XINPUT_STATE*);
struct Hooked { const wchar_t* dll; void* target; GetStateFn orig; GetStateFn origEx; void* targetEx; };
Hooked g_mods[3] = { { L"xinput1_4.dll" }, { L"xinput1_3.dll" }, { L"xinput9_1_0.dll" } };
GetStateFn g_read = nullptr;                // an original XInputGetState for our own polling
volatile bool g_block = false, g_chordHeld = false;
DWORD g_fakePacket[4] = {};

volatile bool g_untilRelease = false;   // after closing: keep blocking until the pad is released
unsigned g_hidden[32]; volatile int g_hiddenN = 0;   // hotkey combinations hidden from the game while held
ExtraPadFn g_extra = nullptr;
DWORD Filter(DWORD r, DWORD user, XINPUT_STATE* st) {
    if (r == ERROR_SUCCESS && st && g_hiddenN > 0) {
        unsigned cur = st->Gamepad.wButtons | (st->Gamepad.bLeftTrigger > 150 ? (unsigned)PadLT : 0u) | (st->Gamepad.bRightTrigger > 150 ? (unsigned)PadRT : 0u);
        unsigned hide = 0;
        for (int k = 0; k < g_hiddenN && k < 32; k++) if (g_hidden[k] && (cur & g_hidden[k]) == g_hidden[k]) hide |= g_hidden[k];
        if (hide) {
            st->Gamepad.wButtons &= (WORD)~(hide & 0xFFFF);
            if (hide & PadLT) st->Gamepad.bLeftTrigger = 0;
            if (hide & PadRT) st->Gamepad.bRightTrigger = 0;
        }
    }
    if (r == ERROR_SUCCESS && st && g_untilRelease && !g_block) {
        const XINPUT_GAMEPAD& p = st->Gamepad;
        if (!p.wButtons && p.bLeftTrigger < 30 && p.bRightTrigger < 30) g_untilRelease = false;
    }
    // while all chord buttons are down together, the game doesn't see them (no stray L3 / R3 actions)
    {   WORD cb = g_set.chordMask ? (WORD)(g_set.chordMask & 0xFFFF) : g_set.chordButtons;
        int bits = 0; for (unsigned y = g_set.chordMask ? g_set.chordMask : cb; y; y &= y - 1) bits++;
        if (r == ERROR_SUCCESS && st && cb && bits >= 2 && (st->Gamepad.wButtons & cb) == cb) st->Gamepad.wButtons &= ~cb; }
    if (r == ERROR_SUCCESS && st && (g_block || g_chordHeld || g_untilRelease)) {
        DWORD pkt = ++g_fakePacket[user & 3];
        ZeroMemory(st, sizeof(*st));
        st->dwPacketNumber = pkt;
    }
    return r;
}
// One hook function per DLL (each needs its own trampoline).
template <int N> DWORD WINAPI HkGet(DWORD u, XINPUT_STATE* s) { return Filter(g_mods[N].orig(u, s), u, s); }
template <int N> DWORD WINAPI HkGetEx(DWORD u, XINPUT_STATE* s) { return Filter(g_mods[N].origEx(u, s), u, s); }
void* const kHk[3] = { (void*)HkGet<0>, (void*)HkGet<1>, (void*)HkGet<2> };
void* const kHkEx[3] = { (void*)HkGetEx<0>, (void*)HkGetEx<1>, (void*)HkGetEx<2> };

// polling state
WORD g_prevButtons = 0; bool g_prevKeys[256] = {};
DWORD g_chordStart = 0; bool g_chordFired = false;
DWORD g_repeatAt[4] = {}; uint32_t g_repeatDir = 0;
} // namespace

void Configure(const Settings& s) { g_set = s; }

bool InstallHooks() {
    bool any = false;
    for (int k = 0; k < 3; ++k) {
        Hooked& h = g_mods[k];
        HMODULE m = GetModuleHandleW(h.dll);
        if (!m) continue;
        if (!h.target) {
            void* p = (void*)GetProcAddress(m, "XInputGetState");
            if (p && MH_CreateHook(p, kHk[k], (void**)&h.orig) == MH_OK && MH_EnableHook(p) == MH_OK) { h.target = p; Log("vrkit: hooked XInputGetState in %ls", h.dll); }
            void* px = (void*)GetProcAddress(m, (LPCSTR)100);   // XInputGetStateEx (ordinal 100, includes the guide button)
            if (px && px != p && MH_CreateHook(px, kHkEx[k], (void**)&h.origEx) == MH_OK && MH_EnableHook(px) == MH_OK) h.targetEx = px;
        }
        if (h.orig && !g_read) g_read = h.orig;
        any = any || h.target;
    }
    if (!g_read) {   // the game hasn't loaded XInput (yet): read the pad ourselves
        HMODULE m = LoadLibraryW(L"xinput1_4.dll");
        if (!m) m = LoadLibraryW(L"xinput1_3.dll");
        if (m) g_read = (GetStateFn)GetProcAddress(m, "XInputGetState");
    }
    return any;
}

void SetBlocking(bool b) { if (g_block && !b) g_untilRelease = true; g_block = b; }

// real milliseconds (speed hacks rewrite GetTickCount; the interrupt-time clock keeps real time)
static DWORD RealMs() { ULONGLONG t = 0; QueryUnbiasedInterruptTime(&t); return (DWORD)(t / 10000); }

uint32_t Poll() {
    uint32_t out = 0;
    // --- gamepad (first connected)
    // XInputGetState on an empty slot is slow (a device query, ~0.3-1 ms each - four of them every frame showed up as
    // 1-2 ms of the mod's time at Present). Only the slot last seen connected is read every frame; the empty slots
    // are scanned once a second.
    XINPUT_STATE st = {}; bool pad = false;
    static int s_slot = -1;
    // the scan of the empty slots runs on a thread of its own (each query can take milliseconds - on the frame thread it was
    // the largest spike of the panel's idle cost); Poll only adopts the slot the scanner found
    static volatile LONG s_found = -1; static volatile LONG s_scanStarted = 0;
    if (g_read && !s_scanStarted && InterlockedExchange(&s_scanStarted, 1) == 0) {
        CreateThread(nullptr, 0, [](LPVOID) -> DWORD {
            for (;;) {
                Sleep(1000);
                if (s_slot >= 0 || !g_read) continue;
                for (DWORD u = 0; u < 4; ++u) { XINPUT_STATE t = {}; if (g_read(u, &t) == ERROR_SUCCESS) { s_found = (LONG)u; break; } }
            }
        }, nullptr, 0, nullptr);
    }
    if (g_read) {
        if (s_slot < 0 && s_found >= 0) { s_slot = (int)s_found; s_found = -1; }
        if (s_slot >= 0) { ZeroMemory(&st, sizeof(st)); pad = g_read((DWORD)s_slot, &st) == ERROR_SUCCESS; if (!pad) s_slot = -1; }
    }
    if (g_extra) {   // other controllers: merged into the same state
        unsigned eb = 0; int elx = 0, ely = 0;
        if (g_extra(&eb, &elx, &ely)) {
            if (!pad) ZeroMemory(&st, sizeof(st));
            pad = true;
            st.Gamepad.wButtons |= (WORD)(eb & 0xFFFF);
            if (eb & PadLT) st.Gamepad.bLeftTrigger = 255;
            if (eb & PadRT) st.Gamepad.bRightTrigger = 255;
            if (abs(elx) > abs(st.Gamepad.sThumbLX)) st.Gamepad.sThumbLX = (SHORT)(elx < -32768 ? -32768 : elx > 32767 ? 32767 : elx);
            if (abs(ely) > abs(st.Gamepad.sThumbLY)) st.Gamepad.sThumbLY = (SHORT)(ely < -32768 ? -32768 : ely > 32767 ? 32767 : ely);
        }
    }
    WORD b = pad ? st.Gamepad.wButtons : 0;
    float lt = pad ? st.Gamepad.bLeftTrigger / 255.f : 0.f, rt = pad ? st.Gamepad.bRightTrigger / 255.f : 0.f;
    // stick as d-pad
    if (pad) {
        const SHORT dz = 16000;
        if (st.Gamepad.sThumbLY > dz) b |= XINPUT_GAMEPAD_DPAD_UP;
        if (st.Gamepad.sThumbLY < -dz) b |= XINPUT_GAMEPAD_DPAD_DOWN;
        if (st.Gamepad.sThumbLX > dz) b |= XINPUT_GAMEPAD_DPAD_RIGHT;
        if (st.Gamepad.sThumbLX < -dz) b |= XINPUT_GAMEPAD_DPAD_LEFT;
    }
    // after closing: the game gets the pad back once everything is released (any controller - the XInput filter
    // alone never saw a PlayStation pad let go)
    if (g_untilRelease && !g_block && !(pad && (st.Gamepad.wButtons || lt > 0.12f || rt > 0.12f))) g_untilRelease = false;
    WORD pressed = b & ~g_prevButtons;
    g_prevButtons = b;
    // --- open / close chord (default L3 + R3)
    DWORD now = RealMs();
    bool chord;
    if (g_set.chordMask) {   // hotkey-style combination (buttons and / or triggers)
        unsigned cur = (pad ? st.Gamepad.wButtons : 0) | (lt > g_set.triggerThreshold ? (unsigned)PadLT : 0u) | (rt > g_set.triggerThreshold ? (unsigned)PadRT : 0u);
        chord = pad && (cur & g_set.chordMask) == g_set.chordMask;
    } else {
        chord = pad && (g_set.chordButtons || g_set.chordTriggers);
        if (g_set.chordButtons) chord = chord && (st.Gamepad.wButtons & g_set.chordButtons) == g_set.chordButtons;
        if (g_set.chordTriggers) chord = chord && lt > g_set.triggerThreshold && rt > g_set.triggerThreshold;
    }
    if (chord) {
        if (!g_chordStart) g_chordStart = now;
        if (!g_chordFired && now - g_chordStart >= (DWORD)g_set.chordHoldMs) { g_chordFired = true; out |= Toggle; }
        g_chordHeld = g_chordFired;   // after it fired, keep the game from seeing the triggers until released
    } else { g_chordStart = 0; g_chordFired = false; g_chordHeld = false; }
    // --- keyboard (every key is queried each frame so its edge state stays right). Esc is not used: the
    // game would see it too (keyboard input is not blocked) and most games open their own menu on it.
    auto key = [&](int vk) { bool d = (GetAsyncKeyState(vk) & 0x8000) != 0; bool p = d && !g_prevKeys[vk]; g_prevKeys[vk] = d; return p; };
    auto held = [&](int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; };
    bool kTog = g_set.keyboardToggleVk ? key(g_set.keyboardToggleVk) : false;
    if (kTog && g_set.keyboardToggleMods) {   // Ctrl / Shift / Alt with the toggle key
        int m = (held(VK_CONTROL) ? ModCtrl : 0) | (held(VK_SHIFT) ? ModShift : 0) | (held(VK_MENU) ? ModAlt : 0);
        kTog = m == g_set.keyboardToggleMods;
    }
    bool kRet = key(VK_RETURN), kBack = key(VK_BACK), kPgUp = key(VK_PRIOR), kPgDn = key(VK_NEXT), kHome = key(VK_HOME);   // (Delete is the mod's screenshot key)
    if (kTog) out |= Toggle;
    if ((pressed & XINPUT_GAMEPAD_A) || kRet) out |= Accept;
    if ((pressed & XINPUT_GAMEPAD_B) || kBack) out |= Back;
    if ((pressed & XINPUT_GAMEPAD_LEFT_SHOULDER) || kPgUp) out |= PagePrev;
    if ((pressed & XINPUT_GAMEPAD_RIGHT_SHOULDER) || kPgDn) out |= PageNext;
    if ((pressed & XINPUT_GAMEPAD_Y) || kHome) out |= Reset;
    // directions with auto-repeat (first repeat after 400 ms, then every 90 ms)
    uint32_t dirs = 0;
    if (b & XINPUT_GAMEPAD_DPAD_UP || held(VK_UP)) dirs |= Up;
    if (b & XINPUT_GAMEPAD_DPAD_DOWN || held(VK_DOWN)) dirs |= Down;
    if (b & XINPUT_GAMEPAD_DPAD_LEFT || held(VK_LEFT)) dirs |= Left;
    if (b & XINPUT_GAMEPAD_DPAD_RIGHT || held(VK_RIGHT)) dirs |= Right;
    const uint32_t bits[4] = { Up, Down, Left, Right };
    for (int k = 0; k < 4; ++k) {
        if (!(dirs & bits[k])) { g_repeatAt[k] = 0; continue; }
        if (!g_repeatAt[k]) { out |= bits[k]; g_repeatAt[k] = now + 400; }
        else if ((int)(now - g_repeatAt[k]) >= 0) { out |= bits[k]; g_repeatAt[k] = now + 90; }
    }
    return out;
}

// ---------------------------------------------------------------- names
namespace {
struct KN { int vk; const char* n; };
const KN kKeys[] = {
    { VK_BACK, "BACKSPACE" }, { VK_TAB, "TAB" }, { VK_RETURN, "ENTER" }, { VK_PAUSE, "PAUSE" }, { VK_CAPITAL, "CAPSLOCK" },
    { VK_ESCAPE, "ESC" }, { VK_SPACE, "SPACE" }, { VK_PRIOR, "PAGEUP" }, { VK_NEXT, "PAGEDOWN" }, { VK_END, "END" }, { VK_HOME, "HOME" },
    { VK_LEFT, "LEFT" }, { VK_UP, "UP" }, { VK_RIGHT, "RIGHT" }, { VK_DOWN, "DOWN" }, { VK_SNAPSHOT, "PRINTSCREEN" },
    { VK_INSERT, "INSERT" }, { VK_DELETE, "DELETE" }, { VK_NUMPAD0, "NUMPAD0" }, { VK_NUMPAD1, "NUMPAD1" }, { VK_NUMPAD2, "NUMPAD2" },
    { VK_NUMPAD3, "NUMPAD3" }, { VK_NUMPAD4, "NUMPAD4" }, { VK_NUMPAD5, "NUMPAD5" }, { VK_NUMPAD6, "NUMPAD6" }, { VK_NUMPAD7, "NUMPAD7" },
    { VK_NUMPAD8, "NUMPAD8" }, { VK_NUMPAD9, "NUMPAD9" }, { VK_MULTIPLY, "NUMPAD*" }, { VK_ADD, "NUMPAD+" }, { VK_SUBTRACT, "NUMPAD-" },
    { VK_DECIMAL, "NUMPAD." }, { VK_DIVIDE, "NUMPAD/" }, { VK_NUMLOCK, "NUMLOCK" }, { VK_SCROLL, "SCROLLLOCK" },
    { VK_OEM_1, ";" }, { VK_OEM_PLUS, "=" }, { VK_OEM_COMMA, "," }, { VK_OEM_MINUS, "-" }, { VK_OEM_PERIOD, "." }, { VK_OEM_2, "/" },
    { VK_OEM_3, "`" }, { VK_OEM_4, "[" }, { VK_OEM_5, "\\" }, { VK_OEM_6, "]" }, { VK_OEM_7, "'" },
    { VK_LSHIFT, "LSHIFT" }, { VK_RSHIFT, "RSHIFT" }, { VK_LCONTROL, "LCTRL" }, { VK_RCONTROL, "RCTRL" }, { VK_LMENU, "LALT" }, { VK_RMENU, "RALT" },
    { VK_XBUTTON1, "MOUSE4" }, { VK_XBUTTON2, "MOUSE5" }, { VK_MBUTTON, "MOUSE3" },
};
struct PN { unsigned bit; const char* n; };
const PN kPad[] = {
    { 0x1000, "A" }, { 0x2000, "B" }, { 0x4000, "X" }, { 0x8000, "Y" }, { 0x0100, "LB" }, { 0x0200, "RB" }, { PadLT, "LT" }, { PadRT, "RT" },
    { 0x0040, "L3" }, { 0x0080, "R3" }, { 0x0010, "START" }, { 0x0020, "BACK" },
    { 0x0001, "DPAD UP" }, { 0x0002, "DPAD DOWN" }, { 0x0004, "DPAD LEFT" }, { 0x0008, "DPAD RIGHT" },
};
std::string Upper(std::string s) { for (auto& c : s) c = (char)toupper((unsigned char)c); return s; }
std::string Trim(const std::string& s) { size_t a = s.find_first_not_of(" \t"), b = s.find_last_not_of(" \t"); return a == std::string::npos ? "" : s.substr(a, b - a + 1); }
const char* VkName(int vk, char* buf) {
    if (vk >= VK_F1 && vk <= VK_F24) { sprintf(buf, "F%d", vk - VK_F1 + 1); return buf; }
    if ((vk >= '0' && vk <= '9') || (vk >= 'A' && vk <= 'Z')) { buf[0] = (char)vk; buf[1] = 0; return buf; }
    for (auto& k : kKeys) if (k.vk == vk) return k.n;
    sprintf(buf, "0x%02X", vk); return buf;
}
bool IsModifierVk(int vk) { return vk == VK_SHIFT || vk == VK_CONTROL || vk == VK_MENU || (vk >= VK_LSHIFT && vk <= VK_RMENU); }
} // namespace

int VkFromName(const std::string& name0) {
    std::string n = Upper(Trim(name0));
    if (n.empty() || n == "NONE" || n == "OFF") return 0;
    if (n[0] == 'F' && n.size() >= 2 && n.size() <= 3 && isdigit((unsigned char)n[1])) { int k = atoi(n.c_str() + 1); if (k >= 1 && k <= 24) return VK_F1 + k - 1; }
    if (n.size() == 1 && isalnum((unsigned char)n[0])) return n[0];
    for (auto& k : kKeys) if (n == k.n) return k.vk;
    if (n == "DEL") return VK_DELETE; if (n == "INS") return VK_INSERT; if (n == "ESCAPE") return VK_ESCAPE; if (n == "RETURN") return VK_RETURN;
    if (n == "PGUP") return VK_PRIOR; if (n == "PGDN") return VK_NEXT;
    if (n.size() > 2 && n[0] == '0' && n[1] == 'X') return (int)strtol(n.c_str(), nullptr, 16);
    return 0;
}
std::string KeyText(int vk, int mods) {
    if (!vk) return "none";
    char b[16]; std::string s;
    if (mods & ModCtrl) s += "CTRL+"; if (mods & ModShift) s += "SHIFT+"; if (mods & ModAlt) s += "ALT+";
    return s + VkName(vk, b);
}
std::string PadText(unsigned pad) {
    if (!pad) return "none";
    std::string s;
    for (auto& p : kPad) if (pad & p.bit) { if (!s.empty()) s += "+"; s += p.n; }
    return s;
}
static void ParseKeyPart(const std::string& t, Binding& b) {
    std::string s = Upper(Trim(t));
    b.vk = 0; b.mods = 0;
    if (s.empty() || s == "NONE") return;
    for (;;) {
        if (s.rfind("CTRL+", 0) == 0) { b.mods |= ModCtrl; s = s.substr(5); }
        else if (s.rfind("SHIFT+", 0) == 0) { b.mods |= ModShift; s = s.substr(6); }
        else if (s.rfind("ALT+", 0) == 0) { b.mods |= ModAlt; s = s.substr(4); }
        else break;
    }
    b.vk = VkFromName(s);
    if (!b.vk) b.mods = 0;
}
static bool ParsePadPart(const std::string& t, unsigned& pad) {
    std::string s = Upper(Trim(t)); pad = 0;
    if (s.empty() || s == "NONE") return true;
    if (s.rfind("PAD:", 0) == 0) s = s.substr(4);
    size_t p = 0;
    while (p <= s.size()) {
        size_t q = s.find('+', p); if (q == std::string::npos) q = s.size();
        std::string tok = Trim(s.substr(p, q - p)); for (auto& c : tok) if (c == '_') c = ' ';
        bool found = false;
        for (auto& k : kPad) if (tok == k.n) { pad |= k.bit; found = true; }
        if (tok == "UP") { pad |= 0x0001; found = true; } else if (tok == "DOWN") { pad |= 0x0002; found = true; }
        else if (tok == "LEFT") { pad |= 0x0004; found = true; } else if (tok == "RIGHT") { pad |= 0x0008; found = true; }
        else if (tok == "VIEW" || tok == "SELECT") { pad |= 0x0020; found = true; } else if (tok == "MENU") { pad |= 0x0010; found = true; }
        if (!found) { pad = 0; return false; }
        p = q + 1;
    }
    return true;
}
Binding ParseBinding(const std::string& text) {
    Binding b;
    size_t bar = text.find('|');
    if (bar != std::string::npos) { ParseKeyPart(text.substr(0, bar), b); ParsePadPart(text.substr(bar + 1), b.pad); return b; }
    unsigned pad = 0;   // a lone part: a pad combination if it reads as one, else a key
    std::string s = Upper(Trim(text));
    if (s.rfind("PAD:", 0) == 0 || (ParsePadPart(s, pad) && pad && !VkFromName(s))) { ParsePadPart(s, b.pad); return b; }
    ParseKeyPart(text, b);
    return b;
}
std::string BindingText(const Binding& b) { return KeyText(b.vk, b.mods) + " | " + PadText(b.pad); }

// ---------------------------------------------------------------- pads
unsigned ReadPadsAll() {
    static bool connected[4] = { true, true, true, true }; static DWORD nextScan = 0;
    DWORD t = RealMs(); bool scan = (int)(t - nextScan) >= 0; if (scan) nextScan = t + 1000;
    unsigned out = 0;
    for (DWORD u = 0; u < 4 && g_read; u++) {
        if (!connected[u] && !scan) continue;
        XINPUT_STATE st = {};
        connected[u] = g_read(u, &st) == ERROR_SUCCESS;
        if (!connected[u]) continue;
        out |= st.Gamepad.wButtons;
        if (st.Gamepad.bLeftTrigger > 150) out |= PadLT;
        if (st.Gamepad.bRightTrigger > 150) out |= PadRT;
    }
    if (g_extra) { unsigned eb = 0; int lx, ly; if (g_extra(&eb, &lx, &ly)) out |= eb; }
    return out;
}
void SetExtraPads(ExtraPadFn fn) { g_extra = fn; }
unsigned HiddenFromGame(unsigned cur) {
    unsigned hide = 0;
    for (int k = 0; k < g_hiddenN && k < 32; k++) if (g_hidden[k] && (cur & g_hidden[k]) == g_hidden[k]) hide |= g_hidden[k];
    unsigned cm = g_set.chordMask ? g_set.chordMask : g_set.chordButtons;
    int bits = 0; for (unsigned y = cm; y; y &= y - 1) bits++;
    if (cm && bits >= 2 && (cur & cm) == cm) hide |= cm;
    return hide;
}
bool GameInputBlocked() { return g_block || g_chordHeld || g_untilRelease; }
void SetHiddenCombos(const unsigned* masks, int n) {
    int m = 0;
    for (int k = 0; k < n && m < 32; k++) { unsigned x = masks[k]; int bits = 0; for (unsigned y = x; y; y &= y - 1) bits++; if (bits >= 2) g_hidden[m++] = x; }
    g_hiddenN = m;
}

// ---------------------------------------------------------------- capture
namespace {
DWORD g_capStart = 0; bool g_capKeyDown[256] = {}; unsigned g_capPadMax = 0; bool g_capPadClean = false;
}
void CaptureBegin() {
    g_capStart = RealMs();
    for (int vk = 1; vk < 256; vk++) g_capKeyDown[vk] = (GetAsyncKeyState(vk) & 0x8000) != 0;   // held now (the key that opened it)
    g_capPadMax = 0; g_capPadClean = ReadPadsAll() == 0;
}
int CaptureStep(Binding& b) {
    DWORD now = RealMs();
    if (now - g_capStart > 6000) return -1;
    // keyboard: a new press of any key that is not a modifier / mouse button
    int mods = ((GetAsyncKeyState(VK_CONTROL) & 0x8000) ? ModCtrl : 0) | ((GetAsyncKeyState(VK_SHIFT) & 0x8000) ? ModShift : 0) | ((GetAsyncKeyState(VK_MENU) & 0x8000) ? ModAlt : 0);
    for (int vk = 3; vk < 256; vk++) {
        if (vk == VK_LBUTTON || vk == VK_RBUTTON || vk == 0x07 || vk == 0x0A || vk == 0x0B || vk == VK_LWIN || vk == VK_RWIN || vk == VK_APPS) continue;
        bool d = (GetAsyncKeyState(vk) & 0x8000) != 0;
        bool pressed = d && !g_capKeyDown[vk];
        g_capKeyDown[vk] = d;
        if (!pressed || IsModifierVk(vk)) continue;
        if (vk == VK_ESCAPE) return -1;
        if (vk == VK_BACK) { b.vk = 0; b.mods = 0; return 3; }
        b.vk = vk; b.mods = mods; return 1;
    }
    // gamepad: the buttons held together - taken when they are all released again
    unsigned p = ReadPadsAll();
    if (!g_capPadClean) { if (!p) g_capPadClean = true; return 0; }   // the button that opened it is still down
    if (p) { unsigned a = p | g_capPadMax; int na = 0, nm = 0; for (unsigned y = a; y; y &= y - 1) na++; for (unsigned y = g_capPadMax; y; y &= y - 1) nm++; if (na <= 3 && na >= nm) g_capPadMax = a; return 0; }
    if (g_capPadMax) { b.pad = g_capPadMax; g_capPadMax = 0; return 2; }
    return 0;
}

// ---------------------------------------------------------------- mouse
namespace {
volatile LONG g_mdx = 0, g_mdy = 0, g_mwheel = 0, g_mbtn = -1; volatile DWORD g_mbtnAt = 0;
Mouse g_mouse; float g_idle = 99.f; bool g_prevL = false, g_prevR = false; int g_wheelAcc = 0;
}
void MouseFeed(int dx, int dy, int wheel) {
    if (dx) InterlockedExchangeAdd(&g_mdx, dx);
    if (dy) InterlockedExchangeAdd(&g_mdy, dy);
    if (wheel) InterlockedExchangeAdd(&g_mwheel, wheel);
}
void MouseButtonsFeed(int buttons) { g_mbtn = buttons; g_mbtnAt = RealMs(); }
void MouseReset(float x, float y) { g_mouse.x = x; g_mouse.y = y; InterlockedExchange(&g_mdx, 0); InterlockedExchange(&g_mdy, 0); InterlockedExchange(&g_mwheel, 0); g_idle = 99.f; }
const Mouse& PollMouse(float w, float h, float dt) {
    LONG dx = InterlockedExchange(&g_mdx, 0), dy = InterlockedExchange(&g_mdy, 0), wh = InterlockedExchange(&g_mwheel, 0);
    // menu pixels per mickey: about the desktop's own pointer speed on a 1280-pixel wide menu
    const float sp = w / 1400.f * 1.15f;
    g_mouse.x += dx * sp; g_mouse.y += dy * sp;
    g_mouse.x = g_mouse.x < 0 ? 0 : g_mouse.x > w - 1 ? w - 1 : g_mouse.x;
    g_mouse.y = g_mouse.y < 0 ? 0 : g_mouse.y > h - 1 ? h - 1 : g_mouse.y;
    // buttons: the game's mouse device (fed by the host) when it reported lately, else the desktop's
    bool swap = GetSystemMetrics(SM_SWAPBUTTON) != 0;
    bool l = (GetAsyncKeyState(swap ? VK_RBUTTON : VK_LBUTTON) & 0x8000) != 0, r = (GetAsyncKeyState(swap ? VK_LBUTTON : VK_RBUTTON) & 0x8000) != 0;
    if (g_mbtn >= 0 && RealMs() - g_mbtnAt < 250) { l = l || (g_mbtn & 1); r = r || (g_mbtn & 2); }
    g_mouse.leftPressed = l && !g_prevL; g_mouse.rightPressed = r && !g_prevR;
    g_mouse.left = l; g_mouse.right = r; g_prevL = l; g_prevR = r;
    g_wheelAcc += wh; g_mouse.wheel = g_wheelAcc / 120; g_wheelAcc -= g_mouse.wheel * 120;
    if (dx || dy || wh || g_mouse.leftPressed || g_mouse.rightPressed) g_idle = 0.f; else g_idle += dt;
    g_mouse.visible = g_idle < 8.f;
    float target = g_mouse.visible ? 1.f : 0.f;
    g_mouse.alpha += (target - g_mouse.alpha) * (dt * 8.f > 1.f ? 1.f : dt * 8.f);
    return g_mouse;
}

} } // namespace vrkit::input
