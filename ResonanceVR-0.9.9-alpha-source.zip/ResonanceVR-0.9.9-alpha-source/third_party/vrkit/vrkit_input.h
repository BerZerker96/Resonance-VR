// vrkit - controller / keyboard input for the in-game menu.
//  - Reads the gamepad through XInput (through the original functions, so it still works while the game's
//    view of the pad is blocked) and the keyboard through GetAsyncKeyState.
//  - Hooks the game's XInputGetState / XInputGetStateEx (xinput1_4, xinput1_3, xinput9_1_0) so that while
//    the menu is open (and until the open/close chord is released; the chord buttons are also hidden from
//    the game while they are held together) the game sees a neutral pad.
// Requires MinHook to be initialised by the host (MH_Initialize) before InstallHooks().
#pragma once
#include <cstdint>
#include <string>

namespace vrkit { namespace input {

enum Button : uint32_t {
    Up = 1, Down = 2, Left = 4, Right = 8, Accept = 16, Back = 32, PagePrev = 64, PageNext = 128, Reset = 256, Toggle = 512
};

struct Settings {
    // Open / close chord: hold every button in chordButtons (XINPUT_GAMEPAD_* mask) for chordHoldMs.
    // Default L3 + R3 (both stick clicks). Set chordTriggers to use LT + RT instead (chordButtons = 0)
    // or in addition.
    unsigned short chordButtons = 0x0040 | 0x0080;   // XINPUT_GAMEPAD_LEFT_THUMB | XINPUT_GAMEPAD_RIGHT_THUMB
    bool chordTriggers = false;
    int chordHoldMs = 300;
    int keyboardToggleVk = 0x2D;// VK_INSERT
    int keyboardToggleMods = 0; // Mod* bits that must be held with keyboardToggleVk
    float triggerThreshold = 0.6f;
    unsigned chordMask = 0;     // if set: the open / close combination as PadText bits (buttons | PadLT | PadRT), replaces the two above
};

void Configure(const Settings& s);
bool InstallHooks();            // hook the game's XInput (call once after the game loaded its xinput DLL; safe to repeat)
void SetBlocking(bool block);   // game sees a neutral pad while true (plus until the chord is released)
bool GameInputBlocked();        // the game's pad input is held back right now (panel open / chord / until released)
// Poll once per frame. Returns newly pressed buttons (with auto-repeat for Up/Down/Left/Right when held);
// Toggle is set when the chord was held long enough or the keyboard toggle key was pressed.
uint32_t Poll();

// ---- bindings (hotkeys): one keyboard key (with Ctrl / Shift / Alt) and / or one gamepad button combination
enum Mod : int { ModCtrl = 1, ModShift = 2, ModAlt = 4 };
enum PadExtra : unsigned { PadLT = 0x10000, PadRT = 0x20000 };   // triggers as buttons (above the 16 XInput bits)
struct Binding { int vk = 0; int mods = 0; unsigned pad = 0; };     // pad: XINPUT_GAMEPAD_* bits | PadLT | PadRT
std::string KeyText(int vk, int mods);          // "F8", "CTRL+F1", "none"
std::string PadText(unsigned pad);              // "LB+DPAD UP", "LT+RT", "none"
Binding ParseBinding(const std::string& text);  // "<key> | <pad>" (either part may be "none"; a lone part is either)
std::string BindingText(const Binding& b);      // "<key> | <pad>"
int VkFromName(const std::string& name);        // 0 = none / unknown
// every connected XInput pad, through the original XInputGetState (the game's filtered view does not matter)
// - buttons ORed together, triggers as PadLT / PadRT; empty slots are looked for once a second
unsigned ReadPadsAll();
// other controllers (PlayStation pads through the game's libScePad, DirectInput pads): the host gives their state in
// the same bits (XINPUT_GAMEPAD_* | PadLT | PadRT) plus the left stick (-32768..32767); returns false when none
typedef bool (*ExtraPadFn)(unsigned* buttons, int* lx, int* ly);
void SetExtraPads(ExtraPadFn fn);
// the bits of `cur` that hidden hotkey combinations / the panel's combination take away from the game right now
unsigned HiddenFromGame(unsigned cur);
// gamepad combinations of 2+ buttons hidden from the game while all of them are held (hotkeys)
void SetHiddenCombos(const unsigned* masks, int n);
// capture a new binding: Begin, then Step every frame until it returns non-zero:
// 1 = keyboard key taken (b.vk / b.mods), 2 = pad combination taken (b.pad), 3 = keyboard part cleared (Backspace),
// -1 = cancelled (Esc / 6 s)
void CaptureBegin();
int CaptureStep(Binding& b);

// ---- mouse for the menu (the host feeds the motion it takes from the game while the menu is open)
void MouseFeed(int dx, int dy, int wheel);          // mickeys / wheel units (120 = one notch)
void MouseButtonsFeed(int buttons);                 // bit 0 left, bit 1 right (from the game's mouse device)
struct Mouse {
    float x = 0, y = 0;            // menu pixels
    bool visible = false;          // moved recently (hidden again after a few seconds without mouse use)
    bool left = false, right = false, leftPressed = false, rightPressed = false;
    int wheel = 0;                 // notches this frame (+ = away from you)
    float alpha = 0.f;             // fade
};
// once per menu frame (menu size in pixels, frame time in seconds)
const Mouse& PollMouse(float w, float h, float dt);
void MouseReset(float x, float y);

} } // namespace vrkit::input
