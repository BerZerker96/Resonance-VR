#include "vrkit_menu_core.h"
#include "vrkit_options.h"
#include <windows.h>
#include <vector>
#include <algorithm>
#include <cfloat>
#include <cctype>
#include <string>
#include <cmath>
#include <cstring>
#include "imgui.h"

// real time in 100 ns (speed hacks rewrite QueryPerformanceCounter; the interrupt-time clock keeps real time)
static void RealQpc(LARGE_INTEGER* c) { ULONGLONG t = 0; QueryUnbiasedInterruptTime(&t); c->QuadPart = (LONGLONG)t; }

namespace vrkit { namespace menu { namespace core {

namespace {
Settings g_s;
ImGuiContext* g_im = nullptr;
bool g_open = false;
int g_page = 0, g_sel = 0;
bool g_hkX = false;   // hotkey row: the X (unbind) button in front of the keycaps has the pad / keyboard focus
LARGE_INTEGER g_qpf, g_last;
ImFont* g_fBody = nullptr; ImFont* g_fTitle = nullptr; ImFont* g_fSmall = nullptr;
float g_anim = 0.f;          // seconds the menu has been drawn (pulse, scan line)
float g_selY = -1.f;         // animated selection bar position
int g_capOpt = -1;           // hotkey row capturing a new binding (index into Options::All), -1 = none
float g_capFlash = 0.f;      // "bound" flash after a capture
int g_capDoneOpt = -1;
// mouse hit areas, collected while drawing (used on the next frame's input)
struct Hit { float x0, y0, x1, y1; int kind; int idx; float v0, v1; };   // kind: 0 tab, 1 row, 2 value bar, 3 close, 4 hotkey X (unbind)
std::vector<Hit> g_hits, g_hitsPrev;

void StartCapture(int optIndex) { g_capOpt = optIndex; input::CaptureBegin(); }

std::vector<int> PageItems(int page) {
    auto& opts = Options::Get().All();
    auto pages = Options::Get().Pages();
    std::vector<int> r;
    if (pages.empty()) return r;
    page = (std::min)(page, (int)pages.size() - 1);
    for (int k = 0; k < (int)opts.size(); ++k)
        if (opts[k].page == pages[page] && (!opts[k].visible || opts[k].visible())) r.push_back(k);
    return r;
}

void Close() {
    g_open = false; g_capOpt = -1;
    input::SetBlocking(false);
    if (Options::Get().Dirty() && !g_s.configPath.empty()) {
        Options::Get().Save(g_s.configPath);   // written on a worker thread (logged there)
    }
}

void Navigate(uint32_t b) {
    auto pages = Options::Get().Pages();
    if (pages.empty()) return;
    int selWas = g_sel, pageWas = g_page;
    if (b & input::PagePrev) { g_page = (g_page + (int)pages.size() - 1) % (int)pages.size(); g_sel = 0; }
    if (b & input::PageNext) { g_page = (g_page + 1) % (int)pages.size(); g_sel = 0; }
    auto items = PageItems(g_page);
    if (items.empty()) return;
    int n = (int)items.size();
    if (b & input::Up) g_sel = (g_sel + n - 1) % n;
    if (b & input::Down) g_sel = (g_sel + 1) % n;
    g_sel = (std::min)(g_sel, n - 1);
    Option& o = Options::Get().All()[items[g_sel]];
    if (g_sel != selWas || g_page != pageWas || o.type != OptType::Hotkey) g_hkX = false;
    if (o.type == OptType::Hotkey) {   // hotkey row: Left = the X (unbind), Right = back to the keycaps
        if (b & input::Left) g_hkX = !o.noUnbind;
        if (b & input::Right) g_hkX = false;
        if (b & input::Accept) {
            if (g_hkX) { Options::Get().Reset(o); g_capDoneOpt = items[g_sel]; g_capFlash = 1.f; Log("vrkit: hotkey %s unbound", o.key.c_str()); }
            else StartCapture(items[g_sel]);
            return;
        }
        if (b & input::Reset) Options::Get().Reset(o);
        return;
    }
    if (b & input::Left) Options::Get().Step(o, -1);
    if (b & input::Right) Options::Get().Step(o, +1);
    if (b & input::Accept) Options::Get().Activate(o);
    if (b & input::Reset) Options::Get().Reset(o);
}
} // namespace

bool InitImGui(const Settings& s) {
    if (g_im) return true;
    g_s = s;
    input::Configure(s.input);
    input::InstallHooks();
    IMGUI_CHECKVERSION();
    g_im = ImGui::CreateContext();
    ImGui::SetCurrentContext(g_im);
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr; io.LogFilename = nullptr;
    io.DisplaySize = ImVec2((float)s.texW, (float)s.texH);
    // fonts: a font file the user drops into the mod folder (ResonanceVR\vrkit_font.ttf / vrkit_title_font.ttf) wins;
    // otherwise a classical serif that ships with Windows, close to the game's own engraved type: Palatino Linotype
    // (bold for the title), then Constantia, Georgia, Times New Roman. ImGui's built-in font as last resort.
    float os = s.fontOversample > 0 ? s.fontOversample : 1.f;
    std::wstring dir = s.configPath; { size_t k = dir.find_last_of(L"\\/"); dir = k == std::wstring::npos ? L"" : dir.substr(0, k + 1); }
    wchar_t win[MAX_PATH] = L"C:\\Windows"; GetWindowsDirectoryW(win, MAX_PATH);
    std::wstring fdir = std::wstring(win) + L"\\Fonts\\";
    auto load = [&](std::initializer_list<std::wstring> files, float px) -> ImFont* {
        for (const std::wstring& p : files) {
            if (p.empty() || GetFileAttributesW(p.c_str()) == INVALID_FILE_ATTRIBUTES) continue;
            char path[MAX_PATH * 3];
            WideCharToMultiByte(CP_UTF8, 0, p.c_str(), -1, path, sizeof(path), nullptr, nullptr);
            ImFontConfig fc; fc.OversampleH = 3; fc.OversampleV = 2;
            if (ImFont* f = io.Fonts->AddFontFromFileTTF(path, px * os, &fc)) { return f; }
        }
        return nullptr;
    };
    std::wstring user = dir.empty() ? L"" : dir + L"ResonanceVR\\vrkit_font.ttf", userT = dir.empty() ? L"" : dir + L"ResonanceVR\\vrkit_title_font.ttf";
    g_fBody = load({ user, fdir + L"pala.ttf", fdir + L"constan.ttf", fdir + L"georgia.ttf", fdir + L"times.ttf", fdir + L"segoeui.ttf", fdir + L"arial.ttf" }, s.fontPx);
    if (!g_fBody) { ImFontConfig fc; fc.SizePixels = s.fontPx * os; g_fBody = io.Fonts->AddFontDefault(&fc); }
    g_fTitle = load({ userT, fdir + L"palab.ttf", fdir + L"constanb.ttf", fdir + L"georgiab.ttf", fdir + L"timesbd.ttf", user }, s.fontPx * 2.3f);
    g_fSmall = load({ user, fdir + L"pala.ttf", fdir + L"constan.ttf", fdir + L"georgia.ttf", fdir + L"segoeui.ttf" }, s.fontPx * 0.78f);
    if (!g_fTitle) g_fTitle = g_fBody;
    if (!g_fSmall) g_fSmall = g_fBody;
    io.FontDefault = g_fBody;
    io.FontGlobalScale = 1.f / os;
    ImGuiStyle& st = ImGui::GetStyle();
    st.WindowRounding = 0.f; st.ChildRounding = 0.f; st.FrameRounding = 0.f; st.PopupRounding = 0.f; st.TabRounding = 0.f;
    st.GrabRounding = 0.f; st.ScrollbarRounding = 0.f;
    st.WindowBorderSize = 0.f; st.WindowPadding = ImVec2(0, 0);
    st.Colors[ImGuiCol_WindowBg] = ImVec4(0, 0, 0, 0);   // the plate is drawn by BuildFrame (chamfered frame)
    g_qpf.QuadPart = 10000000; RealQpc(&g_last);
    return true;
}

void ShutdownImGui() {
    if (g_im) { ImGui::DestroyContext(g_im); g_im = nullptr; }
    g_open = false;
}

const Settings& Get() { return g_s; }

bool UpdateInput() {
    if (!g_im) return false;
    static int rehook = 0;
    if ((++rehook % 300) == 1) input::InstallHooks();   // the game may load XInput late
    // closed: the buttons are looked at every second frame (a press lasts many frames; saves the pad / key queries of half the Presents)
    static unsigned s_idle = 0;
    if (!g_open && g_capOpt < 0 && (++s_idle & 1)) return false;
    uint32_t b = input::Poll();
    if (g_open && g_capOpt >= 0) {   // capturing a hotkey: every key / button goes to the binding, not to the menu
        auto& all = Options::Get().All();
        if (g_capOpt >= (int)all.size() || all[g_capOpt].type != OptType::Hotkey) { g_capOpt = -1; }
        else {
            Option& o = all[g_capOpt];
            input::Binding bd = input::ParseBinding(*o.s);
            int r = input::CaptureStep(bd);
            if (r != 0) {
                if (r > 0 && o.noUnbind && !bd.vk && !bd.pad) r = 0;   // a key that can never be unbound keeps its binding
                if (r > 0) { Options::Get().SetValueText(o, input::BindingText(bd)); g_capDoneOpt = g_capOpt; g_capFlash = 1.f; Log("vrkit: hotkey %s = %s", o.key.c_str(), o.s->c_str()); }
                g_capOpt = -1;
            }
        }
        ImGui::SetCurrentContext(g_im);
        return true;
    }
    if (b & input::Toggle) { if (g_open) Close(); else { g_open = true; input::SetBlocking(true); input::MouseReset(g_s.texW * 0.5f, g_s.texH * 0.5f); } b &= ~input::Toggle; }
    else if (g_open && (b & input::Back)) { Close(); return false; }
    if (!g_open) return false;
    Navigate(b);
    ImGui::SetCurrentContext(g_im);
    return true;
}

namespace {
// colours: A Plague Tale - candle-lit black, old gold leaf, dried-blood red, parchment text. Sharp, chamfered shapes,
// diamond ornaments, rising embers. No game artwork is used: everything is drawn from shapes.
const ImU32 cText = IM_COL32(236, 224, 198, 255), cDim = IM_COL32(150, 134, 106, 255), cAcc = IM_COL32(255, 240, 206, 255),
            cGold = IM_COL32(200, 160, 88, 255), cGoldHi = IM_COL32(244, 210, 138, 255), cGoldLo = IM_COL32(120, 92, 46, 255),
            cRed = IM_COL32(138, 16, 20, 255), cRedHi = IM_COL32(204, 34, 38, 255), cEmber = IM_COL32(255, 120, 52, 255),
            cWarn = IM_COL32(224, 64, 52, 255), cBlack = IM_COL32(8, 6, 5, 255), cTrack = IM_COL32(34, 27, 20, 225),
            cLine = IM_COL32(200, 160, 88, 110), cFaint = IM_COL32(200, 160, 88, 14);
inline ImU32 Alpha(ImU32 c, float a) { unsigned al = (unsigned)((c >> IM_COL32_A_SHIFT) & 0xFF); al = (unsigned)(al * (a < 0 ? 0 : a > 1 ? 1 : a)); return (c & ~IM_COL32_A_MASK) | (al << IM_COL32_A_SHIFT); }
inline ImU32 Mix(ImU32 a, ImU32 b, float t) {
    auto ch = [&](int sh) { float x = (float)((a >> sh) & 0xFF), y = (float)((b >> sh) & 0xFF); return (unsigned)(x + (y - x) * t + 0.5f) << sh; };
    return ch(IM_COL32_R_SHIFT) | ch(IM_COL32_G_SHIFT) | ch(IM_COL32_B_SHIFT) | ch(IM_COL32_A_SHIFT);
}
inline float Hash(int i) { unsigned h = (unsigned)i * 2654435761u; h ^= h >> 15; h *= 2246822519u; h ^= h >> 13; return (h & 0xFFFFFF) / 16777216.f; }

float TextW(ImFont* f, float size, const char* t, float spacing = 0.f) {
    float w = f->CalcTextSizeA(size, FLT_MAX, 0.f, t).x;
    if (spacing > 0.f) { size_t n = strlen(t); if (n > 1) w += spacing * (float)(n - 1); }
    return w;
}
float SpacedText(ImDrawList* dl, ImFont* f, float size, ImVec2 p, ImU32 col, const char* t, float spacing) {
    char ch[2] = { 0, 0 };
    float x = p.x;
    for (const char* c = t; *c; ++c) {
        ch[0] = *c;
        dl->AddText(f, size, ImVec2(x, p.y), col, ch);
        x += f->CalcTextSizeA(size, FLT_MAX, 0.f, ch).x + spacing;
    }
    return x - spacing - p.x;
}
// gold-leaf letters: a top-to-bottom gold sheen, a dark engraved shadow and a faint red halo
float GildedText(ImDrawList* dl, ImFont* f, float size, ImVec2 p, const char* t, float spacing, float glow) {
    float total = TextW(f, size, t, spacing), x = p.x; char ch[2] = { 0, 0 };
    for (const char* c = t; *c; ++c) {
        ch[0] = *c;
        if (glow > 0.f) for (int g = 1; g <= 3; g++) {
            float o = g * size * 0.03f;
            dl->AddText(f, size, ImVec2(x - o, p.y), Alpha(cRedHi, glow * 0.16f / g), ch);
            dl->AddText(f, size, ImVec2(x + o, p.y), Alpha(cRedHi, glow * 0.16f / g), ch);
            dl->AddText(f, size, ImVec2(x, p.y - o), Alpha(cRedHi, glow * 0.12f / g), ch);
        }
        dl->AddText(f, size, ImVec2(x + size * 0.03f, p.y + size * 0.04f), Alpha(cBlack, 0.9f), ch);   // engraved shadow
        dl->AddText(f, size, ImVec2(x, p.y), cGold, ch);
        // sheen: the upper half of the glyph in light gold (clipped)
        dl->PushClipRect(ImVec2(x - 2, p.y), ImVec2(x + size * 2, p.y + size * 0.52f), true);
        dl->AddText(f, size, ImVec2(x, p.y), Alpha(cGoldHi, 0.85f), ch);
        dl->PopClipRect();
        x += f->CalcTextSizeA(size, FLT_MAX, 0.f, ch).x + spacing;
    }
    return total;
}
// a sharp plate with cut corners (chamfer c), optional fill (left -> right gradient) and outline
void Plate(ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 fillL, ImU32 fillR, ImU32 line, float th = 1.5f, float c = -1.f) {
    if (c < 0.f) c = (std::min)((b.y - a.y) * 0.32f, (b.x - a.x) * 0.25f);
    ImVec2 P[8] = { ImVec2(a.x + c, a.y), ImVec2(b.x - c, a.y), ImVec2(b.x, a.y + c), ImVec2(b.x, b.y - c),
                    ImVec2(b.x - c, b.y), ImVec2(a.x + c, b.y), ImVec2(a.x, b.y - c), ImVec2(a.x, a.y + c) };
    if (fillL) {
        if (fillR == fillL || !fillR) dl->AddConvexPolyFilled(P, 8, fillL);
        else {   // gradient: vertical strips clipped to the chamfered outline
            dl->AddConvexPolyFilled(P, 8, fillL);
            const int n = 10; float w = (b.x - a.x) / n;
            for (int i = 1; i < n; i++) {
                float x0 = a.x + i * w, x1 = x0 + w;
                float y0 = a.y, y1 = b.y;
                if (x1 > b.x - c) { float k = (x1 - (b.x - c)); y0 += k; y1 -= k; }
                if (y1 > y0) dl->AddRectFilled(ImVec2(x0, y0), ImVec2(x1 + 0.5f, y1), Mix(fillL, fillR, (i + 0.5f) / n));
            }
        }
    }
    if (line) dl->AddPolyline(P, 8, line, ImDrawFlags_Closed, th);
}
void Diamond(ImDrawList* dl, ImVec2 c, float r, ImU32 fill, ImU32 line = 0, float th = 1.5f) {
    ImVec2 P[4] = { ImVec2(c.x, c.y - r), ImVec2(c.x + r, c.y), ImVec2(c.x, c.y + r), ImVec2(c.x - r, c.y) };
    if (fill) dl->AddConvexPolyFilled(P, 4, fill);
    if (line) dl->AddPolyline(P, 4, line, ImDrawFlags_Closed, th);
}
// a gold rule that fades out to both ends, a diamond in its middle
void GoldRule(ImDrawList* dl, float x0, float x1, float y, float a = 1.f, bool gem = true) {
    float xm = (x0 + x1) * 0.5f;
    dl->AddRectFilledMultiColor(ImVec2(x0, y - 0.75f), ImVec2(xm, y + 0.75f), Alpha(cGold, 0.f), Alpha(cGold, 0.9f * a), Alpha(cGold, 0.9f * a), Alpha(cGold, 0.f));
    dl->AddRectFilledMultiColor(ImVec2(xm, y - 0.75f), ImVec2(x1, y + 0.75f), Alpha(cGold, 0.9f * a), Alpha(cGold, 0.f), Alpha(cGold, 0.f), Alpha(cGold, 0.9f * a));
    if (gem) { Diamond(dl, ImVec2(xm, y), 5.f, Alpha(cRed, a), Alpha(cGoldHi, a), 1.2f); }
}
void Chevron(ImDrawList* dl, ImVec2 c, float r, int dir, ImU32 col, float th = 2.5f) {
    dl->AddLine(ImVec2(c.x - dir * r * 0.5f, c.y - r), ImVec2(c.x + dir * r * 0.5f, c.y), col, th);
    dl->AddLine(ImVec2(c.x + dir * r * 0.5f, c.y), ImVec2(c.x - dir * r * 0.5f, c.y + r), col, th);
}
// an ornamental corner: two gold strokes with a step, a diamond at the joint
void Corner(ImDrawList* dl, ImVec2 p, float s, int sx, int sy, float a) {
    ImU32 g = Alpha(cGold, a);
    dl->AddLine(p, ImVec2(p.x + sx * s, p.y), g, 2.f);
    dl->AddLine(p, ImVec2(p.x, p.y + sy * s), g, 2.f);
    dl->AddLine(ImVec2(p.x + sx * s * 0.18f, p.y + sy * s * 0.18f), ImVec2(p.x + sx * s * 0.62f, p.y + sy * s * 0.18f), Alpha(cGold, a * 0.6f), 1.f);
    dl->AddLine(ImVec2(p.x + sx * s * 0.18f, p.y + sy * s * 0.18f), ImVec2(p.x + sx * s * 0.18f, p.y + sy * s * 0.62f), Alpha(cGold, a * 0.6f), 1.f);
    Diamond(dl, ImVec2(p.x + sx * s * 0.18f, p.y + sy * s * 0.18f), 4.f, Alpha(cRedHi, a), Alpha(cGoldHi, a), 1.f);
}
} // namespace


void BuildFrame() {
    ImGui::SetCurrentContext(g_im);
    ImGuiIO& io = ImGui::GetIO();
    LARGE_INTEGER now; RealQpc(&now);
    io.DeltaTime = (std::max)(0.001f, (float)(now.QuadPart - g_last.QuadPart) / (float)g_qpf.QuadPart); g_last = now;
    g_anim += (std::min)(io.DeltaTime, 0.1f);
    g_capFlash = (std::max)(0.f, g_capFlash - io.DeltaTime * 1.2f);
    io.DisplaySize = ImVec2((float)g_s.texW, (float)g_s.texH);
    // ---------------------------------------------------------------- mouse (hit areas from the last frame)
    const input::Mouse& ms = input::PollMouse((float)g_s.texW, (float)g_s.texH, io.DeltaTime);
    {
        static float lastX = -1.f, lastY = -1.f;
        bool moved = fabsf(ms.x - lastX) > 0.5f || fabsf(ms.y - lastY) > 0.5f; lastX = ms.x; lastY = ms.y;
        auto itemsNow = PageItems(g_page);
        if (ms.visible && g_capOpt < 0) {
            const Hit* row = nullptr; const Hit* bar = nullptr; const Hit* tab = nullptr; const Hit* cls = nullptr; const Hit* unb = nullptr;
            for (const Hit& h : g_hits) {
                if (ms.x < h.x0 || ms.x > h.x1 || ms.y < h.y0 || ms.y > h.y1) continue;
                if (h.kind == 0) tab = &h; else if (h.kind == 1) row = &h; else if (h.kind == 2) bar = &h; else if (h.kind == 3) cls = &h; else if (h.kind == 4) unb = &h;
            }
            int n = (int)itemsNow.size();
            if (row && moved && row->idx < n) { if (g_sel != row->idx) g_hkX = false; g_sel = row->idx; }
            if (moved) { if (unb && unb->idx < n) g_hkX = true; else if (row) g_hkX = false; }   // the pointer on the X focuses it
            if (ms.wheel && n) { g_sel -= ms.wheel; g_sel = g_sel < 0 ? 0 : g_sel >= n ? n - 1 : g_sel; }
            auto& all = Options::Get().All();
            static int dragRow = -1;   // a slider drag stays on the slider it started on
            if (!ms.left) dragRow = -1;
            else if (ms.leftPressed) dragRow = bar ? bar->idx : -2;
            if (bar && ms.left && bar->idx < n && dragRow == bar->idx) {   // click / drag on a slider sets the value where the pointer is
                g_sel = bar->idx;
                Option& o = all[itemsNow[bar->idx]];
                float t = (ms.x - bar->v0) / (std::max)(1.f, bar->v1 - bar->v0); t = t < 0 ? 0 : t > 1 ? 1 : t;
                Options::Get().SetNumber(o, o.minV + t * (o.maxV - o.minV));
            } else if (ms.leftPressed || ms.rightPressed) {
                int dir = ms.leftPressed ? +1 : -1;
                if (cls) { Close(); }
                else if (unb && unb->idx < n && dir > 0) {   // the X in front of a hotkey's keycaps: unbind keyboard + pad
                    g_sel = unb->idx; g_hkX = true;
                    Option& o = all[itemsNow[unb->idx]];
                    if (o.type == OptType::Hotkey) { Options::Get().Reset(o); g_capDoneOpt = itemsNow[unb->idx]; g_capFlash = 1.f; Log("vrkit: hotkey %s unbound", o.key.c_str()); }
                }
                else if (tab) { g_page = tab->idx; g_sel = 0; }
                else if (row && row->idx < n) {
                    g_sel = row->idx;
                    Option& o = all[itemsNow[row->idx]];
                    if (o.type == OptType::Hotkey) { if (dir > 0) StartCapture(itemsNow[row->idx]); else Options::Get().Reset(o); }
                    else if (o.type == OptType::Action || o.type == OptType::Bool) { if (dir > 0 || o.type == OptType::Bool) Options::Get().Activate(o); }
                    else Options::Get().Step(o, dir);
                }
            }
        } else if (g_capOpt >= 0 && ms.rightPressed) g_capOpt = -1;   // right click cancels a hotkey capture
        g_hits.clear();
    }
    if (!g_open) { ImGui::NewFrame(); ImGui::Render(); return; }
    ImGui::NewFrame();
    const float W = (float)g_s.texW, H = (float)g_s.texH, fp = g_s.fontPx, pad = fp * 0.9f;
    ImGui::SetNextWindowPos(ImVec2(0, 0)); ImGui::SetNextWindowSize(ImVec2(W, H));
    ImGui::Begin("##vrkit", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                 ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float fs = fp, sm = fp * 0.78f, ttl = fp * 1.85f;
    const float pulse = 0.80f + 0.20f * sinf(g_anim * 2.4f);
    const float R = fp * 0.9f, m = 6.f;   // R: corner cut of the panel
    const float bgA = g_s.backgroundAlpha;

    // ---------------------------------------------------------------- panel: translucent black, warm vignette, embers
    ImVec2 p0(m, m), p1(W - m, H - m);
    Plate(dl, p0, p1, IM_COL32(6, 5, 4, (int)(bgA * 0.57f * 255))   /* 0.9: plate opacity 0.52 / 0.78 of before - the row plates keep the text readable */, 0, 0, 0.f, R);
    {   // candle-light: a warm glow low in the panel, darker towards the top
        const int n = 20;
        for (int i = 0; i < n; i++) {
            float u = (i + 0.5f) / n;
            float y0 = p0.y + R + (p1.y - p0.y - 2 * R) * i / n, y1 = p0.y + R + (p1.y - p0.y - 2 * R) * (i + 1) / n;
            ImU32 c = Mix(IM_COL32(0, 0, 0, 255), IM_COL32(52, 18, 10, 255), u * u);
            dl->AddRectFilled(ImVec2(p0.x + 1, y0), ImVec2(p1.x - 1, y1 + 0.5f), Alpha(c, bgA * 0.23f));
        }
        for (int k = 6; k >= 1; k--) dl->AddCircleFilled(ImVec2(W * 0.5f, H * 1.05f), W * 0.11f * k, Alpha(IM_COL32(120, 30, 12, 255), 0.012f * bgA), 64);
    }
    // embers: sparks rising slowly from the bottom, drifting, fading out
    for (int i = 0; i < 28; i++) {   // 0.9: 28 embers (was 70)
        float sp = 0.035f + Hash(i + 11) * 0.06f, ph = Hash(i + 71);
        float u = fmodf(g_anim * sp + ph, 1.f);                       // 0 = bottom, 1 = top
        float x = p0.x + R + Hash(i) * (p1.x - p0.x - 2 * R) + sinf(g_anim * (0.6f + Hash(i + 5)) + i) * fs * 0.6f;
        float y = p1.y - R - u * (p1.y - p0.y - 2 * R);
        float a = (u < 0.15f ? u / 0.15f : 1.f) * (1.f - u) * (0.5f + 0.5f * sinf(g_anim * 5.f + i));
        float sz = 0.9f + Hash(i + 501) * 1.7f;
        ImU32 c = Hash(i + 3) < 0.35f ? cGoldHi : cEmber;
        dl->AddCircleFilled(ImVec2(x, y), sz * 2.6f, Alpha(c, a * 0.08f), 10);
        dl->AddCircleFilled(ImVec2(x, y), sz, Alpha(c, a * 0.8f), 8);
    }
    // frame: double gold outline with cut corners, ornamental corners, a red band along the top
    Plate(dl, p0, p1, 0, 0, Alpha(cGold, 0.85f), 2.f, R);
    Plate(dl, ImVec2(p0.x + 7, p0.y + 7), ImVec2(p1.x - 7, p1.y - 7), 0, 0, Alpha(cGoldLo, 0.7f), 1.f, R * 0.8f);
    { const float ci = 13.f, cs = fs * 1.05f;
      Corner(dl, ImVec2(p0.x + ci, p0.y + ci), cs, 1, 1, 0.9f); Corner(dl, ImVec2(p1.x - ci, p0.y + ci), cs, -1, 1, 0.9f);
      Corner(dl, ImVec2(p0.x + ci, p1.y - ci), cs, 1, -1, 0.9f); Corner(dl, ImVec2(p1.x - ci, p1.y - ci), cs, -1, -1, 0.9f); }
    dl->AddRectFilledMultiColor(ImVec2(p0.x + R, p0.y + 1), ImVec2(p1.x - R, p0.y + 5), Alpha(cRed, 0.f), Alpha(cRed, 0.f), Alpha(cRedHi, 0.9f), Alpha(cRedHi, 0.9f));
    { float sx = p0.x + R + fmodf(g_anim * 120.f, p1.x - p0.x - 2 * R); dl->AddLine(ImVec2(sx, p0.y + 1), ImVec2((std::min)(sx + 70.f, p1.x - R), p0.y + 1), Alpha(cGoldHi, 0.55f), 2.f); }

    // ---------------------------------------------------------------- title block: A PLAGUE TALE / RESONANCE / VR crest
    float y = pad * 0.95f;
    {
        float x = pad + R * 0.9f;
        SpacedText(dl, g_fSmall, sm * 0.92f, ImVec2(x + 2, y), Alpha(cGold, 0.9f), "A PLAGUE TALE", sm * 0.42f);
        float ty = y + sm * 0.95f;
        float tw = GildedText(dl, g_fTitle, ttl, ImVec2(x, ty), "RESONANCE", ttl * 0.08f, 0.7f * pulse);
        // the VR crest: a red shield-like plate with a gold rim and a diamond
        float bh = fs * 1.25f, bw = TextW(g_fBody, fs, "VR", fs * 0.15f) + fs * 1.4f, bx = x + tw + fs * 0.8f, by = ty + (ttl - bh) * 0.55f;
        Plate(dl, ImVec2(bx, by), ImVec2(bx + bw, by + bh), cRed, cRedHi, cGoldHi, 1.5f, bh * 0.28f);
        SpacedText(dl, g_fBody, fs, ImVec2(bx + fs * 0.7f, by + (bh - fs) * 0.45f), cAcc, "VR", fs * 0.15f);
        y = ty + ttl * 1.02f;
        float ruleEnd = W - pad;
        if (g_s.statusLine) {   // a small plate right of the crest: never over the title (the text shrinks to fit)
            std::string st = g_s.statusLine(); for (auto& c : st) c = (char)toupper((unsigned char)c);
            float ss = sm * 0.72f;
            float right = W - pad, left = bx + bw + fs * 0.9f, avail = right - left - ss * 2.0f;
            float stw = TextW(g_fSmall, ss, st.c_str(), ss * 0.06f);
            if (stw > avail && avail > 40.f) { ss *= avail / stw; stw = TextW(g_fSmall, ss, st.c_str(), ss * 0.06f); }
            float bx1 = right, bx0 = bx1 - stw - ss * 2.0f;
            float by0 = by + (bh - ss * 1.6f) * 0.5f, by1 = by0 + ss * 1.6f;
            Plate(dl, ImVec2(bx0, by0), ImVec2(bx1, by1), IM_COL32(14, 10, 8, 225), 0, Alpha(cGold, 0.7f), 1.2f);
            Diamond(dl, ImVec2(bx0 + ss * 0.7f, (by0 + by1) * 0.5f), ss * 0.24f, Alpha(cRedHi, pulse), Alpha(cGoldHi, 0.9f), 1.f);
            SpacedText(dl, g_fSmall, ss, ImVec2(bx0 + ss * 1.25f, by0 + (by1 - by0 - ss) * 0.5f), cDim, st.c_str(), ss * 0.06f);
        }
        GoldRule(dl, pad, ruleEnd, y + 2, 1.f);
        y += fs * 0.75f;
    }

    // ---------------------------------------------------------------- tabs: chamfered plates, the active one blood red
    auto pages = Options::Get().Pages();
    {
        ImFont* tf = g_fBody; float ts = fs * 0.78f, sp = ts * 0.2f, gap = 8.f;
        float total = 0; std::vector<std::string> ups;
        for (auto& pg : pages) { std::string up = pg; for (auto& c : up) c = (char)toupper((unsigned char)c); ups.push_back(up); total += TextW(tf, ts, up.c_str(), sp) + ts * 1.9f + gap; }
        float avail = W - 2 * pad;
        if (total > avail) { float sc = avail / total; ts *= sc; sp *= sc; }
        float x = pad, th = ts * 1.8f;
        for (int p = 0; p < (int)ups.size(); ++p) {
            float w = TextW(tf, ts, ups[p].c_str(), sp) + ts * 1.9f;
            ImVec2 a0(x, y), a1(x + w, y + th);
            g_hits.push_back({ a0.x, a0.y, a1.x, a1.y, 0, p, 0, 0 });
            if (p == g_page) {
                for (int g = 3; g >= 1; g--) Plate(dl, ImVec2(a0.x - g * 2, a0.y - g * 2), ImVec2(a1.x + g * 2, a1.y + g * 2), 0, 0, Alpha(cRedHi, 0.09f * (4 - g) * pulse), 2.f);
                Plate(dl, a0, a1, cRed, IM_COL32(70, 8, 10, 255), cGoldHi, 1.6f);
                Diamond(dl, ImVec2((a0.x + a1.x) * 0.5f, a1.y), 4.f, cGoldHi);
                SpacedText(dl, tf, ts, ImVec2(x + ts * 0.95f, y + (th - ts) * 0.5f), cAcc, ups[p].c_str(), sp);
            } else {
                Plate(dl, a0, a1, IM_COL32(20, 15, 11, 200), 0, Alpha(cGold, 0.35f), 1.2f);
                SpacedText(dl, tf, ts, ImVec2(x + ts * 0.95f, y + (th - ts) * 0.5f), cDim, ups[p].c_str(), sp);
            }
            x += w + gap;
        }
        y += th + fs * 0.5f;
    }

    // ---------------------------------------------------------------- option rows
    auto items = PageItems(g_page);
    auto& opts = Options::Get().All();
    const float rowH = fs * 1.32f, listTop = y + fs * 0.05f, listBottom = H - fs * 5.9f;
    const float hdrH = fs * 1.4f;   // 0.9: more room above each section header
    std::vector<float> rowY(items.size()); std::vector<char> hasHdr(items.size(), 0);
    float total = 0.f;
    for (size_t r = 0; r < items.size(); ++r) {
        const std::string& g = opts[items[r]].group;
        if (!g.empty() && (r == 0 || opts[items[r - 1]].group != g)) { hasHdr[r] = 1; total += hdrH; }
        rowY[r] = total; total += rowH;
    }
    const float listH = listBottom - listTop;
    float scroll = 0.f;
    if (total > listH && g_sel >= 0 && g_sel < (int)items.size()) {
        scroll = rowY[g_sel] + rowH * 0.5f - listH * 0.5f;
        scroll = (std::max)(0.f, (std::min)(scroll, total - listH));
    }
    const float valR = W - pad - fs * 0.6f, valW = W * 0.34f;
    dl->PushClipRect(ImVec2(0, listTop - 2), ImVec2(W, listBottom + 2), true);
    for (int r = 0; r < (int)items.size(); ++r) {
        if (rowY[r] + rowH < scroll || rowY[r] - (hasHdr[r] ? hdrH : 0) > scroll + listH) continue;
        Option& o = opts[items[r]];
        float ry = listTop + rowY[r] - scroll, cy = ry + rowH * 0.5f - fs * 0.06f;
        if (hasHdr[r]) {   // section heading: a red diamond, spaced gold caps, a fading gold rule
            float hy = ry - hdrH * 0.5f;
            std::string g = o.group; for (auto& c : g) c = (char)toupper((unsigned char)c);
            float gx = pad * 0.6f + fs * 0.4f;
            Diamond(dl, ImVec2(gx + sm * 0.3f, hy), sm * 0.24f, cRedHi, cGoldHi, 1.f);
            float gw = SpacedText(dl, g_fSmall, sm, ImVec2(gx + sm * 0.9f, hy - sm * 0.55f), cGold, g.c_str(), sm * 0.22f);
            float lx0 = gx + sm * 0.9f + gw + fs * 0.5f, lx1 = W - pad * 0.6f;
            if (lx1 > lx0) dl->AddRectFilledMultiColor(ImVec2(lx0, hy - 0.75f), ImVec2(lx1, hy + 0.75f), Alpha(cGold, 0.8f), Alpha(cGold, 0.f), Alpha(cGold, 0.f), Alpha(cGold, 0.8f));
        }
        { float hy0 = (std::max)(ry + 2.f, listTop), hy1 = (std::min)(ry + rowH - 2.f, listBottom);
          if (hy1 > hy0) g_hits.push_back({ pad * 0.6f, hy0, W - pad * 0.6f, hy1, 1, r, 0, 0 }); }
        bool sel = r == g_sel;
        if (sel) {   // selection: a blood-red band fading to the right, a gold edge and a diamond marker
            if (g_selY < 0.f || fabsf(g_selY - ry) > rowH * 6) g_selY = ry;
            g_selY += (ry - g_selY) * (std::min)(1.f, io.DeltaTime * 18.f);
            float y0 = g_selY + 3, y1 = g_selY + rowH - 3, xl = pad * 0.6f, xr = W - pad * 0.6f;
            dl->AddRectFilledMultiColor(ImVec2(xl, y0), ImVec2(xr, y1), Alpha(cRed, 0.62f * pulse), Alpha(cRed, 0.04f), Alpha(cRed, 0.04f), Alpha(cRed, 0.62f * pulse));
            dl->AddLine(ImVec2(xl, y0), ImVec2(xr, y0), Alpha(cGold, 0.55f), 1.f);
            dl->AddLine(ImVec2(xl, y1), ImVec2(xr, y1), Alpha(cGold, 0.55f), 1.f);
            dl->AddRectFilled(ImVec2(xl, y0), ImVec2(xl + 4, y1), cGoldHi);
            Diamond(dl, ImVec2(xl + 18, (y0 + y1) * 0.5f), fs * 0.2f, cGoldHi, 0);
        } else dl->AddRectFilled(ImVec2(pad * 0.6f, ry + 3), ImVec2(W - pad * 0.6f, ry + rowH - 3), (r & 1) ? Alpha(cBlack, 0.34f) : Alpha(cBlack, 0.20f));   // 0.9: every row on a faint plate, two strengths alternating
        dl->AddText(g_fBody, fs, ImVec2(pad + fs * 0.75f, cy - fs * 0.5f), sel ? cAcc : cText, o.label.c_str());

        float x1 = valR;
        switch (o.type) {
        case OptType::Bool: {   // a sharp gold-rimmed slot; on = red, the gold diamond knob slides across
            bool on = o.b && *o.b;
            float tw = fs * 2.4f, th = fs * 0.82f, x0 = x1 - tw, y0 = cy - th * 0.5f;
            Plate(dl, ImVec2(x0, y0), ImVec2(x1, y0 + th), on ? cRed : cTrack, on ? cRedHi : cTrack, on ? cGoldHi : Alpha(cGold, 0.45f), 1.5f, th * 0.3f);
            float kr = th * 0.42f, kx = on ? x1 - th * 0.55f : x0 + th * 0.55f;
            if (on) dl->AddCircleFilled(ImVec2(kx, cy), kr * 1.8f, Alpha(cEmber, 0.16f * pulse), 20);
            Diamond(dl, ImVec2(kx, cy), kr, on ? cGoldHi : IM_COL32(110, 96, 76, 255), Alpha(cBlack, 0.8f), 1.f);
            const char* t = on ? "ON" : "OFF";
            float lw = TextW(g_fSmall, sm, t, sm * 0.16f);
            SpacedText(dl, g_fSmall, sm, ImVec2(x0 - lw - fs * 0.5f, cy - sm * 0.55f), on ? cGoldHi : cDim, t, sm * 0.16f);
            break;
        }
        case OptType::Int: case OptType::Float: {   // a segmented bar: gold to blood red as it fills
            float v = o.type == OptType::Int ? (float)*o.i : *o.f;
            float frac = o.maxV > o.minV ? (v - o.minV) / (o.maxV - o.minV) : 0.f; frac = frac < 0 ? 0 : frac > 1 ? 1 : frac;
            const int N = 20; float bw = valW * 0.62f, cw = bw / N, x0 = x1 - bw, h = fs * 0.5f, y0 = cy - h * 0.5f;
            int lit = (int)(frac * N + 0.5f);
            if (cy > listTop && cy < listBottom) g_hits.push_back({ x0 - 4.f, y0 - fs * 0.3f, x1 + 4.f, y0 + h + fs * 0.3f, 2, r, x0, x1 });
            dl->AddRect(ImVec2(x0 - 3, y0 - 3), ImVec2(x1 + 1, y0 + h + 3), Alpha(cGold, sel ? 0.6f : 0.3f), 0.f, 0, 1.f);
            for (int c = 0; c < N; c++) {
                ImVec2 a(x0 + c * cw + 1, y0), b(x0 + (c + 1) * cw - 1.5f, y0 + h);
                ImU32 col = Mix(cGold, cRedHi, (c + 0.5f) / N);
                if (c < lit) dl->AddRectFilled(a, b, c == lit - 1 && sel ? Alpha(cAcc, pulse) : col);
                else dl->AddRectFilled(a, b, cTrack);
            }
            std::string t = Options::Get().DisplayText(o);
            float tw = TextW(g_fBody, fs, t.c_str());
            float tx = x0 - tw - fs * (sel ? 1.3f : 0.6f);
            if (sel) { Chevron(dl, ImVec2(tx - fs * 0.45f, cy), fs * 0.2f, -1, cGoldHi); Chevron(dl, ImVec2(x0 - fs * 0.45f, cy), fs * 0.2f, 1, cGoldHi); }
            dl->AddText(g_fBody, fs, ImVec2(tx, cy - fs * 0.5f), sel ? cAcc : cText, t.c_str());
            break;
        }
        case OptType::Choice: {   // the value between gold chevrons, a diamond per choice
            std::string t = Options::Get().DisplayText(o); for (auto& c : t) c = (char)toupper((unsigned char)c);
            float tw = TextW(g_fBody, fs * 0.88f, t.c_str(), fs * 0.07f);
            float tx = x1 - tw - (sel ? fs * 0.9f : 0.f);
            if (sel) { Chevron(dl, ImVec2(x1 - fs * 0.25f, cy), fs * 0.22f, 1, cGoldHi); Chevron(dl, ImVec2(tx - fs * 0.6f, cy), fs * 0.22f, -1, cGoldHi); }
            SpacedText(dl, g_fBody, fs * 0.88f, ImVec2(tx, cy - fs * 0.5f), sel ? cAcc : cText, t.c_str(), fs * 0.07f);
            int n = (int)o.choices.size(), cur = 0;
            for (int k = 0; k < n; k++) if (o.choices[k] == *o.s) cur = k;
            if (n > 1 && n <= 12) {
                float pr = 3.5f, pg = 13.f, px = tx + tw - (n - 1) * pg - pr, py = cy + fs * 0.6f;
                for (int k = 0; k < n; k++) Diamond(dl, ImVec2(px + k * pg, py), k == cur ? pr * 1.35f : pr, k == cur ? cRedHi : Alpha(cGold, 0.45f), k == cur ? cGoldHi : 0, 1.f);
            }
            break;
        }
        case OptType::Hotkey: {   // two chamfered keycaps: keyboard | gamepad; while capturing a pulsing prompt
            if (g_capOpt == items[r]) {
                const char* t = "PRESS A KEY OR PAD BUTTONS...";
                float tw = TextW(g_fSmall, sm, t, sm * 0.1f), bw = tw + sm * 2.f, bh = sm * 1.8f, x0 = x1 - bw, y0 = cy - bh * 0.5f;
                float a = 0.55f + 0.45f * sinf(g_anim * 7.f);
                Plate(dl, ImVec2(x0, y0), ImVec2(x1, y0 + bh), Alpha(cRed, a), Alpha(cRedHi, a), cGoldHi, 1.5f);
                SpacedText(dl, g_fSmall, sm, ImVec2(x0 + sm, cy - sm * 0.55f), cAcc, t, sm * 0.1f);
                break;
            }
            input::Binding bd = input::ParseBinding(*o.s);
            std::string kt = input::KeyText(bd.vk, bd.mods), pt = input::PadText(bd.pad);
            bool flash = g_capDoneOpt == items[r] && g_capFlash > 0.f;
            float bh = sm * 1.7f, y0 = cy - bh * 0.5f, xr = x1;
            const std::string* parts[2] = { &pt, &kt };   // right to left: pad, keyboard
            const char* tags[2] = { "PAD", "KEY" };
            for (int k = 0; k < 2; k++) {
                bool none = *parts[k] == "none";
                std::string t = none ? "-" : *parts[k];
                float tw = TextW(g_fSmall, sm, t.c_str(), sm * 0.06f), gw = TextW(g_fSmall, sm * 0.7f, tags[k], 1.f);
                float bw = (std::max)(tw + gw + sm * 2.2f, sm * 5.2f), x0 = xr - bw;
                ImU32 rim = none ? Alpha(cGold, 0.3f) : (k == 0 ? Alpha(cRedHi, 0.9f) : Alpha(cGold, 0.9f));
                if (flash) rim = Mix(rim, cAcc, g_capFlash);
                Plate(dl, ImVec2(x0, y0), ImVec2(xr, y0 + bh), IM_COL32(18, 13, 10, 235), 0, rim, sel ? 2.f : 1.3f);
                dl->AddText(g_fSmall, sm * 0.7f, ImVec2(x0 + sm * 0.7f, cy - sm * 0.36f), none ? cDim : (k == 0 ? cRedHi : cGold), tags[k]);
                SpacedText(dl, g_fSmall, sm, ImVec2(x0 + sm * 0.7f + gw + sm * 0.5f, cy - sm * 0.55f), none ? cDim : (sel ? cAcc : cText), t.c_str(), sm * 0.06f);
                xr = x0 - sm * 0.5f;
            }
            if (!o.noUnbind) {   // the X (unbind keyboard + pad): a gold-rimmed diamond in front of the keycaps
                bool unbound = pt == "none" && kt == "none";
                float d = bh, x0 = xr - d, cx = x0 + d * 0.5f, r0 = d * 0.55f;
                bool hot = ms.visible && ms.x >= x0 - 3.f && ms.x <= xr + 3.f && ms.y >= y0 - 3.f && ms.y <= y0 + bh + 3.f;
                bool foc = (sel && g_hkX) || hot;
                if (foc) {
                    for (int g = 3; g >= 1; g--) Diamond(dl, ImVec2(cx, cy), r0 + g * sm * 0.12f, Alpha(cRedHi, 0.10f * pulse));
                    Diamond(dl, ImVec2(cx, cy), r0, Mix(cRed, cRedHi, 0.5f + 0.5f * sinf(g_anim * 4.f)), cGoldHi, 2.f);
                } else Diamond(dl, ImVec2(cx, cy), r0, IM_COL32(18, 13, 10, 235), unbound ? Alpha(cGold, 0.3f) : Alpha(cGold, sel ? 0.95f : 0.65f), sel ? 2.f : 1.3f);
                float k = r0 * 0.32f, th = foc ? 2.6f : 2.f;
                ImU32 xc = foc ? cAcc : unbound ? cDim : (sel ? cAcc : cGold);
                dl->AddLine(ImVec2(cx - k, cy - k), ImVec2(cx + k, cy + k), xc, th);
                dl->AddLine(ImVec2(cx - k, cy + k), ImVec2(cx + k, cy - k), xc, th);
                if (cy > listTop && cy < listBottom) g_hits.push_back({ x0 - 3.f, y0 - 3.f, xr + 3.f, y0 + bh + 3.f, 4, r, 0, 0 });
            }
            break;
        }
        case OptType::Action: {
            const char* t = "INVOKE";
            float tw = TextW(g_fSmall, sm, t, sm * 0.24f), bw = tw + sm * 2.6f, bh = sm * 1.8f, x0 = x1 - bw, y0 = cy - bh * 0.5f;
            if (sel) Plate(dl, ImVec2(x0, y0), ImVec2(x1, y0 + bh), cRed, cRedHi, cGoldHi, 1.6f);
            else Plate(dl, ImVec2(x0, y0), ImVec2(x1, y0 + bh), IM_COL32(20, 15, 11, 200), 0, Alpha(cGold, 0.6f), 1.3f);
            SpacedText(dl, g_fSmall, sm, ImVec2(x0 + (bw - tw) * 0.5f, cy - sm * 0.55f), sel ? cAcc : cGold, t, sm * 0.24f);
            x1 = x0;
            break;
        }
        }
        if (o.needsRestart) {
            const char* rs = "RESTART";
            float lw = TextW(g_fBody, fs, o.label.c_str()), rw = TextW(g_fSmall, sm * 0.85f, rs, 2.f);
            float rx = pad + fs * 0.75f + lw + fs * 0.6f, rh = sm * 1.2f;
            Plate(dl, ImVec2(rx, cy - rh * 0.5f), ImVec2(rx + rw + 16, cy + rh * 0.5f), Alpha(cRed, 0.35f), 0, Alpha(cWarn, 0.85f), 1.2f);
            SpacedText(dl, g_fSmall, sm * 0.85f, ImVec2(rx + 8, cy - sm * 0.45f), cWarn, rs, 2.f);
        }
    }
    dl->PopClipRect();
    if (items.empty()) dl->AddText(g_fBody, fs, ImVec2(pad, listTop), cDim, "(nothing on this page)");
    if (total > listH) {   // scroll: a thin gold track, a red diamond-tipped thumb
        float sx = W - pad * 0.45f, h = listH, th = h * listH / total, ty = listTop + h * scroll / total;
        dl->AddRectFilled(ImVec2(sx - 0.75f, listTop), ImVec2(sx + 0.75f, listBottom), cLine);
        dl->AddRectFilled(ImVec2(sx - 2.5f, ty), ImVec2(sx + 2.5f, ty + th), cRedHi);
        Diamond(dl, ImVec2(sx, ty), 4.f, cGoldHi); Diamond(dl, ImVec2(sx, ty + th), 4.f, cGoldHi);
    }

    // ---------------------------------------------------------------- codex box (help) + key hints
    float hy = H - fs * 5.1f;
    {
        float bx0 = pad, bx1 = W - pad, by0 = hy, by1 = H - fs * 2.25f;
        Plate(dl, ImVec2(bx0, by0), ImVec2(bx1, by1), IM_COL32(12, 9, 7, 215), 0, Alpha(cGold, 0.6f), 1.3f, fs * 0.45f);
        float lw = TextW(g_fSmall, sm, "CODEX", sm * 0.3f);
        Plate(dl, ImVec2(bx0 + sm, by0 - sm * 0.7f), ImVec2(bx0 + sm * 3.4f + lw, by0 + sm * 0.7f), cRed, cRedHi, cGoldHi, 1.3f);
        SpacedText(dl, g_fSmall, sm, ImVec2(bx0 + sm * 2.2f, by0 - sm * 0.5f), cAcc, "CODEX", sm * 0.3f);
        if (!items.empty()) {
            const Option& o = opts[items[(std::min)(g_sel, (int)items.size() - 1)]];
            std::string h = o.help;
            if (!o.key.empty()) h += (h.empty() ? "" : "   ") + std::string("[") + o.key + "]";
            ImGui::PushFont(g_fSmall);
            ImGui::SetCursorScreenPos(ImVec2(bx0 + sm * 0.9f, by0 + sm * 1.0f));
            ImGui::PushTextWrapPos(bx1 - sm * 0.9f);
            ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(214, 200, 172, 255));
            ImGui::TextWrapped("%s", h.c_str());
            ImGui::PopStyleColor(); ImGui::PopTextWrapPos(); ImGui::PopFont();
        }
    }
    {
        struct K { const char* key; const char* what; };
        bool hk = !items.empty() && opts[items[(std::min)(g_sel, (int)items.size() - 1)]].type == OptType::Hotkey;
        const K keysN[] = { { "A/ENTER", "CHANGE" }, { "Y/DEL", "UNDO" }, { "LB/RB", "PAGE" }, { "B/BKSP", "CLOSE" }, { "MOUSE", "CLICK / WHEEL" } };
        const K keysHX[] = { { "A/ENTER/CLICK", "UNBIND KEY + PAD" }, { "RIGHT", "BACK TO KEYS" }, { "LB/RB", "PAGE" }, { "B/BKSP", "CLOSE" } };
        const K keysH0[] = { { "A/ENTER/CLICK", "BIND" }, { "LEFT / CLICK X", "UNBIND" }, { "LB/RB", "PAGE" }, { "B/BKSP", "CLOSE" } };
        const K keysHL[] = { { "A/ENTER/CLICK", "BIND" }, { "ALWAYS BOUND", "PANEL KEY" }, { "LB/RB", "PAGE" }, { "B/BKSP", "CLOSE" } };
        bool lockedRow = hk && opts[items[(std::min)(g_sel, (int)items.size() - 1)]].noUnbind;
        const K* keysH = lockedRow ? keysHL : g_hkX ? keysHX : keysH0;
        const K keysC[] = { { "KEY", "KEYBOARD" }, { "PAD", "HOLD + RELEASE" }, { "BKSP", "CLEAR KEY" }, { "ESC", "CANCEL" } };
        const K* keys = g_capOpt >= 0 ? keysC : hk ? keysH : keysN;
        int nk = g_capOpt >= 0 ? 4 : hk ? 4 : 5;
        float ks = sm, total = 0.f;
        for (int i = 0; i < nk; i++) { const K& k = keys[i]; total += TextW(g_fSmall, ks, k.key) + ks * 1.2f + ks * 0.45f + TextW(g_fSmall, ks, k.what, ks * 0.12f) + ks * 1.3f; }
        float avail = W - 2.f * (pad + R * 1.1f);
        if (total > avail) ks *= avail / total;
        const float sm = ks;
        float x = pad + R * 1.1f, ky = H - fs * 1.8f, kh = sm * 1.45f;
        for (int i = 0; i < nk; i++) {
            const K& k = keys[i];
            float kw = TextW(g_fSmall, sm, k.key) + sm * 1.2f, x0 = x;
            bool isClose = strcmp(k.what, "CLOSE") == 0;
            bool hot = isClose && ms.visible && ms.x >= x0 && ms.x <= x0 + kw + sm * 4.5f && ms.y >= ky && ms.y <= ky + kh;
            Plate(dl, ImVec2(x, ky), ImVec2(x + kw, ky + kh), hot ? cRed : IM_COL32(18, 13, 10, 230), hot ? cRedHi : 0, Alpha(cGold, 0.8f), 1.2f);
            dl->AddText(g_fSmall, sm, ImVec2(x + sm * 0.6f, ky + (kh - sm) * 0.5f), hot ? cAcc : cGoldHi, k.key);
            x += kw + sm * 0.45f;
            x += SpacedText(dl, g_fSmall, sm, ImVec2(x, ky + (kh - sm) * 0.5f), hot ? cAcc : cDim, k.what, sm * 0.12f) + sm * 1.3f;
            if (isClose) g_hits.push_back({ x0, ky, x - sm * 1.3f, ky + kh, 3, 0, 0, 0 });
        }
    }
    // ---------------------------------------------------------------- mouse pointer: a gold blade with an ember at the tip
    // (dark core, gold rim, a red glow), drawn larger than a desktop pointer so it reads at panel distance in the headset
    if (ms.alpha > 0.02f) {
        const float a = ms.alpha, s = fs * 1.6f;
        const ImVec2 t(ms.x, ms.y);
        const ImVec2 P[7] = { t, ImVec2(t.x, t.y + s), ImVec2(t.x + s * 0.27f, t.y + s * 0.76f), ImVec2(t.x + s * 0.47f, t.y + s * 1.12f),
                              ImVec2(t.x + s * 0.62f, t.y + s * 1.04f), ImVec2(t.x + s * 0.43f, t.y + s * 0.69f), ImVec2(t.x + s * 0.76f, t.y + s * 0.69f) };
        ImVec2 sh[7]; for (int k = 0; k < 7; k++) sh[k] = ImVec2(P[k].x + 3.f, P[k].y + 4.f);
        dl->AddConcavePolyFilled(sh, 7, IM_COL32(0, 0, 0, (int)(130 * a)));
        for (int g = 3; g >= 1; g--) dl->AddPolyline(P, 7, Alpha(cRedHi, 0.09f * a * (4 - g)), ImDrawFlags_Closed, 2.f + g * 3.f);
        dl->AddConcavePolyFilled(P, 7, Alpha(IM_COL32(14, 10, 8, 255), 0.95f * a));
        ImVec2 in[4] = { ImVec2(t.x + s * 0.08f, t.y + s * 0.22f), ImVec2(t.x + s * 0.08f, t.y + s * 0.78f), ImVec2(t.x + s * 0.24f, t.y + s * 0.62f), ImVec2(t.x + s * 0.5f, t.y + s * 0.62f) };
        dl->AddConvexPolyFilled(in, 4, Alpha(cGold, 0.22f * a));
        dl->AddPolyline(P, 7, Alpha(cGoldHi, a), ImDrawFlags_Closed, 2.2f);
        float pr = s * 0.13f * (0.85f + 0.15f * sinf(g_anim * 6.f));
        dl->AddCircleFilled(t, pr * 2.0f, Alpha(cEmber, 0.22f * a), 16);
        dl->AddCircleFilled(t, pr * 0.8f, Alpha(cRedHi, a), 12);
        dl->AddCircleFilled(t, pr * 0.35f, Alpha(cAcc, a), 8);
        if (ms.left || ms.right) Diamond(dl, t, s * 0.34f, 0, Alpha(ms.left ? cGoldHi : cRedHi, a), 2.f);
    }
    ImGui::End();
    ImGui::Render();
}

bool IsOpen() { return g_open; }
void SetOpen(bool open) { if (open == g_open) return; if (open) { g_open = true; input::SetBlocking(true); input::MouseReset(g_s.texW * 0.5f, g_s.texH * 0.5f); } else Close(); }
bool IsCapturing() { return g_open && g_capOpt >= 0; }

} } } // namespace vrkit::menu::core
