// The screenshot path of compositor.cpp on a real D3D11 device: an RGBA8 eye texture -> staging copy -> next-frame Map
// (DO_NOT_WAIT, retried) -> crop to the headset FOV -> worker-thread PNG. Checks the PNG's size and pixels.
#include <windows.h>
#include <d3d11.h>
#include <cstdio>
#include <cstdarg>
#include <string>
#include <vector>
#include <cstdint>
void LogWrite(const char* l, const char* f, ...) { va_list a; va_start(a, f); printf("   [%s] ", l); vprintf(f, a); printf("\n"); va_end(a); }
bool ShotSaveAsync(const std::wstring& path, const uint8_t* rgba, unsigned pitch, unsigned x0, unsigned y0, unsigned w, unsigned h);
void ShotCrop(const float img[4], const float eye[4], unsigned W, unsigned H, unsigned& x0, unsigned& y0, unsigned& w, unsigned& h);
int main(int argc, char** argv) {
    ID3D11Device* dev = nullptr; ID3D11DeviceContext* ctx = nullptr;
    if (FAILED(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0, D3D11_SDK_VERSION, &dev, nullptr, &ctx))) { printf("no device\n"); return 2; }
    const UINT W = 1150, H = 1250;
    std::vector<uint32_t> px(W * H);
    for (UINT y = 0; y < H; y++) for (UINT x = 0; x < W; x++) px[y * W + x] = 0xFF000000u | ((x & 0xFF) << 0) | ((y & 0xFF) << 8) | (0x40u << 16);   // R = x, G = y, B = 0x40
    D3D11_TEXTURE2D_DESC d = {}; d.Width = W; d.Height = H; d.MipLevels = 1; d.ArraySize = 1; d.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    d.SampleDesc.Count = 1; d.Usage = D3D11_USAGE_DEFAULT; d.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
    D3D11_SUBRESOURCE_DATA sd = { px.data(), W * 4, 0 };
    ID3D11Texture2D* eye = nullptr; if (FAILED(dev->CreateTexture2D(&d, &sd, &eye))) { printf("tex failed\n"); return 2; }
    d.Usage = D3D11_USAGE_STAGING; d.BindFlags = 0; d.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    ID3D11Texture2D* st = nullptr; dev->CreateTexture2D(&d, nullptr, &st);
    ctx->CopyResource(st, eye);
    float img[4] = { -1.2f, 1.1f, 1.2f, -1.3f }, fov[4] = { -1.0f, 0.9f, 1.1f, -1.2f };
    unsigned x0, y0, w, h; ShotCrop(img, fov, W, H, x0, y0, w, h);
    D3D11_MAPPED_SUBRESOURCE m; int tries = 0; HRESULT hr;
    while ((hr = ctx->Map(st, 0, D3D11_MAP_READ, D3D11_MAP_FLAG_DO_NOT_WAIT, &m)) == DXGI_ERROR_WAS_STILL_DRAWING) { tries++; Sleep(1); }
    if (FAILED(hr)) { printf("map failed %08lx\n", (unsigned long)hr); return 2; }
    std::wstring path(argv[1], argv[1] + strlen(argv[1]));
    bool ok = ShotSaveAsync(path, (const uint8_t*)m.pData, m.RowPitch, x0, y0, w, h);
    ctx->Unmap(st, 0);   // the worker has its own copy: unmapping at once is safe
    printf("crop %u,%u %ux%u, map retries %d, queued %d\n", x0, y0, w, h, tries, ok);
    Sleep(3000);
    return ok ? 0 : 1;
}
