// window.cpp under Wine: a game window that keeps itself inside the monitor (like Resonance: 3420x2668 eye -> 3420x2153)
// must still be told - and render at - the eye size: GetClientRect, WM_SIZE and the window size itself.
#include <windows.h>
#include <cstdio>
#include <cstdarg>
#include <string>
#include "MinHook.h"
#include "d3d.h"
#include "settings.h"
#include "camera.h"
#include "xrbridge/client.h"
void LogWrite(const char* l, const char* f, ...) { va_list a; va_start(a, f); printf("   [%s] ", l); vprintf(f, a); printf("\n"); va_end(a); }
VrSettings g_set; CamState g_cam; HWND g_hwnd = nullptr; std::wstring g_modDir;
bool XrStartHost() { return false; }
bool MouseInputWheel(int) { return false; }
float CameraDrawGrowth() { return 1.f; }
void CameraDrawGrowthXY(float& gx, float& gy) { gx = gy = 1.f; }
void CameraStableGrowthXY(float& gx, float& gy) { gx = gy = 1.f; }
float CameraDrawAspect() { return 0.f; }
namespace xrb { bool ClientWaitRecommendedSize(uint32_t*, uint32_t*, uint32_t) { return false; } bool ClientMaxEyeSize(unsigned* w, unsigned* h) { *w = 4096; *h = 4096; return true; } }
void ResolutionStart();
static int bad = 0; static void Check(bool c, const char* w) { printf("%-4s %s\n", c ? "OK" : "FAIL", w); if (!c) bad++; }
static int g_sizeW = 0, g_sizeH = 0;
static LRESULT CALLBACK GameProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
    if (m == WM_WINDOWPOSCHANGING) {   // the game keeps its window on the monitor
        auto* p = (WINDOWPOS*)lp; int sh = GetSystemMetrics(SM_CYSCREEN) - 7, sw = GetSystemMetrics(SM_CXSCREEN) * 2;
        if (!(p->flags & SWP_NOSIZE)) { if (p->cy > sh) p->cy = sh; if (p->cx > sw) p->cx = sw; }
    }
    if (m == WM_SIZE) { g_sizeW = LOWORD(lp); g_sizeH = HIWORD(lp); }
    return DefWindowProcW(h, m, wp, lp);
}
int main() {
    MH_Initialize();
    wchar_t d[MAX_PATH]; GetCurrentDirectoryW(MAX_PATH, d); g_modDir = std::wstring(d) + L"\\ResonanceVR";
    CreateDirectoryW(g_modDir.c_str(), nullptr);
    if (FILE* f = _wfopen((g_modDir + L"\\headset.txt").c_str(), L"w")) { fprintf(f, "3420 2668\n"); fclose(f); }
    g_cam.mode = VRMODE_SYNCED;   // as the mod: XrSetMode(vr_mode) runs before ResolutionStart (0.6.37: the window code reads the mode number)
    ResolutionStart(); Sleep(300);
    unsigned tw = 0, th = 0; Check(ResolutionTarget(tw, th) && tw == 3420 && th == 2668, "eye size 3420 x 2668 from the cached headset size");
    WNDCLASSW wc = {}; wc.lpfnWndProc = GameProc; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"g"; RegisterClassW(&wc);
    HWND hw = CreateWindowW(L"g", L"game", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 1280, 720, nullptr, nullptr, wc.hInstance, nullptr);
    WindowHook(hw); WindowApplyTarget();
    for (int i = 0; i < 50; i++) { MSG m; while (PeekMessageW(&m, 0, 0, 0, PM_REMOVE)) DispatchMessageW(&m); Sleep(10); }
    RECT wr; GetWindowRect(hw, &wr); RECT cr; GetClientRect(hw, &cr);
    printf("     screen %dx%d, window %ldx%ld, client (told to the game) %ldx%ld, last WM_SIZE %dx%d\n", GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN),
           wr.right - wr.left, wr.bottom - wr.top, cr.right, cr.bottom, g_sizeW, g_sizeH);
    Check(cr.right == 3420 && cr.bottom == 2668, "GetClientRect = the eye size");
    Check(wr.right - wr.left == 3420 && wr.bottom - wr.top == 2668, "the window itself is the eye size (beyond the monitor) despite the game's clamp");
    Check(g_sizeW == 3420 && g_sizeH == 2668, "WM_SIZE = the eye size");
    // a resize attempt by the game (e.g. its own windowed resolution) is put back
    SetWindowPos(hw, nullptr, 0, 0, 1920, 1080, SWP_NOZORDER);
    for (int i = 0; i < 20; i++) { MSG m; while (PeekMessageW(&m, 0, 0, 0, PM_REMOVE)) DispatchMessageW(&m); Sleep(10); }
    GetWindowRect(hw, &wr); Check(wr.right - wr.left == 3420 && wr.bottom - wr.top == 2668, "the game's own SetWindowPos keeps the eye size");
    printf(bad ? "%d FAILED\n" : "all passed\n", bad);
    return bad;
}
