#!/usr/bin/env python3
"""ResonanceVR: check every signature of the mod against a Resonance.exe (any store / patch level).
   python3 tools/verify_signatures.py <path to Resonance.exe>
Prints OK / MISSING / AMBIGUOUS per signature and the values the mod reads from the code (struct offsets,
globals). The same patterns are in src/game.cpp - keep both in step."""
import re, struct, sys

SIGS = {  # name: (pattern, must be unique in the code section)
    "ViewSetup":      "44 0F 29 A8 ?? ?? ?? ?? 44 0F 29 B0 ?? ?? ?? ?? 44 0F 29 B8 ?? ?? ?? ?? 45 0F B6 F8 44 0F B6 E2",
    "GetProjection":  "48 89 5C 24 08 57 48 81 EC ?? ?? ?? ?? 4C 8B 41 ?? 45 33 D2 8B FA 4D 8D 48 1C 4D 85 C0",
    "FovTangents":    "40 53 48 81 EC ?? ?? ?? ?? 48 8B D9 48 8B 49 ?? 48 85 C9 75 ?? C7 83 ?? ?? ?? ?? 00 00 80 3F C7 83 ?? ?? ?? ?? 00 00 80 3F",
    "FrameTime":      "48 89 5C 24 18 48 89 74 24 20 57 48 83 EC ?? F3 0F 10 81 ?? ?? ?? ?? 48 8D B9 ?? ?? ?? ?? 0F 5A C0 48 8B D9",
    "AspectCap":      "48 83 EC 28 48 8B 0D ?? ?? ?? ?? C7 05 ?? ?? ?? ?? CD CC CC 3F C7 05 ?? ?? ?? ?? 55 55 15 40",
    "GameplayFov":    "F3 0F 10 8B ?? ?? ?? ?? 49 8B CF E8 ?? ?? ?? ?? F3 0F 10 8B ?? ?? ?? ?? 49 8B CF E8",
    "nvgBeginFrame":  "48 89 5C 24 08 57 48 83 EC 50 0F 29 74 24 40 33 FF 0F 29 7C 24 30 0F 28 F3 44 0F 29 44 24 20 0F 28 FA 44 0F 28 C1 89 B9",
    "nvgTranslate":   "40 53 48 83 EC 40 48 63 81 ?? ?? ?? ?? 0F 28 05 ?? ?? ?? ?? 48 69 D8 ?? ?? ?? ?? F3 0F 11 4C 24 30 F3 0F 11 54 24 34 0F 11 44 24 20",
    "nvgScale":       "40 53 48 83 EC 40 48 63 81 ?? ?? ?? ?? 48 69 D8 ?? ?? ?? ?? F3 0F 11 4C 24 20 F3 0F 11 54 24 2C 48 C7 44 24 24 00 00 00 00",
    "RenderSettings": "41 8B 85 ?? ?? ?? ?? 83 C0 FB 48 8D 1D",
    "VpLoop":         "48 8B CB E8 ?? ?? ?? ?? 45 33 C0 B2 01 48 8B CB E8 ?? ?? ?? ?? 4C 8D AB ?? ?? ?? ?? 49 8B 84 24 ?? ?? ?? ?? 48 8B 38",
    "VpSlot":         "44 8B 73 ?? 44 89 75 ?? 41 83 FE 09",
    "DisplaySurface": "48 8B 81 ?? ?? ?? ?? 4C 8B 0D ?? ?? ?? ?? 48 85 C0 4C 0F 45 C8 83 79 ?? 09",
    "GuiWidgetLayout": "33 FF 84 C0 49 0F 44 FF 48 85 FF 41 0F 95 C6 48 85 FF 74 ?? 48 8B CF E8 ?? ?? ?? ?? 48 85 C0",
    "GuiTextScale":   "F3 48 0F 2A F0 E8 ?? ?? ?? ?? 48 8B D8 48 85 C0 74 ?? 48 8B C8 E8 ?? ?? ?? ?? 84 C0 74 ??",
    "IntroSwitch":    "45 33 C0 48 8D 15 ?? ?? ?? ?? 48 8D 0D ?? ?? ?? ?? E8 ?? ?? ?? ?? 84 C0 74 ?? 48 8D 15",
    "DepthOfField":   "4C 8B F9 0F 57 C0 41 0F 2F 40 0C 0F 92 85 ?? ?? ?? ?? 8B 81 ?? ?? ?? ?? 89 44 24 ?? 80 3D ?? ?? ?? ?? 00 0F 84",
    "CamUpdateNode":  "4C 8D 8B ?? ?? ?? ?? 8B 40 38 41 89 40 08 48 8B 89 ?? ?? ?? ?? 48 85 C9 74",
    "RenderConfig":   "4C 8B 05 ?? ?? ?? ?? 41 8B 80 ?? ?? ?? ?? 48 69 D0 ?? ?? ?? ?? 49 81 C0 ?? ?? ?? ?? 49 03 D0",
}
# found inside a function found above: (parent, search window, pattern)
INNER = {
    "ViewBlock":   ("ViewSetup", 0x100, "48 8B F9 48 8D B1 ?? ?? ?? ?? 44 0F 10"),
    "ViewCamera":  ("ViewSetup", 0x800, "4D 8B BD ?? ?? ?? ?? 49 8B D5 49 8B CF E8"),
    "ViewCamPos":  ("ViewSetup", 0x800, "49 8B 85 ?? ?? ?? ?? 0F 10 40 30 0F 11 86"),
    "ProjOut":     ("GetProjection", 0x120, "48 8D 99 ?? ?? ?? ?? C7 44 24"),
    "ProjJitter":  ("GetProjection", 0x260, "F3 44 0F 10 91 ?? ?? ?? ?? F3 44 0F 10 99"),
    "TanX":        ("FovTangents", 0x260, "F3 0F 11 BB ?? ?? ?? ?? 0F 28 FE"),
    "TanY":        ("FovTangents", 0x260, "F3 0F 11 8B ?? ?? ?? ?? 48 8B 0D"),
    "CamFov":      ("FovTangents", 0x100, "F3 0F 10 B7 ?? ?? ?? ??"),
    "CullBuild":   ("FovTangents", 0x400, "F3 0F 11 44 24 ?? E8"),
    "CamNearFar":  ("FovTangents", 0x300, "F3 0F 10 87 ?? ?? ?? ?? F3 0F 10 9F ?? ?? ?? ?? F3 0F 10 97 ?? ?? ?? ??"),
    "GuiCanvas":   ("GuiWidgetLayout", 0x220, "4C 8B A3 ?? ?? ?? ??"),
    "GamePause":   ("FrameTime", 0x140, "48 8B 05 ?? ?? ?? ?? 80 78 ?? 00 75"),
    "TimeScale":   ("FrameTime", 0x400, "F3 0F 59 93 ?? ?? ?? ?? F3 0F 11 93"),
    "ProjCamId":   ("GetProjection", 0x40, "44 3B 59 ??"),
    "ViewportSize":("FovTangents", 0x100, "66 44 0F 6E 53 ?? 66 44 0F 6E 5B ??"),
    "FocusLimiter":("FrameTime", 0x400, "48 8B 05 ?? ?? ?? ?? 48 8D BB ?? ?? ?? ?? 48 83 B8 ?? ?? ?? ?? 00 7D"),
    "CapRefresh":  ("AspectCap", 0x80, "48 8B 0D ?? ?? ?? ?? E8"),
    "RsDlss":      ("RenderSettings", 0x100, "41 0F B6 85 ?? ?? ?? ?? 4C 8D 35"),
    "RsFsr":       ("RenderSettings", 0x200, "41 8B 8D ?? ?? ?? ?? 85 C9 74 ?? 83 E9 01 74 ?? 83 E9 01 74 ?? 83 E9 01"),
}
POSTFX = ["Fringe", "LensDistortion", "Dirt", "LensFlare", "FilmGrain", "Vignette"]

def load(path):
    d = open(path, "rb").read()
    pe = struct.unpack_from("<I", d, 0x3C)[0]
    ns = struct.unpack_from("<H", d, pe + 6)[0]; osz = struct.unpack_from("<H", d, pe + 20)[0]
    secs = []
    for i in range(ns):
        o = pe + 24 + osz + i * 40
        nm = d[o:o + 8].rstrip(b"\0").decode("latin1")
        vs, va, rs, ro = struct.unpack_from("<IIII", d, o + 8)
        ch = struct.unpack_from("<I", d, o + 36)[0]
        secs.append((nm, va, vs, ro, rs, bool(ch & 0x20000000)))
    return d, secs

def rx(p):
    b = b""
    for t in p.split():
        b += b"." if t.startswith("?") else re.escape(bytes([int(t, 16)]))
    return re.compile(b, re.S)

def main():
    if len(sys.argv) < 2: print(__doc__); return 2
    d, secs = load(sys.argv[1])
    code = [s for s in secs if s[5] and 0x100000 <= s[2] < 0x10000000]
    if not code: print("no code section between 1 and 256 MB"); return 1
    nm, va, vs, ro, rs, _ = code[0]
    text = d[ro:ro + rs]
    rva = lambda off: va + off
    i32 = lambda off: struct.unpack_from("<i", text, off)[0]
    u32 = lambda off: struct.unpack_from("<I", text, off)[0]
    found = {}; bad = 0
    # the exe's unwind table: the start of the function holding a code offset (signatures found inside functions)
    pe = struct.unpack_from("<I", d, 0x3C)[0]
    pd_rva, pd_size = struct.unpack_from("<II", d, pe + 24 + 112 + 3 * 8)
    def to_off(r):
        for _, sva, svs, sro, srs, _x in secs:
            if sva <= r < sva + max(svs, srs): return sro + r - sva
    pdo = to_off(pd_rva); pdata = sorted(struct.unpack_from("<III", d, pdo + i * 12) for i in range(pd_size // 12)) if pdo is not None else []
    def func_start(off):
        r = rva(off); lo, hi = 0, len(pdata)
        while lo < hi:
            m = (lo + hi) // 2
            if pdata[m][0] <= r: lo = m + 1
            else: hi = m
        if not lo or r >= pdata[lo - 1][1]: return None
        b, e, u = pdata[lo - 1]
        for _ in range(8):
            if u & 1: b, e, u = struct.unpack_from("<III", d, to_off(u & ~1)); continue
            uo = to_off(u)
            if not (d[uo] >> 3) & 4: break
            b, e, u = struct.unpack_from("<III", d, uo + 4 + ((d[uo + 2] + 1) & ~1) * 2)
        return b
    print(f"code section {nm}: {rs / 1048576:.1f} MB")
    for k, p in SIGS.items():
        h = [m.start() for m in rx(p).finditer(text)]
        st = "OK" if len(h) == 1 else ("MISSING" if not h else f"AMBIGUOUS ({len(h)})")
        if len(h) != 1: bad += 1
        else: found[k] = h[0]
        print(f"  {k:16s} {st:12s} {'exe+%x' % rva(h[0]) if len(h) == 1 else ''}")
    for k, (parent, win, p) in INNER.items():
        if parent not in found: print(f"  {k:16s} (needs {parent})"); bad += 1; continue
        a = found[parent] + (0x20 if k == "CapRefresh" else 0)
        m = rx(p).search(text, a, a + win)
        if not m: print(f"  {k:16s} MISSING inside {parent}"); bad += 1; continue
        found[k] = m.start()
        print(f"  {k:16s} OK           exe+{rva(m.start()):x}")
    v = {}
    if "ViewBlock" in found: v["view block"] = hex(u32(found["ViewBlock"] + 6))
    if "ViewCamera" in found:
        o = found["ViewCamera"]; v["camera component"] = hex(u32(o + 3))
        th = o + 14 + i32(o + 14) + 4
        t = text[th:th + 15]
        if t[0:3] == b"\x48\x8D\x91" and t[7:10] == b"\x48\x81\xC1" and t[14] == 0xE9:
            v["camera view (inverse)"] = hex(struct.unpack_from("<I", t, 3)[0]); v["camera world"] = hex(struct.unpack_from("<I", t, 10)[0])
        else: v["camera matrices"] = "thunk NOT as expected"; bad += 1
    if "ViewCamPos" in found: o = found["ViewCamPos"]; v["object world ptr"] = hex(u32(o + 3)); v["view block position"] = hex(u32(o + 14))
    if "GetProjection" in found: v["viewport camera handle"] = hex(text[found["GetProjection"] + 16])
    if "ProjOut" in found: v["projection out"] = hex(u32(found["ProjOut"] + 3))
    if "ProjJitter" in found: v["jitter"] = hex(u32(found["ProjJitter"] + 5))
    if "TanX" in found: v["tan x"] = hex(u32(found["TanX"] + 4))
    if "TanY" in found: v["tan y"] = hex(u32(found["TanY"] + 4))
    if "FrameTime" in found: o = found["FrameTime"]; v["dt"] = hex(u32(o + 19)); v["dt unscaled"] = hex(u32(o + 26))
    if "GamePause" in found: o = found["GamePause"]; v["pause global"] = "exe+%x" % (rva(o) + 7 + i32(o + 3)); v["pause flag"] = hex(text[o + 9])
    if "TimeScale" in found: v["time scale"] = hex(u32(found["TimeScale"] + 4))
    if "ProjCamId" in found: v["viewport camera id"] = hex(text[found["ProjCamId"] + 3])
    if "ViewportSize" in found: o = found["ViewportSize"]; v["viewport size"] = "+%x / +%x" % (text[o + 5], text[o + 11])
    if "FocusLimiter" in found:
        o = found["FocusLimiter"]; v["focus limiter"] = "[exe+%x]+%x bit 63" % (rva(o) + 7 + i32(o + 3), u32(o + 17))
    if "CapRefresh" in found:
        o = found["CapRefresh"]; t = o + 7 + 5 + i32(o + 8)
        if text[t:t + 2] == b"\xC6\x81" and text[t + 6:t + 8] == b"\x01\xC3": v["renderer re-layout"] = hex(u32(t + 2))
        else: v["renderer re-layout"] = "NOT as expected"; bad += 1
    if "RenderSettings" in found: v["anti-aliasing"] = hex(u32(found["RenderSettings"] + 3))
    if "RsDlss" in found: v["DLSS mode"] = hex(u32(found["RsDlss"] + 4))
    if "RsFsr" in found:
        o = found["RsFsr"]; v["FSR mode"] = hex(u32(o + 3))
        m = rx("41 0F B6 8D ?? ?? ?? ?? 85 C9 74 ?? 83 E9 01 74 ?? 83 F9 01 75").search(text, o, o + 0x100)
        if m: v["frame generation"] = hex(u32(m.start() + 4))
        else: print("  frame generation MISSING"); bad += 1
        m = rx("F3 41 0F 10 95 ?? ?? ?? ?? 0F 5A D2").search(text, o, o + 0x180)
        if m: v["scaling"] = hex(u32(m.start() + 5))
    if "nvgBeginFrame" in found:
        nst = u32(found["nvgBeginFrame"] + 40); v["NanoVG nstates"] = hex(nst)
        for k in ("nvgTranslate", "nvgScale"):
            if k in found and u32(found[k] + 9) != nst: print(f"  {k} nstates MISMATCH"); bad += 1
    # Camera_Z (RTTI): the vtable slot whose code starts like the camera update
    td = d.find(b".?AVCamera_Z@@\0")
    slot = None
    if td >= 0:
        tdr = None
        for sn, sva, svs, sro, srs, _ in secs:
            if sro <= td - 16 < sro + srs: tdr = td - 16 - sro + sva
        base = 0x140000000
        for m in re.finditer(re.escape(struct.pack("<I", tdr)), d):
            col = m.start() - 12
            sig, off_, cd, tdv, chd, selfr = struct.unpack_from("<IIIIII", d, col)
            if sig != 1 or tdv != tdr: continue
            for m2 in re.finditer(re.escape(struct.pack("<Q", base + selfr)), d):
                vt = m2.start() + 8
                for i in range(8, 48):
                    f = struct.unpack_from("<Q", d, vt + i * 8)[0] - base
                    fo = f - va
                    if not (0 <= fo < rs): break
                    pm = rx("48 8B 82 ?? ?? ?? ?? 4C 8D 81 ?? ?? ?? ??").search(text, fo, fo + 0x2E)
                    if pm and rx("4C 8D 8B ?? ?? ?? ?? 8B 40 38 41 89 40 08 48 8B 89 ?? ?? ?? ?? 48 85 C9 74").search(text, pm.start(), pm.start() + 0x54):
                        slot = (i, f, u32(pm.start() + 10)); break
                if slot: break
            if slot: break
    # the NanoVG renderer's BeginFrame (RTTI vtable slot that calls nvgBeginFrame)
    gui = None
    td = d.find(b".?AVGuiRendererNanoVG@GUI@@\0")
    if td >= 0 and "nvgBeginFrame" in found:
        bfr = rva(found["nvgBeginFrame"])
        for sn, sva, svs, sro, srs, _ in secs:
            if sro <= td - 16 < sro + srs: tdr = td - 16 - sro + sva
        for m in re.finditer(re.escape(struct.pack("<I", tdr)), d):
            col = m.start() - 12
            if struct.unpack_from("<I", d, col)[0] != 1: continue
            selfr = struct.unpack_from("<I", d, col + 20)[0]
            for m2 in re.finditer(re.escape(struct.pack("<Q", 0x140000000 + selfr)), d):
                vt = m2.start() + 8
                for i in range(1, 24):
                    fo = struct.unpack_from("<Q", d, vt + i * 8)[0] - 0x140000000 - va
                    if not (0 <= fo < rs): break
                    for k in range(0x200):
                        if text[fo + k] == 0xE8 and va + fo + k + 5 + i32(fo + k + 1) == bfr:
                            sz = rx("66 0F 6E 53 ?? 0F 5B D2 66 0F 6E 4B ?? 0F 5B C9").search(text, fo, fo + k)
                            if sz and text[fo + k - 4:fo + k - 1] == b"\x48\x8B\x4F":
                                gui = (i, va + fo, text[fo + k - 1], text[sz.start() + 12], text[sz.start() + 4])
                            break
                    if gui: break
                if gui: break
            if gui: break
    if gui: v["GUI BeginFrame"] = "slot %d exe+%x (context +%x, target w +%x h +%x)" % gui
    else: print("  GUI BeginFrame   MISSING"); bad += 1
    if slot: v["Camera_Z update"] = "slot %d exe+%x (position +%x)" % slot
    else: print("  Camera_Z update  MISSING"); bad += 1
    if "AspectCap" in found:
        o = found["AspectCap"]; v["aspect min"] = "exe+%x" % (rva(o) + 21 + i32(o + 13)); v["aspect max"] = "exe+%x" % (rva(o) + 31 + i32(o + 23))
        v["renderer ptr"] = "exe+%x" % (rva(o) + 11 + i32(o + 7))
    if "VpLoop" in found and "ViewSetup" in found:
        o = found["VpLoop"]
        if rva(o) + 21 + i32(o + 17) != func_start(found["ViewSetup"]): print("  VpLoop           does not call the view setup"); bad += 1
        v["viewport table"] = "renderer+%x (slot 0 = the player's view)" % u32(o + 32)
    if "DisplaySurface" in found:
        o = found["DisplaySurface"]; win = text[o:o + 0x80]
        mw = re.search(rx("41 8B 81 ?? ?? ?? ?? 41 89 40 20"), win); mh = re.search(rx("41 8B 81 ?? ?? ?? ?? 41 89 40 24"), win)
        if not mw or not mh: print("  DisplaySurface   size loads not found"); bad += 1
        else: v["display surface"] = "[exe+%x] +%x / +%x" % (rva(o) + 14 + i32(o + 10), u32(o + mw.start() + 3), u32(o + mh.start() + 3))
    if "IntroSwitch" in found:
        o = found["IntroSwitch"]
        def cstr(r):   # a string at an RVA, any section
            for _, sva, svs, sro, srs, _x in secs:
                if sva <= r < sva + max(svs, srs): return d[sro + r - sva:sro + r - sva + 32].split(b"\0")[0].decode("latin1")
            return "?"
        n1, n2 = cstr(rva(o) + 10 + i32(o + 6)), cstr(rva(o) + 33 + i32(o + 29))
        if (n1, n2) != ("-FastLaunch", "SKIP_LOGOS"): print("  IntroSwitch      strings %r %r" % (n1, n2)); bad += 1
        v["intro logo switch"] = "exe+%x (%s -> %s)" % (rva(o) + 22, n1, n2)
    if "VpSlot" in found: v["viewport slot"] = hex(u32(found["VpSlot"] + 3) & 0xff)
    if "RenderConfig" in found:
        o = found["RenderConfig"]; v["render config"] = "exe+%x" % (rva(o) + 7 + i32(o + 3))
        v["config index"] = hex(u32(o + 10)); v["block size"] = hex(u32(o + 17)); v["blocks"] = hex(u32(o + 24))
    # post effects: the settings dump "\t\t<Name> %d\n" - the byte read just before it is the switch
    for n in POSTFX:
        s = ("\t\t%s %%d\n" % n).encode()
        i = d.find(b"\0" + s)
        if i < 0: print(f"  postfx {n:14s} string MISSING"); bad += 1; continue
        srva = None
        for sn, sva, svs, sro, srs, _ in secs:
            if sro <= i + 1 < sro + srs: srva = i + 1 - sro + sva
        hit = None
        for m in re.finditer(b"\x48\x8D\x15", text):
            o = m.start()
            if va + o + 7 + i32(o + 3) == srva: hit = o; break
        if hit is None or text[hit - 8:hit - 4] != b"\x45\x0F\xB6\x86": print(f"  postfx {n:14s} read MISSING"); bad += 1; continue
        v["postfx " + n] = hex(u32(hit - 4))
    print("values read from the code:")
    for k, x in v.items(): print(f"  {k:24s} {x}")
    print("RESULT:", "all signatures OK" if not bad else f"{bad} problem(s)")
    return 0 if not bad else 1

if __name__ == "__main__":
    sys.exit(main())
