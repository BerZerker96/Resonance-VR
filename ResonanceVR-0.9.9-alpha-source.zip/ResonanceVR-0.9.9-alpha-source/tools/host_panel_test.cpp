// The host's DrawPanel (composite panels) on a real D3D11 device: a 1 m x 0.5 m panel 1 m in front of an eye with a
// 90-degree FOV must cover exactly the centre half x quarter of the image; one 30 degrees to the left lands left.
#define wWinMain HostWinMain
#include "../third_party/xrbridge/src/host/main.cpp"
#undef wWinMain
#include <cstdio>
static int bad = 0;
static void Check(bool c, const char* w) { printf("%-4s %s\n", c ? "OK" : "FAIL", w); if (!c) bad++; }
int main() {
    if (FAILED(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0, D3D11_SDK_VERSION, &g_dev, nullptr, &g_ctx))) { printf("no device\n"); return 2; }
    const UINT W = 512, H = 512;
    D3D11_TEXTURE2D_DESC d{}; d.Width = W; d.Height = H; d.MipLevels = 1; d.ArraySize = 1; d.Format = DXGI_FORMAT_R8G8B8A8_TYPELESS;
    d.SampleDesc.Count = 1; d.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
    ID3D11Texture2D* img = nullptr; g_dev->CreateTexture2D(&d, nullptr, &img);
    g_swapFormat = DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;
    Swap s; s.images.assign(1, {XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR}); s.images[0].texture = img; s.rtv.assign(1, nullptr); s.w = W; s.h = H;
    // the panel picture: opaque red with a 50 % transparent green right half
    std::vector<uint32_t> px(256 * 128);
    for (int y = 0; y < 128; y++) for (int x = 0; x < 256; x++) px[y * 256 + x] = x < 128 ? 0xFF0000FFu : 0x80008000u;   // ABGR; green premultiplied 0.5
    d.Width = 256; d.Height = 128; d.Format = DXGI_FORMAT_R8G8B8A8_UNORM; d.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    D3D11_SUBRESOURCE_DATA sd{px.data(), 256 * 4, 0};
    g_dev->CreateTexture2D(&d, &sd, &g_hudTex); g_dev->CreateShaderResourceView(g_hudTex, nullptr, &g_hudSrv);
    auto rtv = GetRtv(s, 0); const float blue[4] = {0, 0, 1, 1}; g_ctx->ClearRenderTargetView(rtv, blue);
    XrPosef eye = Identity(); XrFovf fov{-0.785398f, 0.785398f, 0.785398f, -0.785398f};
    XrPosef q = Identity(); q.position = {0, 0, -1};
    DrawPanel(s, 0, eye, fov, q, {1.f, 0.5f}, false, true);
    // read back
    d.Width = W; d.Height = H; d.Format = DXGI_FORMAT_R8G8B8A8_TYPELESS; d.BindFlags = 0; d.Usage = D3D11_USAGE_STAGING; d.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    ID3D11Texture2D* st = nullptr; g_dev->CreateTexture2D(&d, nullptr, &st); g_ctx->CopyResource(st, img);
    D3D11_MAPPED_SUBRESOURCE m; g_ctx->Map(st, 0, D3D11_MAP_READ, 0, &m);
    auto at = [&](int x, int y) { return *(uint32_t*)((uint8_t*)m.pData + y * m.RowPitch + x * 4); };
    // panel spans x 128..384, y 192..320 (tan 45 = 1: 0.5 m at 1 m = half the half-width)
    printf("     centre-left %08x, centre-right %08x, outside %08x, edges x127 %08x x129 %08x y191 %08x y193 %08x\n",
           at(200, 256), at(320, 256), at(50, 256), at(127, 256), at(129, 256), at(200, 191), at(200, 193));
    Check(at(200, 256) == 0xFF0000FFu, "opaque half: red");
    uint32_t g = at(320, 256); Check(((g >> 16) & 0xFF) > 0x70 && ((g >> 16) & 0xFF) < 0x90 && ((g >> 8) & 0xFF) > 0x70, "transparent half: blue + green blended");
    Check(at(50, 256) == 0xFFFF0000u, "outside: untouched");
    Check(at(127, 256) == 0xFFFF0000u && at(129, 256) == 0xFF0000FFu && at(200, 191) == 0xFFFF0000u && at(200, 193) == 0xFF0000FFu, "edges where the projection puts them");
    g_ctx->Unmap(st, 0);
    // turned: the panel 30 degrees to the left of the view
    g_ctx->ClearRenderTargetView(rtv, blue);
    XrPosef q2 = Identity(); q2.position = {-0.5f, 0, -0.866f};
    q2.orientation = {0, sinf(0.2618f), 0, cosf(0.2618f)};   // facing the eye
    DrawPanel(s, 0, eye, fov, q2, {0.3f, 0.3f}, true, false);
    g_ctx->CopyResource(st, img); g_ctx->Map(st, 0, D3D11_MAP_READ, 0, &m);
    int cx = (int)((-0.5f / 0.866f) * 0.5f * W + W / 2);   // tan(-30) mapped
    printf("     panel 30 deg left: expected centre x %d: %08x, mirrored %08x\n", cx, at(cx, 256), at(W - cx, 256));
    Check(at(cx, 256) != 0xFFFF0000u && at(W - cx, 256) == 0xFFFF0000u, "left of centre, not right");
    g_ctx->Unmap(st, 0);
    printf(bad ? "%d FAILED\n" : "all passed\n", bad);
    return bad;
}
