#define WIDL_EXPLICIT_AGGREGATE_RETURNS
#include <windows.h>
#include <mmsystem.h>
#include <d3d12.h>
#include <dxgi1_6.h>
#include <d3dcompiler.h>
#include <cstdio>
static const char* src = "float4 vs(uint i:SV_VertexID):SV_Position{float2 k=float2((i<<1)&2,i&2);return float4(k*float2(2,-2)+float2(-1,1),0,1);}"
                         "float4 ps():SV_Target{return float4(0.2,0.6,1,1);}";
#define CK(x) do { HRESULT _h = (x); if (FAILED(_h)) { printf("FAIL %s = %08lx\n", #x, (unsigned long)_h); return 1; } } while (0)
int main() {
    timeBeginPeriod(1);
    WNDCLASSW wc = {}; wc.lpfnWndProc = DefWindowProcW; wc.hInstance = GetModuleHandleW(nullptr); wc.lpszClassName = L"t";
    RegisterClassW(&wc);
    HWND hw = CreateWindowW(L"t", L"gotg test", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 0, 0, 640, 360, nullptr, nullptr, wc.hInstance, nullptr);
    Sleep(300);   // let the mod's init thread hook DXGI
    ID3D12Device* dev; CK(D3D12CreateDevice(nullptr, D3D_FEATURE_LEVEL_11_0, __uuidof(ID3D12Device), (void**)&dev));
    D3D12_COMMAND_QUEUE_DESC qd = {}; ID3D12CommandQueue* q; CK(dev->CreateCommandQueue(&qd, __uuidof(ID3D12CommandQueue), (void**)&q));
    IDXGIFactory4* f; CK(CreateDXGIFactory2(0, __uuidof(IDXGIFactory4), (void**)&f));
    DXGI_SWAP_CHAIN_DESC1 sd = {}; sd.Width = 640; sd.Height = 360; sd.Format = DXGI_FORMAT_R8G8B8A8_UNORM; sd.SampleDesc.Count = 1;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT; sd.BufferCount = 3; sd.SwapEffect = DXGI_SWAP_EFFECT_FLIP_DISCARD;
    IDXGISwapChain1* sc1; CK(f->CreateSwapChainForHwnd(q, hw, &sd, nullptr, nullptr, &sc1));
    IDXGISwapChain3* sc; CK(sc1->QueryInterface(__uuidof(IDXGISwapChain3), (void**)&sc));
    DXGI_SWAP_CHAIN_DESC1 got; sc->GetDesc1(&got); printf("swapchain %ux%u\n", got.Width, got.Height);
    D3D12_DESCRIPTOR_HEAP_DESC hd = { D3D12_DESCRIPTOR_HEAP_TYPE_RTV, 3, D3D12_DESCRIPTOR_HEAP_FLAG_NONE, 0 };
    ID3D12DescriptorHeap* heap; CK(dev->CreateDescriptorHeap(&hd, __uuidof(ID3D12DescriptorHeap), (void**)&heap));
    UINT inc = dev->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_RTV);
    D3D12_CPU_DESCRIPTOR_HANDLE h0 = heap->GetCPUDescriptorHandleForHeapStart();
    ID3D12Resource* bb[3];
    auto mkrtv = [&]() { for (int i = 0; i < 3; i++) { sc->GetBuffer(i, __uuidof(ID3D12Resource), (void**)&bb[i]); D3D12_CPU_DESCRIPTOR_HANDLE h = { h0.ptr + i * inc }; dev->CreateRenderTargetView(bb[i], nullptr, h); } };
    mkrtv();
    D3D12_ROOT_SIGNATURE_DESC rsd = {}; rsd.Flags = D3D12_ROOT_SIGNATURE_FLAG_NONE; ID3DBlob* rb, * err = nullptr;
    CK(D3D12SerializeRootSignature(&rsd, D3D_ROOT_SIGNATURE_VERSION_1, &rb, &err));
    ID3D12RootSignature* rs; CK(dev->CreateRootSignature(0, rb->GetBufferPointer(), rb->GetBufferSize(), __uuidof(ID3D12RootSignature), (void**)&rs));
    ID3DBlob* vsb, * psb;
    CK(D3DCompile(src, strlen(src), 0, 0, 0, "vs", "vs_5_0", 0, 0, &vsb, &err)); CK(D3DCompile(src, strlen(src), 0, 0, 0, "ps", "ps_5_0", 0, 0, &psb, &err));
    D3D12_GRAPHICS_PIPELINE_STATE_DESC pd = {}; pd.pRootSignature = rs; pd.VS = { vsb->GetBufferPointer(), vsb->GetBufferSize() };
    pd.PS = { psb->GetBufferPointer(), psb->GetBufferSize() }; pd.BlendState.RenderTarget[0].RenderTargetWriteMask = 15; pd.SampleMask = ~0u;
    pd.RasterizerState.FillMode = D3D12_FILL_MODE_SOLID; pd.RasterizerState.CullMode = D3D12_CULL_MODE_NONE; pd.PrimitiveTopologyType = D3D12_PRIMITIVE_TOPOLOGY_TYPE_TRIANGLE;
    pd.NumRenderTargets = 1; pd.RTVFormats[0] = DXGI_FORMAT_R8G8B8A8_UNORM; pd.SampleDesc.Count = 1;
    ID3D12PipelineState* pso; CK(dev->CreateGraphicsPipelineState(&pd, __uuidof(ID3D12PipelineState), (void**)&pso));
    // G-buffer pass: colour + D32S8 depth (the game's scene depth format)
    pd.DSVFormat = DXGI_FORMAT_D32_FLOAT_S8X24_UINT; pd.DepthStencilState.DepthEnable = TRUE;
    pd.DepthStencilState.DepthWriteMask = D3D12_DEPTH_WRITE_MASK_ALL; pd.DepthStencilState.DepthFunc = D3D12_COMPARISON_FUNC_ALWAYS;
    ID3D12PipelineState* psoG; CK(dev->CreateGraphicsPipelineState(&pd, __uuidof(ID3D12PipelineState), (void**)&psoG));
    D3D12_DESCRIPTOR_HEAP_DESC dhd = { D3D12_DESCRIPTOR_HEAP_TYPE_DSV, 1, D3D12_DESCRIPTOR_HEAP_FLAG_NONE, 0 };
    ID3D12DescriptorHeap* dheap; CK(dev->CreateDescriptorHeap(&dhd, __uuidof(ID3D12DescriptorHeap), (void**)&dheap));
    D3D12_DESCRIPTOR_HEAP_DESC ghd = { D3D12_DESCRIPTOR_HEAP_TYPE_RTV, 1, D3D12_DESCRIPTOR_HEAP_FLAG_NONE, 0 };
    ID3D12DescriptorHeap* gheap; CK(dev->CreateDescriptorHeap(&ghd, __uuidof(ID3D12DescriptorHeap), (void**)&gheap));
    D3D12_CPU_DESCRIPTOR_HANDLE dsvH = dheap->GetCPUDescriptorHandleForHeapStart(), gH = gheap->GetCPUDescriptorHandleForHeapStart();
    ID3D12Resource* depth = nullptr, * gbuf = nullptr;
    auto mkg = [&](UINT w, UINT h) {
        if (depth) depth->Release(); if (gbuf) gbuf->Release();
        D3D12_HEAP_PROPERTIES hp = {}; hp.Type = D3D12_HEAP_TYPE_DEFAULT;
        D3D12_RESOURCE_DESC rd = {}; rd.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D; rd.Width = w; rd.Height = h; rd.DepthOrArraySize = 1; rd.MipLevels = 1;
        rd.Format = DXGI_FORMAT_R32G8X24_TYPELESS; rd.SampleDesc.Count = 1; rd.Flags = D3D12_RESOURCE_FLAG_ALLOW_DEPTH_STENCIL;
        D3D12_CLEAR_VALUE cv = {}; cv.Format = DXGI_FORMAT_D32_FLOAT_S8X24_UINT; cv.DepthStencil.Depth = 0;
        dev->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, &cv, __uuidof(ID3D12Resource), (void**)&depth);
        D3D12_DEPTH_STENCIL_VIEW_DESC dv = {}; dv.Format = DXGI_FORMAT_D32_FLOAT_S8X24_UINT; dv.ViewDimension = D3D12_DSV_DIMENSION_TEXTURE2D;
        dev->CreateDepthStencilView(depth, &dv, dsvH);
        rd.Format = DXGI_FORMAT_R8G8B8A8_UNORM; rd.Flags = D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET;
        dev->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_RENDER_TARGET, nullptr, __uuidof(ID3D12Resource), (void**)&gbuf);
        dev->CreateRenderTargetView(gbuf, nullptr, gH);
        printf("gbuffer %ux%u depth %p\n", w, h, (void*)depth);
    };
    mkg(got.Width, got.Height);
    ID3D12CommandAllocator* al; CK(dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, __uuidof(ID3D12CommandAllocator), (void**)&al));
    ID3D12GraphicsCommandList* cl; CK(dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, al, pso, __uuidof(ID3D12GraphicsCommandList), (void**)&cl)); cl->Close();
    ID3D12Fence* fe; CK(dev->CreateFence(0, D3D12_FENCE_FLAG_NONE, __uuidof(ID3D12Fence), (void**)&fe)); UINT64 fv = 0; HANDLE ev = CreateEventW(0, 0, 0, 0);
    UINT W = got.Width, H = got.Height;
    for (int frame = 0; frame < 900; frame++) {
        MSG m; while (PeekMessageW(&m, 0, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageW(&m); }
        if (frame == 300) {   // resize like a WM_SIZE would
            for (auto* b : bb) b->Release();
            HRESULT hr = sc->ResizeBuffers(3, 800, 600, DXGI_FORMAT_UNKNOWN, 0); sc->GetDesc1(&got); W = got.Width; H = got.Height;
            printf("resize -> %08lx, now %ux%u\n", (unsigned long)hr, W, H); mkrtv();
            q->Signal(fe, ++fv); fe->SetEventOnCompletion(fv, ev); WaitForSingleObject(ev, 5000); mkg(W, H);
        }
        Sleep(14); UINT i = sc->GetCurrentBackBufferIndex();
        al->Reset(); cl->Reset(al, psoG);
        {   // G-buffer: depth to DEPTH_WRITE, 5 draws, then to shader read (its depth is final)
            D3D12_RESOURCE_BARRIER d = {}; d.Transition.pResource = depth; d.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
            d.Transition.StateBefore = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE; d.Transition.StateAfter = D3D12_RESOURCE_STATE_DEPTH_WRITE; cl->ResourceBarrier(1, &d);
            cl->OMSetRenderTargets(1, &gH, FALSE, &dsvH);
            cl->ClearDepthStencilView(dsvH, D3D12_CLEAR_FLAG_DEPTH, 0.f, 0, 0, nullptr);
            cl->SetGraphicsRootSignature(rs); cl->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
            D3D12_VIEWPORT gv = { 0, 0, (float)W, (float)H, 0, 1 }; D3D12_RECT gr = { 0, 0, (LONG)W, (LONG)H };
            cl->RSSetViewports(1, &gv); cl->RSSetScissorRects(1, &gr);
            for (int k = 0; k < 5; k++) cl->DrawInstanced(3, 1, 0, 0);
            d.Transition.StateBefore = D3D12_RESOURCE_STATE_DEPTH_WRITE; d.Transition.StateAfter = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE; cl->ResourceBarrier(1, &d);
            cl->SetPipelineState(pso);
        }
        D3D12_RESOURCE_BARRIER b = {}; b.Transition.pResource = bb[i]; b.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        b.Transition.StateBefore = D3D12_RESOURCE_STATE_PRESENT; b.Transition.StateAfter = D3D12_RESOURCE_STATE_RENDER_TARGET; cl->ResourceBarrier(1, &b);
        D3D12_CPU_DESCRIPTOR_HANDLE h = { h0.ptr + i * inc };
        cl->OMSetRenderTargets(1, &h, FALSE, nullptr);
        float c[4] = { 0, 0, 0, 1 }; cl->ClearRenderTargetView(h, c, 0, nullptr);
        cl->SetGraphicsRootSignature(rs); cl->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
        D3D12_VIEWPORT vp = { 0, 0, (float)W, (float)H, 0, 1 }; D3D12_RECT sr = { 0, 0, (LONG)W, (LONG)H };
        cl->RSSetViewports(1, &vp); cl->RSSetScissorRects(1, &sr);
        cl->DrawInstanced(3, 1, 0, 0);                         // "3D image"
        D3D12_VIEWPORT v2 = { W * 0.7f, H * 0.7f, W * 0.25f, H * 0.25f, 0, 1 }; cl->RSSetViewports(1, &v2);
        cl->DrawInstanced(3, 1, 0, 0); cl->DrawInstanced(3, 1, 0, 0);   // "UI"
        b.Transition.StateBefore = D3D12_RESOURCE_STATE_RENDER_TARGET; b.Transition.StateAfter = D3D12_RESOURCE_STATE_PRESENT; cl->ResourceBarrier(1, &b);
        cl->Close(); ID3D12CommandList* l[] = { cl }; q->ExecuteCommandLists(1, l);
        HRESULT pr = sc->Present(1, 0);
        if (FAILED(pr)) { printf("Present failed %08lx\n", (unsigned long)pr); return 1; }
        q->Signal(fe, ++fv); if (fe->GetCompletedValue() < fv) { fe->SetEventOnCompletion(fv, ev); WaitForSingleObject(ev, 5000); }
    }
    printf("900 frames ok\n"); if (dev->GetDeviceRemovedReason() != S_OK) printf("DEVICE REMOVED %08lx\n", (unsigned long)dev->GetDeviceRemovedReason());
    return 0;
}
