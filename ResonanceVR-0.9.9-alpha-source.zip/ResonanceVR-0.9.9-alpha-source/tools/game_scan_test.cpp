// Offline test of the mod's exe analysis: maps Resonance.exe as an image (nothing of it runs), runs game::InitAt on it -
// the same code the mod runs in the game - and prints the log. Checks every signature and every value read from code.
//   x86_64-w64-mingw32-g++ -std=c++17 -O1 -Isrc tools/game_scan_test.cpp src/game.cpp src/log.cpp -o build/game_scan_test.exe
//   wine build/game_scan_test.exe <path to Resonance.exe>
#include <windows.h>
#include <cstdio>
#include "game.h"
#include "log.h"
int wmain(int argc, wchar_t** argv) {
    if (argc < 2) { printf("usage: game_scan_test <Resonance.exe>\n"); return 2; }
    LogInit(L"game_scan_test.log");
    HMODULE m = LoadLibraryExW(argv[1], nullptr, DONT_RESOLVE_DLL_REFERENCES);
    if (!m) { printf("could not map the exe (error %lu)\n", GetLastError()); return 1; }
    bool ok = game::InitAt((uintptr_t)m, false);
    LogFlushDisk();
    int bad = 0;
    struct { const char* n; bool ok; } r[] = {
        { "view setup", game::g_viewSetup != nullptr }, { "projection getter", game::g_getProj != nullptr },
        { "FOV tangents", game::g_fovTangents != nullptr }, { "camera update", game::g_camUpdate != nullptr },
        { "frame clock", game::g_frameTime != nullptr }, { "pause flag", game::g_pauseGlobal != 0 },
        { "picture shape clamp", game::AspectCapFound() }, { "out-of-focus limiter", game::FocusLimiterFound() },
    };
    for (auto& x : r) { printf("%-22s %s\n", x.n, x.ok ? "OK" : "MISSING"); if (!x.ok) bad++; }
    for (int i = 0; i < game::PFX_COUNT; i++) { printf("postfx %-15s %s\n", game::PostFxName(i), game::PostFxFound(i) ? "OK" : "MISSING"); if (!game::PostFxFound(i)) bad++; }
    printf("offsets: vp cam +%llx/+%llx size +%llx/+%llx tan +%llx/+%llx proj +%llx jitter +%llx block +%llx pos +%llx | cam comp +%llx world +%llx view +%llx objworld +%llx pos +%llx target +%llx | dt +%llx raw +%llx scale +%llx\n",
        (unsigned long long)game::kVpCam, (unsigned long long)game::kVpCamId, (unsigned long long)game::kVpW, (unsigned long long)game::kVpH,
        (unsigned long long)game::kVpTanX, (unsigned long long)game::kVpTanY, (unsigned long long)game::kVpProj, (unsigned long long)game::kVpJitter,
        (unsigned long long)game::kVpBlock, (unsigned long long)game::kBlockPos, (unsigned long long)game::kCamComp, (unsigned long long)game::kCamWorld,
        (unsigned long long)game::kCamView, (unsigned long long)game::kObjWorld, (unsigned long long)game::kCamPos, (unsigned long long)game::kCamTarget,
        (unsigned long long)game::kDt, (unsigned long long)game::kDtRaw, (unsigned long long)game::kTimeScale);
    printf("RESULT: %s\n", ok && !bad ? "OK" : "PROBLEMS");
    return ok && !bad ? 0 : 1;
}
