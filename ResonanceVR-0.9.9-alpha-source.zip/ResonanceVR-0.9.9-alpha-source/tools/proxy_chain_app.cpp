// 0.6.36 chain-loading test app (run as Resonance.exe next to dxgi.dll + dxgi_chain.dll; wine: WINEDLLOVERRIDES=dxgi=n,b, EXPECT_CHAIN=1).
#include <windows.h>
#include <cstdio>
typedef HRESULT(WINAPI* F2)(UINT, REFIID, void**);
int main() {
    HMODULE m = LoadLibraryA("dxgi.dll");
    char p[MAX_PATH] = ""; if (m) GetModuleFileNameA(m, p, MAX_PATH);
    printf("dxgi.dll loaded from: %s, chain module %p\n", p, (void*)GetModuleHandleA("dxgi_chain.dll"));
    F2 f = (F2)GetProcAddress(m, "CreateDXGIFactory2");
    void* o = nullptr; static const GUID g = { 0x50c83a1c, 0xe072, 0x4c48, { 0x87, 0xb0, 0x36, 0x30, 0xfa, 0x36, 0xa6, 0xd0 } };
    HRESULT hr = f ? f(0, g, &o) : -1;
    char hit[8] = ""; GetEnvironmentVariableA("FAKE_HIT", hit, 8);
    printf("CreateDXGIFactory2 -> %08lx, chain hit '%s'\n", (unsigned long)hr, hit);
    bool chained = hit[0] == '2' && hr == 0x12345678;
    printf(getenv("EXPECT_CHAIN") ? (chained ? "OK chained\n" : "FAIL not chained\n") : (!hit[0] && hr == 0 ? "OK system dxgi\n" : "FAIL\n"));
    fflush(stdout); TerminateProcess(GetCurrentProcess(), 0);
}
