// 0.6.36 chain-loading test: a fake dxgi_chain.dll (another dxgi.dll mod) - ResonanceVR's dxgi.dll must forward to it.
#include <windows.h>
extern "C" __declspec(dllexport) HRESULT WINAPI CreateDXGIFactory(REFIID, void** o) { *o = nullptr; SetEnvironmentVariableA("FAKE_HIT", "0"); return E_FAIL; }
extern "C" __declspec(dllexport) HRESULT WINAPI CreateDXGIFactory1(REFIID, void** o) { *o = nullptr; SetEnvironmentVariableA("FAKE_HIT", "1"); return E_FAIL; }
extern "C" __declspec(dllexport) HRESULT WINAPI CreateDXGIFactory2(UINT, REFIID, void** o) { *o = nullptr; SetEnvironmentVariableA("FAKE_HIT", "2"); return 0x12345678; }
BOOL WINAPI DllMain(HINSTANCE, DWORD, LPVOID) { return TRUE; }
