# Numerical check of recon.cpp's matrices + the two shader passes (numpy transcription), against ground truth.
import numpy as np
np.seterr(all='ignore')
W,H=320,288
DEBUG=False
def quat_mat(q):
    x,y,z,w=q
    return np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
def node(base_axes,base_pos,R,t):   # Compose(): rows right, up, back; pos
    ax=[sum(base_axes[i]*R[i][k] for i in range(3)) for k in range(3)]
    pos=base_pos+base_axes[0]*t[0]+base_axes[1]*t[1]+base_axes[2]*t[2]
    return np.concatenate([ax[0],ax[1],ax[2],pos]).astype(np.float32)
def game_proj(reverse,n=0.1,f=5000.):   # row-vector RH, [11]=-1, symmetric (the getter's) + jitter
    P=np.zeros(16); P[0]=1.2; P[5]=1.5; P[11]=-1
    if reverse: P[10]=n/(f-n); P[14]=f*n/(f-n)
    else: P[10]=f/(n-f); P[14]=n*f/(n-f)
    return P
def hook_proj(cap,tan,jit):   # H_GetProj
    P=cap.copy(); P[8]+=jit[0]; P[9]+=jit[1]
    w=tan[1]-tan[0]; h=tan[2]-tan[3]
    P[0]=2/w; P[5]=2/h; P[8]+=(tan[1]+tan[0])/w; P[9]+=(tan[2]+tan[3])/h; P[1]=P[4]=0
    return P
# ---- recon.cpp CPU side
def View(T,o):
    Wm=np.array([[T[0],T[1],T[2],0],[T[3],T[4],T[5],0],[T[6],T[7],T[8],0],[T[9]-o[0],T[10]-o[1],T[11]-o[2],1]],dtype=float)
    return np.linalg.inv(Wm)
def ProjFor(cap,capTan,tan,jit):
    P=cap.astype(float).copy()
    wc=capTan[1]-capTan[0]; hc=capTan[2]-capTan[3]
    jx=cap[8]-(capTan[1]+capTan[0])/wc; jy=cap[9]-(capTan[2]+capTan[3])/hc
    w=tan[1]-tan[0]; h=tan[2]-tan[3]
    P[0]=2/w; P[5]=2/h; P[1]=P[4]=0
    P[8]=(jx if jit else 0)+(tan[1]+tan[0])/w; P[9]=(jy if jit else 0)+(tan[2]+tan[3])/h
    return P.reshape(4,4)
# ---- scene: ray tracing in world (Z up). colour = world position (for exact comparison); sky = direction
SPH=[(np.array([3.0,0.4,1.6]),0.5),(np.array([9.0,-1.5,1.0]),1.0)]
def trace(o,d):
    t=np.full(d.shape[:-1],np.inf); pos=np.zeros(d.shape)
    # floor z=0, wall x=30
    for (n,c) in [((0,0,1),0.0)]:
        n=np.array(n,float); dn=d@n; tt=(c-o@n)/dn
        ok=(dn!=0)&(tt>1e-4)&(tt<t); t=np.where(ok,tt,t)
    for (c,r) in SPH:
        oc=o-c; b=d@oc; cc=oc@oc-r*r; disc=b*b-cc
        tt=-b-np.sqrt(np.maximum(disc,0)); ok=(disc>0)&(tt>1e-4)&(tt<t); t=np.where(ok,tt,t)
    return t
def render(T,P,w,h,sky=0.0):   # depth (ndc z) + world position per pixel, for camera T and row-vector proj P(4x4)
    org=np.zeros(3); V=View(T,org); VP=V@P; inv=np.linalg.inv(VP)
    ys,xs=np.mgrid[0:h,0:w]; nx=(xs+0.5)/w*2-1; ny=1-(ys+0.5)/h*2
    pn=np.stack([nx,ny,np.full_like(nx,0.5),np.ones_like(nx)],-1)@inv; pn=pn[...,:3]/pn[...,3:]
    pf=np.stack([nx,ny,np.full_like(nx,0.9),np.ones_like(nx)],-1)@inv; pf=pf[...,:3]/pf[...,3:]
    cam=T[9:12].astype(float); d=pn-cam; d/=np.linalg.norm(d,axis=-1,keepdims=True)
    t=trace(cam,d); hit=np.isfinite(t)
    wp=cam+d*np.where(hit,t,0)[...,None]
    hp=np.concatenate([wp,np.ones(wp.shape[:-1]+(1,))],-1)@VP
    z=np.where(hit,hp[...,2]/hp[...,3],sky)
    col=np.where(hit[...,None],wp,1000+d*100)   # sky: encoded direction
    return z.astype(np.float32),col,hit
def run(reverse,cant=0.0,jit=(0.0,0.0),shared=True):
    ipd=0.064; s=1.0
    base_axes=[np.array([0,-1.,0]),np.array([0,0,1.]),np.array([-1.,0,0])]   # looking +x, Z up
    base_pos=np.array([0.,0.,1.7])
    qh=np.array([0.05,0.12,0.0,1.0]); qh/=np.linalg.norm(qh)               # head turned / pitched
    def eye_q(e): 
        a=(-1 if e==0 else 1)*cant; qc=np.array([0,np.sin(a/2),0,np.cos(a/2)])
        x1,y1,z1,w1=qh; x2,y2,z2,w2=qc
        return np.array([w1*x2+x1*w2+y1*z2-z1*y2,w1*y2-x1*z2+y1*w2+z1*x2,w1*z2+x1*y2-y1*x2+z1*w2,w1*w2-x1*x2-y1*y2-z1*z2])
    Rh=quat_mat(qh); epos=[Rh@np.array([-ipd/2,0,0]),Rh@np.array([ipd/2,0,0])]
    tan={0:[-1.1,0.95,1.0,-1.05],1:[-0.95,1.1,1.0,-1.05]}
    a=W/H
    def fix(t):
        l,r,u,d=t; cx=(r+l)/2; cy=(u+d)/2; w=r-l; h=u-d
        if w/h<a: w=h*a
        else: h=w/a
        return [cx-w/2,cx+w/2,cy+h/2,cy-h/2]
    eyeTan={e:fix(tan[e]) for e in (0,1)}
    # shared frustum (camera.cpp)
    def shared_tan(e):
        ta=eyeTan[e]; b=eyeTan[e^1]; l,r,u,d=ta
        Re=quat_mat(eye_q(e)); Ro=quat_mat(eye_q(e^1))
        for c in range(4):
            v=np.array([b[1] if c&1 else b[0], b[2] if c&2 else b[3], -1.0]); w=Re.T@(Ro@v)
            tx,ty=w[0]/-w[2],w[1]/-w[2]; l=min(l,tx); r=max(r,tx); u=max(u,ty); d=min(d,ty)
        cx=(r+l)/2; cy=(u+d)/2; Wd=(r-l)*1.03; Hd=(u-d)*1.03
        if Wd/Hd<a: Wd=Hd*a
        else: Hd=Wd/a
        return [cx-Wd/2,cx+Wd/2,cy+Hd/2,cy-Hd/2]
    res=[]
    for de in (0,1):
        oe=de^1
        tanD=shared_tan(de) if shared else eyeTan[de]; tanO=eyeTan[oe]
        Td=node(base_axes,base_pos,quat_mat(eye_q(de)),epos[de]); To=node(base_axes,base_pos,quat_mat(eye_q(oe)),epos[oe])
        cap=hook_proj(game_proj(reverse),tanD,jit).astype(np.float32)          # what the renderer got
        zD,_,_=render(Td,cap.reshape(4,4).astype(float),W,H,0.0 if reverse else 1.0)              # depth: jittered
        capU=hook_proj(game_proj(reverse),tanD,(0,0)); _,colD,hitD=render(Td,capU.reshape(4,4),W,H)  # colour: TAA-resolved (unjittered)
        # ---- recon.cpp
        org=Td[9:12].astype(float)
        Vd=View(Td,org); Vo=View(To,org)
        Pdj=ProjFor(cap,tanD,tanD,True); Pd=ProjFor(cap,tanD,tanD,False); Po=ProjFor(cap,tanD,tanO,False)
        c2w=np.linalg.inv(Vd@Pdj).astype(np.float32); VPo=(Vo@Po).astype(np.float32); toD=(np.linalg.inv(Vo@Po)@(Vd@Pd)).astype(np.float32)
        za,zb=-Po.reshape(16)[10],Po.reshape(16)[14]
        # forward pass
        ys,xs=np.mgrid[0:H,0:W]
        ndc=np.stack([(xs+0.5)/W*2-1,1-(ys+0.5)/H*2],-1)
        wp=np.concatenate([ndc,zD[...,None],np.ones((H,W,1))],-1).astype(np.float32)@c2w
        wp*=np.sign(wp[...,3:]+1e-30)
        oc=wp@VPo
        okc=oc[...,3]>1e-9
        dist=np.where(wp[...,3]>1e-20,oc[...,3]/wp[...,3],1e30)
        px=(oc[...,:2]/oc[...,3:]*np.array([0.5,-0.5])+0.5)*np.array([W,H])
        key=np.full((H,W),np.inf)
        y0=np.floor(px[...,1]-0.5).astype(int); x0=np.floor(px[...,0]-0.5).astype(int)
        for j in range(4):
            xx=x0+(j&1); yy=y0+(j>>1); m=okc&(yy>=0)&(yy<H)&(xx>=0)&(xx<W)
            np.minimum.at(key,(yy[m],xx[m]),np.minimum(dist[m],1e30))
        # resolve (no history: measure geometric accuracy where the drawn eye saw the point)
        filled=np.isfinite(key)
        # resolve's gap logic (march left / right, crack vs hidden)
        reach=int(64*W/1920)+2; stride=max(1,reach//24)
        kl=np.full((H,W),np.inf); kr=np.full((H,W),np.inf); fl=np.zeros((H,W),int); fr=np.zeros((H,W),int)
        steps=[i for i in range(1,4)]+list(range(4,reach+1,stride))
        for i in steps:
            sh_l=np.full((H,W),np.inf); sh_l[:,i:]=key[:,:-i]
            sh_r=np.full((H,W),np.inf); sh_r[:,:-i]=key[:,i:]
            nl=~np.isfinite(kl); kl=np.where(nl,sh_l,kl); fl=np.where(nl,i,fl)
            nr=~np.isfinite(kr); kr=np.where(nr,sh_r,kr); fr=np.where(nr,i,fr)
        both=np.isfinite(kl)&np.isfinite(kr)
        crack=both&(fl+fr<=6)&(np.abs(kl-kr)<=0.03*np.minimum(kl,kr))
        direct=filled|((~filled)&crack)
        dd=np.where(filled,key,np.where(crack,np.minimum(kl,kr),1e30))
        filled=direct
        zn=np.where(dd>=1e29,za,za+zb/np.maximum(dd,1e-6))
        p=np.concatenate([ndc,zn[...,None],np.ones((H,W,1))],-1).astype(np.float32)
        dc=p@toD; su=dc[...,:2]/dc[...,3:]*np.array([0.5,-0.5])+0.5
        sx=np.clip(su[...,0]*W-0.5,0,W-1); sy=np.clip(su[...,1]*H-0.5,0,H-1)
        col=colD[np.round(sy).astype(int),np.round(sx).astype(int)]
        # ground truth for the other eye
        capO=hook_proj(game_proj(reverse),tanO,(0,0)); _,colO,hitO=render(To,capO.reshape(4,4),W,H)
        m=filled&hitO&(np.linalg.norm(colO,axis=-1)<900)
        # true reprojection error: the world point the reconstruction picked, projected into the other eye, vs the pixel
        VPtrue=View(To,np.zeros(3))@capO.reshape(4,4)
        hp=np.concatenate([col,np.ones((H,W,1))],-1)@VPtrue
        pp=(hp[...,:2]/hp[...,3:]*np.array([0.5,-0.5])+0.5)*np.array([W,H])
        pxerr=np.linalg.norm(pp-np.stack([xs+0.5,ys+0.5],-1),axis=-1)[m]
        if DEBUG and de==0:
            cols=filled.mean(axis=0); print('   coverage by column (every 32):',' '.join(f'{c:.2f}' for c in cols[::32]))
        skym=filled&~hitO
        res.append((de,filled.mean()*100,np.median(pxerr),np.percentile(pxerr,95),(pxerr<1.0).mean()*100))
    return res
for rev in (True,False):
    for cant in (0.0,0.17):
        for shared in (True,False):
            for jit in ((0,0),(0.004,-0.003)):
                for de,cov,med,p95,good in run(rev,cant,jit,shared):
                    print(f"revZ={rev!s:5} cant={cant:.2f} shared={shared!s:5} jit={jit!s:15} drawn={de}: covered {cov:5.1f}%  err px median {med:.3f} p95 {p95:.3f}  <1px {good:5.1f}%")
