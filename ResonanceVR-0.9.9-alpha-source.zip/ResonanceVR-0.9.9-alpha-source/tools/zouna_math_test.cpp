// Native unit test (no game, no Windows) of the camera maths for the Zouna engine:
//   g++ -std=c++17 -O1 -Isrc tools/zouna_math_test.cpp -o build/zouna_math_test && build/zouna_math_test
// 1. A camera built exactly as the engine builds it (look-at, exe+185A4B0) converts to a right-handed (right, up, back)
//    frame, and back without loss.
// 2. A head pose composed onto it turns / moves the view the right way (OpenXR: +X right, +Y up, -Z forward).
// 3. The view matrix (rigid inverse) and the projection the mod writes put the frustum edges exactly on NDC +-1,
//    the eye's off-centre frustum included, through the engine's own row-vector maths (v * View * Proj).
// 4. The right-handed copy for the reconstruction gives the same NDC for the same point.
#include <cstdio>
#include <cmath>
#include "vrmath.h"
#include "zouna_math.h"

static int g_fail = 0;
static void Check(bool c, const char* what) { printf("%s  %s\n", c ? "ok  " : "FAIL", what); if (!c) g_fail++; }
static bool Near(float a, float b, float e = 1e-4f) { return fabsf(a - b) <= e; }
static bool NearV(V3 a, V3 b, float e = 1e-4f) { return Near(a.x, b.x, e) && Near(a.y, b.y, e) && Near(a.z, b.z, e); }

// the engine's look-at (exe+185A4B0, roll 0): forward f, right = (-fz, 0, fx)/|.|, up = forward x right (as decoded)
static void EngineLookAt(V3 pos, V3 target, float* M) {
    V3 f = Norm(target - pos);
    float n = sqrtf(f.x * f.x + f.z * f.z);
    V3 r = { -f.z / n, 0.f, f.x / n };
    V3 u = { -f.y * r.z * 0.f + (-f.y * f.x / n) * 1.f, (f.x * f.x + f.z * f.z) / n, -f.y * f.z / n };   // [rbp+0x10..0x18]
    float m[16] = { r.x, r.y, r.z, 0, u.x, u.y, u.z, 0, f.x, f.y, f.z, 0, pos.x, pos.y, pos.z, 1 };
    memcpy(M, m, 64);
}
static void MulRow(const float* v4, const float* M, float* o) {   // o = v * M (row vector)
    for (int c = 0; c < 4; c++) o[c] = v4[0] * M[c] + v4[1] * M[4 + c] + v4[2] * M[8 + c] + v4[3] * M[12 + c];
}

int main() {
    float M[16], T[12], M2[16];
    V3 pos = { 3.f, 1.7f, -2.f }, tgt = { 5.f, 1.2f, 4.f };
    EngineLookAt(pos, tgt, M);
    zm::EngToT(M, T); zm::TToEng(T, M2);
    Check(!memcmp(M, M2, 64), "engine matrix -> mod frame -> engine matrix is exact");
    Frame f; for (int k = 0; k < 3; k++) f.axis[k] = { T[3 * k], T[3 * k + 1], T[3 * k + 2] }; f.pos = { T[9], T[10], T[11] };
    Check(FrameValid(f), "the frame is orthonormal");
    Check(NearV(Cross(f.axis[0], f.axis[1]), f.axis[2]), "right x up = back (right-handed, as OpenXR)");
    Check(NearV(f.axis[2] * -1.f, Norm(tgt - pos)), "back = -(the direction the camera looks)");
    Check(f.axis[1].y > 0.f, "up points up (+Y world)");
    // a level camera looking along +Z: right must be -X in this right-handed +Y-up world
    EngineLookAt({ 0, 0, 0 }, { 0, 0, 5 }, M); zm::EngToT(M, T);
    Check(Near(T[0], -1.f) && Near(T[1], 0.f) && Near(T[2], 0.f), "looking along +Z, right = -X (right-handed world)");
    for (int k = 0; k < 3; k++) f.axis[k] = { T[3 * k], T[3 * k + 1], T[3 * k + 2] }; f.pos = { 0, 0, 0 };
    // head turned 20 degrees to the LEFT (OpenXR: +rotation about +Y), moved 10 cm right
    float a = 20.f * 0.0174533f, R[3][3]; QuatToMat(0.f, sinf(a / 2), 0.f, cosf(a / 2), R);
    Frame e = Compose(f, R, V3{ 0.1f, 0.f, 0.f });
    V3 fwd0 = f.axis[2] * -1.f, fwd1 = e.axis[2] * -1.f;
    Check(Dot(fwd1, f.axis[0]) < -0.3f && Dot(fwd1, fwd0) > 0.9f, "head turned left: the view turns towards the camera's left");
    Check(NearV(e.pos, f.axis[0] * 0.1f), "head moved right: the eye moves along the camera's right");
    // view + projection: frustum edges on NDC +-1
    float W[16], V[16], P[16] = {};
    zm::TToEng(T, W);
    // eye camera somewhere else to make the test non-trivial
    EngineLookAt(pos, tgt, W); zm::RigidInverse(W, V);
    float I[16]; for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) { float s = 0; for (int k = 0; k < 4; k++) s += W[r * 4 + k] * V[k * 4 + c]; I[r * 4 + c] = s; }
    bool id = true; for (int i = 0; i < 16; i++) id = id && Near(I[i], (i % 5) == 0 ? 1.f : 0.f);
    Check(id, "camera->world x view = identity");
    float n = 0.1f, fa = 1000.f;
    P[10] = n / (n - fa); P[11] = 1.f; P[14] = n * fa / (fa - n);
    const float tan_[4] = { -1.1f, 0.85f, 0.9f, -1.2f };   // an off-centre eye (l, r, u, d)
    Check(zm::ProjXY(P, tan_, 0.f, 0.f), "projection x / y terms set");
    float Wf[16]; memcpy(Wf, W, 64);
    V3 R0 = { Wf[0], Wf[1], Wf[2] }, U0 = { Wf[4], Wf[5], Wf[6] }, F0 = { Wf[8], Wf[9], Wf[10] };
    auto ndc = [&](float tx, float ty, float dist, const float* Pm, float* out) {
        V3 p = pos + F0 * dist + R0 * (tx * dist) + U0 * (ty * dist);
        float v4[4] = { p.x, p.y, p.z, 1.f }, vv[4], cc[4];
        MulRow(v4, V, vv); MulRow(vv, Pm, cc);
        out[0] = cc[0] / cc[3]; out[1] = cc[1] / cc[3]; out[2] = cc[2] / cc[3];
    };
    float o[3];
    ndc(tan_[1], 0.f, 7.f, P, o); Check(Near(o[0], 1.f), "the right edge of the eye's frustum lands on NDC x = +1");
    ndc(tan_[0], 0.f, 7.f, P, o); Check(Near(o[0], -1.f), "the left edge lands on NDC x = -1");
    ndc(0.f, tan_[2], 7.f, P, o); Check(Near(o[1], 1.f), "the top edge lands on NDC y = +1");
    ndc(0.f, tan_[3], 7.f, P, o); Check(Near(o[1], -1.f), "the bottom edge lands on NDC y = -1");
    ndc(0.f, 0.f, n, P, o); Check(Near(o[2], 1.f, 1e-3f), "near plane at depth 1 (reversed Z)");
    ndc(0.f, 0.f, fa, P, o); Check(Near(o[2], 0.f, 1e-3f), "far plane at depth 0");
    // the right-handed copy for the reconstruction: view space (x, y, -z) gives the same NDC
    float Q[16]; zm::ProjToRH(P, Q);
    {
        V3 p = pos + F0 * 5.f + R0 * 0.7f + U0 * -0.4f;
        float v4[4] = { p.x, p.y, p.z, 1.f }, vv[4], c1[4], c2[4];
        MulRow(v4, V, vv); MulRow(vv, P, c1);
        float vr[4] = { vv[0], vv[1], -vv[2], 1.f }; MulRow(vr, Q, c2);
        Check(Near(c1[0] / c1[3], c2[0] / c2[3]) && Near(c1[1] / c1[3], c2[1] / c2[3]) && Near(c1[2] / c1[3], c2[2] / c2[3]) && Near(Q[11], -1.f),
              "right-handed projection copy: same NDC, [11] = -1");
    }
    // jitter is kept as an NDC offset
    float Pj[16]; memcpy(Pj, P, 64); zm::ProjXY(Pj, tan_, 0.001f, -0.002f);
    ndc(tan_[1], 0.f, 7.f, Pj, o); Check(Near(o[0], 1.001f), "TAA jitter stays an NDC offset");
    // the GUI placement: centre -> (cx, cy), the frame scaled by s about it
    {
        float W = 2400, H = 2600, cx = 1300, cy = 1250, sc = 0.6f, tx, ty; zm::NvgPlace(W, H, cx, cy, sc, tx, ty);
        auto X = [&](float x) { return sc * x + tx; }; auto Y = [&](float y) { return sc * y + ty; };
        Check(Near(X(W / 2), cx, 1e-2f) && Near(Y(H / 2), cy, 1e-2f), "GUI placement: the frame's centre lands on the eye's UI centre");
        Check(Near(X(W) - X(0), W * sc, 1e-2f) && Near(Y(H) - Y(0), H * sc, 1e-2f), "GUI placement: the frame is scaled by ui_scale");
    }
    printf("%s (%d failed)\n", g_fail ? "FAILED" : "ALL OK", g_fail);
    return g_fail ? 1 : 0;
}
