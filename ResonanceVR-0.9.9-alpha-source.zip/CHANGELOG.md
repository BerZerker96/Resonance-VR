# Resonance VR - changelog

## 0.9.9-alpha

Audit of every reported issue, one by one:

- HUD fusing (alternate eye / synchronized): the second HUD placement path (`UiCentreForEye`, used for canvases that are not the game's
  own symmetric layout) still moved each eye's HUD by half the IPD at `ui_depth`, even with `ui_converge` off. With a symmetric view it
  now keeps the HUD at infinity like the main path, so both paths agree and the two eyes get identical HUD pixels. Turning
  `symmetric_view` on or off rebuilds the eye frusta at once (checked: `SettingsApplyCamera` calls `CameraUpdateFrustum`).
- Edge fill with HDR: the border returned the raw HDR10 / scRGB values without the conversion the picture gets, so it was the wrong
  colour and brightness next to the picture. It now goes through the same conversion.
- Edge fill in head mode: the head picture was sent whole for both eyes with no border. With edge fill on, each eye is now cut from the
  wide head picture to its own view plus the border, so head mode has the soft edge stretch too. With edge fill off head mode is unchanged.
- Hitch when looking around (foveated rendering, also on in stereo reconstruction by default): the eyes' axes in the rate-image key were
  taken from the eye poses in the room, so every head turn changed the key and rebuilt all the rate images (the 0.9.7 log: a rebuild every
  33 ms while turning). The axis is now the eye's rotation relative to the head - fixed for a headset, so the images are built once.
- Hitch on the first panel open of a session (the 0.9.7 log: 463 ms, "VR panel + input"): the panel's shaders and font atlas were built
  on the first open frame. They are now built at start-up.
- Checked and unchanged: reconstruction view growth and pixel density, VRS key tolerance, async config save and logger, pair rate and
  pace lock, signatures (all 18 found), and the edge-fill border in alternate eye, synchronized and both reconstruction paths.

## 0.9.8-alpha

HUD in alternate eye / synchronized:

- The game draws its GUI in screen space: the same pixels in every eye's picture, whatever the eye's projection (0.9.7's assumption that
  it followed the projection was wrong - the 0.9.7 log shows the HUD centred and still split). A HUD that both eyes fuse therefore needs both
  pictures centred on their own line of sight. `symmetric_view` is now on (config_version 16 moves `false` to `true` once) for alternate
  eye, synchronized and head: each eye is drawn with a view symmetric about its own line of sight (as wide as the eyes need, about 1.27 x an
  eye on the Pimax Dream Air, at the headset's pixel density) and the eye is cut out of it. The HUD then stays where the game lays it out,
  scaled about the centre, and sits at infinity in both eyes - identical in every frame, so no frame order can split it.
- `ui_converge` (HUD tab, off): shifts each eye's HUD a little so it sits at `ui_depth` instead of infinity - that needs every layout to
  know its eye; if it shows double, turn it off again. With symmetric view off the HUD is moved per eye as before 0.9.7.
- Stereo reconstruction never uses symmetric view (its eye-size centre view stays narrower - the Performance path).

Edge fill - no black around the picture in any 3D method:

- `edge_fill_margin` (View > Edge fill, 0.06): every eye image is sent to the headset 6 % wider on every side than the headset's view, and
  the eye images are as much larger (the picture keeps its pixel density). The runtime turns the last picture with your head when a new
  one is late (alternate eye shows each eye every second refresh) - it now turns in stretched picture, not black.
- The edge fill itself is a soft stretch: each side's edge row / column and each corner's corner pixel spread outward, blurred more the
  further out, never darkened. `edge_fill` moved to View > Edge fill.

## 0.9.7-alpha

Alternate eye / synchronized HUD (superseded by 0.9.8 - this assumption was wrong): the game draws its GUI through each eye's own projection. The off-centre terms the mod
gives every eye (the headset's eyes look past the middle of their pictures) already move the GUI's centre onto that eye's line of sight.
Since 0.6.20 the mod moved it there a second time in the GUI layout, so each eye's HUD ended up about the same distance again to its side -
two HUDs that never fused, whichever frame's eye was used (which is why 0.9.4 - 0.9.6 changed nothing). The layout now only scales the HUD
about the picture's centre and adds the small sideways shift that sets its depth (half the eye distance at ui_depth); with "symmetric view"
on (a symmetric frustum, no off-centre terms) that shift is the whole placement, as before. `ui_eye_next` goes back off (config_version 15
moves `true` to `false` once): it only sets which frame's eye gets that small depth shift now.

## 0.9.6-alpha

From the 0.9.5 log:

- Alternate eye / synchronized HUD: the log showed the HUD laid out about equally for both eyes, yet it never fused - and both the camera
  set last (0.9.3) and the frame being recorded (0.9.4 / 0.9.5), which agree 89 % of the time, gave two HUDs. The game shows a HUD layout
  with the frame after the one it is laid out on. New `ui_eye_next` (HUD tab, default on): each layout is placed for the NEXT frame's eye.
  If your HUD still shows as two images, press F10 once while playing (it switches the option live) and tell me which one fuses.
- Alternate eye / synchronized frame rate: the frame limiter waited 8 - 11 ms of every frame at the headset's 72 Hz - each eye was new only
  every second refresh although the GPU had room. `pair_rate` is now on (config_version 14 moves `pair_rate = false` to `true` once): both
  eyes every refresh when the GPU keeps up, back to the refresh rate by itself when it cannot (logged as "pair rate: ...").
- Reconstruction: the foveation's shading-rate images were still rebuilt every second (a value on a rounding step flipped); the key is now
  compared with a tolerance, and the first rebuilds log which value changed.
- Edge fill: `recon_edge_fill` (View > Reconstruction, on) - the reconstruction's rim repeat (framework 49.10) is a visible option now. The
  eye methods' edge fill (where an eye image reaches past the drawn picture) is the same rim repeat now, never darkened (the old radial blur
  with a fade to black was the framework's measured dead end).

## 0.9.5-alpha

- Alternate eye / synchronized HUD: the 0.9.4 fix (the HUD laid out for the eye of the frame the renderer is recording) only ran once the
  main-thread prediction was calibrated - before that, and whenever its clock hook was missing, the HUD still took the eye of the camera set
  last. The renderer's own layouts now always take the recorded frame's eye. New log line every 10 s: "ui: HUD layouts placed for the left
  eye N, the right eye M, the head-centre view K" - in alternate eye and synchronized N and M must be about equal; the "HUD eye" counts are
  now per report period (they only ever grew).
- The pointer-safety check (the GUI hook checks thousands of widgets a second on the render thread) keeps a per-thread hash of 1024 readable
  pages instead of 64 ranges scanned in turn; the 0.9.3 log had 41 655 misses in 10 s in reconstruction (27 ms of probes, all on game threads).

## 0.9.4-alpha

From the 0.9.3 log (Pimax Dream Air, RTX 4080):

Stereo reconstruction softer than the eye modes - fixed:

- The centre view was drawn into the headset's own 3420 x 2668 pixels although it is 2.899 tangents wide (an eye is 2.523): 1180 px per unit
  instead of 1355, so every rebuilt eye was magnified 1.15 x sideways and the pixels were not square. The render size only grew with
  "symmetric view" on, which is off by default. Now the reconstruction's centre view always gets the headset's density (framework 49.3:
  render width = density x 2 hx) - 3930 x 2722 at the default reach 0.5, the same detail per degree as alternate eye. Switching between
  reconstruction and the eye methods resizes the render once. For the fastest full-detail view set View > "Drawn view reach" to 0: the
  headset's own pixel count, the outer 13.7 % of each eye repeats the rim.

Performance and hitches:

- The foveation's shading-rate images were rebuilt every second in reconstruction (134 times in two minutes in the log): their key held the
  eyes' axes from the live eye poses, whose last digits change every frame. The key is rounded now - a rebuild only on a real change.
- Settings are written to disk on a worker thread. Closing the VR panel after a change wrote the config on the render thread; a virus scanner
  checking the file on close made that a 200 - 500 ms frame (the log's "mod work at Present ... 514 max").
- The blend pass skips every group without a gap tile in reach before it reads anything (it was 0.4 - 0.7 ms per eye); the resolve writes
  the fill history only near gaps (49.9).
- A new log line names the cause of the slowest Present of every 10 s ("perf: slowest Present ... ms - ...").

Alternate eye / synchronized - the HUD now fuses:

- The game lays out its HUD on the render thread, and the mod placed it for the eye of the camera set LAST. The renderer sets the next frame's
  camera before it lays out this frame's HUD, so the HUD was often placed for the other eye - the two eyes' HUDs apart, never converging. The
  layout now takes the eye of the frame being recorded (the same frame queue the D3D12 placement uses). The log's "HUD eye" line counts the
  layouts this corrected (as "1 frame ahead").

Also: the tab-table check no longer warns about hotkeys (they have their own page).

## 0.9.3-alpha

A full pass over every chapter of the framework documents (Framework Boost 1 - 50 and its port checklist, Stereo Reconstruction 0 / 32 /
46, the guide's performance tables), not only the stereo-reconstruction chapters, in the order of 49.14. Everything that was missing:

Resolution and the window (Framework Boost 1, rule 0.6.63):

- Live VR resolution on the first tab, right under the 3D modes: a slider, "Apply VR resolution" (shows the current per-eye size, and the new
  one while the slider differs - with the same caps as the real size) and "Headset default resolution". Applied in game with no restart and
  saved at once; the eye images, atlas, the host's swap chains and the reconstruction's textures follow by their size checks. The render
  scale hotkeys apply at once too. Range 0.30 - 2.00.
- IDXGISwapChain::ResizeTarget is hooked: a monitor-sized mode request is replaced by the VR size (logged).
- ResizeBuffers1 now releases the shading-rate images and the UI layer as ResizeBuffers does.
- The eye image is capped at 8192 on both sides (only the width was capped), with a warning naming the limit.
- The runtime's recommended size is rechecked every 10 s by the host; a change (SteamVR's resolution slider, Pimax / Virtual Desktop quality)
  is followed in game: "resolution: the runtime now recommends ...".
- RESOLUTION CHECK every 10 s: headset, runtime largest, render scale, eye images, swap chain against the target, window area against what the
  game is told, monitor, DPI and DPI awareness - then OK or what is wrong.

Shared atlas (Framework Boost 2): the layout follows the eye size - a row of three, a column of three, else 2 x 2 (25 % less memory at a
typical eye size than the old fixed 2 x 2). The log line states layout and memory; a failed creation says "out of video memory or above the
texture limit".

Host (Framework Boost 3):

- XR_FB_display_refresh_rate is enabled when offered: the headset's rate and the rates it offers are logged, a rate change is logged and
  followed, and the frame limiter takes the display's own rate (never divided by motion smoothing) when the runtime reports it.
- Runtime quirks guarded: a placeholder or not-yet-real display time (Virtual Desktop) skips that frame's poses; a display period of a second
  or more (SteamVR) counts as unknown. Each warned up to 3 times.
- Quad-layer panels on Virtual Desktop are warned about.
- Fixed: a comment had swallowed the HUD quad's shape guard (`if (!(shp > 0.3f && shp < 3.f)) shp = 1.f;` was part of the comment) - the very
  class of bug the framework's 0.6.96 chapter describes. The whole source was scanned for more; none found.

Logging (Framework Boost 4, 7): SMOKE TEST once (PASS, or CHECK naming the failed part); config validation (settings this version does not
know - typos or old keys - up to 12 names); `safe_mode` (every optional game hook off); a COMPAT line after start-up (game signatures found,
features off).

Stereo reconstruction:

- Depth copied once a frame at Present (0.6.92, 49.2): at each depth barrier only depth -> buffer; the buffer -> shared texture copy runs once
  on the mod's own list at Present. Self-check: more than 20 frames without depth in a report period -> both copies at every barrier again (logged).
- Depth direction from decisive evidence only (0.6.64): the forward pass also counts depth samples at exactly 0 and exactly 1 (cleared / sky
  pixels hold only the far value); the "upper half" count is used only before anything is decided and only with a 75 % majority. Close to a
  wall the old count said the opposite of the truth and could turn the depth round (everything inside-out).
- Steady edges with an upscaled depth (0.6.64): when the depth is smaller than the picture (an upscaler or the game's render scale), at a depth
  step last frame's pixel is blended in (0.7), only at one of the distances around and clipped to the colours the picture has there. Logged.
- `recon_hud_split` off by default (0.6.93: the HUD left in the picture - the performance path). Configs with the 0.9.0 - 0.9.2 default
  (`true`) move to `false` once (config_version 13). Turn it on in View > Reconstruction to have the HUD on its own layer again.
- `recon_resolve_split` (config only, off): the two-dispatch resolve - groups without a gap tile, then groups with one - only to compare its
  GPU time in the log, as the framework keeps it.

Synchronized / alternate eye (0.6.64): `pace_lock` (on): the host publishes when its xrWaitFrame returned, and the limiter nudges each release
(10 % of the error a frame, at most 0.3 ms) so the frame is handed over a margin (2 ms or 15 % of a refresh) before the headset's next frame. A
pair then shows for exactly two refreshes. Every 10 s: "pacing: lock error x ms (spread y), hand-overs within 0.5 ms of the headset's frame n of m".

Version agnostic: every game function is still found by a byte pattern, every offset read from the code it patches, and a missed pattern only
turns its own feature off. New: a code section is scanned only in its committed, readable runs (a re-protected exe no longer risks a crash at
start), a pattern not found in the main code section is looked for in every executable section, and the COMPAT line names what a patch moved.

A correction to 0.9.2's notes: the pause menus keep the stereo method (they are a flat screen inside it), so they never resized the render;
the 0.9.2 change matters only for the explicit switch to the screen method.

Not verified here: the compute shaders (no HLSL compiler in this environment; a failure falls back to the older infill and is logged as
"recon: shader <name>:"), the headset itself, and the game patch behaviour on a real patched exe.

## 0.9.2-alpha

Hitches and lag, and the last item of the 0.6.97 reference that was still missing.

Hitches:

- The log no longer blocks the game. Every log line used to be flushed to the file on the thread that wrote it, and the once-a-second disk
  commit (FlushFileBuffers) held the same lock - on a slow disk or with a virus scanner the render / Present thread waited inside a log call,
  most of all on the 10 s report. Lines now go into a buffer under a short lock and a writer thread writes them; errors are written at once,
  and the crash / device-lost / mark paths still drain everything to disk before they return.
- No render resize when a pause menu or a loading screen is shown with the eye-size view: 0.9.0 / 0.9.1 took the render size from the current
  mode, so every flat pause menu and its return recreated every render target of the game (and the headset-size view had the same fault since
  0.8.1). The size now follows the selected method; the picture's shape follows it too.
- The eye-size view's frustum is rebuilt at every mode change. Before, a session that started on a flat screen could draw reconstruction with
  the full width for a while.
- A new render size is applied once it has held for one second (framework rule 0.6.63: apply once, never on every slider step). Dragging
  "drawn view reach" or the cull margin recreated every render target every 1.5 s while the slider moved.
- Switching `fov_effects` rebuilds the shading-rate images (it was not part of their key).

Stereo reconstruction:

- 10-bit eye image (49.5): the rebuilt eye and the blend input are R10G10B10A2_UNORM when the picture is 8 / 10-bit and the GPU can store
  that format from compute - half the memory traffic of RGBA16F. HDR (float) pictures keep RGBA16F; the log says which is used.

## 0.9.1-alpha

A second audit of 0.9.0 against the framework's 0.6.97 documents (Framework Boost chapters 41 - 50, Stereo Reconstruction chapter 0 and
its sections 32 and 46). What 0.9.0 still lacked:

- Panel order as the 0.6.90 / 0.6.97 table gives it. First tab, View > Reconstruction (the fast path, each costs nothing or very little):
  drawn view size, drawn view reach (shown only with the eye-size view), depth strength, close-object limit, infill blend, infill detail,
  sharpening, HUD placement. Advanced > "Stereo reconstruction (costs more)": infill quality (preset), infill method, shading around both eyes.
  Advanced > "Stereo reconstruction": steady infill, edge guard, gap reach, depth direction, fast forward pass, edge pixels, eye align, show
  hidden areas. The preset's description now states what each step up costs. `recon_infill_preset` (the framework's key) is read as
  `recon_preset` when only it is in the config.
- Sharpening fused into the headset blit (0.6.85): the rebuilt eyes are sharpened in the blit that writes the headset's eye image (luma cross,
  step capped at 0.035 + 0.08 x max(0, amount - 0.3), clamped to the four neighbours), not in the blend pass; the headset-size view still uses at
  least 0.35. The classic infill gets the same sharpening.
- Band-only writes (49.9, 0.6.85): the resolve writes every pixel into the eye image and the blend input only in groups with a gap tile within
  the band reach + 17 cells; the blend pass writes nothing away from the band.
- Each rebuilt eye has its own pair of fill-history images, swapped per eye (0.6.96: never a partly written image shared between eyes).
- Every constant struct is zeroed before it is filled, including the two of the older infill (0.6.96 rule).
- Forward pass (49.6): the group's 1 / distance values and a 2-texel border are read into shared memory once; the edge and hole tests take
  their eight neighbours from there instead of eight more depth reads per pixel. Results are identical.
- Tiles (49.8): in the Performance preset 32 gap and 32 border samples per tile (35 offsets x 32 cells), and the cost includes 0.01 x the mean
  colour-outlier score of the copied sources (plausibility).
- History clip range: the tile copy's colours here plus the membrane's background target (49.8 "lo / hi ... (+ tgt)").
- Log wording as 49.13: "gaps filled from the picture N % ... (of the filled pixels M % kept from last frame)".

Still not ported, and why (0.9.1): `recon_resolve_split` (the framework keeps it only to compare against the slower two-dispatch resolve). `recon_hud_split` stays on by default
in this mod: the exact picture without UI is copied at the first UI draw, so the split is a per-pixel compare, not the framework's 1.5 - 2 ms
UI-layer pass.

Not verified: the compute shaders still could not be compiled where they were written. A shader that fails falls back to the older infill;
the compiler's message is in resonancevr.log ("recon: shader <name>:").

## 0.9.0-alpha

The framework's 0.6.97 stereo-reconstruction performance path (the Performance preset made the default, a smaller drawn view, a better
infill), the panel changes that go with it, and one fix of 0.8.1.

Fix:

- The constant buffer of the new infill's shaders was created 672 bytes long while the structure the CPU uploads is 752 bytes (0.8.1 added the
  second eye's matrix and footprint). The last 80 bytes - the second rebuilt eye's matrix and footprint of the shared forward pass - never
  reached the shader. The buffer is now exactly the structure's size (784 bytes with this version's two new vectors).

Stereo reconstruction:

- Eye-size drawn view (`recon_view = eye`, new default; `recon_eye_cover`, default 0.5): the game draws one view about as wide as a single
  eye plus half of the way to the wide view's width, instead of the wide view (about 1.3 x an eye). hx = hxEye + cover x (hxFull - hxEye);
  the height does not change. The render size follows from the view, so the headset's pixel density is kept and the frame has fewer pixels.
  The log says how wide the drawn view is and how much of each eye repeats the rim. `wide` and `headset` stay as choices.
- Edge fill (49.10): a rebuilt eye's pixel whose ray at infinity leaves the drawn view is not a gap. The band just inside the view's side is
  repeated outward in the same direction (no mirror) with a period of the strip's own width, softened with the distance past the side (seven
  taps, radius 0.1 x the distance), its low frequency (five taps, 16 px apart) shifted to the rim's and fading out quadratically over the
  copy, and cross-faded from the rim over the first 12 px. Above and below the view the rim row repeats.
- Performance preset (default now): 35 matched-tile offsets (five horizontal distances 0, 8, 22, 46, 90 x seven vertical -24 .. 24) instead
  of 63, and the offset a tile used last frame is a candidate again - it is kept unless a new one costs less than 1 / 1.3 of it, and its colour
  correction follows 20 % a frame. Each rebuilt eye keeps its own tile offsets. The remembered real pixels and PatchMatch now only run in
  Balanced and Quality.
- Tile copy: a copy's source must be at least zthr deep (the geometric mean of the background's and the object's distance when the object is
  much nearer, else 0.85 of the nearer; 0.85 of the background when there is no object); the gap pixel's own copy is read with the sharp
  five-tap Catmull-Rom resampler.
- Membrane (0.6.94) replaces the gradient seam: the copy meets the real background at the row border (median of the cells 2, 3, 4 past the
  edge, weight 1 / background distance) and at the upper and lower borders (steps 1, 2, 3, 4, 6, 8, 12, 16, 24, 32 until a seen cell; the
  object and a cell before it that is not a gap are skipped; weight 1 / step). A border counts only with a valid copy and a summed difference
  under 0.3; fill = copy + (sum w d / sum w) x min(1, 3 x sum w).
- Steady infill (history) fixed and sharpened: the distance test compared the stored distance with the pixel's own distance, which is wrong
  after the view has moved - it now compares with pc.w x dist (the point's distance along last frame's axis); the history is resampled
  sharply; it is clipped to the copy's colour range widened by 0.12; the strength is 0.9 x saturate((distance from the edge + 1) / 3).
  The log reports how much of the fill kept last frame's fill.
- Blend band (finish pass): R = round(6 x max(1, blend)) cells into the background, 3 into the fill, s = min(0.3 x blend, 0.9); in the fill
  w = s x (1 - detail) x (1 - (i - 1) / 3), in the background w = s x (1 - (i - 0.5) / (R + 0.5)); eight row taps with weight (1 - 0.2 k) x
  colour likeness, a nearer tap counts zero. Defaults: infill blend 2 (was 1), infill detail 0.5.
- `recon_hud_split` (default on, as before): off makes the HUD part of the picture, moved by the depth under it - cheaper, and the HUD can tear
  at close objects. The framework's reference ships it off; this mod keeps it on because the exact picture without UI is available here.
- Log: "recon: GPU per frame, both eyes (ms)" with every pass and the total, "of the filled pixels N % kept last frame's fill", and the
  eye-size view line.

Foveated rendering:

- `fov_effects` (default `outer`): with foveated rendering on, full-screen passes without a depth target (bloom, blur, post effects) get a
  second shading-rate image that lowers the rate at the lens edge only (full rate to the outer ring or 0.9 half-heights, 2 x 1 and 2 x 2
  beyond). Geometry passes keep their own image. `off` leaves those passes alone.

Panel:

- Look: the plate is 0.57 x the panel opacity (was 0.86), the glow fainter, 28 embers (was 70), every row on a faint plate with two
  strengths alternating, 1.4 x the font of room above each section header (was 1.05).
- The fast options are on the first tab (preset, sharpening, infill detail, infill blend, show hidden areas, shading around both eyes); the
  ones that cost more or are set once moved to Advanced, group "Stereo reconstruction (costs more)": drawn view size and reach, infill, edge
  guard, gap reach, fast forward pass, depth direction, steady infill, edge pixels, close-object limit, parallax, eye align, HUD placement.
- The log checks that every option has an entry in the tab table.

Config (config_version 12): a player's own values are never touched. Only the three values that were the previous defaults move once -
`recon_view = wide` to `eye`, `recon_preset = balanced` to `performance`, `recon_infill_blend = 1.0` to `2.0`. A file that has any other value keeps it.

Not verified: the new compute shaders could not be compiled on the machine they were written on (no HLSL compiler there). If any of them
fails on yours, the older pipeline keeps running and the compiler's message is in resonancevr.log ("recon: shader <name>:").

Not ported, deliberately: the 10-bit eye image, the depth copy at present and the gap-block pass of the framework's reference. They only pay
when a log shows them faster on that game, and this mod cannot measure that here; the resolve split likewise (the one resolve stays).

## 0.8.1-alpha

The rest of the framework's stereo-reconstruction reference (0.6.65 - 0.6.84), ported on top of 0.8.0:

- Shared forward pass (0.6.83): in the centre view the first rebuilt eye of a frame splats every drawn pixel into BOTH eyes' key maps
  (one depth read, one edge / hole test and one close-object limit per drawn pixel); the second eye takes the finished map and runs no
  forward pass. The log's per-pass line shows the saving in "forward". If the new pipeline is unavailable, each eye runs its own pass as before.
- Boundary cleaning (0.6.65): with the Performance preset (matched tiles) the one background pixel beside a gap takes the colour of the cell
  two further out on the same surface - no outline of the object's colour beside the fill. (PatchMatch presets fill that ring as part of the
  gap, as before.)
- Gradient seam of the tile fill (0.6.84, Performance): the colour two, three and four cells past the background's edge (median) against the
  fill at the gap cell next to the edge; the difference fades over the gap (no blur, never row by row).
- Remembered real pixels are clipped into the colour range of the background strip beside the gap, in YCoCg (3 sigma, at least 0.06), so
  an old pixel that no longer matches the surroundings cannot show.
- Headset-size drawn view (0.6.84, `recon_view = headset`): the game draws the headset's pixel count instead of the wide view's (about 25 %
  fewer pixels); each eye shows about 77 % of its pixels across, magnified by the five-tap Catmull-Rom read and sharpened at no less than 0.35
  (clamped to the neighbourhood, no halos); the UI keeps its angular size. Changing it resizes the game's render targets once. Default: wide.
- Shading rate around both eyes (0.6.82, `fov_recon_auto`, default on): with the Performance preset and foveated rendering off, the centre view
  is shaded at full rate inside 0.65 half-heights of the nearer of the two eyes' lens axes, 2 x 1 to 1.05 and 2 x 2 beyond (horizontal x 1.25).
  Needs variable-rate shading tier 2. A foveated mode you set yourself is never changed, but its centre-view image now also follows both axes.

Not ported, deliberately: the "unui" pass and the layer-only HUD read / sparse HUD split (0.6.71, 0.6.83, 0.6.84). They exist for games whose
picture without UI can only be rebuilt from the final picture and a copy of the UI layer. This mod keeps the exact picture without UI, taken
at the first UI draw into the final image, so the HUD already comes from a clean difference and a rebuild would only add a pass.

## 0.8.0-alpha

Stereo reconstruction: the infill pipeline of the framework's 0.6.84 stereo-reconstruction reference, with all of its options.

- New infill ("recon_fill = history", the default, and "patch"): the gaps beside close objects are no longer stretched background.
  They are filled with real background pixels. The pipeline per rebuilt eye is: forward projection (edge pixels follow their own
  colour, holes inside a surface move with it, a close-object limit keeps very near things from being pushed too far apart),
  matched 32 x 32 tiles (the offset whose copy best predicts the real background around the gaps), PatchMatch on a half-size map
  (propagation, random search, a proximity prior so the nearer of two similar patches wins, colours re-estimated each pass), a
  four-level membrane that removes the colour seam, a vote of the matches around each pixel, a ring so the one background pixel
  beside a gap is filled too (no outline), steady infill (the previous fill of the same eye, reprojected and clipped to the colours
  the fill has now, so it does not shimmer), and a finish pass (blend band beside the fill, optional sharpening).
- "recon_fill = history" adds real remembered pixels: once per drawn frame the background that an object hid is remembered from
  earlier frames and re-projected into each eye, so a gap can show what is really behind the object.
- Presets (`recon_preset`, also on the VR panel): performance (matched tiles only, 1 M remembered points), balanced (PatchMatch,
  one pass, 3 x 3 vote, 21 tile offsets, 2 M points; the default) and quality (PatchMatch, three passes, 5 x 5 vote, 63 tile
  offsets, 4 M points). Passes a preset does not need do not run.
- New options: `recon_fill_steady`, `recon_edge_pixels`, `recon_near_limit` (metres), `recon_sharpen`, `recon_infill_blend`,
  `recon_infill_detail`, `recon_edge_guard`, `recon_debug` (1 tints filled gaps orange, remembered pixels blue, unfilled red).
  Everything is on the VR panel's Stereo tab.
- The new shaders are a second HLSL source compiled in the background and cached. If they fail to compile on a machine, the previous
  two-pass infill keeps running and the log carries the compiler's message ("recon: shader <name>: ..."). If the new textures cannot
  be allocated, the previous infill runs for that frame.
- The log now has "recon: GPU per rebuilt eye (ms): memory, forward, tiles, PatchMatch, membrane, resolve, finish (total)" so the preset
  can be chosen by measurement on your GPU.

Not ported from the reference: the HUD-from-UI-layer split pass, the shared forward pass for both eyes, variable-rate-shading
foveation, a headset-size view option, YCoCg clipping of the remembered colours, the tile-gradient seam fix in Performance mode, and
the boundary cleaning pass. The adaptive atlas layout and the resolution slider panel rule are also still not part of this mod.

## 0.7.3-alpha

HUD and UI eye fix, plus the OpenXR host hardening from the framework 0.6.84 guide:

- Alternate-eye and synchronized modes: the HUD / UI is laid out on the game's update thread, which runs one or more frames ahead of
  the render thread, so the layout used the wrong eye and each eye drew the HUD in a different place (no fusion, no convergence).
  The layout now predicts which eye the frame will be shown to (`CameraLayoutEye`: the render eye, flipped for every frame the update
  thread is ahead). Reconstruction keeps its previous behaviour. The log shows "ui: HUD eye - layouts by the renderer ... frames ahead
  of the renderer" so a remaining mismatch can be diagnosed.
- Reconstruction shaders compile in a background thread with a disk cache, so switching to reconstruction no longer stalls the game.
- Host: every failing OpenXR call is logged with its result name instead of a number.
- Host: REFUSED FRAME is logged (first three) when the runtime refuses xrEndFrame, with a 10-second REFUSED FRAMES summary.
- Host: a lost session or instance (runtime restart, cable pulled) no longer ends VR for the rest of the run. The host tears OpenXR down,
  retries after 1 s and then every 3 s, reopens the game's shared atlases and resumes ("Reconnecting to the OpenXR runtime", "Reconnected - VR resumes").
- Host: logs the extensions the runtime offers, an error when the D3D11 extension is missing, the maximum layer count and the
  orientation / position tracking flags, with a warning for 3DoF headsets.

Not ported from the guide: the PatchMatch / HUD-split reconstruction pipeline (the mod keeps its two-pass reconstruction), the adaptive
atlas layout, and the resolution slider panel rule.

## 0.7.2-alpha

Performance pass over the per-frame and per-draw paths:

- The draw-statistics counters (new in 0.7.1) and the render-target descriptor copy counter are only touched in the frames the
  mod samples (1 in 8): the game's render threads no longer share a hot cache line on every draw / descriptor copy.
- With the panel closed, the pad / key query runs every second frame instead of every frame (a press lasts many frames; the
  panel still opens at once). Hotkeys keep their own 5 ms thread.
- Checked and left as they are: the command list hooks (a thread-local list lookup and a few branches per call), the pipeline
  flag table (one hash probe per SetPipelineState), descriptor copy following (returns at once for every heap but RTV / DSV),
  the camera path (0.002 ms per Present), memory checks (0.40 ms in 10 s over all threads, 109 671 served from the cache).

## 0.7.1-alpha

Second audit pass (exe, UI, store / version independence):

- **Draw diagnostics:** the 0.7.0 log showed no draw on any render target (3D 0, UI 0, "no such candidate" for every picker
  step) although 1 783 target binds were seen. The engine has a mesh-shader path (`bUseMeshShaders`, GPU scene), and mesh
  draws reach none of the draw hooks. The mod now also hooks `DispatchMesh` (command list 6, only where the runtime has it)
  and the log gets one line with every direct / indexed / indirect / mesh draw the hooks saw. If the next log shows 0
  everywhere, the draw hooks are bypassed entirely and the UI stays with the engine layout (which does not need them).
- **Audit result:** no absolute address or game-version / store check in the code; every game address comes from a code
  signature or the unwind table, every struct offset is read from the code it belongs to, and a symbol that is not found
  or ambiguous switches only its own feature off (logged). Store detection is a log line only. The mod loads into any
  process named `resonance*.exe`.

## 0.7.0-alpha

From the fifth in-game report (cloth physics in synchronized stereo, UI not scaling, UI not converging in depth, performance):

- **Cloth and hair physics in synchronized stereo:** the held tick of a pair advanced the game clock by 1/32 of a step,
  and the next one by about two steps. The cloth solver (NvCloth) saw a step of 0.5 ms followed by one of 33 ms and
  jittered. The held tick now keeps a larger part of its step (new setting `sync_hold`, default 0.35, range 0.03 - 1;
  Stereo tab, "Synchronized: step kept"). The game time over a pair is unchanged. Lower = the eyes match more exactly on
  moving things, higher = smoother physics; 1 behaves like alternate eye.
- **UI placement defaults to the D3D12 draws** (`ui_placement = draws`). If that path finds no UI draws (this game
  draws its GUI into the scene target), the engine layout path takes over by itself after a second, so the UI is
  never left unplaced. The panel offers "D3D12 draws (+ engine layout)" and "Engine layout only".
- **UI scale and depth convergence:** the engine layout hook now keeps each widget's own quad (before and after
  scaling), detects whether a quad is in canvas-height units or pixels, scales around the UI centre of the current
  eye, and restores a quad the game hands back from its cache instead of scaling it again. The eyes place the UI centre
  with the real eye distance and the draw frustum, so both eyes meet at `ui_depth`: no more misalignment between the
  eyes. The log shows the first quads and counts (scaled / restored / pixels / other canvases).
- **Performance:** the gamepad slot scan (a device query of several ms on empty slots) no longer runs on the frame
  thread; it runs on a thread of its own and the frame thread only adopts the slot it found.

## 0.6.0-alpha

From the fourth in-game report (HUD and UI invisible, reconstruction without depth, wide culling not working, head
aim not working, depth of field in cutscenes):

- **HUD and UI visible again:** 0.5 also scaled quads the game writes into its own memory. A widget's layout cache
  (+0x40) is passed as the output by some callers, so the next frame scaled the already scaled quad again: x0.49
  every frame, and the HUD shrank to nothing within a fraction of a second. Only a quad the caller asked for in a
  temporary buffer on its own stack is moved now. Quads that aren't in canvas pixels are left alone, and the log
  shows a few sample quads.
- **Stereo reconstruction gets its depth:** the 0.5 log showed 9753 depth binds a frame and no candidate, because a
  candidate was only counted on a draw made with a depth buffer bound, and the game's draws never matched that test.
  Each bind of a known depth buffer now counts, with the shape filter (only buffers the size of the picture).
- **Wide culling works, without a bigger picture:** the game builds each camera's culling frustum itself
  (exe+18F9B40, called from inside the FOV tangent update), from the viewport's tangents, before that update returns.
  Up to 0.5 the mod widened the tangents only after it returned, so the culling kept the game's own narrow view and
  things popped in at the sides. The mod now hooks the frustum builder and gives it the frustum that covers every
  eye. Only the culling is wider; the render size stays the same.
- **Head aim, third attempt:** Camera_Z only follows a camera node. Its update (exe+18F0A00) takes its position
  from the node's world matrix and its orientation from the node's quaternion (node+0x50). The game's aiming asks
  that node, which is why turning Camera_Z's matrix (0.4) and its look-at target (0.5) changed nothing. Head aim
  now turns the node's quaternion and world rotation too, after checking that the node's forward really is the
  camera's. The game's own values come back before the next camera update. A guard switches node turning off if
  the game camera starts following the turned node (the view would drift with your head). The log reports how
  often the node was turned, rewritten by the game, or rejected.
- **Depth of field off in cutscenes:** the DOF passes (exe+1CA7570) run only while their blur amount (params+0xC) is
  above 0. The mod sets it to 0 for that call, so the game takes its own no-DOF path. A cutscene is a game camera
  that doesn't look at the player close by (the first-person test, held 0.5 s). `depth_of_field = cutscenes | off |
  game`.
- `tools/verify_signatures.py` also checks the depth of field passes, the culling frustum builder and the camera
  node read.
- **Signatures re-anchored:** the view setup, GUI widget layout and text scale are now found by instructions inside
  each function, with the function's start taken from the exe's own unwind table (.pdata), not from their first
  bytes. The camera update slot is recognised by its node and look-at reads. The same functions and offsets as
  before (checked against the 1.2.0.0 exe), and less dependent on how a compiler lays out a function's entry.

## 0.5.0-alpha

From the third in-game report (3D and resolution right; head aim, HUD scale and reconstruction depth not working):

- **Your settings are the defaults:** alternate eye, head aim always, HUD size 0.49, first-person offsets
  -0.69 / 0.25 / 0.41, panel distance 0.95, symmetric view off.
- **HUD scale works:** the game draws its HUD into its own texture, which the D3D12 hooks can't separate (the log:
  "UI layer not found" all session). The mod now scales the HUD inside the game's own widget layout (exe+2283F30, every
  widget's screen quad; the outermost result is moved onto the eye's line of sight and scaled, so each widget is scaled
  once) and the text scale (exe+22CB670, sharp text at the new size). UI scale, UI depth, UI height and Hide HUD all
  act there. Render-to-texture GUI and flat-screen menus are left alone.
- **Head aim reaches the aim:** the camera matrix was turned 500 times per 10 s, the sling did not follow - the aim
  is taken from the camera's position to its look-at target (+0x488). Head aim now turns that target too (the game's
  own is given back before the next camera update; first person keeps reading the game's). `head_aim_target`, on.
  The game's aim assist still snaps the aim to targets: turn it off for exact aim.
- **Stereo reconstruction finds the scene depth:** the depth candidate list held 8 buffers a frame and the game binds
  ~150 (shadow cascades, light maps, the prepass) - the scene depth was never in it. 64 slots, depth buffers of another
  shape than the picture are dropped at once, the busiest replace the least busy; the log lists the best candidates
  when none is chosen.
- **VR panel:** the status plate is smaller and fits beside the title (it overlapped the game's name).
- **Performance:** memory checks no longer use VirtualQuery (2.5 ms per call in the 0.4 log, some on the game's own
  threads - stalls): a one-byte probe per page through ReadProcessMemory on the mod's own process. The viewport tally
  reads each viewport's slot once per frame (0.15-0.34 ms per Present before).
- **Version agnostic:** the camera's FOV / near / far offsets are now read from the code too (they were the last assumed
  struct offsets in the camera path). `tools/verify_signatures.py` checks the GUI layout, text scale and those offsets.

## 0.4.0-alpha

From the second in-game report (3D works but needs swap eyes, resolution / shape wrong, tracking hitches):

- **Eyes swapped, hitches in head turns - one cause.** The engine draws on a render thread one frame behind the
  frame being set up ("RenderThreadDraw"), so a Present shows the frame set up one Present earlier. The mod paired
  every picture with the newest camera: in alternate eye / synchronized each eye's picture was labelled as the other
  eye (swap_eyes only hid it), and in every method the compositor got the next frame's head pose for each picture (a
  hitch whenever the head turns). `aer_frame_delay` is now 1 (config_version 11 moves 0 -> 1 and swap_eyes back off).
- **Resolution and shape follow the headset.** The game makes its 3D and every render target at its display
  object's render surface ([exe+39B07D8]+0x1D4/+0x1D8, found by the viewport-size code), not at the swap chain's size.
  The mod now sets the surface in the same ResizeBuffers call where it sets the swap chain, so the game renders at the
  headset's per-eye size and shape x render scale. `render_resolution = auto` is the default again (config_version 11
  moves `game` back to `auto`); if a build does not follow, the mod still notices and falls back by itself.
- **Stereo reconstruction finds the scene depth.** This engine draws its scene GPU-driven (ExecuteIndirect) with a
  depth prepass that binds no colour target; depth-only passes now count. The log reports depth binds per 10 s.
- **Frame cap at the headset's refresh by default** (`fps_unlocked = false`): uncapped frames went late and stuttered.
- **VR panel restyled for the game:** translucent black, old gold and blood red, sharp chamfered plates, diamond
  ornaments, gold-leaf serif title (A PLAGUE TALE / RESONANCE + a red VR crest), rising embers, a "codex" help box,
  Palatino Linotype from Windows (your own `ResonanceVR\vrkit_font.ttf` / `vrkit_title_font.ttf` still win).

## 0.3.1-alpha

- **Intro logos skipped, built in** (`skip_intro`, default on; VR panel > Display > Skip intro logos). The game has its
  own developer switch: with `-FastLaunch` on the command line it sets the script variable `SKIP_LOGOS`
  (exe+136A2DC). The mod forces that test at start - no separate no-intro mod or ASI loader needed. Found by the code
  shape and checked against both strings; a build without it is left alone (the log says so).

## 0.3.0-alpha

Fixes the first in-game report: no 3D and no head tracking in any stereo method.

- **Head tracking went into the wrong viewport.** The main view was picked by size, and a viewport the size of the
  back buffer that is drawn about three times a second won on the first frame and was never replaced. The mod now
  takes the player's view from the renderer itself: its viewport table (renderer+0xB20, slot 0 - the only viewport
  that gets the camera update and the FOV tangents in the engine's own loop). Without the table the fallback prefers
  slot 0, then draw count, then size. The log lists every viewport each 10 s (slot, size, draws, which one is MAIN).
- **The game's 3D was drawn into a corner of the eye image.** This engine draws its 3D at its own resolution setting
  (the display object's render surface), not at the swap chain's size. The mod forced the swap chain to the headset
  size (4440x2722), the game kept drawing 3840x2160 into it: the eye cut, the scene depth (stereo reconstruction found
  none - its shape was 16:9) and the UI layer were all measured against the wrong picture. render_resolution is now
  game by default (config_version 10 moves an existing `auto` to `game`); with auto the mod checks the player's view
  against the back buffer and goes back to the game's size by itself when they differ.
- **HUD:** the exe has a NanoVG GUI renderer, but nothing ever creates one - the 0.2 engine-side HUD placement never
  ran. The log now says so and the D3D12 hooks place the UI (they could not before: the UI too was drawn at the game's
  size, not the back buffer's).
- Log: the frame clock's pause flag address printed with a doubled `+`.

## 0.2.0-alpha

- HUD in the engine: the game's NanoVG GUI is placed per eye with its own 2D transform (on your line of sight,
  converged at UI depth, at UI scale; sharp text). The D3D12 placement stands aside while it acts and stays as a
  fallback (HUD > UI placed by). The reconstruction's UI split finds the UI where it always did.
- Hide the HUD (F7, HUD page) - gameplay HUD only, menus keep theirs.
- The game gets its own camera back after each eye is set up (keep_game_camera): camera behaviours, movement and audio
  never see the head pose - no drift or spin from accumulation. Head aim still turns the aim.
- Render settings read from the renderer: anti-aliasing (FXAA / DLAA / TAA / DLSS / DLSS RR / FSR / PSSR), DLSS / FSR
  mode, frame generation, scaling. Setup check: frame generation is a problem; a temporal AA in synchronized /
  alternate eye is named. Panel status line shows DLSS / FSR.
- Log: GUI frames placed / hidden / not VR / render-to-texture, other viewports drawing from the main camera, camera
  given back, render settings on change.
- Verified offline: every new signature and offset on the 1.2.0.0 exe; the GUI placement maths (unit test).

## 0.1.0-alpha (first build)

First version for Resonance: A Plague Tale Legacy (game version 1.2.0.0), on mark-mon's VR framework (in-process
XrBridge OpenXR host, vrkit VR panel, proxy loader) and its D3D12 compositor.

- Engine layer for Asobo's Zouna engine, store / version agnostic: every function found by a wildcarded pattern,
  every struct offset read from the code that uses it, nothing hard-coded (NOTES.md, `tools/verify_signatures.py`).
- Head and position tracking on the game's render camera (Viewport_Z::SetupView), the headset's frustum in the
  projection getter (all 23 consumers), wide culling through the engine's FOV tangents.
- 3D methods: stereo reconstruction (default), synchronized (the engine's frame clock held for the second eye,
  1/32 kept, given back on the next tick), alternate eye, head-tracked mono, flat screen.
- No black bars: the engine's picture-shape clamp (1.6 .. 2.33) kept open in VR - a VR eye would be letterboxed.
- Full speed without focus: the game's out-of-focus frame limiter kept off.
- Post effects that do not fit a stereo picture: lens distortion, chromatic fringe, vignette off by default; film
  grain, lens dirt, lens flare optional.
- First person at the camera's look-at target, head aim (off by default), decoupled pitch, shake filter, idle-sway
  lock, flat screen for pause menus (judged on the game's own camera and pause flag).
- Setup check, diagnostics (run header, previous logs, system, config diff, crash report, HEALTH, USER MARK, report
  folder), all from the framework; plus: an external FOV / ultrawide patcher is detected (the gameplay FOV load
  patched).

Verified: builds; every signature and offset on the 1.2.0.0 exe; the camera maths (unit test). Not verified: anything
in the running game or in a headset - the first log is needed (NOTES.md section 9).
